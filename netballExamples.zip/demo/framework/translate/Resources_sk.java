package	demo.framework.translate;

import java.util.ListResourceBundle;

public class Resources_sk extends ListResourceBundle {

	public Object[][] getContents() {
 	   return CONTENTS;
	}

	private static final Object[][] CONTENTS = {
		{ResourceConstants.TYP_FAKUTRY , "Typ faktury"}, /*Typ faktury*/
		{ResourceConstants.NEMATE_PRAVA_NA_VYSTAVENIE_A_EDITOVANIE_ZAZNAMOV__, "Nemate prava na vystavenie a editovanie zaznamov !"}, /*Nemate prava na vystavenie a editovanie zaznamov !*/
		{ResourceConstants.NIE_JE_DEFINOVANY_TYP_FAKTURY__PRETO_NIE_JE_MOZNE_OVERIT__CI_MOZEDE_MODIFIKOVAT_FAKURY_, "Nie je definovany typ faktury, preto nie je mozne overit, ci mozede modifikovat fakury."}, /*Nie je definovany typ faktury, preto nie je mozne overit, ci mozede modifikovat fakury.*/
		{ResourceConstants.NEMATE_PRAVO_MODIFIKOVAT_TYPU_FAKTURY___0___, "Nemate pravo modifikovat typu faktury [{0}]."}, /*Nemate pravo modifikovat typu faktury [{0}].*/
		{ResourceConstants.V_EVIDENCII__0__SA_NENACHADZA_ZAZNAM_S_HODNOTOU___1___, "V evidencii {0} sa nenachadza zaznam s hodnotou [{1}]."}, /*V evidencii {0} sa nenachadza zaznam s hodnotou [{1}].*/
		{ResourceConstants.ICO, "Ico"}, /*Ico*/
		{ResourceConstants.ICO_ZAKAZNIKA, "Ico zakaznika"}, /*Ico zakaznika*/
		{ResourceConstants.NAZOV, "Nazov"}, /*Nazov*/
		{ResourceConstants.NAZOV_ZAKAZNIKA, "Nazov zakaznika"}, /*Nazov zakaznika*/
		{ResourceConstants.ADRESA, "Adresa"}, /*Adresa*/
		{ResourceConstants.ADRESA_ZAKAZNIKA, "Adresa zakaznika"}, /*Adresa zakaznika*/
		{ResourceConstants.JE_ZAHRANICNY, "Je zahranicny"}, /*Je zahranicny*/
		{ResourceConstants.V_CISELNIKU_SA_UZ_NACHADZA_ZAZNAM_S_ICOM___0___, "V ciselniku sa uz nachadza zaznam s icom [{0}]."}, /*V ciselniku sa uz nachadza zaznam s icom [{0}].*/
		{ResourceConstants.KOD, "Kod"}, /*Kod*/
		{ResourceConstants.ZAKAZKA, "Zakazka"}, /*Zakazka*/
		{ResourceConstants.NAZOV_ZAKAZKY, "Nazov zakazky"}, /*Nazov zakazky*/
		{ResourceConstants.NIE_JE_MOZNE_VYMAZAT_ZAKAZKU__PRETOZE_SA_NACHADZA_V_NASLEDUJUCICH_FAKTURACH_, "Nie je mozne vymazat zakazku, pretoze sa nachadza v nasledujucich fakturach:"}, /*Nie je mozne vymazat zakazku, pretoze sa nachadza v nasledujucich fakturach:*/
		{ResourceConstants.V_CISELNIKU_SA_UZ_NACHADZA_ZAZNAM_S_KODOM___0___, "V ciselniku sa uz nachadza zaznam s kodom [{0}]."}, /*V ciselniku sa uz nachadza zaznam s kodom [{0}].*/
		{ResourceConstants.MENA, "Mena"}, /*Mena*/
		{ResourceConstants.NAZOV_MENY, "Nazov meny"}, /*Nazov meny*/
		{ResourceConstants.NIE_JE_MOZNE_VYMAZAT_MENU__PRETOZE_SA_NACHADZA_V_NASLEDUJUCICH_FAKTURACH_, "Nie je mozne vymazat menu, pretoze sa nachadza v nasledujucich fakturach:"}, /*Nie je mozne vymazat menu, pretoze sa nachadza v nasledujucich fakturach:*/
		{ResourceConstants.SUMA, "Suma"}, /*Suma*/
		{ResourceConstants.DATUM_VYSTAVENIE, "Datum vystavenia"}, /*Datum vystavenie*/
		{ResourceConstants.DATUM__VYSTAVENIE, "Datum\nvystavenia"}, /*Datum\nvystavenie*/
		{ResourceConstants.CELKOVA_SUMA, "Celkova suma"}, /*Celkova suma*/
		{ResourceConstants.CELKOVA_SUMA_MENA, "Celkova suma mena"}, /*Celkova suma mena*/
		{ResourceConstants.ZAKAZNIK, "Zakaznik"}, /*Zakaznik*/
		{ResourceConstants.UCTOVNE_OBDOBIE, "Uctovne obdobie"}, /*Uctovne obdobie*/
		{ResourceConstants.UCTOVNE__OBDOBIE, "Uctovne\nobdobie"}, /*Uctovne\nobdobie*/
		{ResourceConstants.STAV, "Stav"}, /*Stav*/
		{ResourceConstants.POLOZKY, "Polozky"}, /*Polozky*/
		{ResourceConstants.VERZIA, "Verzia"}, /*Verzia*/
		{ResourceConstants.TYP, "Typ"}, /*Typ*/
		{ResourceConstants.CISLO, "Cislo"}, /*Cislo*/
		{ResourceConstants.FAKTURA, "Faktura"}, /*Faktura*/
		{ResourceConstants.SPRACOVANU_FAKTURU_NIE_JE_MOZNE_VYMAZAT_, "Spracovanu fakturu nie je mozne vymazat."}, /*Spracovanu fakturu nie je mozne vymazat.*/
		{ResourceConstants.LEN_ROZPRACOVANA_FAKTURA_MOZE_BYT_SPRACOVANA_, "Len rozpracovana faktura moze byt spracovana."}, /*Len rozpracovana faktura moze byt spracovana.*/
		{ResourceConstants.LEN_SPRACOVANA_FAKTURA_MOZE_BYT_STORNOVANA_, "Len spracovana faktura moze byt stornovana."}, /*Len spracovana faktura moze byt stornovana.*/
		{ResourceConstants.FAKTURA_S_CISLOM___0___UZ_EXISTUJE_, "Faktura s cislom [{0}] uz existuje."}, /*Faktura s cislom [{0}] uz existuje.*/
		{ResourceConstants.ZAKAZKA__0__VO_FAKTURE_SA_VYSKYTUJE_VIACKRAT_, "Zakazka {0} vo fakture sa vyskytuje viackrat."}, /*Zakazka {0} vo fakture sa vyskytuje viackrat.*/
		{ResourceConstants.MNOZSTVO, "Mnozstvo"}, /*Mnozstvo*/
		{ResourceConstants.JEDNOTKOVA_CENA, "Jednotkova cena"}, /*Jednotkova cena*/
		{ResourceConstants.JEDNOTKOVA__CENA, "Jednotkova\ncena"}, /*Jednotkova\ncena*/
		{ResourceConstants.CELKOVA_CENA, "Celkova cena"}, /*Celkova cena*/
		{ResourceConstants.MARNA_JEDNOTKA, "Marna jednotka"}, /*Marna jednotka*/
		{ResourceConstants.MARNA__JEDNOTKA, "Marna\njednotka"}, /*Marna\njednotka*/
		{ResourceConstants.NAZOV_TOVARU, "Nazov tovaru"}, /*Nazov tovaru*/
		{ResourceConstants.OBMEDZENIE, "Obmedzenie"}, /*Obmedzenie*/
		{ResourceConstants.MENY, "Meny"}, /*Meny*/
		{ResourceConstants.FAKTURY, "Faktury"}, /*Faktury*/
		{ResourceConstants.ZAKAZKY, "Zakazky"}, /*Zakazky*/
		{ResourceConstants.SKUTOCNE_SI_PRAJETE_VYMAZAT_ZAZNAM_, "Skutocne si prajete vymazat zaznam?"}, /*Skutocne si prajete vymazat zaznam?*/
		{ResourceConstants.SKUTOCNE_SI_PRAJETE_NASTAVIT_ZAZNAM_NA_SPRACOVANY_, "Skutocne si prajete nastavit zaznam na spracovany?"}, /*Skutocne si prajete nastavit zaznam na spracovany?*/
		{ResourceConstants.SKUTOCNE_SI_PRAJETE_STORNOVAT_ZAZNAM_, "Skutocne si prajete stornovat zaznam?"}, /*Skutocne si prajete stornovat zaznam?*/
		{ResourceConstants.UMOZNUJE_ZMENIT_STAV_DOKLADU_, "Umoznuje zmenit stav dokladu."}, /*Umoznuje zmenit stav dokladu.*/
		{ResourceConstants.DETAIL, "Detail"}, /*Detail*/
		{ResourceConstants.UMOZNUJE_ZOBRAZIT_DETAIL_ZAZNAMU_, "Umoznuje zobrazit detail zaznamu."}, /*Umoznuje zobrazit detail zaznamu.*/
		{ResourceConstants.TLAC_DOKLADU, "Tlac dokladu"}, /*Tlac dokladu*/
		{ResourceConstants.UMOZNUJE_VYTLACIT_DOKLAD_, "Umoznuje vytlacit doklad."}, /*Umoznuje vytlacit doklad.*/
		{ResourceConstants.OBMEDZENIA, "Obmedzenia"}, /*Obmedzenia*/
		{ResourceConstants.UMOZNUJE_SPRAVOVAT_OBMEDZENIA_, "Umoznuje spravovat obmedzenia."}, /*Umoznuje spravovat obmedzenia.*/
		{ResourceConstants.ODBERATELSKE_FAKTURY, "Odberatelske faktury"}, /*Odberatelske faktury*/
		{ResourceConstants.DODAVATELSKE_FAKTURY, "Dodavatelske faktury"}, /*Dodavatelske faktury*/
		{ResourceConstants.CISELNIK, "Ciselnik"}, /*Ciselnik*/
		{ResourceConstants.ZAKAZNICI, "Zakaznici"}, /*Zakaznici*/
		{ResourceConstants.PREHLADY, "Prehlady"}, /*Prehlady*/
		{ResourceConstants.INE, "Ine"}, /*Ine*/
		{ResourceConstants.KLIENT_SERVER_PRENOS, "Klient server prenos"}, /*Klient server prenos*/
		{ResourceConstants.KLIENT_SERVER_PRENOS___CAKACIE_OKNO, "Klient server prenos + cakacie okno"}, /*Klient server prenos + cakacie okno*/
		{ResourceConstants.SERVER_KLIENT_PRENOS, "Server klient prenos"}, /*Server klient prenos*/
		{ResourceConstants.SERVER_KLIENT_PRENOS___CAKACIE_OKNO, "Server klient prenos + cakacie okno"}, /*Server klient prenos + cakacie okno*/
		{ResourceConstants.POUZITIE_PAGEBUFFER, "Pouzitie PageBuffer"}, /*Pouzitie PageBuffer*/
		{ResourceConstants.KOMPONENTY, "Komponenty"}, /*Komponenty*/
		{ResourceConstants.AUTORIZACIA, "Autorizacia"}, /*Autorizacia*/
		{ResourceConstants.POUZIVATELIA, "Pouzivatelia"}, /*Pouzivatelia*/
		{ResourceConstants.ROLE, "Role"}, /*Role*/
		{ResourceConstants.POUZIVATELIA_APLIKACIE, "Pouzivatelia aplikacie"}, /*Pouzivatelia aplikacie*/
		{ResourceConstants.AKCIE, "Akcie"}, /*Akcie*/
		{ResourceConstants.POUZIVATELIA_APLIKACIE_S_OBMEDZENIM_VERZIA_1, "Pouzivatelia aplikacie s obmedzenim verzia 1"}, /*Pouzivatelia aplikacie s obmedzenim verzia 1*/
		{ResourceConstants.POUZIVATELIA_APLIKACIE_S_OBMEDZENIM_VERZIA_2, "Pouzivatelia aplikacie s obmedzenim verzia 2"}, /*Pouzivatelia aplikacie s obmedzenim verzia 2*/
		{ResourceConstants.ZMENA_HESLA, "Zmena hesla"}, /*Zmena hesla*/
		{ResourceConstants.DEMO, "Demo"}, /*Demo*/
		{ResourceConstants.STRANA_, "Strana:"}, /*Strana:*/
		{ResourceConstants.NEPODARILO_SA_NACITAT_DATA_, "Nepodarilo sa nacitat data."}, /*Nepodarilo sa nacitat data.*/
		{ResourceConstants.OBDOBIE_MUSI_BYT_VYPLNENE_, "Obdobie musi byt vyplnene."}, /*Obdobie musi byt vyplnene.*/
		{ResourceConstants.ZOZMAM_SPRACOVANYCH_ODBERATELSKYCH_FAKTUR_PO_ZAKAZNIKOCH, "Zozmam spracovanych odberatelskych faktur po zakaznikoch"}, /*Zozmam spracovanych odberatelskych faktur po zakaznikoch*/
		{ResourceConstants.POUZITIE_IMPLEMENTS_REPORT_A_IMPLEMENTS_REPORTSOURCE, "Pouzitie implements Report a implements ReportSource"}, /*Pouzitie implements Report a implements ReportSource*/
		{ResourceConstants.ICO_, "Ico:"}, /*Ico:*/
		{ResourceConstants.CELKOM_, "CELKOM:"}, /*CELKOM:*/
		{ResourceConstants.ZP_INFORMATIKA, "ZP Informatika"}, /*ZP Informatika*/
		{ResourceConstants.CELKOM, "CELKOM"}, /*CELKOM*/
		{ResourceConstants.ZOZMAM_POLOZIEK_SPRACOVANYCH_ODBERATELSKYCH_FAKTUR, "Zozmam poloziek spracovanych odberatelskych faktur"}, /*Zozmam poloziek spracovanych odberatelskych faktur*/
		{ResourceConstants.POUZITIE_IMPLEMENTS_REPORT_IMPLEMENTS_A_VIEWCURSOR, "Pouzitie implements Report implements a ViewCursor"}, /*Pouzitie implements Report implements a ViewCursor*/
		{ResourceConstants.POUZITIE_IMPLEMENTS_REPORT_A_EXTENDS_BASICREPORTSOURCE, "Pouzitie implements Report a extends BasicReportSource"}, /*Pouzitie implements Report a extends BasicReportSource*/
		{ResourceConstants.NEPODARILO_SA_NACITAT_DOKLAD_S_ID_____0___, "Nepodarilo sa nacitat doklad s id = [{0}]."}, /*Nepodarilo sa nacitat doklad s id = [{0}].*/
		{ResourceConstants.P_C_, "P.c."}, /*P.c.*/
		{ResourceConstants.FAKTURA_, "Faktura:"}, /*Faktura:*/
		{ResourceConstants.VYSTAVIL_, "Vystavil:"}, /*Vystavil:*/
		{ResourceConstants.POLOZKY_FAKTURY, "Polozky faktury"}, /*Polozky faktury*/
		{ResourceConstants.POUZITIE_EXTENDS_USERREPORT, "Pouzitie extends UserReport"}, /*Pouzitie extends UserReport*/
		{ResourceConstants.POUZITIE_IMPLEMENTS_REPORT_A_IMPLEMENTS_GROUPCOLUMNSUMATOR, "Pouzitie implements Report a implements GroupColumnSumator"}, /*Pouzitie implements Report a implements GroupColumnSumator*/
		{ResourceConstants.SPOLU_, "SPOLU:"}, /*SPOLU:*/
		{ResourceConstants.POUZITIE_IMPLEMENTS_REPORT_A_IMPLEMENTS_GROUPSUMATOR, "Pouzitie implements Report a implements GroupSumator"}, /*Pouzitie implements Report a implements GroupSumator*/
		{ResourceConstants.DOLNY_POPIS_TEXT___VYTLACI_SA_ZA_POSLEDNOU_POLOZKOU_, "Dolny popis text,\nvytlaci sa za poslednou polozkou."}, /*Dolny popis text,\nvytlaci sa za poslednou polozkou.*/
		{ResourceConstants.PECIATKA_A_PODPIS, "Peciatka a podpis"}, /*Peciatka a podpis*/
		{ResourceConstants.TLAC_ODBERATELSKYCH_DOKLADOV, "Tlac odberatelskych dokladov"}, /*Tlac odberatelskych dokladov*/
		{ResourceConstants.UKAZKA_POUZITIA_PRINTPAGEDATASOURCE_AKO_REPORT, "Ukazka pouzitia PrintPageDataSource ako report"}, /*Ukazka pouzitia PrintPageDataSource ako report*/
		{ResourceConstants.NEPODARILO_SA_NACITAT_ZAZNAMY_PRE_TLAC_, "Nepodarilo sa nacitat zaznamy pre tlac."}, /*Nepodarilo sa nacitat zaznamy pre tlac.*/
		{ResourceConstants.TLACOVE_ZOSTAVY, "Tlacove zostavy"}, /*Tlacove zostavy*/
		{ResourceConstants.POUZITIE_IMPLEMENTS_REPORT, "Pouzitie implements Report"}, /*Pouzitie implements Report*/
		{ResourceConstants.POLOZKA_FAKTURY, "Polozka faktury"}, /*Polozka faktury*/
		{ResourceConstants.ZAKL__UDAJE, "Zakl. udaje"}, /*Zakl. udaje*/
		{ResourceConstants.ODBERATELSKA_FAKTURA, "Odberatelska faktura"}, /*Odberatelska faktura*/
		{ResourceConstants.DODAVATELSKA_FAKTURA, "Dodavatelska faktura"}, /*Dodavatelska faktura*/
	};
}
