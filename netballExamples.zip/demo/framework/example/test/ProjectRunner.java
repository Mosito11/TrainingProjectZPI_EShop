package demo.framework.example.test;


import javax.swing.UIManager;

import org.eclipse.persistence.zpi.sessions.DatabaseSession;

import demo.framework.example.mapping.Projekt;
import demo.framework.example.mapping.VyvojLogin;
import demo.framework.example.su.common.DemoApplication;
import demo.framework.example.su.fakturacia.md.MDViewOdberatelskaFakturaClientServerTable;
import netball.client.ui.jtc.awt.lookandfeel.flat.FlatLookAndFeel;
import zelpo.eclipselink.common.ZPMediatorRunner;

public class ProjectRunner { 
	
	public static void main(String...strings) {
		UIManager.put(FlatLookAndFeel.COLOR_SET, 1);
		//StateManager.WRITE_FORM_STATE = false;
		//StateManager.WRITE_FORM_STATE = true;
		//UIManager.put(MetalLookAndFeelNew.DEFAULT_FONT, new Font("Dialog", Font.PLAIN, 25));
		   try {
				//UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
			   //UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
			   
			    //UIManager.LookAndFeelInfo[] inst = UIManager.getInstalledLookAndFeels();
			    
			   //UIManager.put("Tree.drawsFocusBorderAroundIcon", true);
			   //UIManager.put("Tree.drawDashedFocusIndicator", false);
			   
			    System.out.println("Installed L&Fs: ");
			   /// for (int i=0;i<inst.length;i++) {
			      //System.out.println("  " + inst[i].getClassName());
			    //}

			} catch (Exception e) {
				e.printStackTrace();
			}
		   
		//InfraDebug.getInstance().addDebugLevel(InfraDebug.CIENT_ENGINE);
		//InfraDebug.getInstance().addDebugLevel(InfraDebug.SERVER_ENGINE);
		ZPMediatorRunner.Parameters prmts = new ZPMediatorRunner.Parameters();
	    prmts.application = new DemoApplication();
	    prmts.companyCode = "ZP";
	    prmts.userName = "tester";
	    prmts.lookAndFeel = ZPMediatorRunner.FLAT_LOOK_AND_FEEL;
	    //prmts.locale = Locale.GERMAN;
		Projekt projekt = new Projekt(new VyvojLogin().getLogin(null));
		//ZPMediatorRunner.run(MDDetailRola.class, new MDDetailRola.Parameters(1001087), projekt, prmts);
		//ZPMediatorRunner.run(PRFakturaPolozka.class, null, projekt, prmts);
		//ZPMediatorRunner.run(MDClientRemoteObject.class, null, projekt, prmts);
		//ZPMediatorRunner.run(MDViewAkcia.class, null, projekt, prmts);s
		//ZPMediatorRunner.run(MDViewRola.class, null, projekt, prmts);
		//ZPMediatorRunner.run(TestMediator.class, null, projekt, prmts);
		//ZPMediatorRunner.run(MDViewOdberatelskaFakturaClientServerTable.class, null, projekt, prmts);
		//ZPMediatorRunner.run(MDViewDodavatelskaFaktura.class, null, projekt, prmts);
		//ZPMediatorRunner.run(MDMainMenu.class, null, projekt, prmts);
		//ZPMediatorRunner.run(MDFontSelection.class, null, projekt, prmts);
		//ZPMediatorRunner.run(MDClientRemoteObject.class, null, projekt, prmts);
		//ZPMediatorRunner.run(MDViewDodavatelskaFaktura.class, null, projekt, prmts);
		ZPMediatorRunner.run(MDViewOdberatelskaFakturaClientServerTable.class, null, projekt, prmts);

	       DatabaseSession session = projekt.createDatabaseSession();
	       //session.setLog(new java.io.FileWriter("TopLink.log"));
	       session.setLogLevel(2);
	       System.out.println(session);
		
	}
}
