package demo.framework.example.test;

import org.eclipse.persistence.zpi.expressions.Expression;
import org.eclipse.persistence.zpi.expressions.ExpressionBuilder;
import org.eclipse.persistence.zpi.sessions.DatabaseSession;
import org.eclipse.persistence.zpi.sessions.UnitOfWork;

import demo.framework.example.bo.ciselniky.Mena;
import demo.framework.example.mapping.Projekt;
import demo.framework.example.mapping.VyvojLogin;
import netframework.eclipselink.EclipseLinkSession;
import netframework.eclipselink.SequenceNumberCreator;
import netframework.mediator.LanguageTranslator;
import zelpo.eclipselink.autorizacia.Uzivatel;

public class Test {

	public static void main(String...strings) {
		try {
			Projekt project = new Projekt(new VyvojLogin().getLogin(null));
			EclipseLinkSession session = new EclipseLinkSession();
		    session.setSession(project.createDatabaseSession());
		    ((DatabaseSession) session.getSession()).login();
		    session.getSession().setLog(new java.io.FileWriter("TopLink.log"));
		    session.getSession().setLogLevel(2);
		    session.setTranslator(new LanguageTranslator(new String[] {zelpo.eclipselink.translate.Resources.class.getName(), demo.framework.translate.Resources.class.getName()}));
		    session.setUser(readUzivatel(session));
		}catch(Exception e) {
			e.printStackTrace();
		}

	}
	
	public static void insertMena(EclipseLinkSession session) {
		try {
			Mena mena = new Mena();
			mena.setKod("XCV");
			mena.setNazov("Mena nejaka");
			mena.validate(session);
			UnitOfWork work = session.getSession().acquireUnitOfWork();
			work.registerNewObject(mena);
			work.commit();
		}catch(Exception e) {
			e.printStackTrace();
		}
	} 
	
	public static Uzivatel readUzivatel(EclipseLinkSession session) {
		ExpressionBuilder builder = new ExpressionBuilder();
		Expression exp = builder.get(Uzivatel.UZIVATELSKE_MENO.getName()).equal("tester");
		Uzivatel uzivatel = (Uzivatel) session.getSession().readObject(Uzivatel.class, exp);
		return uzivatel;
	}
	
	public static void updeteSequenceNumbers(Projekt project) { 
		try {
			new SequenceNumberCreator(project).execute(); 
		}catch(Exception e) {
			e.printStackTrace();
		} 
	}
}
