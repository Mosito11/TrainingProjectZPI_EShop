package demo.framework.example.mapping;

import java.util.Iterator;

import org.eclipse.persistence.zpi.descriptors.ClassDescriptor;
import org.eclipse.persistence.zpi.descriptors.VersionLockingPolicy;
import org.eclipse.persistence.zpi.mappings.AggregateObjectMapping;
import org.eclipse.persistence.zpi.mappings.DirectToFieldMapping;
import org.eclipse.persistence.zpi.mappings.ManyToManyMapping;
import org.eclipse.persistence.zpi.mappings.OneToManyMapping;
import org.eclipse.persistence.zpi.mappings.OneToOneMapping;
import org.eclipse.persistence.zpi.sessions.DatabaseLogin;
import org.eclipse.persistence.zpi.sessions.Project;

import demo.framework.example.bo.ciselniky.Mena;
import demo.framework.example.bo.ciselniky.Zakazka;
import demo.framework.example.bo.ciselniky.Zakaznik;
import demo.framework.example.bo.fakturacia.DodavatelskaFaktura;
import demo.framework.example.bo.fakturacia.Faktura;
import demo.framework.example.bo.fakturacia.FakturaPolozka;
import demo.framework.example.bo.fakturacia.OdberatelskaFaktura;
import demo.framework.example.bo.fakturacia.SumaVMene;
import demo.framework.example.bo.fakturacia.TypFaktury;
import demo.framework.example.bo.uzol.Uzol;
import zelpo.eclipselink.autorizacia.project.AutorizaciaProjekt;


public class Projekt1 extends Project {

	public static final String APPLICATION_NAME = "skolenie";

	public Projekt1(DatabaseLogin login) {
		setName(APPLICATION_NAME);
		setLogin(login);
		addDescriptors();
		setForAllDescriptors();
		new AutorizaciaProjekt(this);
	}
	
	public void addDescriptors() {
		this.addDescriptor(buildMenaDescriptor());
		this.addDescriptor(buildZakazkaDescriptor());
		this.addDescriptor(buildZakaznikDescriptor());
		this.addDescriptor(buildSumaVMeneDescriptor());
		this.addDescriptor(buildFakturaDescriptor());
		this.addDescriptor(buildOdberatelskaFakturaDescriptor());
		this.addDescriptor(buildDodavatelskaFakturaDescriptor());
		this.addDescriptor(buildFakturaPolozkaDescriptor());
		this.addDescriptor(buildUzolDescriptor());
	}
	
	private void setForAllDescriptors() {
		Iterator<ClassDescriptor> iterator = this.getDescriptors().values().iterator();
		while (iterator.hasNext()) {
			ClassDescriptor descriptor = iterator.next();
            // Predpoklada sa, ze ak primarny kluc nie je null, tak potom musi existovat.
		    // Nerobi sa kontrola, ci existuje taky objekt. => zvysi sa vykonost 
			descriptor.getQueryManager().assumeExistenceForDoesExist();
		    // vypnutie cache
		    descriptor.useNoIdentityMap();       
		    descriptor.setIdentityMapSize(0);
		}
	}
	
	public ClassDescriptor buildMenaDescriptor(){
		ClassDescriptor descriptor = new ClassDescriptor();
	    descriptor.setJavaClass(Mena.class);
	    descriptor.addTableName("MENA");
	    descriptor.addPrimaryKeyFieldName("ID");
	    
	    // ClassDescriptor properties.
	    descriptor.setSequenceNumberFieldName("ID");
	    descriptor.setSequenceNumberName("MENA");
	    
	    // Mappings.
	    DirectToFieldMapping idMapping = new DirectToFieldMapping();
	    idMapping.setAttributeName("id");
	    idMapping.setFieldName("ID");
	    descriptor.addMapping(idMapping);
	    
	    DirectToFieldMapping kodMapping = new DirectToFieldMapping();
	    kodMapping.setAttributeName("kod");
	    kodMapping.setFieldName("KOD");
	    descriptor.addMapping(kodMapping);	    
	    
	    DirectToFieldMapping nazovMapping = new DirectToFieldMapping();
	    nazovMapping.setAttributeName("nazov");
	    nazovMapping.setFieldName("NAZOV");
	    descriptor.addMapping(nazovMapping);
	    
		return descriptor;
	}
	
	public ClassDescriptor buildZakazkaDescriptor(){
		ClassDescriptor descriptor = new ClassDescriptor();
	    descriptor.setJavaClass(Zakazka.class);
	    descriptor.addTableName("ZAKAZKA_");
	    descriptor.addPrimaryKeyFieldName("ID");
	    
	    // ClassDescriptor properties.
	    descriptor.setSequenceNumberFieldName("ID");
	    descriptor.setSequenceNumberName("ZAKAZKA");
	    
	    // Mappings.
	    DirectToFieldMapping idMapping = new DirectToFieldMapping();
	    idMapping.setAttributeName("id");
	    idMapping.setFieldName("ID");
	    descriptor.addMapping(idMapping);
	    
	    DirectToFieldMapping cisloMapping = new DirectToFieldMapping();
	    cisloMapping.setAttributeName("cislo");
	    cisloMapping.setFieldName("CISLO");
	    descriptor.addMapping(cisloMapping);	    
	    
	    DirectToFieldMapping nazovMapping = new DirectToFieldMapping();
	    nazovMapping.setAttributeName("nazov");
	    nazovMapping.setFieldName("NAZOV");
	    descriptor.addMapping(nazovMapping);
	    
		return descriptor;
	}	
	
	public ClassDescriptor buildZakaznikDescriptor(){
		ClassDescriptor descriptor = new ClassDescriptor();
	    descriptor.setJavaClass(Zakaznik.class);
	    descriptor.addTableName("ZAKAZNIK");
	    descriptor.addPrimaryKeyFieldName("ID");
	    
	    // ClassDescriptor properties.
	    descriptor.setSequenceNumberFieldName("ID");
	    descriptor.setSequenceNumberName("ZAKAZNIK");
	    
	    // Mappings.
	    DirectToFieldMapping idMapping = new DirectToFieldMapping();
	    idMapping.setAttributeName("id");
	    idMapping.setFieldName("ID");
	    descriptor.addMapping(idMapping);
	    
	    DirectToFieldMapping icoMapping = new DirectToFieldMapping();
	    icoMapping.setAttributeName("ico");
	    icoMapping.setFieldName("ICO");
	    descriptor.addMapping(icoMapping);
	    
	    DirectToFieldMapping nazovMapping = new DirectToFieldMapping();
	    nazovMapping.setAttributeName("nazov");
	    nazovMapping.setFieldName("NAZOV");
	    descriptor.addMapping(nazovMapping);
	    
	    DirectToFieldMapping adresaMapping = new DirectToFieldMapping();
	    adresaMapping.setAttributeName("adresa");
	    adresaMapping.setFieldName("ADRESA");
	    descriptor.addMapping(adresaMapping);
	    
	    DirectToFieldMapping jeZahranicnyMapping = new DirectToFieldMapping();
	    jeZahranicnyMapping.setAttributeName("jeZahranicny");
	    jeZahranicnyMapping.setFieldName("JE_ZAHRANICNY");
	    descriptor.addMapping(jeZahranicnyMapping);
	    
		return descriptor;
	}
	
	public ClassDescriptor buildFakturaDescriptor(){
		ClassDescriptor descriptor = new ClassDescriptor();
	    descriptor.setJavaClass(Faktura.class);
	    descriptor.addTableName("FAKTURA");
	    descriptor.addPrimaryKeyFieldName("ID");
	    
	    // ClassDescriptor properties.
	    descriptor.setSequenceNumberFieldName("ID");
	    descriptor.setSequenceNumberName("FAKTURA");
	    
		// Inheritance properties.
		descriptor.getInheritancePolicy().setClassIndicatorFieldName("CLASS_ID");
		descriptor.getInheritancePolicy().addClassIndicator(OdberatelskaFaktura.class, TypFaktury.ODBERATELSKA.getKey());
		descriptor.getInheritancePolicy().addClassIndicator(DodavatelskaFaktura.class, TypFaktury.DOVATELSKA.getKey());
	    
		// locking
		VersionLockingPolicy lockingPolicy = new VersionLockingPolicy("VERSION");
		lockingPolicy.storeInObject();
		descriptor.setOptimisticLockingPolicy(lockingPolicy);
		
	    // Mappings.
	    DirectToFieldMapping idMapping = new DirectToFieldMapping();
	    idMapping.setAttributeName("id");
	    idMapping.setFieldName("ID");
	    descriptor.addMapping(idMapping);

	    DirectToFieldMapping typMapping = new DirectToFieldMapping();
	    typMapping.setAttributeName("typ");
	    typMapping.setFieldName("CLASS_ID");
	    typMapping.setGetMethodName("getTypTL");
	    typMapping.setSetMethodName("setTypTL");
	    descriptor.addMapping(typMapping);
//	    descriptor.setReadOnly();

	    DirectToFieldMapping versionMapping = new DirectToFieldMapping();
	    versionMapping.setAttributeName("version");
	    versionMapping.setFieldName("VERSION");
	    descriptor.addMapping(versionMapping);
	    
	    DirectToFieldMapping cisloMapping = new DirectToFieldMapping();
	    cisloMapping.setAttributeName("cislo");
	    cisloMapping.setFieldName("CISLO");
	    descriptor.addMapping(cisloMapping);
	    
	    DirectToFieldMapping datumVystaveniaMapping = new DirectToFieldMapping();
	    datumVystaveniaMapping.setAttributeName("datumVystavenia");
	    datumVystaveniaMapping.setFieldName("DATUM_VYSTAVENIA");
	    descriptor.addMapping(datumVystaveniaMapping);

	    DirectToFieldMapping obdobieMapping = new DirectToFieldMapping();
	    obdobieMapping.setAttributeName("obdobie");
	    obdobieMapping.setFieldName("OBDOBIE");
	    obdobieMapping.setGetMethodName("getObdobieTL");
	    obdobieMapping.setSetMethodName("setObdobieTL");
	    descriptor.addMapping(obdobieMapping);

	    DirectToFieldMapping stavMapping = new DirectToFieldMapping();
	    stavMapping.setAttributeName("stav");
	    stavMapping.setFieldName("STAV");
	    stavMapping.setGetMethodName("getStavTL");
	    stavMapping.setSetMethodName("setStavTL");
	    descriptor.addMapping(stavMapping);
	    
	    AggregateObjectMapping celkovaSumaMapping = new AggregateObjectMapping();
	    celkovaSumaMapping.setAttributeName("celkovaSuma");
	    celkovaSumaMapping.setReferenceClass(SumaVMene.class);
	    celkovaSumaMapping.setIsNullAllowed(true);
	    celkovaSumaMapping.addFieldNameTranslation("CELKOVA_CENA", "SUMA");
	    celkovaSumaMapping.addFieldNameTranslation("MENA_ID", "MENA");
		descriptor.addMapping(celkovaSumaMapping);
	    
	    OneToOneMapping zakaznikMapping = new OneToOneMapping();
	    zakaznikMapping.setAttributeName("zakaznik");
	    zakaznikMapping.setReferenceClass(Zakaznik.class);
	    zakaznikMapping.useBasicIndirection();
	    zakaznikMapping.addForeignKeyFieldName("ZAKAZNIK_ID", "ID");
		descriptor.addMapping(zakaznikMapping);
		
		OneToManyMapping polozkyMapping = new OneToManyMapping();
		polozkyMapping.setAttributeName("polozky");
		polozkyMapping.setReferenceClass(FakturaPolozka.class);
		polozkyMapping.useBasicIndirection();
		polozkyMapping.privateOwnedRelationship();
		polozkyMapping.addTargetForeignKeyFieldName("FAKTURA_ID", "ID");
		descriptor.addMapping(polozkyMapping);
		
	    return descriptor;
	}	
	
	public ClassDescriptor buildOdberatelskaFakturaDescriptor() {
		ClassDescriptor descriptor = new ClassDescriptor();
	    descriptor.setJavaClass(OdberatelskaFaktura.class);

		// Inheritance properties.
		descriptor.getInheritancePolicy().setParentClass(Faktura.class);

		// Mapping
		ManyToManyMapping zakazkyMapping = new ManyToManyMapping();
		zakazkyMapping.setAttributeName("zakazky");
		zakazkyMapping.setReferenceClass(Zakazka.class);
		zakazkyMapping.useBasicIndirection();
		zakazkyMapping.setRelationTableName("FAKTURA_ZAKAZKA");
		zakazkyMapping.setSourceRelationKeyFieldName("FAKTURA_ID");
		zakazkyMapping.setTargetRelationKeyFieldName("ZAKAZKA_ID");
		descriptor.addMapping(zakazkyMapping);
		
	    return descriptor;
	    
    }	

	public ClassDescriptor buildDodavatelskaFakturaDescriptor() {
		ClassDescriptor descriptor = new ClassDescriptor();
	    descriptor.setJavaClass(DodavatelskaFaktura.class);

		// Inheritance properties.
		descriptor.getInheritancePolicy().setParentClass(Faktura.class);
		
	    return descriptor;
    }	
	
	
	public ClassDescriptor buildSumaVMeneDescriptor() {
		ClassDescriptor descriptor = new ClassDescriptor();
		descriptor.descriptorIsAggregate();
		descriptor.setJavaClass(SumaVMene.class);
		
		// Mappings.
		DirectToFieldMapping sumaMapping = new DirectToFieldMapping();
		sumaMapping.setAttributeName("suma");
		sumaMapping.setFieldName("SUMA");
		descriptor.addMapping(sumaMapping);
		
		OneToOneMapping menaMapping = new OneToOneMapping();
		menaMapping.setAttributeName("mena");
		menaMapping.setReferenceClass(Mena.class);
		menaMapping.useBasicIndirection();
		menaMapping.addForeignKeyFieldName("MENA", "MENA.ID");
		descriptor.addMapping(menaMapping);
		
		return descriptor;
	}

	public ClassDescriptor buildFakturaPolozkaDescriptor(){
		ClassDescriptor descriptor = new ClassDescriptor();
	    descriptor.setJavaClass(FakturaPolozka.class);
	    descriptor.addTableName("FAKTURA_POLOZKA");
	    descriptor.addPrimaryKeyFieldName("ID");
	    
	    // ClassDescriptor properties.
	    descriptor.setSequenceNumberFieldName("ID");
	    descriptor.setSequenceNumberName("FAKTURA_POLOZKA");
	    
	    // Mappings.
	    DirectToFieldMapping idMapping = new DirectToFieldMapping();
	    idMapping.setAttributeName("id");
	    idMapping.setFieldName("ID");
	    descriptor.addMapping(idMapping);
	    
	    DirectToFieldMapping mnozstvoMapping = new DirectToFieldMapping();
	    mnozstvoMapping.setAttributeName("mnozstvo");
	    mnozstvoMapping.setFieldName("MNOZSTVO");
	    descriptor.addMapping(mnozstvoMapping);
	    
	    DirectToFieldMapping jednotkovaCenaMapping = new DirectToFieldMapping();
	    jednotkovaCenaMapping.setAttributeName("jednotkovaCena");
	    jednotkovaCenaMapping.setFieldName("JEDNOTKOVA_CENA");
	    descriptor.addMapping(jednotkovaCenaMapping);
	    
	    DirectToFieldMapping celkovaCenaMapping = new DirectToFieldMapping();
	    celkovaCenaMapping.setAttributeName("celkovaCena");
	    celkovaCenaMapping.setFieldName("CELKOVA_CENA");
	    descriptor.addMapping(celkovaCenaMapping);
	    
	    DirectToFieldMapping mernaJednotkaMapping = new DirectToFieldMapping();
	    mernaJednotkaMapping.setAttributeName("mernaJednotka");
	    mernaJednotkaMapping.setFieldName("MERNA_JEDNOTKA");
	    descriptor.addMapping(mernaJednotkaMapping);
	    
	    DirectToFieldMapping nazovMapping = new DirectToFieldMapping();
	    nazovMapping.setAttributeName("nazov");
	    nazovMapping.setFieldName("NAZOV");
	    descriptor.addMapping(nazovMapping);
	    
	    OneToOneMapping fakturaMapping = new OneToOneMapping();
	    fakturaMapping.setAttributeName("faktura");
	    fakturaMapping.setReferenceClass(Faktura.class);
	    fakturaMapping.useBasicIndirection();
	    fakturaMapping.addForeignKeyFieldName("FAKTURA_ID", "ID");
		descriptor.addMapping(fakturaMapping);
	    
	    return descriptor;
	}
	
	public ClassDescriptor buildUzolDescriptor(){
		ClassDescriptor descriptor = new ClassDescriptor();
	    descriptor.setJavaClass(Uzol.class);
	    descriptor.addTableName("UZOL");
	    descriptor.addPrimaryKeyFieldName("ID");
	    
	    // ClassDescriptor properties.
	    descriptor.setSequenceNumberFieldName("ID");
	    descriptor.setSequenceNumberName("UZOL");
	    
	    // Mappings.
	    DirectToFieldMapping idMapping = new DirectToFieldMapping();
	    idMapping.setAttributeName("id");
	    idMapping.setFieldName("ID");
	    descriptor.addMapping(idMapping);
	    
	    DirectToFieldMapping kodMapping = new DirectToFieldMapping();
	    kodMapping.setAttributeName("kod");
	    kodMapping.setFieldName("KOD");
	    descriptor.addMapping(kodMapping);	    
	    
	    DirectToFieldMapping nazovMapping = new DirectToFieldMapping();
	    nazovMapping.setAttributeName("nazov");
	    nazovMapping.setFieldName("NAZOV");
	    descriptor.addMapping(nazovMapping);

	    DirectToFieldMapping polozka1Mapping = new DirectToFieldMapping();
	    polozka1Mapping.setAttributeName("polozka1");
	    polozka1Mapping.setFieldName("POLOZKA1");
	    descriptor.addMapping(polozka1Mapping);

	    DirectToFieldMapping polozka2Mapping = new DirectToFieldMapping();
	    polozka2Mapping.setAttributeName("polozka2");
	    polozka2Mapping.setFieldName("POLOZKA2");
	    descriptor.addMapping(polozka2Mapping);

	    DirectToFieldMapping polozka3Mapping = new DirectToFieldMapping();
	    polozka3Mapping.setAttributeName("polozka3");
	    polozka3Mapping.setFieldName("POLOZKA3");
	    descriptor.addMapping(polozka3Mapping);

	    OneToOneMapping rodicMapping = new OneToOneMapping();
	    rodicMapping.setAttributeName("rodic");
	    rodicMapping.setReferenceClass(Uzol.class);
	    rodicMapping.useBasicIndirection();
	    rodicMapping.addForeignKeyFieldName("RODIC_ID", "ID");
		descriptor.addMapping(rodicMapping);
	    
	    return descriptor;
	}	
}
