package demo.framework.example.mapping;

import java.util.Iterator;

import org.eclipse.persistence.zpi.descriptors.ClassDescriptor;
import org.eclipse.persistence.zpi.descriptors.VersionLockingPolicy;
import org.eclipse.persistence.zpi.mappings.AggregateObjectMapping;
import org.eclipse.persistence.zpi.mappings.DirectToFieldMapping;
import org.eclipse.persistence.zpi.mappings.ManyToManyMapping;
import org.eclipse.persistence.zpi.mappings.OneToManyMapping;
import org.eclipse.persistence.zpi.mappings.OneToOneMapping;
import org.eclipse.persistence.zpi.sessions.DatabaseLogin;
import org.eclipse.persistence.zpi.sessions.Project;

import demo.framework.example.bo.ciselniky.Mena;
import demo.framework.example.bo.ciselniky.Zakazka;
import demo.framework.example.bo.ciselniky.Zakaznik;
import demo.framework.example.bo.fakturacia.DodavatelskaFaktura;
import demo.framework.example.bo.fakturacia.Faktura;
import demo.framework.example.bo.fakturacia.FakturaPolozka;
import demo.framework.example.bo.fakturacia.OdberatelskaFaktura;
import demo.framework.example.bo.fakturacia.SumaVMene;
import demo.framework.example.bo.fakturacia.TypFaktury;
import demo.framework.example.bo.uzol.Uzol;
import demo.framework.example.su.db.DBFaktura;
import demo.framework.example.su.db.DBFakturaPolozka;
import demo.framework.example.su.db.DBFakturaZakazka;
import demo.framework.example.su.db.DBMena;
import demo.framework.example.su.db.DBSkolenieCatalog;
import demo.framework.example.su.db.DBUzol;
import demo.framework.example.su.db.DBZakazka;
import demo.framework.example.su.db.DBZakaznik;
import zelpo.eclipselink.autorizacia.project.AutorizaciaProjekt;


public class Projekt extends Project {

	public static final String APPLICATION_NAME = "skolenie";

	public Projekt(DatabaseLogin login) {
		setName(APPLICATION_NAME);
		setLogin(login);
		addDescriptors();
		setForAllDescriptors();
		new AutorizaciaProjekt(this);
	}
	
	public void addDescriptors() {
		this.addDescriptor(buildMenaDescriptor());
		this.addDescriptor(buildZakazkaDescriptor());
		this.addDescriptor(buildZakaznikDescriptor());
		this.addDescriptor(buildSumaVMeneDescriptor());
		this.addDescriptor(buildFakturaDescriptor());
		this.addDescriptor(buildOdberatelskaFakturaDescriptor());
		this.addDescriptor(buildDodavatelskaFakturaDescriptor());
		this.addDescriptor(buildFakturaPolozkaDescriptor());
		this.addDescriptor(buildUzolDescriptor());
	}
	
	private void setForAllDescriptors() {
		Iterator<ClassDescriptor> iterator = this.getDescriptors().values().iterator();
		while (iterator.hasNext()) {
			ClassDescriptor descriptor = iterator.next();
            // Predpoklada sa, ze ak primarny kluc nie je null, tak potom musi existovat.
		    // Nerobi sa kontrola, ci existuje taky objekt. => zvysi sa vykonost 
			descriptor.getQueryManager().assumeExistenceForDoesExist();
		    // vypnutie cache
		    descriptor.useNoIdentityMap();       
		    descriptor.setIdentityMapSize(0);
		}
	}
	
	public ClassDescriptor buildMenaDescriptor(){
		ClassDescriptor descriptor = new ClassDescriptor();
	    descriptor.setJavaClass(Mena.class);
	    descriptor.addTableName(DBSkolenieCatalog.MENA.getTableName());
	    descriptor.addPrimaryKeyFieldName(DBMena.ID.getFieldName());
	    
	    // ClassDescriptor properties.
	    descriptor.setSequenceNumberFieldName(DBMena.ID.getFieldName());
	    descriptor.setSequenceNumberName(DBSkolenieCatalog.MENA.getTableName().toUpperCase());
	    
	    // Mappings.
	    DirectToFieldMapping idMapping = new DirectToFieldMapping();
	    idMapping.setAttributeName(Mena.ID.getName());
	    idMapping.setFieldName(DBMena.ID.getFieldName());
	    descriptor.addMapping(idMapping);
	    
	    DirectToFieldMapping kodMapping = new DirectToFieldMapping();
	    kodMapping.setAttributeName(Mena.KOD.getName());
	    kodMapping.setFieldName(DBMena.KOD.getFieldName());
	    descriptor.addMapping(kodMapping);	    
	    
	    DirectToFieldMapping nazovMapping = new DirectToFieldMapping();
	    nazovMapping.setAttributeName(Mena.NAZOV.getName());
	    nazovMapping.setFieldName(DBMena.NAZOV.getFieldName());
	    descriptor.addMapping(nazovMapping);
	    
		return descriptor;
	}
	
	public ClassDescriptor buildZakazkaDescriptor(){
		ClassDescriptor descriptor = new ClassDescriptor();
	    descriptor.setJavaClass(Zakazka.class);
	    descriptor.addTableName(DBSkolenieCatalog.ZAKAZKA.getTableName());
	    descriptor.addPrimaryKeyFieldName(DBZakazka.ID.getFieldName());
	    
	    // ClassDescriptor properties.
	    descriptor.setSequenceNumberFieldName(DBZakazka.ID.getFieldName());
	    descriptor.setSequenceNumberName(DBSkolenieCatalog.ZAKAZKA.getTableName().toUpperCase());
	    
	    // Mappings.
	    DirectToFieldMapping idMapping = new DirectToFieldMapping();
	    idMapping.setAttributeName(Zakazka.ID.getName());
	    idMapping.setFieldName(DBZakazka.ID.getFieldName());
	    descriptor.addMapping(idMapping);
	    
	    DirectToFieldMapping cisloMapping = new DirectToFieldMapping();
	    cisloMapping.setAttributeName(Zakazka.CISLO.getName());
	    cisloMapping.setFieldName(DBZakazka.CISLO.getFieldName());
	    descriptor.addMapping(cisloMapping);	    
	    
	    DirectToFieldMapping nazovMapping = new DirectToFieldMapping();
	    nazovMapping.setAttributeName(Zakazka.NAZOV.getName());
	    nazovMapping.setFieldName(DBZakazka.NAZOV.getFieldName());
	    descriptor.addMapping(nazovMapping);
	    
		return descriptor;
	}	
	
	public ClassDescriptor buildZakaznikDescriptor(){
		ClassDescriptor descriptor = new ClassDescriptor();
	    descriptor.setJavaClass(Zakaznik.class);
	    descriptor.addTableName(DBSkolenieCatalog.ZAKAZNIK.getTableName());
	    descriptor.addPrimaryKeyFieldName(DBZakazka.ID.getFieldName());
	    
	    // ClassDescriptor properties.
	    descriptor.setSequenceNumberFieldName(DBZakazka.ID.getFieldName());
	    descriptor.setSequenceNumberName(DBSkolenieCatalog.ZAKAZNIK.getTableName().toUpperCase());
	    
	    // Mappings.
	    DirectToFieldMapping idMapping = new DirectToFieldMapping();
	    idMapping.setAttributeName(Zakaznik.ID.getName());
	    idMapping.setFieldName(DBZakaznik.ID.getFieldName());
	    descriptor.addMapping(idMapping);
	    
	    DirectToFieldMapping icoMapping = new DirectToFieldMapping();
	    icoMapping.setAttributeName(Zakaznik.ICO.getName());
	    icoMapping.setFieldName(DBZakaznik.ICO.getFieldName());
	    descriptor.addMapping(icoMapping);
	    
	    DirectToFieldMapping nazovMapping = new DirectToFieldMapping();
	    nazovMapping.setAttributeName(Zakaznik.NAZOV.getName());
	    nazovMapping.setFieldName(DBZakaznik.NAZOV.getFieldName());
	    descriptor.addMapping(nazovMapping);
	    
	    DirectToFieldMapping adresaMapping = new DirectToFieldMapping();
	    adresaMapping.setAttributeName(Zakaznik.ADRESA.getName());
	    adresaMapping.setFieldName(DBZakaznik.ADRESA.getFieldName());
	    descriptor.addMapping(adresaMapping);
	    
	    DirectToFieldMapping jeZahranicnyMapping = new DirectToFieldMapping();
	    jeZahranicnyMapping.setAttributeName(Zakaznik.JE_ZAHRANICNA.getName());
	    jeZahranicnyMapping.setFieldName(DBZakaznik.JE_ZAHRANICNA.getFieldName());
	    descriptor.addMapping(jeZahranicnyMapping);
	    
		return descriptor;
	}
	
	public ClassDescriptor buildFakturaDescriptor(){
		ClassDescriptor descriptor = new ClassDescriptor();
	    descriptor.setJavaClass(Faktura.class);
	    descriptor.addTableName(DBSkolenieCatalog.FAKTURA.getTableName());
	    descriptor.addPrimaryKeyFieldName(DBFaktura.ID.getFieldName());
	    
	    // ClassDescriptor properties.
	    descriptor.setSequenceNumberFieldName(DBFaktura.ID.getFieldName());
	    descriptor.setSequenceNumberName(DBSkolenieCatalog.FAKTURA.getTableName().toUpperCase());
	    
		// Inheritance properties.
		descriptor.getInheritancePolicy().setClassIndicatorFieldName(DBFaktura.TYP.getFieldName());
		descriptor.getInheritancePolicy().addClassIndicator(OdberatelskaFaktura.class, TypFaktury.ODBERATELSKA.getKey());
		descriptor.getInheritancePolicy().addClassIndicator(DodavatelskaFaktura.class, TypFaktury.DOVATELSKA.getKey());
	    
		// locking
		VersionLockingPolicy lockingPolicy = new VersionLockingPolicy(DBFaktura.VERSION.getFieldName());
		lockingPolicy.storeInObject();
		descriptor.setOptimisticLockingPolicy(lockingPolicy);
		
	    // Mappings.
	    DirectToFieldMapping idMapping = new DirectToFieldMapping();
	    idMapping.setAttributeName(Faktura.ID.getName());
	    idMapping.setFieldName(DBFaktura.ID.getFieldName());
	    descriptor.addMapping(idMapping);

	    DirectToFieldMapping typMapping = new DirectToFieldMapping();
	    typMapping.setAttributeName(Faktura.TYP.getName());
	    typMapping.setFieldName(DBFaktura.TYP.getFieldName());
	    typMapping.setGetMethodName("getTypTL");
	    typMapping.setSetMethodName("setTypTL");
	    descriptor.addMapping(typMapping);
//	    descriptor.setReadOnly();

	    DirectToFieldMapping versionMapping = new DirectToFieldMapping();
	    versionMapping.setAttributeName(Faktura.VERSION.getName());
	    versionMapping.setFieldName(DBFaktura.VERSION.getFieldName());
	    descriptor.addMapping(versionMapping);
	    
	    DirectToFieldMapping cisloMapping = new DirectToFieldMapping();
	    cisloMapping.setAttributeName(Faktura.CISLO.getName());
	    cisloMapping.setFieldName(DBFaktura.CISLO.getFieldName());
	    descriptor.addMapping(cisloMapping);
	    
	    DirectToFieldMapping datumVystaveniaMapping = new DirectToFieldMapping();
	    datumVystaveniaMapping.setAttributeName(Faktura.DATUM_VYSTAVENIA.getName());
	    datumVystaveniaMapping.setFieldName(DBFaktura.DATUM_VYSTAVENIA.getFieldName());
	    descriptor.addMapping(datumVystaveniaMapping);

	    DirectToFieldMapping obdobieMapping = new DirectToFieldMapping();
	    obdobieMapping.setAttributeName(Faktura.OBDOBIE.getName());
	    obdobieMapping.setFieldName(DBFaktura.OBDOBIE.getFieldName());
	    obdobieMapping.setGetMethodName("getObdobieTL");
	    obdobieMapping.setSetMethodName("setObdobieTL");
	    descriptor.addMapping(obdobieMapping);

	    DirectToFieldMapping stavMapping = new DirectToFieldMapping();
	    stavMapping.setAttributeName(Faktura.STAV.getName());
	    stavMapping.setFieldName(DBFaktura.STAV.getFieldName());
	    stavMapping.setGetMethodName("getStavTL");
	    stavMapping.setSetMethodName("setStavTL");
	    descriptor.addMapping(stavMapping);
	    
	    AggregateObjectMapping celkovaSumaMapping = new AggregateObjectMapping();
	    celkovaSumaMapping.setAttributeName(Faktura.CELKOVA_SUMA.getName());
	    celkovaSumaMapping.setReferenceClass(SumaVMene.class);
	    celkovaSumaMapping.setIsNullAllowed(true);
	    celkovaSumaMapping.addFieldNameTranslation(DBFaktura.CELKOVA_SUMA.getFieldName(), "SUMA");
	    celkovaSumaMapping.addFieldNameTranslation(DBFaktura.MENA.getFieldName(), "MENA");
		descriptor.addMapping(celkovaSumaMapping);
	    
	    OneToOneMapping zakaznikMapping = new OneToOneMapping();
	    zakaznikMapping.setAttributeName(Faktura.ZAKAZNIK.getName());
	    zakaznikMapping.setReferenceClass(Zakaznik.class);
	    zakaznikMapping.useBasicIndirection();
	    zakaznikMapping.addForeignKeyFieldName(DBFaktura.ZAKAZNIK.getFieldName(), DBZakaznik.ID.getFieldName());
		descriptor.addMapping(zakaznikMapping);
		
		OneToManyMapping polozkyMapping = new OneToManyMapping();
		polozkyMapping.setAttributeName(Faktura.POLOZKY.getName());
		polozkyMapping.setReferenceClass(FakturaPolozka.class);
		polozkyMapping.useBasicIndirection();
		polozkyMapping.privateOwnedRelationship();
		polozkyMapping.addTargetForeignKeyFieldName(DBFakturaPolozka.FAKTURA.getFieldName(), DBFaktura.ID.getFieldName());
		descriptor.addMapping(polozkyMapping);
		
	    return descriptor;
	}	
	
	public ClassDescriptor buildOdberatelskaFakturaDescriptor() {
		ClassDescriptor descriptor = new ClassDescriptor();
	    descriptor.setJavaClass(OdberatelskaFaktura.class);

		// Inheritance properties.
		descriptor.getInheritancePolicy().setParentClass(Faktura.class);

		// Mapping
		ManyToManyMapping zakazkyMapping = new ManyToManyMapping();
		zakazkyMapping.setAttributeName(OdberatelskaFaktura.ZAKAZKY.getName());
		zakazkyMapping.setReferenceClass(Zakazka.class);
		zakazkyMapping.useBasicIndirection();
		zakazkyMapping.setRelationTableName(DBSkolenieCatalog.FAKTURA_ZAKAZKA.getTableName());
		zakazkyMapping.setSourceRelationKeyFieldName(DBFakturaZakazka.FAKTURA.getFieldName());
		zakazkyMapping.setTargetRelationKeyFieldName(DBFakturaZakazka.ZAKAZKA.getFieldName());
		descriptor.addMapping(zakazkyMapping);
		
	    return descriptor;
	    
    }	

	public ClassDescriptor buildDodavatelskaFakturaDescriptor() {
		ClassDescriptor descriptor = new ClassDescriptor();
	    descriptor.setJavaClass(DodavatelskaFaktura.class);

		// Inheritance properties.
		descriptor.getInheritancePolicy().setParentClass(Faktura.class);
		
	    return descriptor;
    }	
	
	
	public ClassDescriptor buildSumaVMeneDescriptor() {
		ClassDescriptor descriptor = new ClassDescriptor();
		descriptor.descriptorIsAggregate();
		descriptor.setJavaClass(SumaVMene.class);
		
		// Mappings.
		DirectToFieldMapping sumaMapping = new DirectToFieldMapping();
		sumaMapping.setAttributeName(SumaVMene.SUMA.getName());
		sumaMapping.setFieldName("SUMA");
		descriptor.addMapping(sumaMapping);
		
		OneToOneMapping menaMapping = new OneToOneMapping();
		menaMapping.setAttributeName(SumaVMene.MENA.getName());
		menaMapping.setReferenceClass(Mena.class);
		menaMapping.useBasicIndirection();
		menaMapping.addForeignKeyFieldName("MENA", DBMena.ID.getFieldName());
		descriptor.addMapping(menaMapping);
		
		return descriptor;
	}

	public ClassDescriptor buildFakturaPolozkaDescriptor(){
		ClassDescriptor descriptor = new ClassDescriptor();
	    descriptor.setJavaClass(FakturaPolozka.class);
	    descriptor.addTableName(DBSkolenieCatalog.FAKTURA_POLOZKA.getTableName());
	    descriptor.addPrimaryKeyFieldName(DBFakturaPolozka.ID.getFieldName());
	    
	    // ClassDescriptor properties.
	    descriptor.setSequenceNumberFieldName(DBFakturaPolozka.ID.getFieldName());
	    descriptor.setSequenceNumberName(DBSkolenieCatalog.FAKTURA_POLOZKA.getTableName().toUpperCase());
	    
	    // Mappings.
	    DirectToFieldMapping idMapping = new DirectToFieldMapping();
	    idMapping.setAttributeName(FakturaPolozka.ID.getName());
	    idMapping.setFieldName(DBFakturaPolozka.ID.getFieldName());
	    descriptor.addMapping(idMapping);
	    
	    DirectToFieldMapping mnozstvoMapping = new DirectToFieldMapping();
	    mnozstvoMapping.setAttributeName(FakturaPolozka.MNOZSTVO.getName());
	    mnozstvoMapping.setFieldName(DBFakturaPolozka.MNOZSTVO.getFieldName());
	    descriptor.addMapping(mnozstvoMapping);
	    
	    DirectToFieldMapping jednotkovaCenaMapping = new DirectToFieldMapping();
	    jednotkovaCenaMapping.setAttributeName(FakturaPolozka.JEDNOTKOVA_CENA.getName());
	    jednotkovaCenaMapping.setFieldName(DBFakturaPolozka.JEDNOTKOVA_CENA.getFieldName());
	    descriptor.addMapping(jednotkovaCenaMapping);
	    
	    DirectToFieldMapping celkovaCenaMapping = new DirectToFieldMapping();
	    celkovaCenaMapping.setAttributeName(FakturaPolozka.CELKOVA_CENA.getName());
	    celkovaCenaMapping.setFieldName(DBFakturaPolozka.CELKOVA_CENA.getFieldName());
	    descriptor.addMapping(celkovaCenaMapping);
	    
	    DirectToFieldMapping mernaJednotkaMapping = new DirectToFieldMapping();
	    mernaJednotkaMapping.setAttributeName(FakturaPolozka.MERNA_JEDNOTKA.getName());
	    mernaJednotkaMapping.setFieldName(DBFakturaPolozka.MERNA_JEDNOTKA.getFieldName());
	    descriptor.addMapping(mernaJednotkaMapping);
	    
	    DirectToFieldMapping nazovMapping = new DirectToFieldMapping();
	    nazovMapping.setAttributeName(FakturaPolozka.NAZOV.getName());
	    nazovMapping.setFieldName(DBFakturaPolozka.NAZOV.getFieldName());
	    descriptor.addMapping(nazovMapping);
	    
	    OneToOneMapping fakturaMapping = new OneToOneMapping();
	    fakturaMapping.setAttributeName(FakturaPolozka.FAKTURA.getName());
	    fakturaMapping.setReferenceClass(Faktura.class);
	    fakturaMapping.useBasicIndirection();
	    fakturaMapping.addForeignKeyFieldName(DBFakturaPolozka.FAKTURA.getFieldName(), DBFaktura.ID.getFieldName());
		descriptor.addMapping(fakturaMapping);
	    
	    return descriptor;
	}
	
	public ClassDescriptor buildUzolDescriptor(){
		ClassDescriptor descriptor = new ClassDescriptor();
	    descriptor.setJavaClass(Uzol.class);
	    descriptor.addTableName(DBSkolenieCatalog.UZOL.getTableName());
	    descriptor.addPrimaryKeyFieldName(DBUzol.ID.getFieldName());
	    
	    // ClassDescriptor properties.
	    descriptor.setSequenceNumberFieldName(DBUzol.ID.getFieldName());
	    descriptor.setSequenceNumberName(DBSkolenieCatalog.UZOL.getTableName().toUpperCase());
	    
	    // Mappings.
	    DirectToFieldMapping idMapping = new DirectToFieldMapping();
	    idMapping.setAttributeName(Uzol.ID.getName());
	    idMapping.setFieldName(DBUzol.ID.getFieldName());
	    descriptor.addMapping(idMapping);
	    
	    DirectToFieldMapping kodMapping = new DirectToFieldMapping();
	    kodMapping.setAttributeName(Uzol.KOD.getName());
	    kodMapping.setFieldName(DBUzol.KOD.getFieldName());
	    descriptor.addMapping(kodMapping);	    
	    
	    DirectToFieldMapping nazovMapping = new DirectToFieldMapping();
	    nazovMapping.setAttributeName(Uzol.NAZOV.getName());
	    nazovMapping.setFieldName(DBUzol.NAZOV.getFieldName());
	    descriptor.addMapping(nazovMapping);

	    DirectToFieldMapping polozka1Mapping = new DirectToFieldMapping();
	    polozka1Mapping.setAttributeName(Uzol.POLOZKA_1.getName());
	    polozka1Mapping.setFieldName(DBUzol.POLOZKA_1.getFieldName());
	    descriptor.addMapping(polozka1Mapping);

	    DirectToFieldMapping polozka2Mapping = new DirectToFieldMapping();
	    polozka2Mapping.setAttributeName(Uzol.POLOZKA_2.getName());
	    polozka2Mapping.setFieldName(DBUzol.POLOZKA_2.getFieldName());
	    descriptor.addMapping(polozka2Mapping);

	    DirectToFieldMapping polozka3Mapping = new DirectToFieldMapping();
	    polozka3Mapping.setAttributeName(Uzol.POLOZKA_3.getName());
	    polozka3Mapping.setFieldName(DBUzol.POLOZKA_3.getFieldName());
	    descriptor.addMapping(polozka3Mapping);

	    OneToOneMapping rodicMapping = new OneToOneMapping();
	    rodicMapping.setAttributeName(Uzol.RODIC.getName());
	    rodicMapping.setReferenceClass(Uzol.class);
	    rodicMapping.useBasicIndirection();
	    rodicMapping.addForeignKeyFieldName(DBUzol.RODIC.getFieldName(), DBUzol.ID.getFieldName());
		descriptor.addMapping(rodicMapping);
	    
	    return descriptor;
	}	
}
