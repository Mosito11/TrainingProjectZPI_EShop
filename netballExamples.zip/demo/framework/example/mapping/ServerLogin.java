package demo.framework.example.mapping;

import javax.naming.Context;
import javax.naming.InitialContext;

import netframework.eclipselink.EclipseLinkLogin;

import org.eclipse.persistence.zpi.platform.database.InformixPlatform;
import org.eclipse.persistence.zpi.sequencing.TableSequence;
import org.eclipse.persistence.zpi.sessions.DatabaseLogin;
import org.eclipse.persistence.zpi.sessions.JNDIConnector;

public class ServerLogin implements EclipseLinkLogin {
    
	@Override
	public DatabaseLogin getLogin(String sourceName) {
	    DatabaseLogin login = new DatabaseLogin();
	    login.usePlatform(new InformixPlatform());
	    login.setDriverClass(com.informix.jdbc.IfxDriver.class);
        
        Context ctx = null;
        try {
           ctx = new InitialContext();
           javax.sql.DataSource ds  = (javax.sql.DataSource) ctx.lookup(sourceName);
           JNDIConnector connector = new JNDIConnector(ds);
           login.setConnector(connector);
        }catch(Exception e) {
    	   throw new IllegalArgumentException(e.getMessage());  
        }               
	    
        login.setProperty("DBDATE","DMY4.");
        login.setProperty("DBMONEY",".");
        login.setProperty("DB_LOCALE","sk_sk.912");
        login.setProperty("CLIENT_LOCALE","sk_sk.1250");
    	
        TableSequence sequence = new TableSequence(); 
        sequence.setTableName("SEKVENCNA_TABULKA");
        sequence.setNameFieldName("NAZOV");
        sequence.setCounterFieldName("POCET");
        sequence.setPreallocationSize(100);
        login.setDefaultSequence(sequence);
        
	    login.setShouldBindAllParameters(false);
	    login.setShouldCacheAllStatements(false);
	    login.setUsesByteArrayBinding(true);
	    login.setUsesStringBinding(false);
	    if (login.shouldUseByteArrayBinding()) { // Can only be used with binding.
		    login.setUsesStreamsForBinding(false);
	    }
	    login.setShouldForceFieldNamesToUpperCase(false);
	    login.setShouldOptimizeDataConversion(true);
	    login.setShouldTrimStrings(true);
	    login.setUsesBatchWriting(false);
	    if (login.shouldUseBatchWriting()) { // Can only be used with batch writing.
		    login.setUsesJDBCBatchWriting(true);
	    }
	    login.setUsesExternalConnectionPooling(true);
	    login.setUsesExternalTransactionController(false);
	    return login;
	}
}    
