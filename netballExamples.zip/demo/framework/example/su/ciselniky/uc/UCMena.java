package demo.framework.example.su.ciselniky.uc;

import netball.server.pack.EnabledPack;
import netball.server.pack.Item;
import netball.server.pack.RequiredPack;
import netball.server.pack.ValuePack;
import netframework.bo.PersistentObject;
import netframework.eclipselink.EclipseLinkSession;
import netframework.eclipselink.UCPersistentObject;

import org.eclipse.persistence.zpi.sessions.UnitOfWork;

import demo.framework.example.bo.ciselniky.Mena;


public class UCMena extends UCPersistentObject {
    
    public static final String KOD = Mena.KOD.getId();
    public static final String NAZOV = Mena.NAZOV.getId();
    
    private UCMena(Mena object, EclipseLinkSession session) {
        super(object, session); 
    }

    @Override
    protected void setValuePack(ValuePack pack) throws Exception { 
        if (pack == null)
           return;
        Mena mena = (Mena) getObject();   
        EnabledPack enabledPack = getEnabledPack(); 
        for (int i = 0; i < pack.size(); i++) {
           Item item = pack.get(i);                
           Object id = item.getId();
           Object value = item.getValue();                
           if (enabledPack != null && !enabledPack.isEnabled(id))
              continue;
           if (id.equals(KOD)) {
              mena.setKod((String) value);
           }else if (id.equals(NAZOV)) {
              mena.setNazov((String) value); 
           }   
        }   
    }
    
    @Override
    public ValuePack getValuePack() {
        Mena mena = (Mena) getObject();
        ValuePack pack = new ValuePack();
        pack.put(KOD, mena.getKod());
        pack.put(NAZOV, mena.getNazov());
        return pack;
    }
    
    @Override
    public RequiredPack getRequiredPack() {
        RequiredPack pack = new RequiredPack();
        pack.put(KOD, Mena.KOD.isRequired());
        pack.put(NAZOV, Mena.NAZOV.isRequired());
        return pack;
    } 
    
    @Override
    public EnabledPack getEnabledPack() {
        return null;
    }

	@Override
	public void validate() throws Exception {
		((Mena) getObject()).validate(getSessionObject());
	}        
    
    // vytvori novy
    public static UCMena create(EclipseLinkSession session) {
        return new UCMena(new Mena(), session);
    }

    // nacita 
    public static UCMena read(Object id, EclipseLinkSession session) throws Exception {
        Mena mena = (Mena) read(Mena.class, id, session);
        return new UCMena(mena, session);
    }   
    
    // vymaze
    public static void delete(Object id, EclipseLinkSession session) throws Exception {
    	DeleteController controller = new DeleteController() {
			@Override
			public void delete(PersistentObject object,	EclipseLinkSession session, UnitOfWork uow)	throws Exception {
				((Mena) object).delete(session);
			}
    	};  
        delete(Mena.class, id, controller, session);
    }
}          
