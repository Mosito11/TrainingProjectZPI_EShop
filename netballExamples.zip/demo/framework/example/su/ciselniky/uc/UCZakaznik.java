package demo.framework.example.su.ciselniky.uc;

import netball.server.pack.EnabledPack;
import netball.server.pack.Item;
import netball.server.pack.RequiredPack;
import netball.server.pack.ValuePack;
import netframework.bo.PersistentObject;
import netframework.eclipselink.EclipseLinkSession;
import netframework.eclipselink.UCPersistentObject;

import org.eclipse.persistence.zpi.sessions.UnitOfWork;

import demo.framework.example.bo.ciselniky.Zakaznik;


public class UCZakaznik extends UCPersistentObject {
    
	public static final String ADRESA = Zakaznik.ADRESA.getId();
    public static final String NAZOV = Zakaznik.NAZOV.getId();
    public static final String ICO = Zakaznik.ICO.getId();
    public static final String JE_ZAHRANICNA = Zakaznik.JE_ZAHRANICNA.getId();
    
    protected UCZakaznik(Zakaznik zakaznik, EclipseLinkSession session) {
    	super(zakaznik, session);
    }

    @Override
    protected void setValuePack(ValuePack pack) throws Exception { 
        if (pack == null)
           return;
        EnabledPack enabledPack = getEnabledPack(); 
        for (int i = 0; i < pack.size(); i++) {
           Item item = pack.get(i);                
           Object id = item.getId();
           Object value = item.getValue();                
           if (enabledPack != null && !enabledPack.isEnabled(id))
              continue;
           Zakaznik zakaznik = (Zakaznik) getObject();
           if (id.equals(ICO)) {
              zakaznik.setIco((String) value);
           }else if (id.equals(NAZOV)) {
              zakaznik.setNazov((String) value); 
           }else if (id.equals(ADRESA)) {
               zakaznik.setAdresa((String) value); 
           }else if (id.equals(JE_ZAHRANICNA)) {
        	   zakaznik.setJeZahranicny((Boolean) value);
           }
        }   
    }
    
	@Override
	public void validate() throws Exception {
		((Zakaznik) getObject()).validate(getSessionObject());
	}
    
    @Override
    public ValuePack getValuePack() {
    	Zakaznik zakaznik = (Zakaznik) getObject();
        ValuePack pack = new ValuePack();
        pack.put(ICO, zakaznik.getIco());
        pack.put(NAZOV, zakaznik.getNazov());
        pack.put(ADRESA, zakaznik.getAdresa());
        pack.put(JE_ZAHRANICNA, zakaznik.getJeZahranicny());
        return pack;
    }
    
    @Override
    public RequiredPack getRequiredPack() {
        RequiredPack pack = new RequiredPack();
        pack.put(ICO, Zakaznik.ICO.isRequired());
        pack.put(NAZOV, Zakaznik.NAZOV.isRequired());
        pack.put(ADRESA, Zakaznik.ADRESA.isRequired());
        pack.put(JE_ZAHRANICNA, Zakaznik.JE_ZAHRANICNA.isRequired());
        return pack;
    } 
    
    @Override
    public EnabledPack getEnabledPack() {
        return null;
    }
    
    // vytvori novy
    public static UCZakaznik create(EclipseLinkSession session) {
        return new UCZakaznik(new Zakaznik(), session);
    }

    // nacita 
    public static UCZakaznik read(Object id, EclipseLinkSession session) throws Exception {
        Zakaznik zakaznik = (Zakaznik) read(Zakaznik.class, id, session);
        return new UCZakaznik(zakaznik, session);
    }   
    
    // vymaze
    public static void delete(Object id, EclipseLinkSession session) throws Exception {
    	DeleteController controller = new DeleteController() {
			@Override
			public void delete(PersistentObject object,	EclipseLinkSession session, UnitOfWork uow)	throws Exception {
				((Zakaznik) object).delete(session);
			}
    	};  
        delete(Zakaznik.class, id, controller, session);
    }

}          
