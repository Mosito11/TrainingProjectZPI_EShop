package demo.framework.example.su.ciselniky.uc;

import netball.server.pack.EnabledPack;
import netball.server.pack.Item;
import netball.server.pack.RequiredPack;
import netball.server.pack.ValuePack;
import netframework.bo.PersistentObject;
import netframework.eclipselink.EclipseLinkSession;
import netframework.eclipselink.UCPersistentObject;

import org.eclipse.persistence.zpi.sessions.UnitOfWork;

import demo.framework.example.bo.ciselniky.Zakazka;


public class UCZakazka extends UCPersistentObject{
    
    public static final String CISLO = Zakazka.CISLO.getId();
    public static final String NAZOV = Zakazka.NAZOV.getId();
    
    private UCZakazka(Zakazka zakazka, EclipseLinkSession session) {
    	super(zakazka, session);
    }

    @Override
    protected void setValuePack(ValuePack pack) throws Exception { 
        if (pack == null)
           return;
        EnabledPack enabledPack = getEnabledPack(); 
        for (int i = 0; i < pack.size(); i++) {
           Item item = pack.get(i);                
           Object id = item.getId();
           Object value = item.getValue();                
           if (enabledPack != null && !enabledPack.isEnabled(id))
              continue;
           Zakazka zakazka = (Zakazka) getObject();
           if (id.equals(CISLO)) {
              zakazka.setCislo((String) value);
           }else if (id.equals(NAZOV)) {
              zakazka.setNazov((String) value); 
           }   
        }   
    }
    
    @Override
    public ValuePack getValuePack() {
    	Zakazka zakazka = (Zakazka) getObject();
        ValuePack pack = new ValuePack();
        pack.put(CISLO, zakazka.getCislo());
        pack.put(NAZOV, zakazka.getNazov());
        return pack;
    }
    
    @Override
    public RequiredPack getRequiredPack() {
        RequiredPack pack = new RequiredPack();
        pack.put(CISLO, Zakazka.CISLO.isRequired());
        pack.put(NAZOV, Zakazka.NAZOV.isRequired());
        return pack;
    } 
    
    @Override
    public EnabledPack getEnabledPack() {
        return null;
    }
    
	@Override
	public void validate() throws Exception {
		((Zakazka) getObject()).validate(getSessionObject());
	}
    
    // vytvori novy
    public static UCZakazka create(EclipseLinkSession session) {
        return new UCZakazka(new Zakazka(), session);
    }

    // nacita 
    public static UCZakazka read(Object id, EclipseLinkSession session) throws Exception {
        Zakazka zakazka = (Zakazka) read(Zakazka.class, id, session);
        return new UCZakazka(zakazka, session);
    }   
    
    // vymaze
    public static void delete(Object id, EclipseLinkSession session) throws Exception {
    	DeleteController controller = new DeleteController() {
			@Override
			public void delete(PersistentObject object,	EclipseLinkSession session, UnitOfWork uow)	throws Exception {
				((Zakazka) object).delete(session);
			}
    	};  
        delete(Zakazka.class, id, controller, session);
    }

}          
