package demo.framework.example.su.ciselniky.md;

import netball.server.pack.ServerPack;
import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.MDViewClientTable;
import netframework.mediator.ViewTableDataSource;
import demo.framework.example.su.ciselniky.uc.UCMena;
import demo.framework.example.su.common.view.ViewMena;
import demo.framework.translate.ResourceConstants;


public class MDViewMena extends MDViewClientTable {
	
	@Override
	protected ViewTableDataSource createDataSource() {
        String[] columns = new String[] {ViewMena.ID,
                                         ViewMena.KOD,
                                         ViewMena.NAZOV};
        return new ViewTableDataSource(new ViewMena(), columns, ViewMena.ID, ViewMena.KOD);
    }    

	@Override
    protected void insert(ServerPack pack) {
        MDMena.Parameters prmts = new MDMena.Parameters(UCMena.create((EclipseLinkSession) getSessionObject()));
        runNext(MDMena.class, prmts, pack);
    }    
    
	@Override
    protected void update(ServerPack pack, Object id) throws Exception {          
    	runNext(MDMena.class, new MDMena.Parameters(UCMena.read(id, (EclipseLinkSession) getSessionObject())), pack);
    }
    
	@Override
    protected void delete(Object id) throws Exception {
        UCMena.delete(id, (EclipseLinkSession) getSessionObject());
    }

	@Override
    protected String getTitleText() {
        return ResourceConstants.MENY;
    }
	
}
