package demo.framework.example.su.ciselniky.md;

import javax.swing.SwingConstants;

import demo.framework.example.su.common.view.ViewZakaznik;
import demo.framework.translate.ResourceConstants;
import netball.server.component.XBoxPanel;
import netball.server.component.XClientTable;
import netball.server.component.XForm;
import netball.server.component.XPanel;
import netball.server.component.table.ClientTableSelectedRow;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ClientWindowEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerMouseEvent;
import netball.server.event.ServerWindowEvent;
import netball.server.pack.EnabledPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.MDUtilities;
import netframework.mediator.MDViewBasicClientTable;
import netframework.mediator.MediatorCallBackObject;
import netframework.mediator.MediatorParameters;
import netframework.mediator.ViewTableDataSource;
import netframework.mediator.resource.MediatorResourceBuilder;


public class MDVyberZakaznik extends MDViewBasicClientTable {

    private final String POTVRD_ACTION = createId(MediatorResourceBuilder.OK_BUTTON);
    private final String VYBER_ACTION = createId(MediatorResourceBuilder.READ_BUTTON);
    
    @Override
	public void init(MediatorParameters parameters, ServerPack pack) throws Exception {
		super.init(parameters, pack);
	}

	@Override
    public AccessAction[] getAccessActions(){
        return null;
    }
    
    @Override
    protected ViewTableDataSource createDataSource() {
		String cols[] = new String[] {	
					    ViewZakaznik.ID,
					    ViewZakaznik.ICO,
					    ViewZakaznik.NAZOV,
					    ViewZakaznik.ADRESA,
					    ViewZakaznik.JE_ZAHRANICNA};
		return new ViewTableDataSource(new ViewZakaznik(), cols, ViewZakaznik.ID, ViewZakaznik.ICO);
   }
   
    @Override
   protected String getTitleText() {
        return ResourceConstants.ZAKAZNICI;
   }
   
    @Override
	protected XPanel createEastPanel(ServerPack pack) {
    	XBoxPanel panel = new XBoxPanel(SwingConstants.VERTICAL);
    	panel.setSameSizeForAllComponents(true);
    	panel.setGapForAll(5);
    	
        panel.add(createButton(VYBER_ACTION, MediatorResourceBuilder.READ_BUTTON, MDUtilities.READ_ICON, new ServerActionEvent()));
    	
    	ServerActionEvent event = new ServerActionEvent();
    	event.addReturnValue(TABLE);    	
    	panel.add(createButton(POTVRD_ACTION, MediatorResourceBuilder.OK_BUTTON, MDUtilities.OK_ICON, event));
    	
        panel.add(createButton(CANCEL_ACTION, MediatorResourceBuilder.CANCEL_BUTTON, MDUtilities.HOME_ICON, new ServerActionEvent()));
        addButtonEnabledPack(pack);
        return panel;
    }
   
	@Override
   protected EnabledPack createButtonEnabledPack() {
       EnabledPack pack = new EnabledPack();
       pack.put(POTVRD_ACTION, getRowCount() > 0);
       return pack;
   }
   
   @Override	
   protected XForm createForm(){
	   XForm form = super.createForm();
       form.setHotButton(POTVRD_ACTION);
       form.addWindowEvent(new ServerWindowEvent(ServerWindowEvent.WINDOW_OPENED_EVENT));
       return form;
   }
   
   @Override
   protected XClientTable createTable(ServerPack serverPack) {
	   XClientTable table = super.createTable(serverPack);
	   ServerMouseEvent event = new ServerMouseEvent(ServerMouseEvent.MOUSE_CLICKED_EVENT);
	   event.setDoubleClick(true);
	   event.addReturnValue(TABLE);
	   table.addMouseEvent(event);
	   return table;
   }

   @Override
   public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
       try{
           if(event.getSourceId().equals(POTVRD_ACTION)){
   			   sendCallBack(event, pack);
           }else if (event.getSourceId().equals(VYBER_ACTION)) {
           	   this.runNext(MDFilterVyberZakaznik.class, this.getFilterParameters(), pack);
           }else{
        	   super.actionEventExecuted(event, pack);
           }
       }catch(Exception e){
           addExceptionToPack(e, pack);
       }
   	}
   	
   	@Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
   		if (event.getSourceId().equals(TABLE)) {
   			sendCallBack(event, pack);
   		}
	}
   	
	@Override
	public void windowEventExecuted(ClientWindowEvent event, ServerPack pack) {
		if (event.getCode() == ServerWindowEvent.WINDOW_OPENED_EVENT) {
			this.runNext(MDFilterVyberZakaznik.class, this.getFilterParameters(), pack);
		}
		super.windowEventExecuted(event, pack);
	}

	private void sendCallBack(ClientEvent event, ServerPack pack) {
        Object id = getSelectedPrimaryKeyFromEvent(event, pack);
        if(id != null){
        	ClientTableSelectedRow rows[] = (ClientTableSelectedRow[]) event.getValuePack().getValue(TABLE);
    	    Object ico = (String) rows[0].getRow().getValueAt(ViewZakaznik.ICO);
     	    this.sendCallBack(new CallBack(id, ico), pack);
               close(pack);
        }
   	}
    
    public static class CallBack implements MediatorCallBackObject {
    	
    	public Object zakaznikId;
    	public Object ico;
    	
    	public CallBack(Object zakaznikId, Object ico) {
    		this.zakaznikId = zakaznikId;
    		this.ico = ico;
    	}
    }
}
