package demo.framework.example.su.ciselniky.md;


import java.awt.Insets;

import netball.server.component.XDualComponentPanel;
import netball.server.component.XPanel;
import netball.server.component.border.XTitleBorder;
import netball.server.pack.EnabledPack;
import netball.server.pack.RequiredPack;
import netball.server.pack.ServerPack;
import netball.server.pack.ValuePack;
import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.ComponentBuilder;
import netframework.mediator.MDOkCancel;
import netframework.mediator.MediatorCallBackObject;
import netframework.mediator.MediatorParameters;
import demo.framework.example.bo.ciselniky.Zakazka;
import demo.framework.example.su.ciselniky.uc.UCZakazka;
import demo.framework.translate.ResourceConstants;

public class MDZakazka extends MDOkCancel {

    private UCZakazka zakazka; 
    private boolean isNew;

    @Override
    public void init(MediatorParameters parameters, ServerPack pack) throws Exception {
    	 if (parameters == null) {
    		 zakazka = UCZakazka.create((EclipseLinkSession) this.getSessionObject());
    		 isNew = true;
         }else if (parameters instanceof Parameters) {
        	 zakazka = UCZakazka.read(((Parameters) parameters).zakazkaId, (EclipseLinkSession) this.getSessionObject());
         }else{
           	 throw new IllegalArgumentException("Chybny parameter!");
        } 
    	putFormToPack(pack);
    }        
    
    @Override
    protected XPanel createPanel(ServerPack pack) throws Exception {
        XDualComponentPanel panel = new XDualComponentPanel();
        panel.setInsets(new Insets(10,10,10,10));
        panel.setBorder(new XTitleBorder());

        panel.add(ComponentBuilder.createComponent(UCZakazka.CISLO, Zakazka.CISLO, getSessionObject()));
        panel.add(ComponentBuilder.createComponent(UCZakazka.NAZOV, Zakazka.NAZOV, getSessionObject()));
        return panel;
    }
    
    @Override
    protected void execute(ValuePack valuePack, ServerPack pack) throws Exception {
       zakazka.execute(valuePack);
       sendCallBack(new CallBack(zakazka.getId(), isNew), pack);
       close(pack);
    }
    
    @Override
	protected String getTitleText() {
       return ResourceConstants.ZAKAZKA; 
    }    
    
    @Override
    protected ValuePack getValuePack() {
        return zakazka.getValuePack();
    }

    @Override
    protected EnabledPack getEnabledPack() {
        return zakazka.getEnabledPack();
    }

    @Override
    protected RequiredPack getRequiredPack() {
        return zakazka.getRequiredPack();
    }
    
    public static class Parameters implements MediatorParameters {
    
    	public Object zakazkaId;
    
    	public Parameters(Object zakazkaId) {
    		this.zakazkaId = zakazkaId;
    	} 
    }

	public static class CallBack implements MediatorCallBackObject{
        
		public Object zakazkaId;
		public boolean isNew;
    
    	public CallBack(Object zakazkaId, boolean isNew) {
    		this.zakazkaId = zakazkaId;
    		this.isNew = isNew;
    	} 
	}

}
