package demo.framework.example.su.ciselniky.md;


import java.awt.Color;
import java.util.List;

import javax.swing.SwingConstants;

import demo.framework.example.su.common.view.ViewZakazka;
import demo.framework.translate.ResourceConstants;
import netball.server.component.XBoxPanel;
import netball.server.component.XClientTable;
import netball.server.component.XPanel;
import netball.server.component.setting.ClientTableSettings;
import netball.server.component.table.ValueTableRowColorModel;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.EnabledPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.MDUtilities;
import netframework.mediator.MDViewBasicClientTable;
import netframework.mediator.MediatorCallBackObject;
import netframework.mediator.MediatorParameters;
import netframework.mediator.ViewTableDataSource;
import netframework.mediator.resource.MediatorResourceBuilder;


public class MDVyberZakazka extends MDViewBasicClientTable {
	
    private final String POTVRD_ACTION = createId(MediatorResourceBuilder.OK_BUTTON);
    
    @Override
    public AccessAction[] getAccessActions() {
    	return null;
    }    
    
    @Override
	public void init(MediatorParameters parameters, ServerPack pack) throws Exception {
		super.init(parameters, pack);
		this.read(pack, null, null, false);
	}



	@Override
    protected ViewTableDataSource createDataSource() {
        String[] columns = new String[] {  	
						        		ViewZakazka.ID,
						        		ViewZakazka.CISLO,
						        		ViewZakazka.NAZOV};
        return new ViewTableDataSource(new ViewZakazka(), columns, ViewZakazka.ID, ViewZakazka.CISLO);
    }    
    
    @Override
    protected String getTitleText() {
        return ResourceConstants.ZAKAZKY;
    }
    
    @Override
	protected XPanel createEastPanel(ServerPack pack) {
    	XBoxPanel panel = new XBoxPanel(SwingConstants.VERTICAL);
    	panel.setSameSizeForAllComponents(true);
    	panel.setGapForAll(5);
    	ServerActionEvent event = new ServerActionEvent();
    	event.addReturnValue(TABLE);
    	panel.add(createButton(POTVRD_ACTION, MediatorResourceBuilder.OK_BUTTON, MDUtilities.OK_ICON, event));
        panel.add(createButton(CANCEL_ACTION, MediatorResourceBuilder.CANCEL_BUTTON, MDUtilities.HOME_ICON, new ServerActionEvent()));
        addButtonEnabledPack(pack);
        return panel;
    }
 
    @Override
    protected EnabledPack createButtonEnabledPack() {
        EnabledPack pack = new EnabledPack();
        pack.put(POTVRD_ACTION, getRowCount() > 0);
        return pack;  
    }    

    
    @Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
        try {
            if (event.getSourceId().equals(POTVRD_ACTION)) {      
                Object ids[] = getSelectedPrimaryKeysFromEvent(event, pack);
                if(ids != null){
               	   if (this.sendCallBack(new CallBack(ids), pack))
	                  close(pack);
                }
            }else{
            	super.actionEventExecuted(event, pack);
            }
        }catch(Exception e) {
        	addExceptionToPack(e, pack);
        }                           
    }
    
    @Override
    protected XClientTable createTable(ServerPack serverPack) {
    	XClientTable table = super.createTable(serverPack);
    	table.setSelectionMode(XClientTable.MULTIPLE_INTERVAL_SELECTION);
		return table;
    }
    
    public void oznacRiadky(List<Object> ids, ServerPack pack) {
    	ValueTableRowColorModel tableRowColor = new ValueTableRowColorModel();
        if (ids != null && ids.size() > 0) { 
           for (int i = 0; i < ids.size(); i++) {
         	  Object id = ids.get(i);
           	  if (id != null) {
 	             tableRowColor.add(ViewZakazka.ID, id, null, Color.red);
           	  }
 	       } 
        }      	
    	ValuePack valuePack = new ValuePack();
        ClientTableSettings  tablePack = new ClientTableSettings();
        tablePack.setTableRowColorModel(tableRowColor);
        tablePack.setClearSelection(false);
        valuePack.put(TABLE, tablePack);
        pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));           	      	      	
    }
    
    @Override
	public int getMaxRows() {
		return 0;
	}

    public class CallBack implements MediatorCallBackObject {
		public Object[] zakazkyIds;
		
		public CallBack(Object[] zakazkyIds) {
			this.zakazkyIds = zakazkyIds;
		}
	}
}
