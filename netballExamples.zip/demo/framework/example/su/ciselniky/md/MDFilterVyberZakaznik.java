package demo.framework.example.su.ciselniky.md;

import netball.server.component.XDualComponentPanel;
import netball.server.component.XPanel;
import netframework.mediator.MDViewFilter;
import demo.framework.example.bo.ciselniky.Zakaznik;
import demo.framework.example.su.common.view.ViewZakaznik;


public class MDFilterVyberZakaznik extends MDViewFilter {
    
	@Override
	protected XPanel createFilterPanel() { 
       XDualComponentPanel panel = new XDualComponentPanel();
       panel.add(createComponent(ViewZakaznik.ICO, Zakaznik.ICO));
       panel.add(createComponent(ViewZakaznik.NAZOV, Zakaznik.NAZOV));
       panel.add(createComponent(ViewZakaznik.ADRESA, Zakaznik.ADRESA));
       panel.add(createComponent(ViewZakaznik.JE_ZAHRANICNA, Zakaznik.JE_ZAHRANICNA));
       return panel; 
    }
}
