package demo.framework.example.su.ciselniky.md;

import javax.swing.SwingConstants;

import demo.framework.example.su.ciselniky.uc.UCZakaznik;
import demo.framework.example.su.common.MDHelper;
import demo.framework.example.su.common.view.ViewZakaznik;
import demo.framework.translate.ResourceConstants;
import netball.server.component.XBoxPanel;
import netball.server.component.XPanel;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.alert.YesNoAlert;
import netball.server.pack.EnabledPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.BasicMediator;
import netframework.mediator.MDTablePreview;
import netframework.mediator.MDUtilities;
import netframework.mediator.MDViewBasicClientServerTable;
import netframework.mediator.MediatorCallBackObject;
import netframework.mediator.ViewTableDataSource;
import netframework.mediator.resource.MediatorResourceBuilder;


public class MDViewZakaznik extends MDViewBasicClientServerTable {

    private final String PRIDAJ_ACTION = createId(MediatorResourceBuilder.ADD_BUTTON);
    private final String OPRAVA_ACTION = createId(MediatorResourceBuilder.CORRECT_BUTTON);
    private final String VYMAZ_ACTION = createId(MediatorResourceBuilder.DELETE_BUTTON);
    private final String TLAC_ACTION = createId(MediatorResourceBuilder.PRINT_BUTTON);
    private final String VYBER_ACTION = createId(MediatorResourceBuilder.READ_BUTTON);
    
//    public void init(MediatorParameters parameters, ServerPack pack) throws Exception {
//    	super.init(parameters, pack);  // V pripade, ze prekryvate metodu initialize() je potrebne vzdy zavolat super,
//    	                               // inak nedojde k inicializacii datove kontajnera a program moze vyhadzovat NullPointerException 
//    }  
    
    @Override
    public AccessAction[] getAccessActions() {      
        return new AccessAction[] {
               getAccessAction(PRIDAJ_ACTION, MediatorResourceBuilder.ADD_BUTTON),
               getAccessAction(OPRAVA_ACTION, MediatorResourceBuilder.CORRECT_BUTTON),
               getAccessAction(VYMAZ_ACTION, MediatorResourceBuilder.DELETE_BUTTON),
         };
    }    
    
    protected boolean getInstallFilterHeader() {
    	return true;
    }
    
    private AccessAction getAccessAction(String actionCode, String buttonCode) {
    	return MediatorResourceBuilder.createAccessAction(actionCode, buttonCode, getLocale());
    }
    
    @Override
    protected ViewTableDataSource createDataSource() {
        String[] columns = new String[] {ViewZakaznik.ID,
							        	 ViewZakaznik.ICO,
									     ViewZakaznik.NAZOV,
									     ViewZakaznik.ADRESA,
									     ViewZakaznik.JE_ZAHRANICNA};
        return new ViewTableDataSource(new ViewZakaznik(), columns, ViewZakaznik.ID, ViewZakaznik.ICO);
    }    

    @Override
    protected String getTitleText() {
        return ResourceConstants.ZAKAZNICI;
    }
    
    @Override
	protected XPanel createEastPanel(ServerPack pack) {
    	XBoxPanel panel = new XBoxPanel(SwingConstants.VERTICAL);
    	panel.setSameSizeForAllComponents(true);
    	panel.setGapForAll(5);
    	
        panel.add(MediatorResourceBuilder.createButton(VYBER_ACTION, MediatorResourceBuilder.READ_BUTTON, new ServerActionEvent(), MDUtilities.READ_ICON, getSessionObject()));
        panel.add(MediatorResourceBuilder.createButton(PRIDAJ_ACTION, MediatorResourceBuilder.ADD_BUTTON, new ServerActionEvent(), MDUtilities.ADD_ICON, getSessionObject()));

    	ServerActionEvent event = new ServerActionEvent();
        event.addReturnValue(TABLE);
        panel.add(MediatorResourceBuilder.createButton(OPRAVA_ACTION, MediatorResourceBuilder.CORRECT_BUTTON, event, MDUtilities.CORRECT_ICON, getSessionObject()));

        event = new ServerActionEvent();
        event.addReturnValue(TABLE);
        event.addAlert(new YesNoAlert(getSessionObject().translateText(MDHelper.MESSAGE_VYMAZ_ZAZNAM)));
        panel.add(MediatorResourceBuilder.createButton(VYMAZ_ACTION, MediatorResourceBuilder.DELETE_BUTTON, event, MDUtilities.DELETE_ICON, getSessionObject()));
        
        panel.add(MediatorResourceBuilder.createButton(TLAC_ACTION, MediatorResourceBuilder.PRINT_BUTTON, new ServerActionEvent(), MDUtilities.PRINT_ICON, getSessionObject()));
        addButtonEnabledPack(pack);
        
        panel.add(MediatorResourceBuilder.createButton(CANCEL_ACTION, MediatorResourceBuilder.CANCEL_BUTTON, new ServerActionEvent(), MDUtilities.HOME_ICON, getSessionObject()));
        addButtonEnabledPack(pack);
        return panel;
    }
    
    @Override
    protected EnabledPack createButtonEnabledPack() {
        EnabledPack pack = new EnabledPack();
        if (getRowCount() > 0) {
            pack.put(OPRAVA_ACTION, true);
            pack.put(TLAC_ACTION, true);
            pack.put(VYMAZ_ACTION, true);
        }else{
            pack.put(OPRAVA_ACTION, false);
            pack.put(TLAC_ACTION, false);
            pack.put(VYMAZ_ACTION, false);
        }           
        return pack;  
    }    
    
    
	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
        try {
        	if (event.getSourceId().equals(OPRAVA_ACTION)) {            
        		int index = this.getSelectedIndexFromEvent(event, pack);
        		if (index != -1) {
        			Object id = this.getPrimaryKeyValue(index);
        			runNext(MDZakaznik.class, new MDZakaznik.Parameters(id), pack);
        			this.setSelectedIndex(index);
        		}
        	}else if (event.getSourceId().equals(PRIDAJ_ACTION)) {
        		runNext(MDZakaznik.class, null, pack);
        	}else if (event.getSourceId().equals(VYMAZ_ACTION)) {             
        		int index = this.getSelectedIndexFromEvent(event, pack);
        		if (index != -1) {
        			Object id = this.getPrimaryKeyValue(index);
        			UCZakaznik.delete(id, (EclipseLinkSession) this.getSessionObject());
        			this.addDeletedPack(index, pack);
        			this.addButtonEnabledPack(pack);
        		}   
        	}else if (event.getSourceId().equals(VYBER_ACTION)) {        	  
        		this.read(pack, null, null, false);
        		this.addButtonEnabledPack(pack);
        	}else if (event.getSourceId().equals(TLAC_ACTION)) {
        		runNext(MDTablePreview.class, new MDTablePreview.Parameters(TABLE, getId()), pack);
        	}else{
            	super.actionEventExecuted(event, pack); 
        	}    
        }catch(Exception e) {
        	addExceptionToPack(e, pack);
        }                           
    }    
 	
	@Override
    protected boolean receiveCallBack(BasicMediator mediator,  MediatorCallBackObject obj, ServerPack pack) {
        if (obj instanceof MDZakaznik.CallBack) {
        	MDZakaznik.CallBack callBack = (MDZakaznik.CallBack) obj;
        	if (callBack.isNew) {
        		addInsertedPack(callBack.zakaznikId, pack);          
        		addButtonEnabledPack(pack);
        	}else {
        		addUpdatedPack(callBack.zakaznikId, this.getSelectedIndex(), pack);          
        	} 
        }else {
        	return super.receiveCallBack(mediator, obj, pack);
        }  
        return false;        
    }     

	@Override
    public int getMaxRows() {
    	return 0;
    }
}
