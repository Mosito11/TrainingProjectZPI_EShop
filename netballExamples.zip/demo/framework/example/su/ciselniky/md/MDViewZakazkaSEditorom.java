package demo.framework.example.su.ciselniky.md;

import java.awt.Insets;

import javax.swing.SwingConstants;

import demo.framework.example.bo.ciselniky.Zakazka;
import demo.framework.example.su.ciselniky.uc.UCZakazka;
import demo.framework.example.su.common.view.ViewZakazka;
import demo.framework.translate.ResourceConstants;
import netball.server.component.XBoxPanel;
import netball.server.component.XClientTable;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XPanel;
import netball.server.component.border.XTitleBorder;
import netball.server.component.table.ClientTableSelectedRow;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientSelectionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerSelectionEvent;
import netball.server.pack.EnabledPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.ComponentBuilder;
import netframework.mediator.MDUtilities;
import netframework.mediator.MDViewBasicClientTable;
import netframework.mediator.ViewTableDataSource;
import netframework.mediator.resource.MediatorResourceBuilder;


public class MDViewZakazkaSEditorom extends MDViewBasicClientTable {

    private final String POTVRD_ACTION = createId(MediatorResourceBuilder.OK_BUTTON);
    private final String VYBER_ACTION = createId(MediatorResourceBuilder.READ_BUTTON);
    
    @Override
    public AccessAction[] getAccessActions() {
    	return null;
    }    
    
    @Override
    protected ViewTableDataSource createDataSource() {
        String[] columns = new String[] {ViewZakazka.ID,
							        	 ViewZakazka.CISLO,
									     ViewZakazka.NAZOV};
        return new ViewTableDataSource(new ViewZakazka(), columns, ViewZakazka.ID, ViewZakazka.CISLO);
    }    
    
    @Override
    protected String getTitleText() {
        return ResourceConstants.ZAKAZKY;
    }
    
    @Override
	protected XPanel createEastPanel(ServerPack pack) {
    	XBoxPanel panel = new XBoxPanel(SwingConstants.VERTICAL);
    	panel.setSameSizeForAllComponents(true);
    	panel.setGapForAll(5);
        panel.add(createButton(VYBER_ACTION, MediatorResourceBuilder.READ_BUTTON, MDUtilities.READ_ICON, new ServerActionEvent()));
        panel.add(createButton(CANCEL_ACTION, MediatorResourceBuilder.CANCEL_BUTTON, MDUtilities.HOME_ICON, new ServerActionEvent()));
        addButtonEnabledPack(pack);
        return panel;
    }
    
    @Override
    protected EnabledPack createButtonEnabledPack() {
        EnabledPack packet = new EnabledPack();
        if (getRowCount() > 0) {
        	packet.put(POTVRD_ACTION, true);
            packet.put(Zakazka.CISLO.getId(), true);
            packet.put(Zakazka.NAZOV.getId(), true);
        }else{
        	packet.put(POTVRD_ACTION, false);
            packet.put(Zakazka.CISLO.getId(), false);
            packet.put(Zakazka.NAZOV.getId(), false);
        }           
        return packet;  
    }    
    
    @Override
	protected XPanel createSouthPanel(ServerPack packet) {
        XDualComponentPanel panel = new XDualComponentPanel();
        panel.setColumnCount(2);
        panel.add(ComponentBuilder.createComponent(Zakazka.CISLO.getId(), Zakazka.CISLO, getSessionObject()));
        panel.add(ComponentBuilder.createComponent(Zakazka.NAZOV.getId(), Zakazka.NAZOV, getSessionObject()));
        
        XBoxPanel mainPanel = new XBoxPanel(SwingConstants.HORIZONTAL);
        mainPanel.setInsets(new Insets(10,10,10,10));
        mainPanel.setBorder(new XTitleBorder());
        mainPanel.add(panel);
        
    	ServerActionEvent event = new ServerActionEvent();
    	event.setReturnAllValues(true);
    	mainPanel.add(MediatorResourceBuilder.createButton(POTVRD_ACTION, MediatorResourceBuilder.OK_BUTTON, event, getSessionObject().getLocale()));
        
        return mainPanel;
	}
    
    @Override
	protected XClientTable createTable(ServerPack serverPack) {
    	XClientTable table = super.createTable(serverPack);
    	ServerSelectionEvent  event = new ServerSelectionEvent();
    	event.addReturnValue(TABLE);
    	table.addSelectionEvent(event);
    	return table;
	}

    
	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
	      	if (event.getSourceId().equals(VYBER_ACTION)) {        	  
            this.read(pack, null, null);
      	}else if (event.getSourceId().equals(POTVRD_ACTION)) {
	        Object id = getSelectedPrimaryKeyFromEvent(event, pack);
	        if(id != null){
	        	try {
	      		    UCZakazka zakazka = UCZakazka.read(id, (EclipseLinkSession) this.getSessionObject());
	      		    zakazka.execute(event.getValuePack());
	      		    this.addUpdatedPack(id, pack);
	        	}catch(Exception e) {
	        		this.addExceptionToPack(e, pack);
	        	}
	        }
       	}else{
       		super.actionEventExecuted(event, pack);
       	}                           
    }

	
	@Override
	public void selectionEventExecuted(ClientSelectionEvent event,	ServerPack pack) {
		if (event.getSourceId().equals(TABLE)) {
	        Object id = getSelectedPrimaryKeyFromEvent(event, pack);
	        if(id != null){
	        	ClientTableSelectedRow rows[] = (ClientTableSelectedRow[]) event.getValuePack().getValue(TABLE);
	        	Object cislo = rows[0].getRow().getValueAt(ViewZakazka.CISLO);
	        	Object nazov = rows[0].getRow().getValueAt(ViewZakazka.NAZOV);
	    	    ValuePack valuePack = new ValuePack();
	    	    valuePack.put(Zakazka.CISLO.getId(), cislo);
	    	    valuePack.put(Zakazka.NAZOV.getId(), nazov);
	    	    UpdatedPack updatePack = new UpdatedPack(this.getId(), valuePack);
	    	    updatePack.setFocusTo(Zakazka.CISLO.getId());
	    	    pack.addUpdatedPack(updatePack);
	        }
		}
	}    
}
