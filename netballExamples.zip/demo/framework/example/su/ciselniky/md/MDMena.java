package demo.framework.example.su.ciselniky.md;

import java.awt.Insets;

import netball.server.component.XDualComponentPanel;
import netball.server.component.XPanel;
import netball.server.component.border.XTitleBorder;
import netball.server.pack.ServerPack;
import netframework.mediator.ComponentBuilder;
import netframework.mediator.MDPersistentObject;
import demo.framework.example.bo.ciselniky.Mena;
import demo.framework.example.su.ciselniky.uc.UCMena;
import demo.framework.translate.ResourceConstants;


public class MDMena extends MDPersistentObject {
    
	@Override
	protected XPanel createPanel(ServerPack pack) throws Exception {
       XDualComponentPanel panel = new XDualComponentPanel();
       panel.setInsets(new Insets(10,10,10,10));
       panel.setBorder(new XTitleBorder());

       panel.add(ComponentBuilder.createComponent(UCMena.KOD, Mena.KOD, getSessionObject()));
       panel.add(ComponentBuilder.createComponent(UCMena.NAZOV, Mena.NAZOV, getSessionObject()));
       return panel; 
    }

	@Override
    protected String getTitleText() {
        return ResourceConstants.MENA; 
    }
}    
