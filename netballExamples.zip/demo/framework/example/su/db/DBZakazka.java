package demo.framework.example.su.db;

import java.sql.Types;

import netframework.sql.SQLField;
import netframework.sql.SQLTable;
import demo.framework.example.bo.ciselniky.Zakazka;


public class DBZakazka extends SQLTable {
	
	public static final SQLField ID = new SQLField("id", Types.INTEGER, 11);
	public static final SQLField CISLO = new SQLField("cislo", Types.CHAR, 10);
	public static final SQLField NAZOV = new SQLField("nazov", Types.VARCHAR, 50);
	
	public DBZakazka() {
		super("zakazka_");
	    addField(Zakazka.ID.getId(), ID);	
	    addField(Zakazka.CISLO.getId(), CISLO);	
	    addField(Zakazka.NAZOV.getId(), NAZOV);	
	}    
}
