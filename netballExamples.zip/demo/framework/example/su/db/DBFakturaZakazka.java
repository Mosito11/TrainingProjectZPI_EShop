package demo.framework.example.su.db;

import java.sql.Types;

import netframework.sql.SQLField;
import netframework.sql.SQLTable;

public class DBFakturaZakazka extends SQLTable {
  
	public static final SQLField FAKTURA = new SQLField("faktura_id", Types.INTEGER, 11);
	public static final SQLField ZAKAZKA = new SQLField("zakazka_id", Types.INTEGER, 11);
	
	public DBFakturaZakazka() {
		super("faktura_zakazka");
		addField("DBFakturaZakazka.faktura", FAKTURA);
		addField("DBFakturaZakazka.zakazka", ZAKAZKA);
	}
	
}
