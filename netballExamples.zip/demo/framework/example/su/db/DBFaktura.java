package demo.framework.example.su.db;

import java.sql.Types;

import netframework.sql.SQLField;
import netframework.sql.SQLTable;
import demo.framework.example.bo.fakturacia.Faktura;
import demo.framework.example.bo.fakturacia.SumaVMene;


public class DBFaktura extends SQLTable {
	
	public static final SQLField ID = new SQLField("id", Types.INTEGER, 11);
	public static final SQLField DATUM_VYSTAVENIA = new SQLField("datum_vystavenia", Types.DATE, 11);
	public static final SQLField CELKOVA_SUMA = new SQLField("celkova_cena", Types.DECIMAL, 12, 2);
	public static final SQLField MENA = new SQLField("mena_id", Types.INTEGER, 11);
	public static final SQLField ZAKAZNIK = new SQLField("zakaznik_id", Types.INTEGER, 11);
	public static final SQLField OBDOBIE = new SQLField("obdobie", Types.CHAR, 6);
	public static final SQLField STAV = new SQLField("stav", Types.CHAR, 1);
	public static final SQLField VERSION = new SQLField("version", Types.INTEGER, 11);
	public static final SQLField TYP = new SQLField("class_id", Types.CHAR, 1);
	public static final SQLField CISLO = new SQLField("cislo", Types.CHAR, 10);
	
	public DBFaktura() {
		super("faktura");
	    addField(Faktura.ID.getId(), ID);	
		addField(Faktura.DATUM_VYSTAVENIA.getId(), DATUM_VYSTAVENIA);
		addField(SumaVMene.SUMA.getId(), CELKOVA_SUMA);
		addField(SumaVMene.MENA.getId(), MENA);
		addField(Faktura.ZAKAZNIK.getId(), ZAKAZNIK);
		addField(Faktura.OBDOBIE.getId(), OBDOBIE);
		addField(Faktura.STAV.getId(), STAV);
		addField(Faktura.VERSION.getId(), VERSION);
		addField(Faktura.TYP.getId(), TYP);
		addField(Faktura.CISLO.getId(), CISLO);
	}    
}
