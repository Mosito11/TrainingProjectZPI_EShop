package demo.framework.example.su.db;

import netframework.FrameworkUtilities;
import netframework.sql.SQLCatalog;
import demo.framework.example.bo.ciselniky.Mena;
import demo.framework.example.bo.ciselniky.Zakazka;
import demo.framework.example.bo.ciselniky.Zakaznik;
import demo.framework.example.bo.fakturacia.Faktura;
import demo.framework.example.bo.fakturacia.FakturaPolozka;
import demo.framework.example.bo.uzol.Uzol;

public class DBSkolenieCatalog extends SQLCatalog {
	
	public static final DBFaktura FAKTURA = new DBFaktura(); 
	public static final DBFakturaPolozka FAKTURA_POLOZKA = new DBFakturaPolozka(); 
	public static final DBFakturaZakazka FAKTURA_ZAKAZKA = new DBFakturaZakazka(); 
	public static final DBMena MENA = new DBMena(); 
	public static final DBZakazka ZAKAZKA = new DBZakazka(); 
	public static final DBZakaznik ZAKAZNIK = new DBZakaznik(); 
	public static final DBUzol UZOL = new DBUzol();
	
	private static DBSkolenieCatalog catalog = new DBSkolenieCatalog();
	
	private DBSkolenieCatalog(){
		addTable(FrameworkUtilities.getShortClassName(Faktura.class), FAKTURA);
		addTable(FrameworkUtilities.getShortClassName(FakturaPolozka.class), FAKTURA_POLOZKA);
		addTable(FrameworkUtilities.getShortClassName(DBFakturaZakazka.class), FAKTURA_ZAKAZKA);
		addTable(FrameworkUtilities.getShortClassName(Mena.class), MENA);
		addTable(FrameworkUtilities.getShortClassName(Zakazka.class), ZAKAZKA);
		addTable(FrameworkUtilities.getShortClassName(Zakaznik.class), ZAKAZNIK);
		addTable(FrameworkUtilities.getShortClassName(Uzol.class), UZOL);
	}
	   
	public static DBSkolenieCatalog getInstance() {
	    return catalog;
    }
}	
