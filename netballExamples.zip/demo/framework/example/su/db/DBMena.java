package demo.framework.example.su.db;

import java.sql.Types;

import netframework.sql.SQLField;
import netframework.sql.SQLTable;
import demo.framework.example.bo.ciselniky.Mena;

public class DBMena extends SQLTable {
	
	public static final SQLField ID = new SQLField("id", Types.INTEGER, 11);
	public static final SQLField KOD = new SQLField("kod", Types.CHAR, 3);
	public static final SQLField NAZOV = new SQLField("nazov", Types.VARCHAR, 50);
	
	public DBMena() {
		super("mena");
	    addField(Mena.ID.getId(), ID);	
	    addField(Mena.KOD.getId(), KOD);	
	    addField(Mena.NAZOV.getId(), NAZOV);	
	}    
}
