package demo.framework.example.su.db;

import java.sql.Types;

import netframework.sql.SQLField;
import netframework.sql.SQLTable;
import demo.framework.example.bo.uzol.Uzol;

public class DBUzol extends SQLTable {
	
	public static final SQLField ID = new SQLField("id", Types.INTEGER, 11);
	public static final SQLField KOD = new SQLField("kod", Types.CHAR, 3);
	public static final SQLField NAZOV = new SQLField("nazov", Types.VARCHAR, 40);
	public static final SQLField POLOZKA_1 = new SQLField("polozka1", Types.VARCHAR, 20);
	public static final SQLField POLOZKA_2 = new SQLField("polozka2", Types.VARCHAR, 20);
	public static final SQLField POLOZKA_3 = new SQLField("polozka3", Types.VARCHAR, 20);
	public static final SQLField RODIC = new SQLField("rodic_id", Types.INTEGER, 11);
	
	public DBUzol() {
		super("uzol");
	    addField(Uzol.ID.getId(), ID);	
	    addField(Uzol.KOD.getId(), KOD);	
	    addField(Uzol.NAZOV.getId(), NAZOV);	
		addField(Uzol.POLOZKA_1.getId(), POLOZKA_1);
		addField(Uzol.POLOZKA_2.getId(), POLOZKA_2);
		addField(Uzol.POLOZKA_3.getId(), POLOZKA_3);
		addField(Uzol.RODIC.getId(), RODIC);
	}    
}
