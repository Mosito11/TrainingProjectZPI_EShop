package demo.framework.example.su.db;

import java.sql.Types;

import netframework.sql.SQLField;
import netframework.sql.SQLTable;
import demo.framework.example.bo.ciselniky.Zakaznik;


public class DBZakaznik extends SQLTable {
	
	public static final SQLField ID = new SQLField("id", Types.INTEGER, 11);
	public static final SQLField ICO = new SQLField("ico", Types.CHAR, 10);
	public static final SQLField NAZOV = new SQLField("nazov", Types.VARCHAR, 50);
	public static final SQLField ADRESA = new SQLField("adresa", Types.VARCHAR, 100);
	public static final SQLField JE_ZAHRANICNA = new SQLField("je_zahranicny", Types.CHAR, 1);
	
	public DBZakaznik() {
		super("zakaznik");
	    addField(Zakaznik.ID.getId(), ID);	
	    addField(Zakaznik.ICO.getId(), ICO);	
	    addField(Zakaznik.NAZOV.getId(), NAZOV);	
	    addField(Zakaznik.ADRESA.getId(), ADRESA);	
	    addField(Zakaznik.JE_ZAHRANICNA.getId(), JE_ZAHRANICNA);	
	}    
}
