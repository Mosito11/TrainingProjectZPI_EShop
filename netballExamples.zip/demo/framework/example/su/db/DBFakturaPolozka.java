package demo.framework.example.su.db;

import java.sql.Types;

import netframework.sql.SQLField;
import netframework.sql.SQLTable;
import demo.framework.example.bo.fakturacia.FakturaPolozka;


public class DBFakturaPolozka extends SQLTable {
	
	public static final SQLField ID = new SQLField("id", Types.INTEGER, 11);
	public static final SQLField MNOZSTVO = new SQLField("mnozstvo", Types.DECIMAL, 10, 5);
	public static final SQLField JEDNOTKOVA_CENA = new SQLField("jednotkova_cena", Types.DECIMAL, 12, 2);
	public static final SQLField CELKOVA_CENA = new SQLField("celkova_cena", Types.DECIMAL, 12, 2);
	public static final SQLField MERNA_JEDNOTKA = new SQLField("merna_jednotka", Types.CHAR, 5);
	public static final SQLField NAZOV = new SQLField("nazov", Types.VARCHAR, 100);
	public static final SQLField FAKTURA = new SQLField("faktura_id", Types.INTEGER, 10);
	
	public DBFakturaPolozka() {
		super("faktura_polozka");
	    addField(FakturaPolozka.ID.getId(), ID);	
		addField(FakturaPolozka.MNOZSTVO.getId(), MNOZSTVO);
		addField(FakturaPolozka.JEDNOTKOVA_CENA.getId(), JEDNOTKOVA_CENA);
		addField(FakturaPolozka.CELKOVA_CENA.getId(), CELKOVA_CENA);
		addField(FakturaPolozka.MERNA_JEDNOTKA.getId(), MERNA_JEDNOTKA);
		addField(FakturaPolozka.NAZOV.getId(), NAZOV);
		addField(FakturaPolozka.FAKTURA.getId(), FAKTURA);
	}    
}
