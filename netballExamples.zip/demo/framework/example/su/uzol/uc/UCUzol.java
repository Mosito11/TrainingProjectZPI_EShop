package demo.framework.example.su.uzol.uc;

import netball.server.pack.EnabledPack;
import netball.server.pack.Item;
import netball.server.pack.RequiredPack;
import netball.server.pack.ValuePack;
import netframework.bo.PersistentObject;
import netframework.eclipselink.EclipseLinkSession;
import netframework.eclipselink.UCPersistentObject;

import org.eclipse.persistence.zpi.expressions.Expression;
import org.eclipse.persistence.zpi.expressions.ExpressionBuilder;
import org.eclipse.persistence.zpi.sessions.UnitOfWork;

import demo.framework.example.bo.uzol.Uzol;


public class UCUzol extends UCPersistentObject {
    
    public static final String KOD = Uzol.KOD.getId();
    public static final String NAZOV = Uzol.NAZOV.getId();
    public static final String POLOZKA_1 = Uzol.POLOZKA_1.getId();
    public static final String POLOZKA_2 = Uzol.POLOZKA_2.getId();
    public static final String POLOZKA_3 = Uzol.POLOZKA_3.getId();
    
    private UCUzol(Uzol object, EclipseLinkSession session) {
        super(object, session); 
    }

    @Override
    protected void setValuePack(ValuePack pack) throws Exception { 
        if (pack == null)
           return;
        Uzol uzol = (Uzol) getObject();   
        EnabledPack enabledPack = getEnabledPack(); 
        for (int i = 0; i < pack.size(); i++) {
           Item item = pack.get(i);                
           Object id = item.getId();
           Object value = item.getValue();                
           if (enabledPack != null && !enabledPack.isEnabled(id))
              continue;
           if (id.equals(KOD)) {
              uzol.setKod((String) value);
           }else if (id.equals(NAZOV)) {
              uzol.setNazov((String) value); 
           }else if (id.equals(POLOZKA_1)) {
               uzol.setPolozka1((String) value); 
           }else if (id.equals(POLOZKA_2)) {
               uzol.setPolozka2((String) value); 
           }else if (id.equals(POLOZKA_3)) {
               uzol.setPolozka3((String) value); 
           }   
        }   
    }
    
    @Override
    public ValuePack getValuePack() {
        Uzol uzol = (Uzol) getObject();
        ValuePack pack = new ValuePack();
        pack.put(KOD, uzol.getKod());
        pack.put(NAZOV, uzol.getNazov());
        pack.put(POLOZKA_1, uzol.getPolozka1());
        pack.put(POLOZKA_2, uzol.getPolozka2());
        pack.put(POLOZKA_3, uzol.getPolozka3());
        return pack;
    }
    
    @Override
    public RequiredPack getRequiredPack() {
        RequiredPack pack = new RequiredPack();
        pack.put(KOD, Uzol.KOD.isRequired());
        pack.put(NAZOV, Uzol.NAZOV.isRequired());
        pack.put(POLOZKA_1, Uzol.POLOZKA_1.isRequired());
        pack.put(POLOZKA_2, Uzol.POLOZKA_2.isRequired());
        pack.put(POLOZKA_3, Uzol.POLOZKA_3.isRequired());
        return pack;
    } 
    
    @Override
    public EnabledPack getEnabledPack() {
        return null;
    }

	@Override
	public void validate() throws Exception {
		((Uzol) getObject()).validate(getSessionObject());
	}        
    
    // vytvori novy
    public static UCUzol create(Object parentId, EclipseLinkSession session) {
    	UCUzol uc = new UCUzol(new Uzol(), session);
    	if (parentId != null) {
    		Expression exp = new ExpressionBuilder().get(Uzol.ID.getName()).equal(parentId);
    		Uzol rodic = (Uzol) uc.getUnitOfWork().readObject(Uzol.class, exp);
    		((Uzol) uc.getObject()).setRodic(rodic);
    	}
    	return uc;
    }

    // nacita 
    public static UCUzol read(Object id, EclipseLinkSession session) throws Exception {
        Uzol uzol = (Uzol) read(Uzol.class, id, session);
        return new UCUzol(uzol, session);
    }   
    
    // vymaze
    public static void delete(Object id, EclipseLinkSession session) throws Exception {
    	DeleteController controller = new DeleteController() {
			@Override
			public void delete(PersistentObject object,	EclipseLinkSession session, UnitOfWork uow)	throws Exception {
				((Uzol) object).delete(session, uow);
			}
    	};  
        delete(Uzol.class, id, controller, session);
    }
}          
