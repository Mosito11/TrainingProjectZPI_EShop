package demo.framework.example.su.uzol.md;

import java.awt.Insets;

import netball.server.component.XDualComponentPanel;
import netball.server.component.XPanel;
import netball.server.component.border.XTitleBorder;
import netball.server.pack.EnabledPack;
import netball.server.pack.RequiredPack;
import netball.server.pack.ServerPack;
import netball.server.pack.ValuePack;
import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.ComponentBuilder;
import netframework.mediator.MDOkCancel;
import netframework.mediator.MediatorCallBackObject;
import netframework.mediator.MediatorParameters;
import demo.framework.example.bo.uzol.Uzol;
import demo.framework.example.su.uzol.uc.UCUzol;
import demo.framework.translate.ResourceConstants;


public class MDUzol extends MDOkCancel {

    private UCUzol uzol; 
    private boolean isNew;

    @Override
    public void init(MediatorParameters parameters, ServerPack pack) throws Exception {
    	 if (parameters instanceof ParametersInsert) {
    		 uzol = UCUzol.create(((ParametersInsert) parameters).parentUzolId, (EclipseLinkSession) this.getSessionObject());
    		 isNew = true;
         }else if (parameters instanceof ParametersUpdate) {
        	 uzol = UCUzol.read(((ParametersUpdate) parameters).uzolId, (EclipseLinkSession) this.getSessionObject());
         }else{
           	 throw new IllegalArgumentException("Chybny parameter!");
        } 
    	putFormToPack(pack);
    }        
    
    @Override
    protected XPanel createPanel(ServerPack pack) throws Exception {
        XDualComponentPanel panel = new XDualComponentPanel();
        panel.setInsets(new Insets(10,10,10,10));
        panel.setBorder(new XTitleBorder());
        panel.add(ComponentBuilder.createComponent(UCUzol.KOD, Uzol.KOD, getSessionObject()));
        panel.add(ComponentBuilder.createComponent(UCUzol.NAZOV, Uzol.NAZOV, getSessionObject()));
        panel.add(ComponentBuilder.createComponent(UCUzol.POLOZKA_1, Uzol.POLOZKA_1, getSessionObject()));
        panel.add(ComponentBuilder.createComponent(UCUzol.POLOZKA_2, Uzol.POLOZKA_2, getSessionObject()));
        panel.add(ComponentBuilder.createComponent(UCUzol.POLOZKA_3, Uzol.POLOZKA_3, getSessionObject()));
        return panel;
    }
    
    @Override
    protected void execute(ValuePack valuePack, ServerPack pack) throws Exception {
       uzol.execute(valuePack);
       sendCallBack(new CallBack(uzol.getId(), isNew), pack);
       close(pack);
    }
    
    @Override
	protected String getTitleText() {
       return ResourceConstants.ZAKAZKA; 
    }    
    
    @Override
    protected ValuePack getValuePack() {
        return uzol.getValuePack();
    }

    @Override
    protected EnabledPack getEnabledPack() {
        return uzol.getEnabledPack();
    }

    @Override
    protected RequiredPack getRequiredPack() {
        return uzol.getRequiredPack();
    }

    public static class ParametersInsert implements MediatorParameters {
        
    	public Object parentUzolId;
    
    	public ParametersInsert(Object parentUzolId) {
    		this.parentUzolId = parentUzolId;
    	} 
    }
    
    public static class ParametersUpdate implements MediatorParameters {
    
    	public Object uzolId;
    
    	public ParametersUpdate(Object uzolId) {
    		this.uzolId = uzolId;
    	} 
    }

	public static class CallBack implements MediatorCallBackObject{
        
		public Object uzolId;
		public boolean isNew;
    
    	public CallBack(Object uzolId, boolean isNew) {
    		this.uzolId = uzolId;
    		this.isNew = isNew;
    	} 
	}
}
