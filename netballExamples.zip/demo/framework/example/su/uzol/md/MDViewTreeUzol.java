package demo.framework.example.su.uzol.md;

import netball.server.pack.ServerPack;
import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.BasicMediator;
import netframework.mediator.MDViewTree;
import netframework.mediator.MediatorCallBackObject;
import netframework.mediator.ViewTreeDataSource;
import netframework.view.ViewOrder;
import demo.framework.example.su.common.view.ViewUzol;
import demo.framework.example.su.uzol.uc.UCUzol;

public class MDViewTreeUzol extends MDViewTree {


	@Override
	protected void delete(Object id) throws Exception {
		UCUzol.delete(id, (EclipseLinkSession) getSessionObject());
	}

	@Override
	protected ViewTreeDataSource createDataSource() {
		ViewTreeDataSource.Parameters prmts = new ViewTreeDataSource.Parameters();
		prmts.view = new ViewUzol();
		prmts.treeColumns = new String[] {ViewUzol.ID, ViewUzol.KOD, ViewUzol.NAZOV, ViewUzol.RODIC};
		prmts.primaryColumn = ViewUzol.ID;
		prmts.parentColumn = ViewUzol.RODIC;
		prmts.orderingColumns = new ViewOrder[] {new ViewOrder(ViewUzol.KOD, true)};
		prmts.hiddenColumns = new String[] {ViewUzol.ID, ViewUzol.RODIC};
		return new ViewTreeDataSource(prmts); 
	}

	@Override
	protected String getTitleText() {
		return /*~~*/"MDViewTree";
	}

	@Override
	protected Object getRootUserObject() {
		return /*~~*/"Uzly";
	}

	@Override
	protected void insert(Object parentId, ServerPack pack) throws Exception {
		this.runNext(MDUzol.class, new MDUzol.ParametersInsert(parentId), pack);
	}

	@Override
	protected void update(Object nodeId, ServerPack pack) throws Exception {
		this.runNext(MDUzol.class, new MDUzol.ParametersUpdate(nodeId), pack);
	}
	
	@Override
	protected boolean receiveCallBack(BasicMediator mediator, MediatorCallBackObject obj, ServerPack pack) {
		if (obj instanceof MDUzol.CallBack) {
			MDUzol.CallBack callBack = (MDUzol.CallBack) obj;
			if (callBack.isNew) {
				this.addInsertedPack(callBack.uzolId, pack);
			}else{
				this.addUpdatedPack(callBack.uzolId, pack);
			}
			return true;
		}else{
			return super.receiveCallBack(mediator, obj, pack);
		}
	}
			
}
