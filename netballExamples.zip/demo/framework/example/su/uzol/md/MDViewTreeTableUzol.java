package demo.framework.example.su.uzol.md;

import java.awt.Color;

import netball.server.component.XTreeTable;
import netball.server.component.table.ValueTableRowColorModel;
import netball.server.pack.ServerPack;
import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.BasicMediator;
import netframework.mediator.MDViewTreeTable;
import netframework.mediator.MediatorCallBackObject;
import netframework.mediator.ViewTreeTableDataSource;
import netframework.view.ViewOrder;
import demo.framework.example.su.common.view.ViewUzol;
import demo.framework.example.su.uzol.uc.UCUzol;

public class MDViewTreeTableUzol extends MDViewTreeTable {


	@Override
	protected void delete(Object id) throws Exception {
		UCUzol.delete(id, (EclipseLinkSession) getSessionObject());
	}

	@Override
	protected ViewTreeTableDataSource createDataSource() {
		ViewTreeTableDataSource.Parameters prmts = new ViewTreeTableDataSource.Parameters();
		prmts.view = new ViewUzol();
		prmts.treeColumns = new String[] {ViewUzol.ID, ViewUzol.KOD, ViewUzol.NAZOV};
		prmts.tableColumns = new String[] {ViewUzol.POLOZKA_1, ViewUzol.POLOZKA_2, ViewUzol.POLOZKA_3, ViewUzol.RODIC};
		prmts.primaryColumn = ViewUzol.ID;
		prmts.parentColumn = ViewUzol.RODIC;
		prmts.orderingColumns = new ViewOrder[] {new ViewOrder(ViewUzol.KOD, true)};
		prmts.hiddenPrimaryColumn = true;
		prmts.hiddenColumns = new String[] {ViewUzol.RODIC};
		return new ViewTreeTableDataSource(prmts); 
	}

	@Override
	protected String getTitleText() {
		return /*~~*/"MDViewTreeTable";
	}

	@Override
	protected Object getRootUserObject() {
		return /*~~*/"Uzly";
	}

	@Override
	protected void insert(Object parentId, ServerPack pack) throws Exception {
		this.runNext(MDUzol.class, new MDUzol.ParametersInsert(parentId), pack);
	}

	@Override
	protected void update(Object nodeId, ServerPack pack) throws Exception {
		this.runNext(MDUzol.class, new MDUzol.ParametersUpdate(nodeId), pack);
	}

	@Override
    protected XTreeTable createTreeTable(ServerPack serverPack) throws Exception {
   	    XTreeTable tree = super.createTreeTable(serverPack);
   	    tree.setTreeHeaderText(/*~~*/"Kod nazov");
   	    
   	    ValueTableRowColorModel model = new ValueTableRowColorModel();
   	    model.add(ViewUzol.POLOZKA_1, "5", Color.RED);
   	    tree.setTableCellColorModel(model);
   	    
   	    return tree;
	}
	
	@Override
	protected boolean receiveCallBack(BasicMediator mediator, MediatorCallBackObject obj, ServerPack pack) {
		if (obj instanceof MDUzol.CallBack) {
			MDUzol.CallBack callBack = (MDUzol.CallBack) obj;
			if (callBack.isNew) {
				this.addInsertedPack(callBack.uzolId, pack);
			}else{
				this.addUpdatedPack(callBack.uzolId, pack);
			}
			return true;
		}else{
			return super.receiveCallBack(mediator, obj, pack);
		}
	}
			
}
