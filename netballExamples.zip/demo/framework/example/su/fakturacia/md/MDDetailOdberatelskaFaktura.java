package demo.framework.example.su.fakturacia.md;


import java.awt.Insets;

import demo.framework.example.bo.ciselniky.Mena;
import demo.framework.example.bo.ciselniky.Zakazka;
import demo.framework.example.bo.ciselniky.Zakaznik;
import demo.framework.example.bo.fakturacia.Faktura;
import demo.framework.example.bo.fakturacia.FakturaPolozka;
import demo.framework.example.bo.fakturacia.OdberatelskaFaktura;
import demo.framework.example.bo.fakturacia.SumaVMene;
import demo.framework.example.su.common.MDHelper;
import demo.framework.example.su.db.DBSkolenieCatalog;
import demo.framework.translate.ResourceConstants;
import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XClientTable;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XForm;
import netball.server.component.XPanel;
import netball.server.component.XTabbedPage;
import netball.server.component.XTabbedPane;
import netball.server.component.table.TableContainer;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.ValuePack;
import netframework.FrameworkUtilities;
import netframework.access.AccessAction;
import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.BasicMediator;
import netframework.mediator.ComponentBuilder;
import netframework.mediator.MDUtilities;
import netframework.mediator.MediatorParameters;
import netframework.mediator.resource.MediatorResourceBuilder;
import netframework.sql.SQLExpressionBuilder;
import netframework.sql.SQLJoinCondition;
import netframework.sql.SQLQuery;
import netframework.view.ViewCursor;
import netframework.view.ViewRow;


public class MDDetailOdberatelskaFaktura extends BasicMediator {
    
    private final String CANCEL_ACTION = createId(MediatorResourceBuilder.CANCEL_BUTTON);
    private Object fakturaId;
    private final String TABLE_POLOZKY = "tablePolozky";
    private final String DETAIL_POLOZKY_ACTION = "detailPolozkyAction";

    @Override
    public void init(MediatorParameters parameters, ServerPack pack) throws Exception {
        if (parameters instanceof Parameters) {
           Parameters prmts = (Parameters) parameters;    
           fakturaId = prmts.fakturaId;
        }else {
           throw new IllegalArgumentException("Chybny parameter !"); 
        }
        this.putFormToPack(pack);
    }    
    
    public AccessAction[] getAccessActions() {      
        return null;
    }     

    private ValuePack read() throws Exception{
    	DBSkolenieCatalog c = DBSkolenieCatalog.getInstance();
        SQLQuery query = new SQLQuery();
        query.addTable(new SQLJoinCondition(c.FAKTURA)); 
        query.addTable(new SQLJoinCondition(c.ZAKAZNIK, SQLJoinCondition.LEFT_OUTER_JOIN, c.FAKTURA.ZAKAZNIK, c.ZAKAZNIK.ID));
        query.addTable(new SQLJoinCondition(c.MENA, SQLJoinCondition.LEFT_OUTER_JOIN, c.FAKTURA.MENA, c.MENA.ID));
        query.addField(OdberatelskaFaktura.OBDOBIE.getId(), c.FAKTURA.OBDOBIE);
        query.addField(OdberatelskaFaktura.STAV.getId(), c.FAKTURA.STAV);
        query.addField(OdberatelskaFaktura.CISLO.getId(), c.FAKTURA.CISLO);
        query.addField(OdberatelskaFaktura.DATUM_VYSTAVENIA.getId(), c.FAKTURA.DATUM_VYSTAVENIA);
        query.addField(SumaVMene.SUMA.getId(), c.FAKTURA.CELKOVA_SUMA);
        query.addField(Mena.KOD.getId(), c.MENA.KOD);
        query.addField(Zakaznik.ICO.getId(), c.ZAKAZNIK.ICO);
        query.addField(Zakaznik.NAZOV.getId(), c.ZAKAZNIK.NAZOV);
        query.setExpression(SQLExpressionBuilder.get(c.FAKTURA.ID).equal(this.fakturaId));
        ViewCursor cursor = ((EclipseLinkSession) getSessionObject()).execute(query);
        if(!cursor.hasNext())
            throw new IllegalArgumentException("Nepodarilo sa nacitat zaznam id = " + fakturaId + " !");
        ViewRow row = cursor.next();
        ValuePack valuePack = new ValuePack();
        for(int i = 0; i < row.getSize(); i++){
            valuePack.put(row.getColumnName(i), row.getValueAt(i));
        }
        return valuePack;
    }

    protected XPanel createAtributyPanel() throws Exception{
        XDualComponentPanel panel = new XDualComponentPanel();
        panel.setInsets(new Insets(10,10,10,10));
        panel.add(ComponentBuilder.createReadOnlyComponent(OdberatelskaFaktura.CISLO.getId(), OdberatelskaFaktura.CISLO, getSessionObject()));
        panel.add(ComponentBuilder.createReadOnlyComponent(Zakaznik.ICO.getId(), Zakaznik.ICO, getSessionObject()));
        panel.add(ComponentBuilder.createReadOnlyComponent(Zakaznik.NAZOV.getId(), Zakaznik.NAZOV, Faktura.ZAKAZNIK.getCaption(), getSessionObject()));
        panel.add(ComponentBuilder.createReadOnlyComponent(SumaVMene.SUMA.getId(), SumaVMene.SUMA, OdberatelskaFaktura.CELKOVA_SUMA.getCaption(), getSessionObject()));
        panel.add(ComponentBuilder.createReadOnlyComponent(Mena.KOD.getId(), Mena.KOD, false, getSessionObject()));
        panel.add(ComponentBuilder.createReadOnlyComponent(OdberatelskaFaktura.OBDOBIE.getId(), OdberatelskaFaktura.OBDOBIE, getSessionObject()));
        panel.add(ComponentBuilder.createReadOnlyComponent(OdberatelskaFaktura.STAV.getId(), OdberatelskaFaktura.STAV, getSessionObject()));
        panel.add(ComponentBuilder.createReadOnlyComponent(OdberatelskaFaktura.DATUM_VYSTAVENIA.getId(), OdberatelskaFaktura.DATUM_VYSTAVENIA, getSessionObject()));
        return panel;
    }
    
    protected XPanel createPolozkyPanel() throws Exception {        
    	DBSkolenieCatalog c = DBSkolenieCatalog.getInstance();
        SQLQuery query = new SQLQuery();
        query.addTable(new SQLJoinCondition(c.FAKTURA_POLOZKA));
        query.addField(FakturaPolozka.ID.getId(), c.FAKTURA_POLOZKA.ID);
        query.addField(FakturaPolozka.NAZOV.getId(), c.FAKTURA_POLOZKA.NAZOV);
        query.addField(FakturaPolozka.MNOZSTVO.getId(), c.FAKTURA_POLOZKA.MNOZSTVO);
        query.addField(FakturaPolozka.MERNA_JEDNOTKA.getId(), c.FAKTURA_POLOZKA.MERNA_JEDNOTKA);
        query.addField(FakturaPolozka.JEDNOTKOVA_CENA.getId(), c.FAKTURA_POLOZKA.JEDNOTKOVA_CENA);
        query.addField(FakturaPolozka.CELKOVA_CENA.getId(), c.FAKTURA_POLOZKA.CELKOVA_CENA);
        query.addOrdering(c.FAKTURA_POLOZKA.NAZOV);
        query.setExpression(SQLExpressionBuilder.get(c.FAKTURA_POLOZKA.FAKTURA).equal(fakturaId));
        ViewCursor cursor = ((EclipseLinkSession) getSessionObject()).execute(query);
        TableContainer container = cursor.readToContainer();        
        
        XClientTable table = new XClientTable(TABLE_POLOZKY);
        table.addColumn(ComponentBuilder.createTableColumn(FakturaPolozka.ID.getId(), FakturaPolozka.ID, getSessionObject()));
        table.addColumn(ComponentBuilder.createTableColumn(FakturaPolozka.NAZOV.getId(), FakturaPolozka.NAZOV, getSessionObject())); 
        table.addColumn(ComponentBuilder.createTableColumn(FakturaPolozka.MNOZSTVO.getId(), FakturaPolozka.MNOZSTVO, getSessionObject()));
        table.addColumn(ComponentBuilder.createTableColumn(FakturaPolozka.MERNA_JEDNOTKA.getId(), FakturaPolozka.MERNA_JEDNOTKA, getSessionObject()));
        table.addColumn(ComponentBuilder.createTableColumn(FakturaPolozka.JEDNOTKOVA_CENA.getId(), FakturaPolozka.JEDNOTKOVA_CENA, getSessionObject()));
        table.addColumn(ComponentBuilder.createTableColumn(FakturaPolozka.CELKOVA_CENA.getId(), FakturaPolozka.CELKOVA_CENA, getSessionObject()));
        table.getColumn(FakturaPolozka.ID.getId()).setVisible(false);
        
        table.setPrimaryKey(FakturaPolozka.ID.getId());
        table.setDataSource(container);
        table.setWidth(600);
        
        XBoxPanel buttonPanel = new XBoxPanel(javax.swing.SwingConstants.HORIZONTAL);                
        buttonPanel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);       
        ServerActionEvent event = new ServerActionEvent();
        event.addReturnValue(TABLE_POLOZKY);
        buttonPanel.add(MDUtilities.createButton(DETAIL_POLOZKY_ACTION, MDHelper.DETAIL_BUTTON, event, getSessionObject()));             
        
        XBorderPanel panel = new XBorderPanel(10, 10);
        panel.setInsets(new Insets(10,10,10,10)); 
        panel.setCenter(table);
        panel.setSouth(buttonPanel);
        return panel;
    }
    
    protected XPanel createZakazkyPanel() throws Exception {        
    	DBSkolenieCatalog c = DBSkolenieCatalog.getInstance();
        SQLQuery query = new SQLQuery();
        query.addTable(new SQLJoinCondition(c.FAKTURA_ZAKAZKA));
        query.addTable(new SQLJoinCondition(c.ZAKAZKA, c.FAKTURA_ZAKAZKA.ZAKAZKA, c.ZAKAZKA.ID));
        query.addField(Zakazka.CISLO.getId(), c.ZAKAZKA.CISLO);
        query.addField(Zakazka.NAZOV.getId(), c.ZAKAZKA.NAZOV);
        query.addOrdering(c.ZAKAZKA.CISLO);
        query.setExpression(SQLExpressionBuilder.get(c.FAKTURA_ZAKAZKA.FAKTURA).equal(fakturaId));
        ViewCursor cursor = ((EclipseLinkSession) getSessionObject()).execute(query);
        TableContainer container = cursor.readToContainer();        

        XClientTable table = new XClientTable("zakazkaTable");
        table.addColumn(ComponentBuilder.createTableColumn(Zakazka.CISLO.getId(), Zakazka.CISLO, getSessionObject())); 
        table.addColumn(ComponentBuilder.createTableColumn(Zakazka.NAZOV.getId(), Zakazka.NAZOV, getSessionObject())); 
        table.setDataSource(container);
        
        XBorderPanel panel = new XBorderPanel(10, 10);
        panel.setInsets(new Insets(10,10,10,10)); 
        panel.setCenter(table);
        return panel;
    }
    
    public void putFormToPack(ServerPack serverPack) throws Exception {
            XBoxPanel buttonPanel = new XBoxPanel(javax.swing.SwingConstants.HORIZONTAL);                
            buttonPanel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);            
            buttonPanel.add(MediatorResourceBuilder.createButton(CANCEL_ACTION, MediatorResourceBuilder.CANCEL_BUTTON, new ServerActionEvent(), MDUtilities.HOME_ICON, getSessionObject()));

            XTabbedPane tabbedPanel = new XTabbedPane("zalozka");
            tabbedPanel.add(new XTabbedPage("zakladneUdaje", translateText(ResourceConstants.ZAKL__UDAJE), createAtributyPanel()));
            tabbedPanel.add(new XTabbedPage("polozky", translateText(ResourceConstants.POLOZKY), createPolozkyPanel()));
            tabbedPanel.add(new XTabbedPage("zakazky", translateText(ResourceConstants.ZAKAZKY), createZakazkyPanel()));
            
            XBorderPanel mainPanel = new XBorderPanel(10, 10);
            mainPanel.setInsets(new Insets(10,10,10,10)); 
            mainPanel.setCenter(tabbedPanel);
            mainPanel.setSouth(buttonPanel);     
          
            XForm form = new XForm();
            form.setTitle(getSessionObject().translateText(ResourceConstants.ODBERATELSKA_FAKTURA));
            form.setPanel(mainPanel);
            
            FormPack formPack = new FormPack(getId(), form);        
            formPack.setValuePack(read());
            serverPack.addFormPack(formPack);
    }       
    
    
    @Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
        if (event.getSourceId().equals(CANCEL_ACTION)) {
           close(pack);
        }else if (event.getSourceId().equals(DETAIL_POLOZKY_ACTION)) {
           Object id = FrameworkUtilities.getSelectedPrimaryKeyFromEvent(event, pack, TABLE_POLOZKY, getSessionObject());
           if (id != null) {
        	   runNext(MDDetailFakturaPolozka.class, new MDDetailFakturaPolozka.Parameter(id), pack);
           }
        }
    }     

public static class Parameters implements MediatorParameters {
    public Object fakturaId;
    
    public Parameters (Object fakturaId) {
        this.fakturaId = fakturaId;
    }
} 
}
