package demo.framework.example.su.fakturacia.md;

import java.awt.Insets;

import demo.framework.example.bo.ciselniky.Zakaznik;
import demo.framework.example.bo.fakturacia.OdberatelskaFaktura;
import demo.framework.example.su.ciselniky.md.MDVyberZakazka;
import demo.framework.example.su.common.MDHelper;
import demo.framework.example.su.fakturacia.uc.UCFakturaPolozka;
import demo.framework.example.su.fakturacia.uc.UCOdberatelskaFaktura;
import demo.framework.example.su.fakturacia.uc.UCOdberatelskaFakturaZakazka;
import demo.framework.example.su.komponenty.ComponentMena;
import demo.framework.example.su.komponenty.ComponentZakaznik;
import demo.framework.translate.ResourceConstants;
import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XClientTable;
import netball.server.component.XCompoundField;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XForm;
import netball.server.component.XPanel;
import netball.server.component.XTabbedPage;
import netball.server.component.XTabbedPane;
import netball.server.component.setting.ClientTableSettings;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientEvent;
import netball.server.event.ClientFocusEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerFocusEvent;
import netball.server.event.ServerMouseEvent;
import netball.server.event.alert.YesNoAlert;
import netball.server.pack.EnabledPack;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.FrameworkUtilities;
import netframework.access.AccessAction;
import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.BasicMediator;
import netframework.mediator.ComponentBuilder;
import netframework.mediator.MDUtilities;
import netframework.mediator.MediatorCallBackObject;
import netframework.mediator.MediatorParameters;
import netframework.mediator.resource.MediatorResourceBuilder;

public class MDOdberatelskaFaktura extends BasicMediator {

    private final String PRIDAJ_ACTION = createId(MediatorResourceBuilder.ADD_BUTTON);
    private final String OPRAVA_ACTION = createId(MediatorResourceBuilder.CORRECT_BUTTON);
    private final String VYMAZ_ACTION = createId(MediatorResourceBuilder.DELETE_BUTTON);
    private final String CANCEL_ACTION = createId(MediatorResourceBuilder.CANCEL_BUTTON);
    private final String POTVRD_ACTION = createId(MediatorResourceBuilder.OK_BUTTON);

    private String VYMAZ_ZAKAZKA_ACTION = createId(MediatorResourceBuilder.DELETE_BUTTON + "zazazka");
    private String PRIDAJ_ZAKAZKA_ACTION = createId(MediatorResourceBuilder.ADD_BUTTON + "zazazka");
    
    private UCOdberatelskaFaktura faktura;
    private boolean isNew;
    private Object vyberZakazkaId;
    
    @Override
    public void init(MediatorParameters parameters, ServerPack pack) throws Exception {
        if (parameters == null) {
           faktura = UCOdberatelskaFaktura.create((EclipseLinkSession) getSessionObject()); 
           isNew = true;             
        }else if (parameters instanceof Parameters) {
           Parameters prmts = (Parameters) parameters;    
           faktura = UCOdberatelskaFaktura.read(prmts.fakturaId, (EclipseLinkSession) getSessionObject());
        }else {
            throw new IllegalArgumentException("Chybny parameter!"); 
        }
        putFormToPack(pack);
    }    

    @Override
    public AccessAction[] getAccessActions() {      
    	return null;
    } 
    
    protected XPanel createAtributyPanel() {
        XDualComponentPanel panel = new XDualComponentPanel();
        panel.setInsets(new Insets(10,10,10,10));
        panel.add(ComponentBuilder.createComponent(UCOdberatelskaFaktura.CISLO, OdberatelskaFaktura.CISLO, getSessionObject()));        
        panel.add(ComponentMena.createComponent(UCOdberatelskaFaktura.MENA_KOD, this));
        
        XCompoundField fieldZakaznik = ComponentZakaznik.createComponent(UCOdberatelskaFaktura.ZAKAZNIK_ICO, this);
        ServerFocusEvent event = new ServerFocusEvent(ServerFocusEvent.FOCUS_LAST_EVENT);
        event.addReturnValue(UCOdberatelskaFaktura.ZAKAZNIK_ICO);
        fieldZakaznik.addFocusEvent(event);
        panel.add(fieldZakaznik);
        
        panel.add(ComponentBuilder.createReadOnlyComponent(UCOdberatelskaFaktura.ZAKAZNIK_NAZOV, Zakaznik.NAZOV, getSessionObject()));
        return panel;
    }
    
    protected XPanel createPolozkyPanel() {
        XBoxPanel buttonPanel = new XBoxPanel(javax.swing.SwingConstants.HORIZONTAL);
        buttonPanel.setSameSizeForAllComponents(true);
        buttonPanel.setGapForAll(5);
        buttonPanel.add(MediatorResourceBuilder.createButton(PRIDAJ_ACTION, MediatorResourceBuilder.ADD_BUTTON, new ServerActionEvent(), MDUtilities.ADD_ICON, getSessionObject()));

        ServerActionEvent event = new ServerActionEvent();
        event.addReturnValue(UCOdberatelskaFaktura.POLOZKY);
        buttonPanel.add(MediatorResourceBuilder.createButton(OPRAVA_ACTION, MediatorResourceBuilder.CORRECT_BUTTON, event, MDUtilities.CORRECT_ICON, getSessionObject()));                
        
        event = new ServerActionEvent();
        event.addReturnValue(UCOdberatelskaFaktura.POLOZKY);
        event.addAlert(new YesNoAlert(getSessionObject().translateText(MDHelper.MESSAGE_VYMAZ_ZAZNAM)));
        buttonPanel.add(MediatorResourceBuilder.createButton(VYMAZ_ACTION, MediatorResourceBuilder.DELETE_BUTTON, event, MDUtilities.DELETE_ICON, getSessionObject()));

        XClientTable table = UCFakturaPolozka.createTableProperty(UCOdberatelskaFaktura.POLOZKY, getSessionObject());
        ServerMouseEvent mouseEvent = new ServerMouseEvent(ServerMouseEvent.MOUSE_CLICKED_EVENT);
        mouseEvent.setDoubleClick(true);
        mouseEvent.addReturnValue(UCOdberatelskaFaktura.POLOZKY);
        table.addMouseEvent(mouseEvent);
        table.setHeight(300);
        table.setWidth(600);
        
        XBorderPanel contentPane = new XBorderPanel(10, 10);
        contentPane.setInsets(new Insets(10,10,10,10)); 
        contentPane.setCenter(table);
        contentPane.setSouth(buttonPanel);     
        return contentPane;
    }    

    protected XPanel createZakazkyPanel() {
        XBoxPanel buttonPanel = new XBoxPanel(javax.swing.SwingConstants.HORIZONTAL);
        buttonPanel.setSameSizeForAllComponents(true);
        buttonPanel.setGapForAll(5);
        buttonPanel.add(MediatorResourceBuilder.createButton(PRIDAJ_ZAKAZKA_ACTION, MediatorResourceBuilder.ADD_BUTTON, MDUtilities.ADD_ICON, getSessionObject()));

        ServerActionEvent event = new ServerActionEvent();
        event.addReturnValue(UCOdberatelskaFaktura.ZAKAZKY);
        event.addAlert(new YesNoAlert(getSessionObject().translateText(MDHelper.MESSAGE_VYMAZ_ZAZNAM)));
        buttonPanel.add(MediatorResourceBuilder.createButton(VYMAZ_ZAKAZKA_ACTION, MediatorResourceBuilder.DELETE_BUTTON, event, MDUtilities.DELETE_ICON, getSessionObject()));

        XClientTable table = UCOdberatelskaFakturaZakazka.createTableProperty(UCOdberatelskaFaktura.ZAKAZKY, getSessionObject());
        table.setHeight(300);
        table.setWidth(600);
        
        XBorderPanel contentPane = new XBorderPanel(10, 10);
        contentPane.setInsets(new Insets(10,10,10,10)); 
        contentPane.setCenter(table);
        contentPane.setSouth(buttonPanel);     
        return contentPane;
    }    
    
    public void putFormToPack(ServerPack serverPack){
        XBoxPanel buttonPanel = new XBoxPanel(javax.swing.SwingConstants.HORIZONTAL);
        buttonPanel.setSameSizeForAllComponents(true);
        buttonPanel.setGapForAll(5);
        buttonPanel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);        
        ServerActionEvent event = new ServerActionEvent();
        event.setReturnAllValues(true);        
        event.setDoControlOfRequiredValues(true);
        buttonPanel.add(MediatorResourceBuilder.createButton(POTVRD_ACTION, MediatorResourceBuilder.OK_BUTTON, event, MDUtilities.OK_ICON, getSessionObject()));
        buttonPanel.add(MediatorResourceBuilder.createButton(CANCEL_ACTION, MediatorResourceBuilder.CANCEL_BUTTON, MDUtilities.HOME_ICON, getSessionObject()));
              
        XTabbedPane tabbedPanel = new XTabbedPane("Zalozka");
        tabbedPanel.add(new XTabbedPage("zakladneUdaje", translateText(ResourceConstants.ZAKL__UDAJE), createAtributyPanel()));
        tabbedPanel.add(new XTabbedPage("polozky", translateText(ResourceConstants.POLOZKY), createPolozkyPanel()));
        tabbedPanel.add(new XTabbedPage("zakazky", translateText(ResourceConstants.ZAKAZKY), createZakazkyPanel()));        

        XBorderPanel contentPane = new XBorderPanel(10, 10);
        contentPane.setInsets(new Insets(10,10,10,10)); 
        contentPane.setCenter(tabbedPanel);
        contentPane.setSouth(buttonPanel);     
        
        XForm form = new XForm();
        form.setTitle(translateText(ResourceConstants.ODBERATELSKA_FAKTURA));
        form.setPanel(contentPane);            
        form.setHotButton(POTVRD_ACTION);
        addEnabledPack(serverPack);
       
        FormPack formPack = new FormPack(getId(), form);             
        formPack.setValuePack(faktura.getValuePack());
        formPack.setEnabledPack(faktura.getEnabledPack());
        formPack.setRequiredPack(faktura.getRequiredPack());     
        serverPack.addFormPack(formPack);
    }       

    private void addEnabledPack(ServerPack serverPack) {
        EnabledPack pack = new EnabledPack();                
        pack.put(VYMAZ_ACTION, faktura.getPolozkaPocet() > 0);
        pack.put(OPRAVA_ACTION, faktura.getPolozkaPocet() > 0);
        pack.put(VYMAZ_ZAKAZKA_ACTION, faktura.getZakazkaPocet() > 0);
        
        UpdatedPack updatePack = new UpdatedPack(getId());
        updatePack.setEnabledPack(pack);
        serverPack.addUpdatedPack(updatePack);
    }
    
    private void addAktualizujPolozkyTable(ServerPack pack, Object key){
        ClientTableSettings tableValuePack = new ClientTableSettings();
        tableValuePack.setDataSource(faktura.createDataContainerPolozka());    
        tableValuePack.setSelectedItem(key);
        tableValuePack.setScrollRowToVisible(key);
        ValuePack valuePack = new ValuePack();
        valuePack.put(UCOdberatelskaFaktura.POLOZKY, tableValuePack);                  
        UpdatedPack updatePack = new UpdatedPack(this.getId());
        updatePack.setValuePack(valuePack);
        pack.addUpdatedPack(updatePack);
        addEnabledPack(pack); 
    }

    private void addAktualizujZakazkayTable(ServerPack pack, Object key){
    	ClientTableSettings tableValuePack = new ClientTableSettings();
        tableValuePack.setDataSource(faktura.createDataContainerZakazka());    
        tableValuePack.setSelectedItem(key);
        tableValuePack.setScrollRowToVisible(key);
        ValuePack valuePack = new ValuePack();
        valuePack.put(UCOdberatelskaFaktura.ZAKAZKY, tableValuePack);                  
        UpdatedPack updatePack = new UpdatedPack(this.getId());
        updatePack.setValuePack(valuePack);
        pack.addUpdatedPack(updatePack);
        addEnabledPack(pack); 
    }
    
    
    @Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
	    try {
        	if (event.getSourceId().equals(VYMAZ_ACTION)) {            
        		Object id = FrameworkUtilities.getSelectedPrimaryKeyFromEvent(event, pack, UCOdberatelskaFaktura.POLOZKY, getSessionObject());
        		if (id != null) {            
        			faktura.deletePolozka(id);
        			addAktualizujPolozkyTable(pack, id);
        		}   
        	}else if (event.getSourceId().equals(PRIDAJ_ACTION)) {
        		this.runNext(MDFakturaPolozka.class, new MDFakturaPolozka.Parameters(faktura.createPolozka()), pack);        	 
        	}else if (event.getSourceId().equals(OPRAVA_ACTION)) {
        		startFakturaPolozkaUpdate(event, pack);
        	}else if (event.getSourceId().equals(POTVRD_ACTION)) {                        
        		faktura.execute(event.getValuePack());  
        		sendCallBack(new CallBack(faktura.getId(), isNew), pack);
        		close(pack);
        	}else if (event.getSourceId().equals(VYMAZ_ZAKAZKA_ACTION)) {            
            	Object id = FrameworkUtilities.getSelectedPrimaryKeyFromEvent(event, pack, UCOdberatelskaFaktura.ZAKAZKY, getSessionObject());
            	if (id != null) {            
            		faktura.deleteZakazka(id);
            		addAktualizujZakazkayTable(pack, id);
            	}   
        	}else if (event.getSourceId().equals(PRIDAJ_ZAKAZKA_ACTION)) {
        		if (vyberZakazkaId == null) {
        		    vyberZakazkaId = this.runNext(MDVyberZakazka.class, null, pack, BasicMediator.HIDE_ON_CLOSE);
        		}else{
        			this.show(vyberZakazkaId, pack);
        		}
        		((MDVyberZakazka) this.getMediator(vyberZakazkaId)).oznacRiadky(faktura.getZakazkyIds(), pack); 
        	}else if (event.getSourceId().equals(CANCEL_ACTION)) {
        		close(pack);
        	}
        }catch(Exception e) {
        	addExceptionToPack(e, pack);
        }                           
    }     
    
	@Override
	public void focusEventExecuted(ClientFocusEvent event, ServerPack pack) {
    	if (event.getSourceId().equals(UCOdberatelskaFaktura.ZAKAZNIK_ICO)) {
    		try {
	    		Object ico = event.getValuePack().getValue(UCOdberatelskaFaktura.ZAKAZNIK_ICO);
	    		UpdatedPack updatePack = new UpdatedPack(this.getId(), this.faktura.setZakaznikIco(ico));
	    		pack.addUpdatedPack(updatePack);
    		}catch(Exception e) {
    			this.addExceptionToPack(e, pack);
    		}
    	}
	}

	private void startFakturaPolozkaUpdate(ClientEvent event, ServerPack pack) {
		Object id = FrameworkUtilities.getSelectedPrimaryKeyFromEvent(event, pack, UCOdberatelskaFaktura.POLOZKY, getSessionObject());
		if (id != null) {
			this.runNext(MDFakturaPolozka.class, new MDFakturaPolozka.Parameters(faktura.getPolozka(id)), pack); 
		}
    }
    
	
	@Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
		if (event.getSourceId().equals(UCOdberatelskaFaktura.POLOZKY)) {
			startFakturaPolozkaUpdate(event, pack);
		}
	}

	@Override
	protected boolean receiveCallBack(BasicMediator mediator,  MediatorCallBackObject obj, ServerPack pack) {
        if (obj instanceof MDFakturaPolozka.CallBack) {
        	MDFakturaPolozka.CallBack callback = (MDFakturaPolozka.CallBack) obj;
       	    addAktualizujPolozkyTable(pack, callback.polozka.getId());
       	    if (callback.polozka.isNew()) {
        		addEnabledPack(pack);
        	}
        }else if (obj instanceof MDVyberZakazka.CallBack) {
        	MDVyberZakazka.CallBack callback = (MDVyberZakazka.CallBack) obj;
        	try {        	    
        		faktura.addZakazkaIds(callback.zakazkyIds);
        		this.addAktualizujZakazkayTable(pack, callback.zakazkyIds[0]);
        	}catch(Exception e) {
        		this.addExceptionToPack(e, pack);
        	}
        }
        return true;
    }        
    
	public static class Parameters implements MediatorParameters {
		
		public Object fakturaId;
    
		public Parameters (Object fakturaId) {
			this.fakturaId = fakturaId;
		}
	}

	public class CallBack implements MediatorCallBackObject {
		
		public Object fakturaId;
		public boolean isNew;
	
		public CallBack(Object fakturaId, boolean isNew) {
			this.fakturaId = fakturaId;
			this.isNew = isNew;
		}
	}     
}
