package demo.framework.example.su.fakturacia.md;


import java.awt.Insets;

import netball.server.component.XDualComponentPanel;
import netball.server.component.XPanel;
import netball.server.component.border.XTitleBorder;
import netball.server.pack.EnabledPack;
import netball.server.pack.RequiredPack;
import netball.server.pack.ServerPack;
import netball.server.pack.ValuePack;
import netframework.mediator.ComponentBuilder;
import netframework.mediator.MDOkCancel;
import netframework.mediator.MediatorCallBackObject;
import netframework.mediator.MediatorParameters;
import demo.framework.example.bo.fakturacia.FakturaPolozka;
import demo.framework.example.su.fakturacia.uc.UCFakturaPolozka;
import demo.framework.translate.ResourceConstants;


public class MDFakturaPolozka extends MDOkCancel {

    private UCFakturaPolozka polozka; 

    @Override
    public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {        
        if (parameters != null && parameters instanceof Parameters) {
        	polozka = ((Parameters) parameters).polozka;
        }else{
        	throw new IllegalArgumentException("Chybny parameter!");
        }
        this.putFormToPack(serverPack);
    }        
    
    @Override
    protected XPanel createPanel(ServerPack pack) throws Exception {
        XDualComponentPanel panel = new XDualComponentPanel();
        panel.setInsets(new Insets(10,10,10,10));
        panel.setBorder(new XTitleBorder());
    	panel.add(ComponentBuilder.createComponent(UCFakturaPolozka.NAZOV, FakturaPolozka.NAZOV, getSessionObject()));
        panel.add(ComponentBuilder.createComponent(UCFakturaPolozka.MNOZSTVO, FakturaPolozka.MNOZSTVO, getSessionObject()));
    	panel.add(ComponentBuilder.createComponent(UCFakturaPolozka.MERNA_JEDNOTKA, FakturaPolozka.MERNA_JEDNOTKA, getSessionObject()));
    	panel.add(ComponentBuilder.createComponent(UCFakturaPolozka.JEDNOTKOVA_CENA, FakturaPolozka.JEDNOTKOVA_CENA, getSessionObject()));
    	return panel;
    }
    
    @Override
    protected void execute(ValuePack valuePack, ServerPack pack) throws Exception {
       polozka.execute(valuePack); 
       if (sendCallBack(new CallBack(polozka), pack))
          close(pack);
    }

    @Override
	protected String getTitleText() {
       return ResourceConstants.POLOZKA_FAKTURY; 
    }    
    
    @Override
    protected ValuePack getValuePack() {
        return polozka.getValuePack();
    }

    @Override
    protected EnabledPack getEnabledPack() {
        return polozka.getEnabledPack();
    }

    @Override
    protected RequiredPack getRequiredPack() {
        return polozka.getRequiredPack();
    }

    public static class Parameters implements MediatorParameters {
    
    	public UCFakturaPolozka polozka;
    
    	public Parameters(UCFakturaPolozka polozka) {
    		this.polozka = polozka;
    	} 
    }

	public static class CallBack implements MediatorCallBackObject{
        
		public UCFakturaPolozka polozka;
    
		public CallBack(UCFakturaPolozka polozka) {
			this.polozka = polozka;
		} 
	}
}
