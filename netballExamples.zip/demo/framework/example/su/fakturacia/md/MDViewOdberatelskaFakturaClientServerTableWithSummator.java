package demo.framework.example.su.fakturacia.md;

import java.math.BigDecimal;

import netball.server.component.XDualComponentPanel;
import netball.server.component.XPanel;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.BasicMediator;
import netframework.mediator.ComponentBuilder;
import netframework.mediator.MDViewClientServerTable;
import netframework.mediator.MDViewFilter;
import netframework.mediator.MediatorCallBackObject;
import netframework.mediator.ViewTableDataSource;
import netframework.mediator.tempcontainer.TemporaryDataContainerSummator;
import netframework.view.ViewRow;
import demo.framework.example.bo.common.Helper;
import demo.framework.example.bo.fakturacia.Faktura;
import demo.framework.example.bo.fakturacia.SumaVMene;
import demo.framework.example.su.common.view.ViewFaktura;
import demo.framework.example.su.fakturacia.uc.UCFaktura;
import demo.framework.translate.ResourceConstants;


public class MDViewOdberatelskaFakturaClientServerTableWithSummator extends MDViewClientServerTable {

    private final String CELKOVA_SUMA = Faktura.CELKOVA_SUMA.getId();  

    @Override
    protected ViewTableDataSource createDataSource() {
        String[] columns = new String[] {ViewFaktura.ID,        
								    	ViewFaktura.DATUM_VYSTAVENIA,
								    	ViewFaktura.ZAKAZNIK_ICO,
								    	ViewFaktura.ZAKAZNIK_NAZOV,
								    	ViewFaktura.OBDOBIE,
								    	ViewFaktura.STAV,
								    	ViewFaktura.CISLO,
								    	ViewFaktura.MENA_KOD,
								    	ViewFaktura.CELKOVA_SUMA};
        return new ViewTableDataSource(new ViewFaktura(), columns, ViewFaktura.ID, ViewFaktura.CISLO);
    }    

    @Override
    protected boolean getInstallFilterHeader() {
    	return true;
    }
    
    @Override
    protected String getTitleText() {
        return ResourceConstants.ODBERATELSKE_FAKTURY;
    }
    

	@Override
	protected Class<? extends MDViewFilter> getFilterMediator() {
		return MDFilterOdberatelskaFaktura.class;
	}
	
	@Override
	protected void insert(ServerPack pack) {
		runNext(MDOdberatelskaFaktura.class, null, pack);
	}

	@Override
	protected void update(ServerPack pack, Object id) throws Exception {
		runNext(MDOdberatelskaFaktura.class, new MDOdberatelskaFaktura.Parameters(id), pack);
	}

	@Override
	protected void delete(Object id) throws Exception {
		UCFaktura.delete(id, (EclipseLinkSession) this.getSessionObject());
	}
	
    @Override
	protected void detail(ServerPack pack, Object id) throws Exception {
    	runNext(MDDetailOdberatelskaFaktura.class, new MDDetailOdberatelskaFaktura.Parameters(id), pack);
	}

	@Override
	protected boolean installDetailButton() {
		return true;
	}
	
	@Override
	protected XPanel createSouthPanel(ServerPack pack) {
		XDualComponentPanel panel = new XDualComponentPanel(); 
		panel.add(ComponentBuilder.createReadOnlyComponent(CELKOVA_SUMA, SumaVMene.SUMA, translateText(/*~~*/"Spolu"), getSessionObject()));  
		return panel;
	}

	@Override
	protected TemporaryDataContainerSummator createSummator() {
		return new CelkovaSumaSumator();
	}

	@Override
    protected boolean receiveCallBack(BasicMediator mediator,  MediatorCallBackObject obj, ServerPack pack) {
        if (obj instanceof MDOdberatelskaFaktura.CallBack) {
        	MDOdberatelskaFaktura.CallBack callBack = (MDOdberatelskaFaktura.CallBack) obj;
        	if (callBack.isNew) {
        		addInsertedPack(callBack.fakturaId, pack);          
        		addButtonEnabledPack(pack);
        	}else {
        		addUpdatedPack(callBack.fakturaId, getSelectedIndex(), pack);          
        	} 
        }else {
        	return super.receiveCallBack(mediator, obj, pack);
        }  
        return false;        
    }     
	
	private class CelkovaSumaSumator implements TemporaryDataContainerSummator {
		
		private BigDecimal spolu = Helper.DEFAULT_VALUE;
		private int colIndex = -1;

		@Override
		public void start() {
			spolu = Helper.DEFAULT_VALUE;
		}

		@Override
		public void add(ViewRow row) {
			if (colIndex == -1)
				colIndex = row.getColumnIndex(ViewFaktura.CELKOVA_SUMA);
			spolu = spolu.add((BigDecimal) row.getValueAt(colIndex));
		}

		@Override
		public void result(ServerPack pack) {
			ValuePack valuePack = new ValuePack();
			valuePack.put(CELKOVA_SUMA, spolu);
			pack.addUpdatedPack(new UpdatedPack(getId(), valuePack)); 
		}
		
	}
}
