package demo.framework.example.su.fakturacia.md;

import netball.server.component.XDualComponentPanel;
import netball.server.component.XPanel;
import netball.server.pack.ValuePack;
import netframework.mediator.MDViewFilter;
import netframework.view.ViewExpression;
import netframework.view.ViewExpressionBuilder;
import demo.framework.example.bo.fakturacia.Faktura;
import demo.framework.example.bo.fakturacia.SumaVMene;
import demo.framework.example.bo.fakturacia.TypFaktury;
import demo.framework.example.su.common.view.ViewFaktura;
import demo.framework.example.su.komponenty.ComponentMena;
import demo.framework.example.su.komponenty.ComponentZakaznik;


public class MDFilterOdberatelskaFaktura extends MDViewFilter {
	
	@Override
	protected XPanel createFilterPanel() { 
		XDualComponentPanel panel = new XDualComponentPanel();
		panel.add(createComponent(ViewFaktura.CISLO, Faktura.CISLO));
		panel.add(createExpressionComponent(ViewFaktura.DATUM_VYSTAVENIA, Faktura.DATUM_VYSTAVENIA));
		panel.add(ComponentZakaznik.createExpressionComponent(ViewFaktura.ZAKAZNIK_ICO, this));
		panel.add(createExpressionComponent(ViewFaktura.OBDOBIE, Faktura.OBDOBIE));
		panel.add(createComponent(ViewFaktura.STAV, Faktura.STAV));
		panel.add(ComponentMena.createExpressionComponent(ViewFaktura.MENA_KOD, this));
		panel.add(createExpressionComponent(ViewFaktura.CELKOVA_SUMA, SumaVMene.SUMA));
	    return panel; 
	}

	@Override
	protected ViewExpression createExpression(ValuePack valuePack) {
		ViewExpression exp = super.createExpression(valuePack);
		ViewExpression exp1 = ViewExpressionBuilder.get(ViewFaktura.TYP).equal(TypFaktury.ODBERATELSKA.getKey());
		exp = exp != null ? exp.and(exp1) : exp1; 
		return exp;
	}
}
