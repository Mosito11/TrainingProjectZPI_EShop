package demo.framework.example.su.fakturacia.md;

import demo.framework.example.bo.ciselniky.Mena;
import demo.framework.example.bo.ciselniky.Zakaznik;
import demo.framework.example.bo.fakturacia.Faktura;
import demo.framework.example.bo.fakturacia.SumaVMene;
import demo.framework.example.su.common.view.ViewFaktura;
import demo.framework.example.su.komponenty.ComponentFaktura;
import demo.framework.example.su.komponenty.ComponentMena1;
import demo.framework.example.su.komponenty.ComponentZakaznik;
import netball.client.ui.jtc.DynamicFilterEditorBuilder;
import netball.server.component.XBorderPanel;
import netball.server.component.XComponent;
import netball.server.component.XDynamicFilter;
import netball.server.component.XPanel;
import netframework.mediator.BasicMediator;
import netframework.mediator.MDViewFilter;


public class MDFilterDodavatelskaFaktura extends MDViewFilter {
	
	private static final String DYNAMIC_FILTER = "DynamicFilter";  
	
	protected XPanel createFilterPanel() {
		XBorderPanel panel = new XBorderPanel();
		XDynamicFilter filter = new XDynamicFilter(DYNAMIC_FILTER);
		filter.addField(ViewFaktura.CISLO, translateText(Faktura.CISLO.getCaption()));
		filter.addField(ViewFaktura.DATUM_VYSTAVENIA, translateText(Faktura.DATUM_VYSTAVENIA.getCaption()));
		filter.addField(ViewFaktura.ZAKAZNIK_ICO, translateText(Zakaznik.ICO.getCaption()));
		filter.addField(ViewFaktura.OBDOBIE, translateText(Faktura.OBDOBIE.getCaption()));
		filter.addField(ViewFaktura.STAV, translateText(Faktura.STAV.getCaption()));
		filter.addField(ViewFaktura.MENA_KOD, translateText(Mena.KOD.getLongCaption()));
		filter.addField(ViewFaktura.CELKOVA_SUMA, translateText(Faktura.CELKOVA_SUMA.getCaption()));
		filter.setHeight(500);
		filter.setWidth(600);
		filter.setEditorBuilder(new EditorBuilder(), this);
		//filter.setCanResetValue(false);
		panel.setCenter(filter);
		return panel;
	}
	
	private class EditorBuilder extends DynamicFilterEditorBuilder {

		@Override
		public XComponent createEditor(Object fieldId, String componentId) throws Exception {
			BasicMediator thisMediator = MDFilterDodavatelskaFaktura.this;
			if (fieldId.equals(ViewFaktura.CISLO)) {
				return ComponentFaktura.createComponent(componentId, thisMediator);
			}else if (fieldId.equals(ViewFaktura.DATUM_VYSTAVENIA)) {
				return createComponent(componentId, Faktura.DATUM_VYSTAVENIA);
			}else if (fieldId.equals(ViewFaktura.ZAKAZNIK_ICO)) {
				return ComponentZakaznik.createExpressionComponent(componentId, thisMediator);
			}else if (fieldId.equals(ViewFaktura.OBDOBIE)) {
				return createComponent(componentId, Faktura.OBDOBIE);
			}else if (fieldId.equals(ViewFaktura.STAV)) {
				return createComponent(componentId, Faktura.STAV);
			}else if (fieldId.equals(ViewFaktura.MENA_KOD)) {
				return ComponentMena1.createComponent(componentId, thisMediator);
			}else if (fieldId.equals(ViewFaktura.CELKOVA_SUMA)) {
				return createExpressionComponent(componentId, SumaVMene.SUMA);
			}
			return null;
		}
	}
}
