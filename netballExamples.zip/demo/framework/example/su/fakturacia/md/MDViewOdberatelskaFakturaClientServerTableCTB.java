package demo.framework.example.su.fakturacia.md;

import java.awt.Color;
import java.util.List;

import demo.framework.example.bo.fakturacia.StavFaktury;
import demo.framework.example.su.common.MDHelper;
import demo.framework.example.su.common.report.ReportDokladOdberatelskaFakturaFlowPanel;
import demo.framework.example.su.common.report.ReportDokladOdberatelskaFakturaSimpleMultiLineGrid;
import demo.framework.example.su.common.report.ReportDokladOdberatelskaFakturaTable;
import demo.framework.example.su.common.view.ViewFaktura;
import demo.framework.example.su.fakturacia.uc.UCFaktura;
import demo.framework.translate.ResourceConstants;
import netball.server.component.XClientServerTable;
import netball.server.component.XComponent;
import netball.server.component.XMenu;
import netball.server.component.XToolBarPopupMenuButton;
import netball.server.component.table.ValueTableRowColorModel;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.alert.YesNoAlert;
import netball.server.pack.EnabledPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.access.AccessControlObject;
import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.BasicMediator;
import netframework.mediator.MDReportPreview;
import netframework.mediator.MDUtilities;
import netframework.mediator.MDViewFilter;
import netframework.mediator.MediatorCallBackObject;
import netframework.mediator.ViewTableDataSource;
import netframework.mediator.ctb.MDViewClientServerTableCTB;


public class MDViewOdberatelskaFakturaClientServerTableCTB extends MDViewClientServerTableCTB {

    private final String STAV_ACTION = createId(MDHelper.STAV_BUTTON.getId());
    private final String TLAC_DOKLADU_ACTION = createId(MDHelper.TLAC_DOKLADU_BUTTON.getId());
    
    private final String TLAC_DOKLADU_FLOW_LAYOUT_PANEL_ACTION = "FlowLayoutPanel";
    private final String TLAC_DOKLADU_SIMPLE_MULTI_LINE_GRID_ACTION = "SimpleMultiLineGrid";
    private final String TLAC_DOKLADU_GRID_ACTION = "Grid";
    
    private StavFakturyActions stavFakturyActions = new StavFakturyActions();

    @Override
    public AccessAction[] getAccessActions() {  
    	AccessAction[] actions = new AccessAction[]{
                new AccessAction(STAV_ACTION, MDHelper.STAV_BUTTON.getText(), MDHelper.STAV_BUTTON.getDescription(), stavFakturyActions),
                new AccessAction(TLAC_DOKLADU_ACTION, MDHelper.TLAC_DOKLADU_BUTTON.getText(), MDHelper.TLAC_DOKLADU_BUTTON.getDescription())
        };
        return MDUtilities.splitAccessActions(super.getAccessActions(), actions);        		 
    }    
    
    @Override
    protected ViewTableDataSource createDataSource() {
        String[] columns = new String[] {ViewFaktura.ID,        
								    	ViewFaktura.DATUM_VYSTAVENIA,
								    	ViewFaktura.ZAKAZNIK_ICO,
								    	ViewFaktura.ZAKAZNIK_NAZOV,
								    	ViewFaktura.OBDOBIE,
								    	ViewFaktura.STAV,
								    	ViewFaktura.CISLO,
								    	ViewFaktura.MENA_KOD,
								    	ViewFaktura.CELKOVA_SUMA};
        return new ViewTableDataSource(new ViewFaktura(), columns, ViewFaktura.ID, ViewFaktura.CISLO);
    }    

   // @Override
    //protected boolean getInstallFilterHeader() {
    	//return true;
    //}
    
    @Override
    protected String getTitleText() {
        return ResourceConstants.ODBERATELSKE_FAKTURY;
    }
    

	@Override
	protected Class<? extends MDViewFilter> getFilterMediator() {
		return MDFilterOdberatelskaFaktura.class;
	}
	
	@Override
	protected void insert(ServerPack pack) {
		runNext(MDOdberatelskaFaktura.class, null, pack);
	}

	@Override
	protected void update(ServerPack pack, Object id) throws Exception {
		runNext(MDOdberatelskaFaktura.class, new MDOdberatelskaFaktura.Parameters(id), pack);
	}

	@Override
	protected void delete(Object id) throws Exception {
		UCFaktura.delete(id, (EclipseLinkSession) this.getSessionObject());
	}
	
    @Override
	protected void detail(ServerPack pack, Object id) throws Exception {
    	runNext(MDDetailOdberatelskaFaktura.class, new MDDetailOdberatelskaFaktura.Parameters(id), pack);
	}

	@Override
	protected boolean installDetailButton() {
		return true;
	}

    @Override
	protected void addButtonsToToolBar(List<XComponent> components) {
    	ServerActionEvent event = new ServerActionEvent(getId());
        event.addReturnValue(TABLE);
        event.addReturnProperty(STAV_ACTION);
        components.add(createStavButton());

        event = new ServerActionEvent(getId());
        event.addReturnValue(TABLE);
        
        components.add(createTlacDokladButton());
        event.addReturnProperty(TLAC_DOKLADU_ACTION);
    }

	private XToolBarPopupMenuButton createStavButton() {
		XToolBarPopupMenuButton button = MDUtilities.createToolBarPopupMenuButton(STAV_ACTION, MDHelper.STAV_BUTTON, null, getSessionObject());

        XMenu menuItem = new XMenu(stavFakturyActions.SPRACOVANA_ACTION, translateText(StavFaktury.SPRACOVANA.getText()));
        ServerActionEvent event = new ServerActionEvent(getId());
        event.addReturnValue(TABLE);
        event.addAlert(new YesNoAlert(translateText(MDHelper.MESSAGE_SPRACOVANY)));                         
        menuItem.addActionEvent(event);
        button.addMenuItem(menuItem);
    	
        menuItem = new XMenu(stavFakturyActions.STORNOVANA_ACTION, translateText(StavFaktury.STORNOVANA.getText()));
        event = new ServerActionEvent(getId());
        event.addReturnValue(TABLE);
        event.addAlert(new YesNoAlert(translateText(MDHelper.MESSAGE_STORNO)));                         
        menuItem.addActionEvent(event);
        button.addMenuItem(menuItem);
    	
    	return button;
    }

    private XToolBarPopupMenuButton createTlacDokladButton() {
    	XToolBarPopupMenuButton button = MDUtilities.createToolBarPopupMenuButton(TLAC_DOKLADU_ACTION, MDHelper.TLAC_DOKLADU_BUTTON, null, getSessionObject());
    	
    	button.addMenuItem(new XMenu(TLAC_DOKLADU_FLOW_LAYOUT_PANEL_ACTION, "FlowLayoutPanel"));
    	button.addMenuItem(new XMenu(TLAC_DOKLADU_SIMPLE_MULTI_LINE_GRID_ACTION, "SimpleMultiLineGrid"));
    	button.addMenuItem(new XMenu(TLAC_DOKLADU_GRID_ACTION, "Grid"));        
        ServerActionEvent event = new ServerActionEvent(getId());
        event.addReturnValue(TABLE);
        List<XMenu> menuItems = button.getMenu();
        for (int i = 0; i < menuItems.size(); i++) {
        	menuItems.get(i).addActionEvent(event);
        }
        return button;
    }
    
    @Override
    protected EnabledPack createButtonEnabledPack() {
        EnabledPack pack = super.createButtonEnabledPack();
        if (getRowCount() > 0) {
            pack.put(STAV_ACTION, true);
            pack.put(TLAC_DOKLADU_ACTION, true);
        }else{
            pack.put(STAV_ACTION, false);
            pack.put(TLAC_DOKLADU_ACTION, false);
        }           
        return pack;  
    }    
    
    @Override
	protected XClientServerTable createTable(ServerPack serverPack) {
    	XClientServerTable table = super.createTable(serverPack);
    	ValueTableRowColorModel tableRowColor = new ValueTableRowColorModel();
        tableRowColor.add(ViewFaktura.STAV, StavFaktury.SPRACOVANA.getKey(), null, Color.blue);
        tableRowColor.add(ViewFaktura.STAV, StavFaktury.STORNOVANA.getKey(), null, Color.red.darker());
        table.setTableCellColorModel(tableRowColor);
        table.setFreezeColumnsAllowed(true);
        table.setVisibilityOfColumnsAllowed(true);
    	return table;
	}

	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {    	 
        try {
        	if (event.getSourceId().equals(TLAC_DOKLADU_SIMPLE_MULTI_LINE_GRID_ACTION)) {
        		int index = getSelectedIndexFromEvent(event, pack);
        		if (index != -1) {
        			ReportDokladOdberatelskaFakturaSimpleMultiLineGrid report = new ReportDokladOdberatelskaFakturaSimpleMultiLineGrid();
        			runNext(MDReportPreview.class, new MDReportPreview.ArrayPageParameters(report.execute(getSessionObject(), getPrimaryKeyValue(index)), report.getPageFormat()), pack);
        		}
        	}else if (event.getSourceId().equals(TLAC_DOKLADU_FLOW_LAYOUT_PANEL_ACTION)) {
        		int index = getSelectedIndexFromEvent(event, pack);
        		if (index != -1) {
        			ReportDokladOdberatelskaFakturaFlowPanel report = new ReportDokladOdberatelskaFakturaFlowPanel();
        			runNext(MDReportPreview.class, new MDReportPreview.ArrayPageParameters(report.execute(getSessionObject(), getPrimaryKeyValue(index)), report.getPageFormat()), pack);
        		}
        	}else if (event.getSourceId().equals(TLAC_DOKLADU_GRID_ACTION)) {
        		int index = getSelectedIndexFromEvent(event, pack);
        		if (index != -1) {
        			ReportDokladOdberatelskaFakturaTable report = new ReportDokladOdberatelskaFakturaTable();
        			runNext(MDReportPreview.class, new MDReportPreview.ArrayPageParameters(report.execute(getSessionObject(), getPrimaryKeyValue(index)), report.getPageFormat()), pack);
        		}
        	}else if (event.getSourceId().equals(stavFakturyActions.SPRACOVANA_ACTION)) {
        		int index = getSelectedIndexFromEvent(event, pack);
        		if (index != -1) {
        			 Object id = getPrimaryKeyValue(index);
               		 UCFaktura.setSpracovana(getPrimaryKeyValue(index), (EclipseLinkSession) this.getSessionObject());
            		 this.addUpdatedPack(id, index, pack);
        		}
        	}else if (event.getSourceId().equals(stavFakturyActions.STORNOVANA_ACTION)) {
        		int index = getSelectedIndexFromEvent(event, pack);
        		if (index != -1) {
        			 Object id = getPrimaryKeyValue(index);
                	 UCFaktura.setStornovana(id, (EclipseLinkSession) this.getSessionObject());
               	     this.addUpdatedPack(id, index, pack);
        		}
        	}else{
        		super.actionEventExecuted(event, pack);        		
        	}    
        }catch(Exception e) {
        	addExceptionToPack(e, pack);
        }                           
    }    
 	
	@Override
    protected boolean receiveCallBack(BasicMediator mediator,  MediatorCallBackObject obj, ServerPack pack) {
        if (obj instanceof MDOdberatelskaFaktura.CallBack) {
        	MDOdberatelskaFaktura.CallBack callBack = (MDOdberatelskaFaktura.CallBack) obj;
        	if (callBack.isNew) {
        		addInsertedPack(callBack.fakturaId, pack);          
        		addButtonEnabledPack(pack);
        	}else {
        		addUpdatedPack(callBack.fakturaId, getSelectedIndex(), pack);          
        	} 
        }else {
        	return super.receiveCallBack(mediator, obj, pack);
        }  
        return false;        
    }     
    
	private class StavFakturyActions implements AccessControlObject {
		
		final String SPRACOVANA_ACTION = createId(StavFaktury.SPRACOVANA.getKey());
		final String STORNOVANA_ACTION = createId(StavFaktury.STORNOVANA.getKey());
		
	   	public AccessAction[] getAccessActions() {
	   		return new AccessAction[] {
	   				new AccessAction(SPRACOVANA_ACTION, StavFaktury.SPRACOVANA.getText()),
	   				new AccessAction(STORNOVANA_ACTION, StavFaktury.STORNOVANA.getText()),
	   		};
	   	}
    }
}
