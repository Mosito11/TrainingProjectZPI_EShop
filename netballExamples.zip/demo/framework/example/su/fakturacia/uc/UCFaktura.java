package demo.framework.example.su.fakturacia.uc;

import java.sql.Date;

import netball.server.component.table.TableContainer;
import netball.server.pack.EnabledPack;
import netball.server.pack.Item;
import netball.server.pack.RequiredPack;
import netball.server.pack.ValuePack;
import netframework.bo.PersistentObject;
import netframework.eclipselink.EclipseLinkSession;
import netframework.eclipselink.InsertedItemSession;
import netframework.eclipselink.ModifiedItemSession;
import netframework.eclipselink.UCPersistentObject;
import netframework.eclipselink.UpdatedItemSession;

import org.eclipse.persistence.zpi.sessions.UnitOfWork;

import demo.framework.example.bo.ciselniky.Mena;
import demo.framework.example.bo.ciselniky.Zakaznik;
import demo.framework.example.bo.common.Helper;
import demo.framework.example.bo.fakturacia.Faktura;
import demo.framework.example.bo.fakturacia.FakturaPolozka;
import demo.framework.example.bo.fakturacia.SumaVMene;
import demo.framework.example.bo.obmedzenie.Obmedzenia;


public abstract class UCFaktura extends UCPersistentObject {

	public static final String MENA_KOD = Mena.KOD.getId();
	public static final String ZAKAZNIK_ICO = Zakaznik.ICO.getId();
	public static final String ZAKAZNIK_NAZOV = Zakaznik.NAZOV.getId();
	public static final String POLOZKY = Faktura.POLOZKY.getId();
	public static final String CISLO = Faktura.CISLO.getId();
	
    protected UCFaktura(Faktura faktura, EclipseLinkSession session) {
    	super(faktura, session);
    	// Overenie ci je mozne editovat a pridavat fakturu
    	Helper.getObmedzenia(session).getTypFaktury().isMozneEditovat(faktura, session);
    }
    
    @Override
    protected void setValuePack(ValuePack packet) throws Exception { 
        if (packet == null)
           return;
        EnabledPack enabledPack = getEnabledPack(); 
        for (int i = 0; i < packet.size(); i++) {
           Item item = packet.get(i);                
           Object id = item.getId();
           Object value = item.getValue();                
           if (enabledPack != null && !enabledPack.isEnabled(id))
              continue;
          Faktura faktura = (Faktura) getObject(); 
          if (id.equals(CISLO)) {
        	    faktura.setCislo((String) value);
          }else if (id.equals(MENA_KOD)) {
	            if (faktura.getMena() == null || !(faktura.getMena().getKod().equals(value))) {
	            	Mena mena = (Mena) Helper.readObject(value, Mena.KOD.getLongCaption(), Mena.class, Mena.KOD.getName(), getUnitOfWork(), getSessionObject());
	              	faktura.setMena(mena);
	            }
           }else if (id.equals(ZAKAZNIK_ICO)) {
	            if (faktura.getZakaznik() == null || !(faktura.getZakaznik().getIco().equals(value))) {
	            	Zakaznik zakaznik = (Zakaznik) Helper.readObject(value, Zakaznik.ICO.getLongCaption(), Zakaznik.class, Zakaznik.ICO.getName(), getUnitOfWork(), getSessionObject());
	              	faktura.setZakaznik(zakaznik);
	            }
           }   
        }   
    }
    
    @Override
    public ValuePack getValuePack() {
    	Faktura faktura = (Faktura) getObject();
        ValuePack packet = new ValuePack();
        packet.put(CISLO, faktura.getCislo());
    	packet.put(MENA_KOD, faktura.getMena() != null ? faktura.getMena().getKod() : null);
    	packet.put(ZAKAZNIK_ICO, faktura.getZakaznik() != null ? faktura.getZakaznik().getIco() : null);
    	packet.put(ZAKAZNIK_NAZOV, faktura.getZakaznik() != null ? faktura.getZakaznik().getNazov() : null);
    	packet.put(POLOZKY, this.createDataContainerPolozka());
    	packet.put(CISLO, faktura.getCislo());
        return packet;
    }
    
    @Override
    public RequiredPack getRequiredPack() {
        RequiredPack packet = new RequiredPack();
        packet.put(CISLO, Faktura.CISLO.isRequired());
    	packet.put(MENA_KOD, Faktura.CELKOVA_SUMA.getAttribute(SumaVMene.SUMA.getId()).isRequired());
    	packet.put(ZAKAZNIK_ICO, Faktura.ZAKAZNIK.isRequired());
        return packet;
    } 
    
    @Override
    public void validate() throws Exception {
    	Faktura faktura = (Faktura) getObject();
    	if (!faktura.isPersisted()) {
    		faktura.setDatumVystavenia(new Date(System.currentTimeMillis()));
    	}
    	faktura.validate(getSessionObject());
    }    
    
    @Override
    public EnabledPack getEnabledPack() {
    	EnabledPack packet = new EnabledPack();
    	packet.put(ZAKAZNIK_NAZOV, false);
        return packet;
    }
	
	public ValuePack setZakaznikIco(Object zakaznikIco) throws Exception {
		Faktura faktura = (Faktura) getObject();
  	    Zakaznik zakaznik = faktura.getZakaznik();
        if (zakaznik == null || !(zakaznik.getIco().equals(zakaznikIco))) {        
           ValuePack packet = new ValuePack();
           packet.put(ZAKAZNIK_ICO, zakaznikIco);
           setValuePack(packet);
           packet.clear();
           zakaznik = faktura.getZakaznik();
           if (zakaznik != null) {
	       	  packet.put(ZAKAZNIK_NAZOV, zakaznik.getNazov());
           }else{
        	  packet.put(ZAKAZNIK_NAZOV, null);
           }
           return packet;
        }
        return null;
    } 
    
    // -------------------- zaciatok prace s polozkami ------------------------------------------------

    public UCFakturaPolozka getPolozka(Object id) {
    	Faktura faktura = (Faktura) getObject();
        Object polozka = ModifiedItemSession.getItem(faktura.getPolozky(), id);
        return new UCFakturaPolozka(new UpdatedItemSession(polozka, getUnitOfWork(), getSessionObject()));
     }  
    
    public void deletePolozka(Object id) throws Exception {
    	Faktura faktura = (Faktura) getObject();
        int index = ModifiedItemSession.getItemIndex(faktura.getPolozky(), id);
        faktura.getPolozky().remove(index);
    }
   
    public UCFakturaPolozka createPolozka() throws Exception {
    	Faktura faktura = (Faktura) getObject();
        return new UCFakturaPolozka(new InsertedItemSession(faktura, FakturaPolozka.class, Faktura.POLOZKY.getName(), getUnitOfWork(), getSessionObject()));
    }
    
    public int getPolozkaPocet() {
       return ((Faktura) getObject()).getPolozky().size();
    }

    public TableContainer createDataContainerPolozka() {
       return UCFakturaPolozka.createDataContainer(((Faktura) getObject()).getPolozky());
    }
    
    // -------------------- koniec prace s polozkami ------------------------------------------------
    
    public static void setSpracovana(Object id, EclipseLinkSession session) throws Exception {      
        UnitOfWork work = session.getSession().acquireUnitOfWork();
        Faktura faktura = (Faktura) read(Faktura.class, id, session);
        faktura = (Faktura) work.registerObject(faktura);
        faktura.setSpracovana(session);
        work.commit();
    }
    
    public static void setStornovana(Object id, EclipseLinkSession session) throws Exception {      
        UnitOfWork work = session.getSession().acquireUnitOfWork();
        Faktura faktura = (Faktura) read(Faktura.class, id, session);
        faktura = (Faktura) work.registerObject(faktura);
        faktura.setStornovana(session);
        work.commit();
    }
    
    // vymaze
    public static void delete(Object id, EclipseLinkSession session) throws Exception {
    	DeleteController controller = new DeleteController() {
			@Override
			public void delete(PersistentObject object,	EclipseLinkSession session, UnitOfWork uow)	throws Exception {
				((Faktura) object).delete(session);
			}
    	};  
        delete(Faktura.class, id, controller, session);
    }
}          

