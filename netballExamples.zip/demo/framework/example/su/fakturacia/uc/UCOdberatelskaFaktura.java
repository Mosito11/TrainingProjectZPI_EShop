package demo.framework.example.su.fakturacia.uc;


import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import netball.server.component.table.TableContainer;
import netball.server.pack.ValuePack;
import netframework.FrameworkUtilities;
import netframework.eclipselink.EclipseLinkSession;

import org.eclipse.persistence.zpi.expressions.Expression;
import org.eclipse.persistence.zpi.expressions.ExpressionBuilder;

import demo.framework.example.bo.ciselniky.Zakazka;
import demo.framework.example.bo.fakturacia.DodavatelskaFaktura;
import demo.framework.example.bo.fakturacia.OdberatelskaFaktura;
import demo.framework.example.bo.fakturacia.StavFaktury;


public class UCOdberatelskaFaktura extends UCFaktura {
	
	public static final String ZAKAZKY = OdberatelskaFaktura.ZAKAZKY.getId();
	
	private UCOdberatelskaFaktura(OdberatelskaFaktura faktura, EclipseLinkSession session) {
		 super(faktura, session);
	}

	@Override
    public ValuePack getValuePack() {
        ValuePack packet = super.getValuePack();
        packet.put(ZAKAZKY, createDataContainerZakazka());
        return packet;
    }	
	
   // ------------------------- zakazky start ----------------------------------------------------------
    
	public void deleteZakazka(Object id) throws Exception {
		OdberatelskaFaktura odberatelskaFaktura = (OdberatelskaFaktura) getObject();
	    int index = FrameworkUtilities.getItemIndex(odberatelskaFaktura.getZakazky(), id);
	    odberatelskaFaktura.getZakazky().remove(index);        
	}
	     
	public TableContainer createDataContainerZakazka(){
		OdberatelskaFaktura odberatelskaFaktura = (OdberatelskaFaktura) getObject();
		return UCOdberatelskaFakturaZakazka.createDataContainer(odberatelskaFaktura.getZakazky());
	}
	 
	public int getZakazkaPocet() {
		OdberatelskaFaktura odberatelskaFaktura = (OdberatelskaFaktura) getObject();
	    return odberatelskaFaktura.getZakazky().size();
	}
	
	public void addZakazkaIds(Object[] ids) throws Exception {
		if (ids == null)
			return;
		OdberatelskaFaktura odberatelskaFaktura = (OdberatelskaFaktura) getObject();
		ExpressionBuilder builder = null; 
		for (int i = 0; i < ids.length; i++) {
		   boolean found = false;
		   Vector<Zakazka> zakazky = odberatelskaFaktura.getZakazky();
		   for (int k = 0; k < zakazky.size(); k++) {
			   Zakazka zakazka = zakazky.get(k);
			   if (zakazka.getId().equals(ids[i])) {
				   found = true;
				   break;
			   }
		   }
		   if (!found) {
			   if (builder == null)
				   builder = new ExpressionBuilder();
			   Expression exp = builder.get(Zakazka.ID.getName()).equal(ids[i]);
			   Zakazka zakazka = (Zakazka) getUnitOfWork().readObject(Zakazka.class, exp);
			   if (zakazka != null) {
				   odberatelskaFaktura.getZakazky().add(zakazka);
			   }
		   }
		}
	}

	public List<Object> getZakazkyIds() {	   	
		OdberatelskaFaktura odberatelskaFaktura = (OdberatelskaFaktura) getObject();
	    List<Zakazka> zakazky = odberatelskaFaktura.getZakazky();
		List<Object> ids = new ArrayList<Object>(zakazky.size());
		for (int k = 0; k < zakazky.size(); k++) {
		    Zakazka zakazka = zakazky.get(k);
			ids.add(zakazka.getId());
		}
		return ids;
	}
	
    // ------------------------- zakazky koniec ------------------------------------------------------------
	
    public static UCOdberatelskaFaktura create(EclipseLinkSession session) {
        return new UCOdberatelskaFaktura(new OdberatelskaFaktura(), session);
    }

    // nacita 
    public static UCOdberatelskaFaktura read(Object id, EclipseLinkSession session) throws Exception {
    	OdberatelskaFaktura faktura = (OdberatelskaFaktura) read(OdberatelskaFaktura.class, id, session);
    	if (!faktura.getStav().equals(StavFaktury.ROZPRACOVANA))
    		throw new IllegalArgumentException(/*~~*/"Len rozpracovanu fakturu je mozne modifikovat.");
        return new UCOdberatelskaFaktura(faktura, session);
    }   
}
