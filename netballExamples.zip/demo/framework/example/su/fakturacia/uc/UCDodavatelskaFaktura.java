package demo.framework.example.su.fakturacia.uc;

import netframework.eclipselink.EclipseLinkSession;
import demo.framework.example.bo.fakturacia.DodavatelskaFaktura;
import demo.framework.example.bo.fakturacia.StavFaktury;


public class UCDodavatelskaFaktura extends UCFaktura {
	
	private UCDodavatelskaFaktura(DodavatelskaFaktura faktura, EclipseLinkSession session) {
		 super(faktura, session);
	}
	
    public static UCDodavatelskaFaktura create(EclipseLinkSession session) {
        return new UCDodavatelskaFaktura(new DodavatelskaFaktura(), session);
    }

    // nacita 
    public static UCDodavatelskaFaktura read(Object id, EclipseLinkSession session) throws Exception {
    	DodavatelskaFaktura faktura = (DodavatelskaFaktura) read(DodavatelskaFaktura.class, id, session);
    	if (!faktura.getStav().equals(StavFaktury.ROZPRACOVANA))
    		throw new IllegalArgumentException(/*~~*/"Len rozpracovanu fakturu je mozne modifikovat.");
        return new UCDodavatelskaFaktura(faktura, session);
    }   
}
