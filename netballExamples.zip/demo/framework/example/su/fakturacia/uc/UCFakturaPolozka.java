package demo.framework.example.su.fakturacia.uc;

import java.math.BigDecimal;
import java.util.Vector;

import netball.server.comparator.StringComparator;
import netball.server.component.XClientTable;
import netball.server.component.table.TableContainer;
import netball.server.pack.EnabledPack;
import netball.server.pack.Item;
import netball.server.pack.RequiredPack;
import netball.server.pack.ValuePack;
import netframework.eclipselink.InsertedItemSession;
import netframework.eclipselink.UCPersistentObjectItem;
import netframework.eclipselink.UpdatedItemSession;
import netframework.mediator.ComponentBuilder;
import netframework.mediator.SessionObject;
import demo.framework.example.bo.fakturacia.Faktura;
import demo.framework.example.bo.fakturacia.FakturaPolozka;


public class UCFakturaPolozka extends UCPersistentObjectItem {
	
	public static final String MNOZSTVO = FakturaPolozka.MNOZSTVO.getId();
	public static final String JEDNOTKOVA_CENA = FakturaPolozka.JEDNOTKOVA_CENA.getId();
	public static final String MERNA_JEDNOTKA = FakturaPolozka.MERNA_JEDNOTKA.getId();
	public static final String NAZOV = FakturaPolozka.NAZOV.getId();
	
    public UCFakturaPolozka(InsertedItemSession modifyObject) {
    	super(modifyObject);
        FakturaPolozka polozka = (FakturaPolozka) getObject();
        Faktura faktura = (Faktura) modifyObject.getCloneObject();
        polozka.setFaktura(faktura);
    }
    
    public UCFakturaPolozka(UpdatedItemSession modifyObject) {
    	super(modifyObject);
    }

    @Override
    protected void setValuePack(ValuePack packet) throws Exception { 
        if (packet == null)
        	return;
        EnabledPack enabledPack = getEnabledPack(); 
        for (int i = 0; i < packet.size(); i++) {
        	Item item = packet.get(i);                
        	Object id = item.getId();
        	Object value = item.getValue();                
        	if (enabledPack != null && !enabledPack.isEnabled(id))
        		continue;
        	FakturaPolozka polozka = (FakturaPolozka) getObject();
        	if(id.equals(MNOZSTVO)) {
        		 polozka.setMnozstvo((BigDecimal) value);
        	}else if(id.equals(JEDNOTKOVA_CENA)) {
        		 polozka.setJednotkovaCena((BigDecimal) value);
        	}else if(id.equals(MERNA_JEDNOTKA)) {
        		polozka.setMernaJednotka((String) value);
        	}else if(id.equals(NAZOV)) {
        		polozka.setNazov((String) value);
        	}
        }   
    }
    
    @Override
    public ValuePack getValuePack() {
    	FakturaPolozka polozka = (FakturaPolozka) getObject();
        ValuePack packet = new ValuePack();
    	packet.put(MNOZSTVO, polozka.getMnozstvo());
    	packet.put(JEDNOTKOVA_CENA, polozka.getJednotkovaCena());
    	packet.put(MERNA_JEDNOTKA, polozka.getMernaJednotka());
    	packet.put(NAZOV, polozka.getNazov());
        return packet;
    }

    @Override
    public EnabledPack getEnabledPack() {
    	return null;
    }
	
    @Override
    public RequiredPack getRequiredPack() {
    	RequiredPack packet = new RequiredPack();
    	packet.put(MNOZSTVO, FakturaPolozka.MNOZSTVO.isRequired()); 
    	packet.put(JEDNOTKOVA_CENA, FakturaPolozka.JEDNOTKOVA_CENA.isRequired());
    	packet.put(MERNA_JEDNOTKA, FakturaPolozka.MERNA_JEDNOTKA.isRequired());
    	packet.put(NAZOV, FakturaPolozka.NAZOV.isRequired());
    	return packet;
    }     
    
    @Override
	public void validate() throws Exception {
    	FakturaPolozka polozka = (FakturaPolozka) getObject();
        polozka.validate(getSession().getSessionObject());
        if (getSession().isNew()) {
            polozka.getFaktura().getPolozky().add(polozka);
        }   
	}
     
	public static XClientTable createTableProperty(String id, SessionObject session) {
        XClientTable table = new XClientTable(id);
        table.addColumn(ComponentBuilder.createTableColumn(FakturaPolozka.ID.getId(), FakturaPolozka.ID, session));
        table.addColumn(ComponentBuilder.createTableColumn(FakturaPolozka.MNOZSTVO.getId(), FakturaPolozka.MNOZSTVO, true, session));
        table.addColumn(ComponentBuilder.createTableColumn(FakturaPolozka.JEDNOTKOVA_CENA.getId(), FakturaPolozka.JEDNOTKOVA_CENA, true, session));
        table.addColumn(ComponentBuilder.createTableColumn(FakturaPolozka.MERNA_JEDNOTKA.getId(), FakturaPolozka.MERNA_JEDNOTKA, true, session));
        table.addColumn(ComponentBuilder.createTableColumn(FakturaPolozka.NAZOV.getId(), FakturaPolozka.NAZOV, true, session));
        table.addColumn(ComponentBuilder.createTableColumn(FakturaPolozka.CELKOVA_CENA.getId(), FakturaPolozka.CELKOVA_CENA, true, session));
        table.getColumn(FakturaPolozka.ID.getId()).setVisible(false);
        table.setPrimaryKey(FakturaPolozka.ID.getId());
        return table;
    }
	
	public static TableContainer createDataContainer(Vector<FakturaPolozka> polozky) {
   	    String columns[] = new String[] {FakturaPolozka.ID.getId(),
								        FakturaPolozka.MNOZSTVO.getId(),
								        FakturaPolozka.JEDNOTKOVA_CENA.getId(),
								        FakturaPolozka.MERNA_JEDNOTKA.getId(),
								        FakturaPolozka.NAZOV.getId(),
								        FakturaPolozka.CELKOVA_CENA.getId()};
   	    TableContainer container = new TableContainer(columns);  
		// naplni kontajner
		for (int i = 0; i < polozky.size(); i++) {
		   FakturaPolozka polozka = polozky.get(i);
		   container.addNewRow();
		   int rowIndex = container.getRowCount() - 1;
		   container.setValueAt(new Integer(polozka.hashCode()), rowIndex,  FakturaPolozka.ID.getId());
		   container.setValueAt(polozka.getMnozstvo(), rowIndex, FakturaPolozka.MNOZSTVO.getId());
		   container.setValueAt(polozka.getJednotkovaCena(), rowIndex, FakturaPolozka.JEDNOTKOVA_CENA.getId());
		   container.setValueAt(polozka.getMernaJednotka(), rowIndex, FakturaPolozka.MERNA_JEDNOTKA.getId());
		   container.setValueAt(polozka.getNazov(), rowIndex, FakturaPolozka.NAZOV.getId());
		   container.setValueAt(polozka.getCelkovaCena(), rowIndex, FakturaPolozka.CELKOVA_CENA.getId());
		}
		int columnIndex = container.getColumnIndex(FakturaPolozka.NAZOV.getId());
		container.sort(columnIndex, true, new StringComparator());
		return container;
	}
}
