package demo.framework.example.su.fakturacia.uc;

import java.util.Vector;

import netball.server.comparator.StringComparator;
import netball.server.component.XClientTable;
import netball.server.component.table.TableContainer;
import netframework.mediator.ComponentBuilder;
import netframework.mediator.SessionObject;
import demo.framework.example.bo.ciselniky.Zakazka;

public class UCOdberatelskaFakturaZakazka {
	
		public static XClientTable createTableProperty(String id, SessionObject session) {
			XClientTable table = new XClientTable(id);
	        table.addColumn(ComponentBuilder.createTableColumn(Zakazka.ID.getId(), Zakazka.ID, session));
	        table.addColumn(ComponentBuilder.createTableColumn(Zakazka.CISLO.getId(), Zakazka.CISLO, session));
	        table.addColumn(ComponentBuilder.createTableColumn(Zakazka.NAZOV.getId(), Zakazka.NAZOV, session));
	        table.getColumn(Zakazka.ID.getId()).setVisible(false);
	        table.setPrimaryKey(Zakazka.ID.getId());
	        return table;
	    }
		
		public static TableContainer createDataContainer(Vector<Zakazka> zakazky) {
	   	    String columns[] = new String[] {Zakazka.ID.getId(),
	   	    		                         Zakazka.CISLO.getId(),
	   	    		                         Zakazka.NAZOV.getId()};
	   	    TableContainer container = new TableContainer(columns);
			// naplni kontajner
			for (int i = 0; i < zakazky.size(); i++) {
			   Zakazka zakazka = zakazky.get(i);
			   container.addNewRow();
			   int rowIndex = container.getRowCount() - 1;
			   container.setValueAt(zakazka.getId(), rowIndex, Zakazka.ID.getId());
			   container.setValueAt(zakazka.getCislo(), rowIndex, Zakazka.CISLO.getId());
			   container.setValueAt(zakazka.getNazov(), rowIndex, Zakazka.NAZOV.getId());
			}
			int columnIndex = container.getColumnIndex(Zakazka.CISLO.getId());
			container.sort(columnIndex, true, new StringComparator());
			return container;
		}
}
