package demo.framework.example.su.obmedzenie.uc;

import netball.server.pack.Item;
import netball.server.pack.ValuePack;
import netframework.eclipselink.EclipseLinkSession;
import netframework.eclipselink.UCPersistentObject;
import zelpo.eclipselink.autorizacia.PridelenieUzivatela;
import zelpo.eclipselink.autorizacia.uc.UCPridelenieUzivatela;
import demo.framework.example.bo.obmedzenie.Obmedzenia;

public class UCObmedzenieVerzia2 extends UCPridelenieUzivatela {

	public static final String TYP_FAKTURY = Obmedzenia.TYP_FAKTURY.getId();
	
    protected UCObmedzenieVerzia2(PridelenieUzivatela pridelenieUzivatela, EclipseLinkSession session) {
		super(pridelenieUzivatela, session);
	}
    
	@Override
	protected void setValuePack(ValuePack pack) throws Exception {
	   super.setValuePack(pack);
       PridelenieUzivatela pridelenieUzivatela = (PridelenieUzivatela) getObject();
       Obmedzenia obmedzenia = new Obmedzenia();
       for(int i = 0; i < pack.size(); i++){
           Item item = pack.get(i);
           Object id = item.getId();
           Object value = item.getValue();
           if (id.equals(Obmedzenia.TYP_FAKTURY.getId())) {
        	   obmedzenia.getTypFaktury().setString((String) value);
           }
       }
	   pridelenieUzivatela.getUzivatelskeObmedzenie().setObmedzenie(obmedzenia.convertToString());
    }    
  
	@Override
	public ValuePack getValuePack() {
		ValuePack pack = super.getValuePack();
		PridelenieUzivatela pridelenieUzivatela = (PridelenieUzivatela) getObject();
		try {
			Obmedzenia obmedzenia = Obmedzenia.parse(getSessionObject().getSession(), pridelenieUzivatela.getUzivatelskeObmedzenie().getObmedzenie());
	        pack.put(Obmedzenia.TYP_FAKTURY.getId(), obmedzenia.getTypFaktury().getString());
	        return pack;    
		} catch (Exception e) {
			e.printStackTrace();
		}
        return null;
    }        
	
	public static UCObmedzenieVerzia2 read(Object pridelenieUzivatelaId, EclipseLinkSession session) throws Exception {
		PridelenieUzivatela priradenie = (PridelenieUzivatela) UCPersistentObject.read(PridelenieUzivatela.class, pridelenieUzivatelaId, session);
		return new UCObmedzenieVerzia2(priradenie, session);
	}
	
    // vytvori novy
    public static UCObmedzenieVerzia2 create(EclipseLinkSession session) {
    	return new UCObmedzenieVerzia2(new PridelenieUzivatela(), session);
    }
}
