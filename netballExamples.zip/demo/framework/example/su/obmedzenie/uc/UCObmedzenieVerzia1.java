package demo.framework.example.su.obmedzenie.uc;

import netball.server.pack.EnabledPack;
import netball.server.pack.Item;
import netball.server.pack.RequiredPack;
import netball.server.pack.ValuePack;
import netframework.eclipselink.EclipseLinkSession;
import netframework.eclipselink.UCPersistentObject;
import zelpo.eclipselink.autorizacia.PridelenieUzivatela;
import zelpo.eclipselink.autorizacia.UzivatelskeObmedzenie;
import demo.framework.example.bo.obmedzenie.Obmedzenia;


public class UCObmedzenieVerzia1 extends UCPersistentObject {

	public static final String TYP_FAKTURY = Obmedzenia.TYP_FAKTURY.getId();
	private Object priradenieId;
	
    protected UCObmedzenieVerzia1(UzivatelskeObmedzenie obmedzenie, EclipseLinkSession session) {
		super(obmedzenie, session);
	}

    public Object getPriradenieId() {
    	return priradenieId;
    }
    
	@Override
	protected void setValuePack(ValuePack packet) throws Exception {
       Obmedzenia restriction = new Obmedzenia();
       UzivatelskeObmedzenie obmedzenie = (UzivatelskeObmedzenie) getObject();
       for(int i = 0; i < packet.size(); i++){
           Item item = packet.get(i);
           Object id = item.getId();
           Object value = item.getValue();
           if (id.equals(Obmedzenia.TYP_FAKTURY.getId())) {
        	   restriction.getTypFaktury().setString((String) value);
           }
       }
	   obmedzenie.setObmedzenie(restriction.convertToString());
    }    
  
	@Override
	public ValuePack getValuePack() {
		UzivatelskeObmedzenie obmedzenie = (UzivatelskeObmedzenie) getObject();
		try {
			Obmedzenia restriction = Obmedzenia.parse(getSessionObject().getSession(), obmedzenie.getObmedzenie());
			ValuePack pack = new ValuePack();
	        pack.put(Obmedzenia.TYP_FAKTURY.getId(), restriction.getTypFaktury().getString());
	        return pack;    
		} catch (Exception e) {
			e.printStackTrace();
		}
        return null;
    }        
	
	@Override
	public EnabledPack getEnabledPack() {
		return null;
	}
	
	@Override
	public RequiredPack getRequiredPack() {
		return null;
	}
	
	@Override
	public void validate() throws Exception {
	}
	
	public static UCObmedzenieVerzia1 read(Object pridelenieUzivatelaId, EclipseLinkSession session) throws Exception {
		PridelenieUzivatela priradenie = (PridelenieUzivatela) UCPersistentObject.read(PridelenieUzivatela.class, pridelenieUzivatelaId, session);
		UCObmedzenieVerzia1 uc = new UCObmedzenieVerzia1(priradenie.getUzivatelskeObmedzenie(), session);
		uc.priradenieId = pridelenieUzivatelaId;
		return uc;
	}
}
