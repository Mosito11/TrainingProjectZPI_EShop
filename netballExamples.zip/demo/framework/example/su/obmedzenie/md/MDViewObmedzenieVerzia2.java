package demo.framework.example.su.obmedzenie.md;

import netball.server.pack.ServerPack;
import netframework.eclipselink.EclipseLinkSession;
import zelpo.eclipselink.autorizacia.md.MDPridelenieUzivatela;
import zelpo.eclipselink.autorizacia.md.MDViewPridelenieUzivatela;
import demo.framework.example.su.obmedzenie.uc.UCObmedzenieVerzia2;

public class MDViewObmedzenieVerzia2 extends MDViewPridelenieUzivatela {

    @Override
    protected void insert(ServerPack pack) {
        MDPridelenieUzivatela.Parameters prmts = new MDPridelenieUzivatela.Parameters(UCObmedzenieVerzia2.create((EclipseLinkSession) getSessionObject()));
        runNext(MDObmedzenieVerzia2.class, prmts, pack);
    }    

    @Override
    protected void update(ServerPack pack, Object id) throws Exception {          
    	runNext(MDObmedzenieVerzia2.class, new MDPridelenieUzivatela.Parameters(UCObmedzenieVerzia2.read(id, (EclipseLinkSession) getSessionObject())), pack);
    }
}
