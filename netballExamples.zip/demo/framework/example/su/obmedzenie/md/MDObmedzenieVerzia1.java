package demo.framework.example.su.obmedzenie.md;

import java.awt.Insets;

import netball.server.component.XDualComponentPanel;
import netball.server.component.XPanel;
import netball.server.component.border.XTitleBorder;
import netball.server.pack.ServerPack;
import netframework.mediator.ComponentBuilder;
import netframework.mediator.MDPersistentObject;
import demo.framework.example.bo.fakturacia.Faktura;
import demo.framework.example.su.obmedzenie.uc.UCObmedzenieVerzia1;
import demo.framework.translate.ResourceConstants;

public class MDObmedzenieVerzia1 extends MDPersistentObject {

	@Override
	protected XPanel createPanel(ServerPack pack) throws Exception {
		XDualComponentPanel panel = new XDualComponentPanel();
		panel.setInsets(new Insets(10, 10, 10, 10));
		panel.setBorder(new XTitleBorder());
		panel.add(ComponentBuilder.createFilterComponent(UCObmedzenieVerzia1.TYP_FAKTURY, Faktura.TYP, getSessionObject()));
		return panel;
	}

	@Override
	protected String getTitleText() {
		return ResourceConstants.OBMEDZENIE;
	}
}
