package demo.framework.example.su.obmedzenie.md;

import netball.server.component.XBoxPanel;
import netball.server.component.XPanel;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.EnabledPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.BasicMediator;
import netframework.mediator.MDPersistentObject;
import netframework.mediator.MDUtilities;
import netframework.mediator.MediatorCallBackObject;
import zelpo.eclipselink.autorizacia.md.MDViewPridelenieUzivatela;

import javax.swing.SwingConstants;

import demo.framework.example.su.common.MDHelper;
import demo.framework.example.su.obmedzenie.uc.UCObmedzenieVerzia1;

public class MDViewObmedzenieVerzia1 extends MDViewPridelenieUzivatela {

	private final String OBMEDZENIA_ACTION = createId(MDHelper.OBMEDZENIA_BUTTON.getId());
	
	@Override
	protected EnabledPack createButtonEnabledPack() {
		EnabledPack pack = super.createButtonEnabledPack();
		pack.put(OBMEDZENIA_ACTION, this.getRowCount() > 0);
		return pack;
	}

	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
		if (event.getSourceId().equals(OBMEDZENIA_ACTION)) {
            int selectedIndex = this.getSelectedIndexFromEvent(event, pack);
            if (selectedIndex != -1) {
            	this.setSelectedIndex(selectedIndex);
                Object id = getPrimaryKeyValue(selectedIndex);
			    try {
				    UCObmedzenieVerzia1 obmedzenie = UCObmedzenieVerzia1.read(id, (EclipseLinkSession) getSessionObject());
				    runNext(MDObmedzenieVerzia1.class, new MDPersistentObject.Parameters(obmedzenie), pack);
				} catch (Exception e) {
					this.addExceptionToPack(e, pack);
				}
			}
		}else{
		   super.actionEventExecuted(event, pack);
		}
	}

	@Override
	public AccessAction[] getAccessActions() {
    	AccessAction[] actions = new AccessAction[]{
             new AccessAction(OBMEDZENIA_ACTION, MDHelper.OBMEDZENIA_BUTTON.getText(), MDHelper.OBMEDZENIA_BUTTON.getDescription()),
        };
        return MDUtilities.splitAccessActions(super.getAccessActions(), actions);        		 
	}

	@Override
	protected XPanel createEastPanel(ServerPack pack) {
		XBoxPanel panel = new XBoxPanel(SwingConstants.VERTICAL);
		ServerActionEvent event = new ServerActionEvent();
		event.addReturnValue(TABLE);
		panel.add(MDUtilities.createButton(OBMEDZENIA_ACTION, MDHelper.OBMEDZENIA_BUTTON, event, getSessionObject()));
		return panel;
	}

	@Override
	protected boolean receiveCallBack(BasicMediator mediator, MediatorCallBackObject obj, ServerPack pack) {
		if (mediator instanceof MDObmedzenieVerzia1) {
			Object id = ((UCObmedzenieVerzia1) ((MDPersistentObject.CallBack) obj).source).getPriradenieId();
			this.addUpdatedPack(id, getSelectedIndex(), pack);
            return false;			
		}else{
		    return super.receiveCallBack(mediator, obj, pack);
		}
	}
}
