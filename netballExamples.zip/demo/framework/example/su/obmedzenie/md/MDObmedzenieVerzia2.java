package demo.framework.example.su.obmedzenie.md;

import java.awt.Insets;

import netball.server.component.XDualComponentPanel;
import netball.server.component.XTabbedPage;
import netball.server.component.XTabbedPane;
import netball.server.pack.ServerPack;
import netframework.mediator.ComponentBuilder;
import zelpo.eclipselink.autorizacia.md.MDPridelenieUzivatela;
import demo.framework.example.bo.fakturacia.Faktura;
import demo.framework.example.su.obmedzenie.uc.UCObmedzenieVerzia2;

public class MDObmedzenieVerzia2 extends MDPridelenieUzivatela {

	@Override
	protected void addPageToTabbedPanel(XTabbedPane panel, ServerPack serverPack) {
		XDualComponentPanel panel1 = new XDualComponentPanel();
		panel1.setInsets(new Insets(10, 10, 10, 10));
		panel1.add(ComponentBuilder.createFilterComponent(UCObmedzenieVerzia2.TYP_FAKTURY, Faktura.TYP, getSessionObject()));
		panel.add(new XTabbedPage("obmedzenia", translateText("Obmedzenia"), panel1));
	}
}
