package demo.framework.example.su.common;

import java.util.ArrayList;
import java.util.List;

import demo.framework.components.DemoComponenets;
import demo.framework.example.su.ciselniky.md.MDViewMena;
import demo.framework.example.su.ciselniky.md.MDViewZakazka;
import demo.framework.example.su.ciselniky.md.MDViewZakaznik;
import demo.framework.example.su.common.report.ReportTree;
import demo.framework.example.su.common.report.prmt.MDSkolenieDynamicReport;
import demo.framework.example.su.fakturacia.md.MDViewDodavatelskaFaktura;
import demo.framework.example.su.fakturacia.md.MDViewOdberatelskaFakturaClientServerTable;
import demo.framework.example.su.fakturacia.md.MDViewOdberatelskaFakturaClientTable;
import demo.framework.example.su.ine.md.MDClientServerTransferFileExample;
import demo.framework.example.su.ine.md.MDClientServerTransferFileExampleWithWaitDialog;
import demo.framework.example.su.ine.md.MDServerClientTransferFileExample;
import demo.framework.example.su.ine.md.MDServerClientTransferFileExampleWithWaitDialog;
import demo.framework.example.su.ine.md.MDUsePageBuffer;
import demo.framework.example.su.ine.md.MDViewKomponenty;
import demo.framework.example.su.obmedzenie.md.MDViewObmedzenieVerzia1;
import demo.framework.example.su.obmedzenie.md.MDViewObmedzenieVerzia2;
import demo.framework.example.su.uzol.md.MDViewTreeTableUzol;
import demo.framework.example.su.uzol.md.MDViewTreeUzol;
import demo.framework.translate.ResourceConstants;
import netball.server.component.XMenu;
import netframework.mediator.MDFontSelection;
import netframework.mediator.MDMainMediator;
import netframework.mediator.MDReportTree;
import netframework.mediator.resource.MediatorResourceBuilder;
import zelpo.eclipselink.autorizacia.md.MDUzivatelNoveHeslo;
import zelpo.eclipselink.autorizacia.md.MDViewAkcia;
import zelpo.eclipselink.autorizacia.md.MDViewPridelenieUzivatela;
import zelpo.eclipselink.autorizacia.md.MDViewRola;
import zelpo.eclipselink.autorizacia.md.MDViewUzivatel;

public class MDMainMenu extends MDMainMediator {

	@Override
	protected List<XMenu> createMenu() {
	   java.util.List<XMenu> mainMenu = new ArrayList<XMenu>();
   	   
	   XMenu menu = createMenu("faktury", ResourceConstants.FAKTURY);
	   menu.add(createMenuItem("odberatelskeFaktury", ResourceConstants.ODBERATELSKE_FAKTURY, MDViewOdberatelskaFakturaClientTable.class));
	   menu.add(createMenuItem("odberatelskeFakturyClientServer", ResourceConstants.ODBERATELSKE_FAKTURY, MDViewOdberatelskaFakturaClientServerTable.class));
	   menu.add(createMenuItem("dodavatelskeFaktury", ResourceConstants.DODAVATELSKE_FAKTURY, MDViewDodavatelskaFaktura.class));
	   mainMenu.add(menu);
   	
	   menu = createMenu("ciselniky", ResourceConstants.CISELNIK);
	   menu.add(createMenuItem("meny", ResourceConstants.MENY, MDViewMena.class));
	   menu.add(createMenuItem("zakaznici", ResourceConstants.ZAKAZNICI, MDViewZakaznik.class));
	   menu.add(createMenuItem("zakazky", ResourceConstants.ZAKAZKY, MDViewZakazka.class));
	   mainMenu.add(menu);

	   menu = createMenu("prehlady", ResourceConstants.PREHLADY);
	   menu.add(createMenuItem("prehladyItem", ResourceConstants.PREHLADY, ReportTree.class));
	   menu.add(createMenuItem("prehladyDynamic", /*~~*/"Dynamicke prehlady", MDSkolenieDynamicReport.class));
	   mainMenu.add(menu);
	   
	   menu = createMenu("ine", ResourceConstants.INE);
	   menu.add(createMenuItem("clientServerTransferFileExample", ResourceConstants.KLIENT_SERVER_PRENOS, MDClientServerTransferFileExample.class));
	   menu.add(createMenuItem("clientServerTransferFileExampleWithWaitDialog", ResourceConstants.KLIENT_SERVER_PRENOS___CAKACIE_OKNO, MDClientServerTransferFileExampleWithWaitDialog.class));
	   menu.add(createMenuItem("serverClientTransferFileExample", ResourceConstants.SERVER_KLIENT_PRENOS, MDServerClientTransferFileExample.class));
	   menu.add(createMenuItem("serverClientTransferFileExampleWithWaitDialog", ResourceConstants.SERVER_KLIENT_PRENOS___CAKACIE_OKNO, MDServerClientTransferFileExampleWithWaitDialog.class));
	   menu.add(createMenuItem("usePageBuffer", ResourceConstants.POUZITIE_PAGEBUFFER, MDUsePageBuffer.class));
	   menu.add(createMenuItem("MDViewTreeTable", "MDViewTreeTable", MDViewTreeTableUzol.class));
	   menu.add(createMenuItem("MDViewTree", "MDViewTree", MDViewTreeUzol.class));
	   menu.add(createMenuItem("viewComponents", "View komponenty", MDViewKomponenty.class));	   
	   menu.add(createMenuItem("components", ResourceConstants.KOMPONENTY, DemoComponenets.class));	   
	   mainMenu.add(menu);

	   menu = createMenu("autorizacia", ResourceConstants.AUTORIZACIA);
	   menu.add(createMenuItem("uzivatelia", ResourceConstants.POUZIVATELIA, MDViewUzivatel.class));
	   menu.add(createMenuItem("role", ResourceConstants.ROLE, MDViewRola.class));
	   menu.add(createMenuItem("uzivateliaAplikacie", ResourceConstants.POUZIVATELIA_APLIKACIE, MDViewPridelenieUzivatela.class));
	   menu.add(createMenuItem("akcie", ResourceConstants.AKCIE, MDViewAkcia.class));
	   menu.add(createMenuItem("obmedzenieVerzia1", ResourceConstants.POUZIVATELIA_APLIKACIE_S_OBMEDZENIM_VERZIA_1, MDViewObmedzenieVerzia1.class));	   
	   menu.add(createMenuItem("obmedzenieVerzia2", ResourceConstants.POUZIVATELIA_APLIKACIE_S_OBMEDZENIM_VERZIA_2, MDViewObmedzenieVerzia2.class));
	   menu.add(createMenuItem("zmenaHesla", ResourceConstants.ZMENA_HESLA, MDUzivatelNoveHeslo.class));
	   mainMenu.add(menu);
	   
   	   return mainMenu;   	      	   
	}

	@Override
	protected String getTitleText() {
		return ResourceConstants.DEMO;
	}
	
	@Override
	protected Class<? extends MDReportTree> getReportTree() {
		return ReportTree.class;
	}
	
	@Override
	protected XMenu createFavoritMenu(List<XMenu> mainMenu) {
		XMenu menu = super.createFavoritMenu(mainMenu);
		menu.add(createMenuItem("zmenaFontu", MediatorResourceBuilder.getString(MediatorResourceBuilder.FONT_SELECTION_TITLE, getLocale()), MDFontSelection.class));
		return menu;
	}
}

