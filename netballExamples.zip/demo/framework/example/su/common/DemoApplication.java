package demo.framework.example.su.common;

import java.awt.Font;

import demo.framework.example.bo.common.Helper;
import demo.framework.example.bo.obmedzenie.Obmedzenia;
import netball.server.component.XFont;
import netframework.eclipselink.Application;
import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.BasicMediator;
import netframework.mediator.SessionObject;
import zelpo.eclipselink.autorizacia.UzivatelskeObmedzenie;

public class DemoApplication implements Application {

	@Override
	public Class<? extends BasicMediator> getStartingMediatorClass() {
		return MDMainMenu.class;
	}

	@Override
	public Class<? extends BasicMediator> getMediatorClassForAccessActionTree() {
		return MDMainMenu.class;
		//return MDMainMenuCTB.class;
	}

	@Override
	public String getCode() {
		return "skolenie";
	}

	@Override
	public String[] getTranslationResourcesClasses() {
		return new String[] {zelpo.eclipselink.translate.Resources.class.getName(),
				             demo.framework.translate.Resources.class.getName()};
	}

	@Override
	public void initializeSessionObject(SessionObject session) {
		try {
			String obmedzenie = UzivatelskeObmedzenie.readObmedzenie(session);
			((EclipseLinkSession) session).addProperty(Helper.OBMEDZENIA, Obmedzenia.parse(((EclipseLinkSession) session).getSession(), obmedzenie));
			((EclipseLinkSession) session).addProperty("companyName", "ZP informatika"); // vyuzije sa pri tlaci reportu
			//(((EclipseLinkSession) session).getServerEngine()).getClientSettings().defaultFont = new XFont("Dialog", Font.PLAIN | Font.BOLD, 25);
			//(((EclipseLinkSession) session).getServerEngine()).getClientSettings().defaultFont = MDUtilities.getDefaultFont((((EclipseLinkSession) session)));
			/*
			BasicServerEngine serverEngine = (BasicServerEngine) session.getServerEngine();
		    ClientSystemProperties clientSystemProperties = serverEngine.getClientSystemProperties();
		    String name = clientSystemProperties.operatingSystemName ;
		    String version = clientSystemProperties.operatingSystemVersion ;
		    System.out.println(name + " " + version);
		    */
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
