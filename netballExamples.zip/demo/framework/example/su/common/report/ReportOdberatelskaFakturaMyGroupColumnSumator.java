package demo.framework.example.su.common.report;

import java.util.HashMap;
import java.util.Iterator;

import javax.swing.SwingConstants;

import demo.framework.example.bo.ciselniky.Mena;
import demo.framework.example.bo.ciselniky.Zakaznik;
import demo.framework.example.bo.fakturacia.Faktura;
import demo.framework.example.bo.fakturacia.OdberatelskaFaktura;
import demo.framework.example.bo.fakturacia.StavFaktury;
import demo.framework.example.bo.fakturacia.SumaVMene;
import demo.framework.example.bo.fakturacia.TypFaktury;
import demo.framework.example.su.common.report.prmt.PROdberatelskaFakturaMyGroupColumnSumator;
import demo.framework.example.su.db.DBSkolenieCatalog;
import demo.framework.translate.ResourceConstants;
import netball.server.print.table.PRBlankTableRow;
import netball.server.print.table.PRGroupTableFooter;
import netframework.FrameworkUtilities;
import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.ComponentBuilder;
import netframework.mediator.SessionObject;
import netframework.report.BasicReportSource;
import netframework.report.Report;
import netframework.report.ReportBuilder;
import netframework.report.ReportColumnProperties;
import netframework.report.ReportParameters;
import netframework.report.ReportSource;
import netframework.report.RowBuilder;
import netframework.report.ViewCursorReportSource;
import netframework.report.grouping.GroupColumn;
import netframework.report.grouping.GroupColumnItem;
import netframework.report.grouping.GroupColumnSummarizer;
import netframework.report.grouping.GroupRules;
import netframework.report.grouping.GroupTotalRules;
import netframework.sql.SQLExpression;
import netframework.sql.SQLExpressionBuilder;
import netframework.sql.SQLJoinCondition;
import netframework.sql.SQLQuery;
import netframework.view.ViewCursor;
import netframework.view.ViewRow;


public class ReportOdberatelskaFakturaMyGroupColumnSumator implements Report {
    
    public static final String OBDOBIE = OdberatelskaFaktura.OBDOBIE.getId();
    public static final String ZAKAZNIK_ICO = Zakaznik.ICO.getId();

    @Override
    public ReportBuilder execute(ReportParameters prmt, SessionObject session) throws Exception{
        Parameters prmts = createParameters(prmt, session);        
        ViewCursor cursor = createCursor(prmts, session);
        ViewCursorReportSource report = new ViewCursorReportSource();             
        ReportColumnProperties[] cols = new ReportColumnProperties[] {
            	ComponentBuilder.createReportColumn(OdberatelskaFaktura.CISLO.getId(), OdberatelskaFaktura.CISLO, true, session),
            	ComponentBuilder.createReportColumn(OdberatelskaFaktura.DATUM_VYSTAVENIA.getId(), OdberatelskaFaktura.DATUM_VYSTAVENIA, true, session),
            	ComponentBuilder.createReportColumn(OdberatelskaFaktura.CELKOVA_SUMA.getId(), SumaVMene.SUMA, true, session),
            	ComponentBuilder.createReportColumn(Mena.KOD.getId(), Mena.KOD, false, session),
        };
        report.setCursor(cursor);
        report.setColumnProperty(cols);
        report.setUserName(session.getUser() != null ? session.getUser().getName() : null);
        report.setCompanyName((String)((EclipseLinkSession) session).getProperty("companyName"));
        report.setHeaderText(session.translateText(getName()) +  prmts.headerText);
        
        GroupColumn groupColumns[] = new GroupColumn[1];
        groupColumns = new GroupColumn[1];
        int indexIco = cursor.getColumnIndex(Zakaznik.ICO.getId());
        groupColumns[0] = new GroupColumn(indexIco);
        groupColumns[0].setHeaderItem(new GroupColumnItem(indexIco, ComponentBuilder.createRenderer(Zakaznik.ICO, session), session.translateText(Zakaznik.ICO.getLongCaption())));
        groupColumns[0].setFooterItem(new GroupColumnItem(indexIco, ComponentBuilder.createRenderer(Zakaznik.ICO, session), session.translateText(Zakaznik.ICO.getLongCaption())));
        groupColumns[0].setSummarizer(new MySumator(cursor.getColumnIndex(Faktura.CELKOVA_SUMA.getId()), session));
        
        GroupRules rules = new GroupRules(groupColumns, null);        
        report.setGroupRules(rules);
        
        GroupTotalRules groupTotalRules = new GroupTotalRules(new MyTotalSumator(cursor.getColumnIndex(Faktura.CELKOVA_SUMA.getId())));
        report.setGroupTotalRules(groupTotalRules);        
        return new ReportBuilder(report);
    }

    private ViewCursor createCursor(Parameters prmts, SessionObject session) throws Exception {
    	DBSkolenieCatalog c = DBSkolenieCatalog.getInstance();
        SQLQuery query = new SQLQuery();
        query.addTable(new SQLJoinCondition(c.FAKTURA));
        query.addTable(new SQLJoinCondition(c.MENA, c.MENA.ID, c.FAKTURA.MENA));
        query.addTable(new SQLJoinCondition(c.ZAKAZNIK, c.ZAKAZNIK.ID, c.FAKTURA.ZAKAZNIK));        
        query.addField(OdberatelskaFaktura.DATUM_VYSTAVENIA.getId(), c.FAKTURA.DATUM_VYSTAVENIA);
    	query.addField(OdberatelskaFaktura.CELKOVA_SUMA.getId(), c.FAKTURA.CELKOVA_SUMA);
    	query.addField(Mena.KOD.getId(), c.MENA.KOD);
    	query.addField(Zakaznik.ICO.getId(), c.ZAKAZNIK.ICO);
    	query.addField(OdberatelskaFaktura.OBDOBIE.getId(), c.FAKTURA.OBDOBIE);
    	query.addField(OdberatelskaFaktura.CISLO.getId(), c.FAKTURA.CISLO);
    	query.addOrdering(c.ZAKAZNIK.ICO);
        query.addOrdering(c.FAKTURA.CISLO);
        SQLExpression exp1 = SQLExpressionBuilder.get(c.FAKTURA.STAV).equal(StavFaktury.SPRACOVANA.getKey());
        SQLExpression exp2 = SQLExpressionBuilder.get(c.FAKTURA.TYP).equal(TypFaktury.ODBERATELSKA.getKey());
        query.setExpression(exp1.and(exp2));
        if (prmts.obdobie != null) {
        	SQLExpression exp = FrameworkUtilities.createSQLExpression(c.FAKTURA.OBDOBIE, prmts.obdobie); 
            query.setExpression(query.getExpression() != null ? query.getExpression().and(exp) : exp);
        }
        if (prmts.zakaznik != null) {
        	SQLExpression exp = FrameworkUtilities.createSQLExpression(c.ZAKAZNIK.ICO, prmts.zakaznik); 
            query.setExpression(query.getExpression() != null ? query.getExpression().and(exp) : exp);
        }
        return ((EclipseLinkSession) session).execute(query); 
    }
    
    private Parameters createParameters(ReportParameters prmt, SessionObject session) throws Exception {
        Parameters parameteres = new Parameters();
        if (prmt != null) {
           Object value = prmt.getValue(OBDOBIE);
           if (value != null) {
              parameteres.obdobie = value;
              parameteres.headerText.add(OdberatelskaFaktura.OBDOBIE.getLongCaption(), value, session);
           }else{
        	  throw new IllegalArgumentException(session.translateText(ResourceConstants.OBDOBIE_MUSI_BYT_VYPLNENE_)); 
           }
           value = prmt.getValue(ZAKAZNIK_ICO);
           if (value != null) {
              parameteres.zakaznik = value;
              parameteres.headerText.add(Zakaznik.ICO.getLongCaption(), value, session);
           }
        }
        return parameteres;
    }

    @Override
    public String getName() {
        return ResourceConstants.ZOZMAM_SPRACOVANYCH_ODBERATELSKYCH_FAKTUR_PO_ZAKAZNIKOCH;
    }
    
    @Override
    public String getDescription() {
        return ResourceConstants.POUZITIE_IMPLEMENTS_REPORT_A_IMPLEMENTS_GROUPCOLUMNSUMATOR; 
    }
    
    public Class<PROdberatelskaFakturaMyGroupColumnSumator> getParameterMediatorClass() {
        return PROdberatelskaFakturaMyGroupColumnSumator.class;
    }        
 
private static class Parameters {
    public Object obdobie;
    public Object zakaznik;
    public FilterTextBuilder headerText = new FilterTextBuilder();
}             
	
private class MySumator implements GroupColumnSummarizer {

	   private int columnIndex;
	   private double sum = 0;
	   private SessionObject session;
		  
	   public MySumator(int columnIndex, SessionObject session) {
	      this.columnIndex = columnIndex;
	      this.session = session;
	   }

	   @Override
	   public void sum(ViewRow row) {
	      Number value = (Number) row.getValueAt(columnIndex);
	      sum += (value == null ? 0 : value.doubleValue());         	  
	   }
		      
	   @Override
	   public void startNewGroup() {
	   	  sum = 0;  	   
	   }
		    
	   @Override
	   public void writeToBuilder(RowBuilder rowBuilder, ReportSource source) {		   
	   	  BasicReportSource basicReportSource = (BasicReportSource) source;
	      int sumaIndex = basicReportSource.getColumnIndex(Faktura.CELKOVA_SUMA.getId());
	      PRGroupTableFooter sumFooter = new PRGroupTableFooter(session.translateText(ResourceConstants.SPOLU_), javax.swing.SwingConstants.RIGHT);      
	      sumFooter.addItem(basicReportSource.convertValueToString(new Double(sum), sumaIndex), sumaIndex);
	      rowBuilder.writeRow(sumFooter); 
	   }
}

private class MyTotalSumator implements GroupColumnSummarizer {
			
	   private int columnIndex;
	   private HashMap<String, Number> zoznam = new HashMap<String, Number>();
		  
	   public MyTotalSumator(int columnIndex) {
	      this.columnIndex = columnIndex;
	   }

	   @Override
	   public void sum(ViewRow row) {
	   	  String mena = (String) row.getValueAt(row.getColumnIndex(Mena.KOD.getId()));
	      Number value = (Number) row.getValueAt(columnIndex);
	      if (value == null)
	         value = new Double(0);
	   	  if (zoznam.containsKey(mena)) 
	   	     value = new Double(value.doubleValue() + zoznam.get(mena).doubleValue());
	   	  zoznam.put(mena, value);  
	   }
		      
	   @Override
	   public void startNewGroup() {
	   	  zoznam = new HashMap<String, Number>();
	   }
		    
	   @Override
	   public void writeToBuilder(RowBuilder rowBuilder, ReportSource source) {		   
	   	  if (zoznam.size() == 0)
	   	     return;
	   	  BasicReportSource basicReportSource = (BasicReportSource) source;   
	   	  rowBuilder.writeRow(new PRBlankTableRow());    
	   	  int sumaIndex = basicReportSource.getColumnIndex(Faktura.CELKOVA_SUMA.getId());
	   	  for (Iterator<String> iterator = zoznam.keySet().iterator(); iterator.hasNext(); ) {
	   	  	 String mena = iterator.next();
	   	     PRGroupTableFooter sumFooter = new PRGroupTableFooter(mena + ":");
	   	     sumFooter.setTextLocation(SwingConstants.RIGHT);
	         sumFooter.addItem(basicReportSource.convertValueToString(zoznam.get(mena), sumaIndex), sumaIndex);
	         rowBuilder.writeRow(sumFooter);    	  	 
	   	  }	 
	   }	
	}        
}
