package demo.framework.example.su.common.report;


import netball.client.ui.print.PrintPageDataSource;
import netball.server.print.PRPage;
import netball.server.print.PRPageFormat;
import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.MDReportTreeItemPrmts;
import netframework.mediator.SessionObject;
import netframework.report.PageBuffer;
import netframework.report.PageReport;
import netframework.report.ReportParameters;
import netframework.sql.SQLExpressionBuilder;
import netframework.sql.SQLJoinCondition;
import netframework.sql.SQLQuery;
import netframework.view.ViewCursor;
import demo.framework.example.bo.fakturacia.OdberatelskaFaktura;
import demo.framework.example.bo.fakturacia.TypFaktury;
import demo.framework.example.su.db.DBSkolenieCatalog;
import demo.framework.translate.ResourceConstants;

public class ReportOdberatelskaFakturaDoklady implements PageReport {

	@Override
	public Class<? extends MDReportTreeItemPrmts> getParameterMediatorClass() {
		return null;
	}
	
	@Override
	public String getName() {
		return ResourceConstants.TLAC_ODBERATELSKYCH_DOKLADOV;
	}

	@Override
	public String getDescription() {
		return ResourceConstants.UKAZKA_POUZITIA_PRINTPAGEDATASOURCE_AKO_REPORT;
	}

	@Override
	public PrintPageDataSource execute(ReportParameters prmts,	SessionObject sessionObject) throws Exception {
		PageBuffer pageBuffer = new PageBuffer();
		EclipseLinkSession session = (EclipseLinkSession) sessionObject;
		DBSkolenieCatalog c = DBSkolenieCatalog.getInstance();
		SQLQuery query = new SQLQuery();
		query.addTable(new SQLJoinCondition(c.FAKTURA));
		query.addField(OdberatelskaFaktura.ID.getId(), c.FAKTURA.ID);
		query.setExpression(SQLExpressionBuilder.get(c.FAKTURA.TYP).equal(TypFaktury.ODBERATELSKA.getKey()));
		ViewCursor cursor = session.execute(query);
		if (cursor.hasNext()) {
			 while(cursor.hasNext()) {
			    Object id = cursor.next().getValueAt(0);
			    PRPage[] pages = new ReportDokladOdberatelskaFakturaTable().execute(session, id);
			    if (pages != null) {
			    	for (int i = 0; i < pages.length; i++) {
			    		pageBuffer.addPage(pages[i]);
			    	}
			    }
			 }
		}else{
			throw new IllegalAccessException(sessionObject.translateText(ResourceConstants.NEPODARILO_SA_NACITAT_ZAZNAMY_PRE_TLAC_));
		}
		return pageBuffer;
	}

	@Override
	public PRPageFormat getPageFormat() {
		return new PRPageFormat();
	}

}
