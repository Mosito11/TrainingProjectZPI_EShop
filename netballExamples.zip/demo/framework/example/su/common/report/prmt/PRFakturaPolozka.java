package demo.framework.example.su.common.report.prmt;

import netball.server.component.XDualComponentPanel;
import netball.server.component.XPanel;
import netframework.mediator.MDUserReportPrmts;
import netframework.report.UserReport;
import demo.framework.example.bo.fakturacia.Faktura;
import demo.framework.example.su.common.report.ReportFakturaPolozka;
import demo.framework.example.su.common.view.ViewFakturaPolozka;
import demo.framework.example.su.komponenty.ComponentMena;
import demo.framework.example.su.komponenty.ComponentZakaznik;


public class PRFakturaPolozka extends MDUserReportPrmts {   

	   @Override
	   protected XPanel createFilterPanel() {
			XDualComponentPanel panel = new XDualComponentPanel();
			panel.add(createComponent(ViewFakturaPolozka.FAKTURA_CISLO, Faktura.CISLO));
			panel.add(createExpressionComponent(ViewFakturaPolozka.FAKTURA_DATUM_VYSTAVENIA, Faktura.DATUM_VYSTAVENIA));
			panel.add(ComponentZakaznik.createComponent(ViewFakturaPolozka.ZAKAZNIK_ICO, this));
			panel.add(createExpressionComponent(ViewFakturaPolozka.FAKTURA_OBDOBIE, Faktura.OBDOBIE));
			panel.add(createExpressionComponent(ViewFakturaPolozka.FAKTURA_STAV, Faktura.STAV));
			panel.add(ComponentMena.createComponent(ViewFakturaPolozka.MENA_KOD, this));
			panel.add(createExpressionComponent(ViewFakturaPolozka.FAKTURA_TYP, Faktura.TYP));
	        return panel; 
	    }

	    @Override
	    protected UserReport createUserReport() {
	        return new ReportFakturaPolozka();
	    }
}
