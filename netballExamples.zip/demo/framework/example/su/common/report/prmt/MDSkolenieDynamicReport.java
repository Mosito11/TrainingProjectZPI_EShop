package demo.framework.example.su.common.report.prmt;

import demo.framework.example.su.dynamicreport.DRSkolenieCatalog;
import netball.server.pack.ServerPack;
import netframework.dynamicreport.MDDynamicReport;
import netframework.mediator.MediatorParameters;

public class MDSkolenieDynamicReport extends MDDynamicReport {

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
		MDDynamicReport.Parameters prmts = new MDDynamicReport.Parameters(DRSkolenieCatalog.getInstance());
		super.init(prmts, serverPack);
	}
}
