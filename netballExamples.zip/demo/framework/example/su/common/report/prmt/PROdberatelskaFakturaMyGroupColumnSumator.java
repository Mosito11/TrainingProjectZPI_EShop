package demo.framework.example.su.common.report.prmt;

import netball.server.component.XDualComponentPanel;
import netball.server.component.XPanel;
import netball.server.component.border.XTitleBorder;
import netball.server.pack.RequiredPack;
import netball.server.pack.ServerPack;
import netframework.mediator.MDReportPrmts;
import netframework.report.Report;
import demo.framework.example.bo.fakturacia.OdberatelskaFaktura;
import demo.framework.example.su.common.report.ReportOdberatelskaFakturaMyGroupColumnSumator;
import demo.framework.example.su.komponenty.ComponentZakaznik;


public class PROdberatelskaFakturaMyGroupColumnSumator extends MDReportPrmts {   

	@Override
    protected XPanel createFilterPanel(ServerPack pack) {        
       XDualComponentPanel panel = new XDualComponentPanel();
       panel.setBorder(new XTitleBorder());
       panel.setInsets(new java.awt.Insets(10,10,10,10));
       panel.add(createExpressionComponent(ReportOdberatelskaFakturaMyGroupColumnSumator.OBDOBIE, OdberatelskaFaktura.OBDOBIE));       
       panel.add(ComponentZakaznik.createComponent(ReportOdberatelskaFakturaMyGroupColumnSumator.ZAKAZNIK_ICO, this));       
       return panel; 
    }

	@Override
    protected Report createReport() {
        return new ReportOdberatelskaFakturaMyGroupColumnSumator();
    }
    
	@Override
    protected RequiredPack getRequiredPack() {
		RequiredPack pack = new RequiredPack();
        pack.put(ReportOdberatelskaFakturaMyGroupColumnSumator.OBDOBIE, true);
        return pack;
    }        
}
