package demo.framework.example.su.common.report.prmt;

import demo.framework.example.bo.fakturacia.OdberatelskaFaktura;
import demo.framework.example.su.common.report.ReportOdberatelskaFaktura;
import demo.framework.example.su.common.report.ReportOdberatelskaFakturaSpanReport;
import demo.framework.example.su.komponenty.ComponentZakaznik;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XPanel;
import netball.server.component.border.XTitleBorder;
import netball.server.pack.RequiredPack;
import netball.server.pack.ServerPack;
import netframework.mediator.MDSpanTableReportPreview;
import netframework.mediator.MDSpanTableReportPrmts;
import netframework.report.Report;

public class PROdberatelskaFakturaSpanTable extends MDSpanTableReportPrmts {

	@Override
	protected Report createReport(){
		return new ReportOdberatelskaFakturaSpanReport();
	}

	@Override
	protected XPanel createFilterPanel(ServerPack paramServerPack){
	       XDualComponentPanel panel = new XDualComponentPanel();
	       panel.setBorder(new XTitleBorder());
	       panel.setInsets(new java.awt.Insets(10,10,10,10));
	       panel.add(createExpressionComponent(ReportOdberatelskaFaktura.OBDOBIE, OdberatelskaFaktura.OBDOBIE));       
	       panel.add(ComponentZakaznik.createComponent(ReportOdberatelskaFaktura.ZAKAZNIK_ICO, this));       
	       return panel; 
	}

	@Override
	protected RequiredPack getRequiredPack(){
		RequiredPack pack = new RequiredPack();
        pack.put(ReportOdberatelskaFaktura.OBDOBIE, true);
        return pack;
	}

	@Override
	protected Class<? extends MDSpanTableReportPreview> getPreviewMediator() {
		return MDOdberatelskaFakturaSpanTablePreview.class;
	}	
}
