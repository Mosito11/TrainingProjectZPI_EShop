package demo.framework.example.su.common.report.prmt;

import demo.framework.example.bo.ciselniky.Mena;
import demo.framework.example.bo.fakturacia.Faktura;
import demo.framework.example.bo.fakturacia.SumaVMene;
import demo.framework.example.su.common.report.ReportFaktura;
import demo.framework.example.su.common.view.ViewFaktura;
import demo.framework.example.su.komponenty.ComponentMena;
import demo.framework.example.su.komponenty.ComponentZakaznik;
import netball.client.ui.jtc.DynamicFilterEditorBuilder;
import netball.server.component.XBorderPanel;
import netball.server.component.XComponent;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XDynamicFilter;
import netball.server.component.XPanel;
import netframework.mediator.BasicMediator;
import netframework.mediator.MDUserReportPrmts;
import netframework.report.UserReport;


public class PRFaktura extends MDUserReportPrmts {   

	   private static final String DYNAMIC_FILTER = "DynamicFilter";
		
	   @Override	
	   protected XPanel createFilterPanel() {
			XDualComponentPanel panel = new XDualComponentPanel();
			panel.add(createComponent(ViewFaktura.CISLO, Faktura.CISLO));
			panel.add(ComponentZakaznik.createComponent(ViewFaktura.ZAKAZNIK_ICO, this));
			
			XDynamicFilter filter = new XDynamicFilter(DYNAMIC_FILTER);
			filter.addField(ViewFaktura.DATUM_VYSTAVENIA, translateText(Faktura.DATUM_VYSTAVENIA.getCaption()));
			filter.addField(ViewFaktura.OBDOBIE, translateText(Faktura.OBDOBIE.getCaption()));
			filter.addField(ViewFaktura.STAV, translateText(Faktura.STAV.getCaption()));
			filter.addField(ViewFaktura.MENA_KOD, translateText(Mena.KOD.getLongCaption()));
			filter.addField(ViewFaktura.CELKOVA_SUMA, translateText(Faktura.CELKOVA_SUMA.getCaption()));
			filter.setHeight(500);
			filter.setWidth(600);
			filter.setEditorBuilder(new EditorBuilder(), this);
			
			XBorderPanel mainPanel = new XBorderPanel(10, 10);
			mainPanel.setNorth(panel);
			mainPanel.setCenter(filter);
			
	        return mainPanel; 
	  }

      @Override
	  protected UserReport createUserReport() {
	       return new ReportFaktura();
	  }    
	   
	  private class EditorBuilder extends DynamicFilterEditorBuilder {
	
			@Override
			public XComponent createEditor(Object fieldId, String componentId) throws Exception {
				BasicMediator thisMediator = PRFaktura.this;
				if (fieldId.equals(ViewFaktura.DATUM_VYSTAVENIA)) {
					return createExpressionComponent(componentId, Faktura.DATUM_VYSTAVENIA);
				}else if (fieldId.equals(ViewFaktura.OBDOBIE)) {
					return createExpressionComponent(componentId, Faktura.OBDOBIE);
				}else if (fieldId.equals(ViewFaktura.STAV)) {
					return createExpressionComponent(componentId, Faktura.STAV);
				}else if (fieldId.equals(ViewFaktura.MENA_KOD)) {
					return ComponentMena.createExpressionComponent(componentId, thisMediator);
				}else if (fieldId.equals(ViewFaktura.CELKOVA_SUMA)) {
					return createExpressionComponent(componentId, SumaVMene.SUMA);
				}
				return null;
			}
	  }
}
