package demo.framework.example.su.common.report.prmt;

import demo.framework.example.su.fakturacia.md.MDDetailOdberatelskaFaktura;
import netball.client.ui.jtc.awt.spantable.SpanCell;
import netball.client.ui.jtc.spantable.SpanTableCell;
import netball.server.component.XSpanTable;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ServerMouseEvent;
import netball.server.pack.ServerPack;
import netframework.mediator.MDSpanTableReportPreview;

public class MDOdberatelskaFakturaSpanTablePreview extends MDSpanTableReportPreview {
	
	@Override
	protected XSpanTable createTable(ServerPack pack) throws Exception {
		XSpanTable table = super.createTable(pack);
		// zaregistrujeme mouse event aby nam vracal oznacenu bunku
		ServerMouseEvent event = new ServerMouseEvent(ServerMouseEvent.MOUSE_CLICKED_EVENT);
		event.addReturnValue(TABLE);
		table.addMouseEvent(event);
		return table;
	}

	@Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
		if (event.getSourceId().equals(TABLE)) {
			SpanCell[] cells = (SpanCell[]) event.getValuePack().getValue(TABLE);
			if (cells != null) {
				String string = (String) ((SpanTableCell) cells[0]).getUserObjekt();
				if (string != null) {
					// v ReportOdberatelskaFakturaSpanReport sme si do cell ulozili id faktury  
					// PRTableCell cell = new PRTableCell(...);  
	               	// cell.setUserText(...);
					Integer id = Integer.parseInt(string);  
					runNext(MDDetailOdberatelskaFaktura.class, new MDDetailOdberatelskaFaktura.Parameters(id), pack);
				}
			}
		}
	}
}
