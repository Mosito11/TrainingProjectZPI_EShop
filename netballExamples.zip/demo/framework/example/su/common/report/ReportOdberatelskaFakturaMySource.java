package demo.framework.example.su.common.report;

import java.math.BigDecimal;

import javax.swing.SwingConstants;

import demo.framework.example.bo.ciselniky.Mena;
import demo.framework.example.bo.ciselniky.Zakaznik;
import demo.framework.example.bo.common.Helper;
import demo.framework.example.bo.fakturacia.OdberatelskaFaktura;
import demo.framework.example.bo.fakturacia.StavFaktury;
import demo.framework.example.bo.fakturacia.SumaVMene;
import demo.framework.example.bo.fakturacia.TypFaktury;
import demo.framework.example.su.common.report.prmt.PROdberatelskaFakturaMySource;
import demo.framework.example.su.db.DBSkolenieCatalog;
import demo.framework.translate.ResourceConstants;
import netball.server.print.table.PRBlankTableRow;
import netball.server.print.table.PRGroupTableFooter;
import netball.server.print.table.PRGroupTableHeader;
import netball.server.print.table.PRValueTableRow;
import netframework.FrameworkUtilities;
import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.ComponentBuilder;
import netframework.mediator.SessionObject;
import netframework.report.BasicReportSource;
import netframework.report.Report;
import netframework.report.ReportBuilder;
import netframework.report.ReportColumnProperties;
import netframework.report.ReportParameters;
import netframework.report.RowBuilder;
import netframework.sql.SQLExpression;
import netframework.sql.SQLExpressionBuilder;
import netframework.sql.SQLJoinCondition;
import netframework.sql.SQLQuery;
import netframework.view.ViewCursor;
import netframework.view.ViewRow;


public class ReportOdberatelskaFakturaMySource extends BasicReportSource implements Report {
    
    public static final String OBDOBIE = OdberatelskaFaktura.OBDOBIE.getId();
    public static final String ZAKAZNIK_ICO = Zakaznik.ICO.getId();

    private Parameters prmts;
    private SessionObject session;
	private ViewCursor cursor;
    
	@Override
    public ReportBuilder execute(ReportParameters prmt, SessionObject session) throws Exception{
        prmts = createParameters(prmt, session);
        this.session = session;
        prmts = createParameters(prmt, session);
        
    	cursor = createCursor();
    	if (!cursor.hasNext()) {
            throw new IllegalArgumentException(session.translateText(ResourceConstants.NEPODARILO_SA_NACITAT_DATA_));	
        }
        ReportColumnProperties[] cols = new ReportColumnProperties[] {
            	ComponentBuilder.createReportColumn(OdberatelskaFaktura.CISLO.getId(), OdberatelskaFaktura.CISLO, true, session),
            	ComponentBuilder.createReportColumn(OdberatelskaFaktura.DATUM_VYSTAVENIA.getId(), OdberatelskaFaktura.DATUM_VYSTAVENIA, true, session),
            	ComponentBuilder.createReportColumn(OdberatelskaFaktura.CELKOVA_SUMA.getId(), SumaVMene.SUMA, true, session),
            	ComponentBuilder.createReportColumn(Mena.KOD.getId(), Mena.KOD, false, session),
        };
    	setColumnProperty(cols);    	
        // nastavi indexi zdroja (kursora) do stlpcov reportu, koli rychlejsiemu spracovaniu
        for (int i = 0; i < cols.length; i++) { 
            cols[i].setSourceIndex(cursor.getColumnIndex(cols[i].getId()));
        }
        setHeaderText(session.translateText(getName()) + prmts.headerText.toString());
        setUserName(session.getUser() != null ? session.getUser().getName() : null);
        setCompanyName((String)((EclipseLinkSession) session).getProperty("companyName"));
        return new ReportBuilder(this);         
    }
    
    private Parameters createParameters(ReportParameters prmt, SessionObject session) throws Exception {
        Parameters parameteres = new Parameters();
        if (prmt != null) {
           Object value = prmt.getValue(OBDOBIE);
           if (value != null) {
              parameteres.obdobie = value;
              parameteres.headerText.add(OdberatelskaFaktura.OBDOBIE.getLongCaption(), value, session);
           }else{
        	  throw new IllegalArgumentException(session.translateText(ResourceConstants.OBDOBIE_MUSI_BYT_VYPLNENE_)); 
           }
           value = prmt.getValue(ZAKAZNIK_ICO);
           if (value != null) {
              parameteres.zakaznik = value;
              parameteres.headerText.add(Zakaznik.ICO.getLongCaption(), value, session);
           }
        }
        return parameteres;
    }

    @Override
    public String getName() {
        return ResourceConstants.ZOZMAM_SPRACOVANYCH_ODBERATELSKYCH_FAKTUR_PO_ZAKAZNIKOCH;
    }
    
    @Override
    public String getDescription() {
        return ResourceConstants.POUZITIE_IMPLEMENTS_REPORT_A_EXTENDS_BASICREPORTSOURCE; 
    }
    
    private ViewCursor createCursor() throws Exception {
    	DBSkolenieCatalog c = DBSkolenieCatalog.getInstance();
        SQLQuery query = new SQLQuery();
        query.addTable(new SQLJoinCondition(c.FAKTURA));
        query.addTable(new SQLJoinCondition(c.MENA, c.MENA.ID, c.FAKTURA.MENA));
        query.addTable(new SQLJoinCondition(c.ZAKAZNIK, c.ZAKAZNIK.ID, c.FAKTURA.ZAKAZNIK));        
        query.addField(OdberatelskaFaktura.DATUM_VYSTAVENIA.getId(), c.FAKTURA.DATUM_VYSTAVENIA);
    	query.addField(OdberatelskaFaktura.CELKOVA_SUMA.getId(), c.FAKTURA.CELKOVA_SUMA);
    	query.addField(Mena.KOD.getId(), c.MENA.KOD);
    	query.addField(Zakaznik.ICO.getId(), c.ZAKAZNIK.ICO);
    	query.addField(OdberatelskaFaktura.OBDOBIE.getId(), c.FAKTURA.OBDOBIE);
    	query.addField(OdberatelskaFaktura.CISLO.getId(), c.FAKTURA.CISLO);
        query.addOrdering(c.ZAKAZNIK.ICO);
        query.addOrdering(c.FAKTURA.CISLO);
        SQLExpression exp1 = SQLExpressionBuilder.get(c.FAKTURA.STAV).equal(StavFaktury.SPRACOVANA.getKey());
        SQLExpression exp2 = SQLExpressionBuilder.get(c.FAKTURA.TYP).equal(TypFaktury.ODBERATELSKA.getKey());
        query.setExpression(exp1.and(exp2));
        if (prmts.obdobie != null) {
        	SQLExpression exp = FrameworkUtilities.createSQLExpression(c.FAKTURA.OBDOBIE, prmts.obdobie); 
            query.setExpression(query.getExpression() != null ? query.getExpression().and(exp) : exp);
        }
        if (prmts.zakaznik != null) {
        	SQLExpression exp = FrameworkUtilities.createSQLExpression(c.ZAKAZNIK.ICO, prmts.zakaznik); 
            query.setExpression(query.getExpression() != null ? query.getExpression().and(exp) : exp);
        }
        return ((EclipseLinkSession) session).execute(query); 
    }
    
    @Override
    public Class<PROdberatelskaFakturaMySource> getParameterMediatorClass() {
    	return PROdberatelskaFakturaMySource.class;
    }        
        
    @Override
    public void addRowsToBuilder(RowBuilder rowBuilder) throws Exception {
      	ViewRow row = cursor.next();
       	int indexIco = cursor.getColumnIndex(Zakaznik.ICO.getId());
       	int indexSuma = cursor.getColumnIndex(OdberatelskaFaktura.CELKOVA_SUMA.getId());
       	int reportSumaIndex = this.getColumnIndex(OdberatelskaFaktura.CELKOVA_SUMA.getId());
       	BigDecimal celkovaSuma = Helper.DEFAULT_VALUE;
       	while(row != null) {
       		Object ico = row.getValueAt(indexIco);
       		BigDecimal icoSuma = Helper.DEFAULT_VALUE;
       		PRGroupTableHeader header = new PRGroupTableHeader(session.translateText(ResourceConstants.ICO_) + ico);
       		rowBuilder.writeRow(header);
       		while (row != null && row.getValueAt(indexIco).equals(ico)) {
       	    	 PRValueTableRow gridRow = new PRValueTableRow();
                 for (int k = 0; k < getColumnProperty().length; k++) {
                     if (getColumnProperty()[k].getSourceIndex() != -1) {
                         Object value = row.getValueAt(getColumnProperty()[k].getSourceIndex());
                         gridRow.add(convertValueToString(value, k)); 
                     }
                  }
                  rowBuilder.writeRow(gridRow);
                  icoSuma = icoSuma.add((BigDecimal) row.getValueAt(indexSuma));
        		  row = cursor.hasNext() ? cursor.next() : null;
        	}
            celkovaSuma = celkovaSuma.add(icoSuma);
           	PRGroupTableFooter footer = new PRGroupTableFooter(session.translateText(ResourceConstants.ICO_) + ico);
           	footer.setTextLocation(SwingConstants.RIGHT);
           	footer.addItem(convertValueToString(icoSuma, reportSumaIndex), reportSumaIndex);
           	rowBuilder.writeRow(footer);
        }
        rowBuilder.writeRow(new PRBlankTableRow());
        // celkova suma
        PRGroupTableFooter footer = new PRGroupTableFooter(session.translateText(ResourceConstants.CELKOM_));
       	footer.setTextLocation(SwingConstants.RIGHT);
       	footer.addItem(convertValueToString(celkovaSuma, reportSumaIndex), reportSumaIndex);
       	rowBuilder.writeRow(footer);
     }
      
     @Override
     public void close() {
       	try {
       	  if (cursor != null)
       		  cursor.close();
       	  }catch(Exception e) {
        	  e.printStackTrace(); 	
       	  }  
     }    
    
	 private class Parameters {
	     public Object obdobie;
	     public Object zakaznik;
	     public FilterTextBuilder headerText = new FilterTextBuilder();
	 }             
}
