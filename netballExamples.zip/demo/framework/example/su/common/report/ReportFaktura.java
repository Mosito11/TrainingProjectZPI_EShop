package demo.framework.example.su.common.report;

import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.SessionObject;
import netframework.report.UserReport;
import netframework.report.UserReportGroupItem;
import netframework.view.View;
import demo.framework.example.bo.ciselniky.Mena;
import demo.framework.example.bo.ciselniky.Zakaznik;
import demo.framework.example.bo.fakturacia.Faktura;
import demo.framework.example.su.common.report.prmt.PRFaktura;
import demo.framework.example.su.common.view.ViewFaktura;
import demo.framework.translate.ResourceConstants;


public class ReportFaktura extends UserReport {
	
	@Override
    public String[] createColumns() {
        return new String[] {
                ViewFaktura.CISLO,
            	ViewFaktura.DATUM_VYSTAVENIA,
            	ViewFaktura.ZAKAZNIK_ICO,
            	ViewFaktura.ZAKAZNIK_NAZOV,
            	ViewFaktura.OBDOBIE,
            	ViewFaktura.STAV,
            	ViewFaktura.TYP,
            	ViewFaktura.MENA_KOD};            	
    }
    
	@Override
    public String[] createSumColumns() {    
        return new String[] {ViewFaktura.CELKOVA_SUMA};
    }

	@Override
    public String[] createSortableColumns() {
        return new String[] {
                ViewFaktura.CISLO,
            	ViewFaktura.DATUM_VYSTAVENIA,
            	ViewFaktura.ZAKAZNIK_ICO,
            	ViewFaktura.ZAKAZNIK_NAZOV,
            	ViewFaktura.OBDOBIE,
            	ViewFaktura.STAV,
            	ViewFaktura.TYP,
            	ViewFaktura.MENA_KOD};            	
    }
    
	@Override
    public UserReportGroupItem[] createGroupColumns(){
        UserReportGroupItem[] columns = new UserReportGroupItem[3]; 
        
        columns[0] = new UserReportGroupItem(Zakaznik.ICO.getLongCaption(), ViewFaktura.ZAKAZNIK_ICO); 
        columns[0].setHeaderColumns(new String[] {ViewFaktura.ZAKAZNIK_ICO, ViewFaktura.ZAKAZNIK_NAZOV});
        columns[0].setFooterColumns(new String[] {ViewFaktura.ZAKAZNIK_ICO});                

        /*
        columns[0] = new UserReportGroupItem(Zakaznik.ICO.getLongCaption(), ViewFaktura.ZAKAZNIK_ICO); 
        columns[0].setGroupingColumns(new String[] {ViewFaktura.ZAKAZNIK_NAZOV, ViewFaktura.ZAKAZNIK_ICO});
        columns[0].setHeaderColumns(new String[] {ViewFaktura.ZAKAZNIK_ICO, ViewFaktura.ZAKAZNIK_NAZOV});
        columns[0].setFooterColumns(new String[] {ViewFaktura.ZAKAZNIK_ICO});
        Vysledok: ORDERING Zakaznik.nazov,Zakaznik.ico,Zakaznik.id,Faktura.cislo,Faktura.obdobie
        
        columns[0] = new UserReportGroupItem(Zakaznik.ICO.getLongCaption(), ViewFaktura.ZAKAZNIK_ID); 
        columns[0].setGroupingColumns(new String[] {ViewFaktura.ZAKAZNIK_ICO, ViewFaktura.ZAKAZNIK_NAZOV});
        columns[0].setHeaderColumns(new String[] {ViewFaktura.ZAKAZNIK_ICO, ViewFaktura.ZAKAZNIK_NAZOV});
        columns[0].setFooterColumns(new String[] {ViewFaktura.ZAKAZNIK_ICO});    
        Vysledok: ORDERING Zakaznik.ico,Zakaznik.nazov,Zakaznik.id,Faktura.cislo,Faktura.obdobie
        
        columns[0] = new UserReportGroupItem(Zakaznik.ICO.getLongCaption(), ViewFaktura.ZAKAZNIK_ICO); 
        columns[0].setGroupingColumns(new String[] {ViewFaktura.ZAKAZNIK_ID, ViewFaktura.ZAKAZNIK_NAZOV});
        columns[0].setHeaderColumns(new String[] {ViewFaktura.ZAKAZNIK_ICO, ViewFaktura.ZAKAZNIK_NAZOV});
        columns[0].setFooterColumns(new String[] {ViewFaktura.ZAKAZNIK_ICO});
        Vysledok: ORDERING Zakaznik.id,Zakaznik.nazov,Zakaznik.ico,Faktura.cislo,Faktura.obdobie
        */
        
        columns[1] = new UserReportGroupItem(Mena.KOD.getLongCaption(), ViewFaktura.MENA_KOD); 
        columns[1].setHeaderColumns(new String[] {ViewFaktura.MENA_KOD});
        columns[1].setFooterColumns(new String[] {ViewFaktura.MENA_KOD});                

        columns[2] = new UserReportGroupItem(Faktura.OBDOBIE.getLongCaption(), ViewFaktura.OBDOBIE); 
        columns[2].setHeaderColumns(new String[] {ViewFaktura.OBDOBIE});
        columns[2].setFooterColumns(new String[] {ViewFaktura.OBDOBIE});
        
        return columns;
    }
    
	@Override
    public View createView(SessionObject session) {
        return new ViewFaktura();
    }
    
	@Override
    public String getName() {
        return ResourceConstants.FAKTURY;
    }
    
	@Override
    public String getDescription() {
        return ResourceConstants.POUZITIE_EXTENDS_USERREPORT;
    }

	@Override
	public Class<PRFaktura> getParameterMediatorClass() {
		return PRFaktura.class;
	}

	@Override
	public String getCompanyName() {
		return (String)((EclipseLinkSession) getSessionObject()).getProperty("companyName");
	}
}
