package demo.framework.example.su.common.report;
import demo.framework.translate.ResourceConstants;
import netball.server.component.tree.TreeContainer;
import netball.server.component.tree.TreeNode;
import netframework.mediator.MDReportTree;

public class ReportTree extends MDReportTree {
    
	@Override
	protected TreeContainer createTreeContainer() {
        TreeNode root = createNode("tlacoveZostavy", translateText(ResourceConstants.TLACOVE_ZOSTAVY), null);
        root.add(createFakturaNode());
        return new TreeContainer(root);
    }    
    
    protected TreeNode createFakturaNode() {
    	TreeNode root = createNode("faktury",  translateText(ResourceConstants.FAKTURY), null);
        root.add(createLeaf(new ReportFaktura()));
        root.add(createLeaf(new ReportOdberatelskaFaktura()));
        root.add(createLeaf(new ReportOdberatelskaFakturaMySource()));
        root.add(createLeaf(new ReportOdberatelskaFakturaMySource1()));
        root.add(createLeaf(new ReportOdberatelskaFakturaMyCursor()));
        root.add(createLeaf(new ReportOdberatelskaFakturaMySumator()));
        root.add(createLeaf(new ReportOdberatelskaFakturaMyGroupColumnSumator()));
        root.add(createLeaf(new ReportFakturaPolozka()));       
        root.add(createLeaf(new ReportOdberatelskaFakturaDoklady()));
        root.add(createLeaf(new ReportOdberatelskaFakturaSpanReport()));
        return root;        
    }
} 
