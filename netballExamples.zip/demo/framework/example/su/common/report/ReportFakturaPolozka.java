package demo.framework.example.su.common.report;

import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.SessionObject;
import netframework.report.UserReport;
import netframework.report.UserReportGroupItem;
import netframework.view.View;
import demo.framework.example.bo.ciselniky.Mena;
import demo.framework.example.bo.ciselniky.Zakaznik;
import demo.framework.example.bo.fakturacia.Faktura;
import demo.framework.example.su.common.report.prmt.PRFakturaPolozka;
import demo.framework.example.su.common.view.ViewFakturaPolozka;
import demo.framework.translate.ResourceConstants;


public class ReportFakturaPolozka extends UserReport {
	
	@Override
    public String[] createColumns() {
        return new String[] {
        		ViewFakturaPolozka.FAKTURA_CISLO,
        		ViewFakturaPolozka.FAKTURA_OBDOBIE,
        		ViewFakturaPolozka.FAKTURA_STAV,
        		ViewFakturaPolozka.FAKTURA_TYP,
        		ViewFakturaPolozka.FAKTURA_DATUM_VYSTAVENIA,
        		ViewFakturaPolozka.ZAKAZNIK_ICO, 
        		ViewFakturaPolozka.ZAKAZNIK_NAZOV, 
        		ViewFakturaPolozka.MNOZSTVO,
        		ViewFakturaPolozka.JEDNOTKOVA_CENA,
        		ViewFakturaPolozka.MERNA_JEDNOTKA,
        		ViewFakturaPolozka.NAZOV,
        		ViewFakturaPolozka.MENA_KOD};
    }
    
	@Override
    public String[] createSumColumns() {    
        return new String[] {ViewFakturaPolozka.CELKOVA_CENA};
    }

	@Override
    public String[] createSortableColumns() {
        return new String[] {
        		ViewFakturaPolozka.FAKTURA_CISLO,
        		ViewFakturaPolozka.FAKTURA_OBDOBIE,
        		ViewFakturaPolozka.FAKTURA_STAV,
        		ViewFakturaPolozka.FAKTURA_TYP,
        		ViewFakturaPolozka.FAKTURA_DATUM_VYSTAVENIA,
        		ViewFakturaPolozka.ZAKAZNIK_ICO, 
        		ViewFakturaPolozka.ZAKAZNIK_NAZOV, 
        		ViewFakturaPolozka.MNOZSTVO,
        		ViewFakturaPolozka.JEDNOTKOVA_CENA,
        		ViewFakturaPolozka.CELKOVA_CENA,
        		ViewFakturaPolozka.MERNA_JEDNOTKA,
        		ViewFakturaPolozka.NAZOV,
        		ViewFakturaPolozka.MENA_KOD};
    }
    
	@Override
    public UserReportGroupItem[] createGroupColumns(){
        UserReportGroupItem[] columns = new UserReportGroupItem[3]; 
        
        columns[0] = new UserReportGroupItem(Zakaznik.ICO.getLongCaption(), ViewFakturaPolozka.ZAKAZNIK_ICO); 
        columns[0].setHeaderColumns(new String[] {ViewFakturaPolozka.ZAKAZNIK_ICO, ViewFakturaPolozka.ZAKAZNIK_NAZOV});
        columns[0].setFooterColumns(new String[] {ViewFakturaPolozka.ZAKAZNIK_ICO});                
        
        columns[1] = new UserReportGroupItem(Mena.KOD.getLongCaption(), ViewFakturaPolozka.MENA_KOD); 
        columns[1].setHeaderColumns(new String[] {ViewFakturaPolozka.MENA_KOD});
        columns[1].setFooterColumns(new String[] {ViewFakturaPolozka.MENA_KOD});                

        columns[2] = new UserReportGroupItem(Faktura.OBDOBIE.getLongCaption(), ViewFakturaPolozka.FAKTURA_OBDOBIE); 
        columns[2].setHeaderColumns(new String[] {ViewFakturaPolozka.FAKTURA_OBDOBIE});
        columns[2].setFooterColumns(new String[] {ViewFakturaPolozka.FAKTURA_OBDOBIE});
        
        return columns;
    }
    
	@Override
    public View createView(SessionObject session) {
        return new ViewFakturaPolozka();
    }
    
	@Override
    public String getName() {
        return ResourceConstants.POLOZKY_FAKTURY;
    }
    
	@Override
    public String getDescription() {
        return ResourceConstants.POUZITIE_EXTENDS_USERREPORT;
    }
    
	@Override
    public Class<PRFakturaPolozka> getParameterMediatorClass() {
    	return PRFakturaPolozka.class;
    }
	
	@Override
	public String getCompanyName() {
		return (String)((EclipseLinkSession) getSessionObject()).getProperty("companyName");
	}
}
