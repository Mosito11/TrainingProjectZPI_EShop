package demo.framework.example.su.common.report;
import netball.server.component.tree.TreeContainer;
import netball.server.component.tree.TreeNode;
import netframework.mediator.MDUtilities;
import netframework.mediator.ctb.MDReportTreeCTB;
import demo.framework.translate.ResourceConstants;

public class ReportTreeCTB extends MDReportTreeCTB {
    
	@Override
	protected TreeContainer createTreeContainer() {
        TreeNode root = createNode("tlacoveZostavy", translateText(ResourceConstants.TLACOVE_ZOSTAVY), null);
        root.add(createFakturaNode());
        return new TreeContainer(root);
    }    
    
    protected TreeNode createFakturaNode() {
    	TreeNode root = createNode("faktury",  translateText(ResourceConstants.FAKTURY), null);
        root.add(createLeaf(new ReportFaktura()));
        root.add(createLeaf(new ReportOdberatelskaFaktura()));
        root.add(createLeaf(new ReportOdberatelskaFakturaMySource()));
        root.add(createLeaf(new ReportOdberatelskaFakturaMySource1()));
        root.add(createLeaf(new ReportOdberatelskaFakturaMyCursor()));
        root.add(createLeaf(new ReportOdberatelskaFakturaMySumator()));
        root.add(createLeaf(new ReportOdberatelskaFakturaMyGroupColumnSumator()));
        root.add(createLeaf(new ReportFakturaPolozka()));       
        root.add(createLeaf(new ReportOdberatelskaFakturaDoklady()));
        return root;
    }
} 
