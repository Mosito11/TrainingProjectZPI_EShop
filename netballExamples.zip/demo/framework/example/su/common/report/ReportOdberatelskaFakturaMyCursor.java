package demo.framework.example.su.common.report;

import java.math.BigDecimal;

import demo.framework.example.bo.ciselniky.Mena;
import demo.framework.example.bo.common.Helper;
import demo.framework.example.bo.fakturacia.FakturaPolozka;
import demo.framework.example.bo.fakturacia.OdberatelskaFaktura;
import demo.framework.example.bo.fakturacia.StavFaktury;
import demo.framework.example.bo.fakturacia.TypFaktury;
import demo.framework.example.su.common.report.prmt.PROdberatelskaFakturaMyCursor;
import demo.framework.example.su.db.DBSkolenieCatalog;
import demo.framework.translate.ResourceConstants;
import netball.server.component.table.TableContainer;
import netframework.FrameworkUtilities;
import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.ComponentBuilder;
import netframework.mediator.SessionObject;
import netframework.report.Report;
import netframework.report.ReportBuilder;
import netframework.report.ReportColumnProperties;
import netframework.report.ReportParameters;
import netframework.report.ViewCursorReportSource;
import netframework.report.grouping.GroupColumn;
import netframework.report.grouping.GroupColumnItem;
import netframework.report.grouping.GroupRules;
import netframework.report.grouping.GroupTotalRules;
import netframework.report.grouping.NumberGroupSummarizer;
import netframework.sql.SQLExpression;
import netframework.sql.SQLExpressionBuilder;
import netframework.sql.SQLItem;
import netframework.sql.SQLJoinCondition;
import netframework.sql.SQLQuery;
import netframework.sql.SQLValueConvertor;
import netframework.view.ViewCursor;
import netframework.view.ViewRow;


public class ReportOdberatelskaFakturaMyCursor implements Report {
    
    public static final String OBDOBIE = OdberatelskaFaktura.OBDOBIE.getId();

    @Override 
    public ReportBuilder execute(ReportParameters prmt, SessionObject session) throws Exception{
        Parameters prmts = createParameters(prmt, session);        
        ViewCursor cursor = createCursor(prmts, session);
        ViewCursorReportSource report = new ViewCursorReportSource();             
        ReportColumnProperties[] cols = new ReportColumnProperties[] {
                ComponentBuilder.createReportColumn(FakturaPolozka.NAZOV.getId(), FakturaPolozka.NAZOV, false, session), 
                ComponentBuilder.createReportColumn(FakturaPolozka.MNOZSTVO.getId(), FakturaPolozka.MNOZSTVO, false, session),
                ComponentBuilder.createReportColumn(FakturaPolozka.JEDNOTKOVA_CENA.getId(), FakturaPolozka.JEDNOTKOVA_CENA, false, session),
                ComponentBuilder.createReportColumn(MyCursor.CELKOVA_SUMA, FakturaPolozka.JEDNOTKOVA_CENA, ResourceConstants.CELKOVA_CENA, session),
                ComponentBuilder.createReportColumn(Mena.KOD.getId(), Mena.KOD, false, session)
        };
        report.setCursor(new MyCursor(cursor));
        report.setColumnProperty(cols);
        report.setUserName(session.getUser() != null ? session.getUser().getName() : null);
        report.setCompanyName((String)((EclipseLinkSession) session).getProperty("companyName"));
        report.setHeaderText(session.translateText(getName()) +  prmts.headerText);
        
        GroupColumn groupColumns[] = new GroupColumn[1];
        int indexCislo = cursor.getColumnIndex(OdberatelskaFaktura.CISLO.getId());
        groupColumns[0] = new GroupColumn(indexCislo);
        groupColumns[0].setHeaderItem(new GroupColumnItem(indexCislo, ComponentBuilder.createRenderer(OdberatelskaFaktura.CISLO, session), session.translateText(OdberatelskaFaktura.CISLO.getCaption())));
        groupColumns[0].setFooterItem(new GroupColumnItem(indexCislo, ComponentBuilder.createRenderer(OdberatelskaFaktura.CISLO, session), session.translateText(OdberatelskaFaktura.CISLO.getCaption())));
        groupColumns[0].setFooterText(session.translateText(OdberatelskaFaktura.CISLO.getCaption()));
        
        NumberGroupSummarizer[] sumators = new NumberGroupSummarizer[] {
            new NumberGroupSummarizer(cursor.getColumnIndex(MyCursor.CELKOVA_SUMA), report.getColumnIndex(MyCursor.CELKOVA_SUMA), report.getRenderer(MyCursor.CELKOVA_SUMA)),
        };
        report.setGroupRules(new GroupRules(groupColumns, sumators));
        report.setGroupTotalRules(new GroupTotalRules(sumators, session.translateText(ResourceConstants.CELKOM)));
        
        return new ReportBuilder(report);
    }

    private ViewCursor createCursor(Parameters prmts, SessionObject session) throws Exception {
    	DBSkolenieCatalog c = DBSkolenieCatalog.getInstance();
        SQLQuery query = new SQLQuery();
        query.addTable(new SQLJoinCondition(c.FAKTURA));
        query.addTable(new SQLJoinCondition(c.MENA, c.MENA.ID, c.FAKTURA.MENA));
        query.addTable(new SQLJoinCondition(c.ZAKAZNIK, c.ZAKAZNIK.ID, c.FAKTURA.ZAKAZNIK));
        query.addTable(new SQLJoinCondition(c.FAKTURA_POLOZKA, c.FAKTURA_POLOZKA.FAKTURA, c.FAKTURA.ID));
    	query.addField(Mena.KOD.getId(), c.MENA.KOD);
    	query.addField(OdberatelskaFaktura.OBDOBIE.getId(), c.FAKTURA.OBDOBIE);
    	query.addField(OdberatelskaFaktura.CISLO.getId(), c.FAKTURA.CISLO);
    	query.addField(FakturaPolozka.NAZOV.getId(), c.FAKTURA_POLOZKA.NAZOV);
    	query.addField(FakturaPolozka.MNOZSTVO.getId(), c.FAKTURA_POLOZKA.MNOZSTVO);
    	query.addField(FakturaPolozka.JEDNOTKOVA_CENA.getId(), c.FAKTURA_POLOZKA.JEDNOTKOVA_CENA);
    	query.addField(MyCursor.CELKOVA_SUMA, new EmptyField()); 
        query.addOrdering(c.FAKTURA.CISLO);
        SQLExpression exp1 = SQLExpressionBuilder.get(c.FAKTURA.STAV).equal(StavFaktury.SPRACOVANA.getKey());
        SQLExpression exp2 = SQLExpressionBuilder.get(c.FAKTURA.TYP).equal(TypFaktury.ODBERATELSKA.getKey());
        query.setExpression(exp1.and(exp2));
        if (prmts.obdobie != null) {
        	SQLExpression exp = FrameworkUtilities.createSQLExpression(c.FAKTURA.OBDOBIE, prmts.obdobie); 
            query.setExpression(query.getExpression() != null ? query.getExpression().and(exp) : exp);
        }
        if (prmts.zakaznik != null) {
        	SQLExpression exp = FrameworkUtilities.createSQLExpression(c.ZAKAZNIK.ICO, prmts.zakaznik); 
            query.setExpression(query.getExpression() != null ? query.getExpression().and(exp) : exp);
        }
        return ((EclipseLinkSession) session).execute(query); 
    }
    
    private Parameters createParameters(ReportParameters prmt, SessionObject session) throws Exception {
        Parameters parameteres = new Parameters();
        if (prmt != null) {
           Object value = prmt.getValue(OBDOBIE);
           if (value != null) {
              parameteres.obdobie = value;
              parameteres.headerText.add(OdberatelskaFaktura.OBDOBIE.getLongCaption(), value, session);
           }else{
        	  throw new IllegalArgumentException(session.translateText(ResourceConstants.OBDOBIE_MUSI_BYT_VYPLNENE_)); 
           }
        }
        return parameteres;
    }

    @Override
    public String getName() {
        return ResourceConstants.ZOZMAM_POLOZIEK_SPRACOVANYCH_ODBERATELSKYCH_FAKTUR;
    }
    
    @Override
    public String getDescription() {
        return ResourceConstants.POUZITIE_IMPLEMENTS_REPORT_IMPLEMENTS_A_VIEWCURSOR; 
    }
    
    @Override
    public Class<PROdberatelskaFakturaMyCursor> getParameterMediatorClass() {
        return PROdberatelskaFakturaMyCursor.class;
    }        
 
private static class EmptyField implements SQLItem {

	@Override
	public String toSqlSyntax(int sqlType, SQLValueConvertor convertor) {
		return "0";
	}
}     

private static class MyCursor implements ViewCursor {

	private ViewCursor cursor;
	private static final String CELKOVA_SUMA = "celkovaSuma";
	private int celkovaSumaIndex;
	private int mnozstvoIndex;
	private int jednotkovaCenaIndex;
	
	public MyCursor (ViewCursor cursor) {
		this.cursor = cursor;
		celkovaSumaIndex = cursor.getColumnIndex(CELKOVA_SUMA);
		mnozstvoIndex = cursor.getColumnIndex(FakturaPolozka.MNOZSTVO.getId());
		jednotkovaCenaIndex = cursor.getColumnIndex(FakturaPolozka.JEDNOTKOVA_CENA.getId());
	}
	
	@Override
	public void close() throws Exception {
		cursor.close();
	}

	@Override
	public int getColumnIndex(Object colIndex) {
		return this.cursor.getColumnIndex(colIndex);
	}

	@Override
	public String[] getColumnNames() {
		return this.getColumnNames();
	}

	@Override
	public boolean hasNext() throws Exception {
		return cursor.hasNext();
	}

	@Override
	public ViewRow next() throws Exception {
		ViewRow row = this.cursor.next();
		BigDecimal mnozstvo = (BigDecimal) row.getValueAt(mnozstvoIndex);
		BigDecimal jednotkovaCena = (BigDecimal) row.getValueAt(jednotkovaCenaIndex);
		if (mnozstvo != null && jednotkovaCena != null) {
			BigDecimal celkovaCena = mnozstvo.multiply(jednotkovaCena);
			celkovaCena = celkovaCena.setScale(2, BigDecimal.ROUND_HALF_UP);
			row.setValueAt(celkovaCena, celkovaSumaIndex);
		}else{
			row.setValueAt(Helper.DEFAULT_VALUE, celkovaSumaIndex);
		}
		return row;
	}

	@Override
	public TableContainer readToContainer() throws Exception {
		return null;
	}
}    
    
private static class Parameters {
    public Object obdobie;
    public Object zakaznik;
    public FilterTextBuilder headerText = new FilterTextBuilder();
}             
}
