package demo.framework.example.su.common.report;

import java.awt.Font;
import java.awt.Insets;

import javax.swing.SwingConstants;

import netball.server.print.PRBorderPanel;
import netball.server.print.PRComponent;
import netball.server.print.PREmptyComponent;
import netball.server.print.PRFlowCaptionComp;
import netball.server.print.PRFlowPanel;
import netball.server.print.PRFont;
import netball.server.print.PRLabel;
import netball.server.print.PRMultiLineLabel;
import netball.server.print.PRReport;
import netframework.bo.attributes.Attribute;
import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.ComponentBuilder;
import netframework.sql.SQLExpressionBuilder;
import netframework.sql.SQLJoinCondition;
import netframework.sql.SQLQuery;
import netframework.view.ViewCursor;
import netframework.view.ViewRow;
import demo.framework.example.bo.ciselniky.Mena;
import demo.framework.example.bo.ciselniky.Zakaznik;
import demo.framework.example.bo.common.Helper;
import demo.framework.example.bo.fakturacia.FakturaPolozka;
import demo.framework.example.bo.fakturacia.OdberatelskaFaktura;
import demo.framework.example.bo.fakturacia.SumaVMene;
import demo.framework.example.su.db.DBSkolenieCatalog;
import demo.framework.translate.ResourceConstants;


public class ReportDokladOdberatelskaFakturaFlowPanel extends ReportDokladFlowPanel {
	
	@Override
    protected ViewRow readHeader() throws Exception {
    	DBSkolenieCatalog c = DBSkolenieCatalog.getInstance();
        SQLQuery query = new SQLQuery();
        query.addTable(new SQLJoinCondition(c.FAKTURA)); 
        query.addTable(new SQLJoinCondition(c.ZAKAZNIK, SQLJoinCondition.LEFT_OUTER_JOIN, c.ZAKAZNIK.ID, c.FAKTURA.ZAKAZNIK));
        query.addTable(new SQLJoinCondition(c.MENA, SQLJoinCondition.LEFT_OUTER_JOIN, c.MENA.ID, c.FAKTURA.MENA));
        query.addField(OdberatelskaFaktura.OBDOBIE.getId(), c.FAKTURA.OBDOBIE);
        query.addField(OdberatelskaFaktura.STAV.getId(), c.FAKTURA.STAV);
        query.addField(OdberatelskaFaktura.CISLO.getId(), c.FAKTURA.CISLO);
        query.addField(OdberatelskaFaktura.DATUM_VYSTAVENIA.getId(), c.FAKTURA.DATUM_VYSTAVENIA);
        query.addField(SumaVMene.SUMA.getId(), c.FAKTURA.CELKOVA_SUMA);
        query.addField(Mena.KOD.getId(), c.MENA.KOD);
        query.addField(Zakaznik.NAZOV.getId(), c.ZAKAZNIK.NAZOV);
        query.addField(Zakaznik.ADRESA.getId(), c.ZAKAZNIK.ADRESA);
        query.setExpression(SQLExpressionBuilder.get(c.FAKTURA.ID).equal(this.dokladId));
        ViewCursor cursor = ((EclipseLinkSession) session).execute(query);
        if (!cursor.hasNext())
           throw new IllegalArgumentException(Helper.createMessage(session, ResourceConstants.NEPODARILO_SA_NACITAT_DOKLAD_S_ID_____0___, dokladId));
        return cursor.next();   
    }
    
	@Override
    protected ViewCursor readItems() throws Exception {
    	DBSkolenieCatalog c = DBSkolenieCatalog.getInstance();
    	SQLQuery query = new SQLQuery();
        query.addTable(new SQLJoinCondition(c.FAKTURA_POLOZKA));
        query.addField(FakturaPolozka.NAZOV.getId(), c.FAKTURA_POLOZKA.NAZOV);
        query.addField(FakturaPolozka.MNOZSTVO.getId(), c.FAKTURA_POLOZKA.MNOZSTVO);
        query.addField(FakturaPolozka.MERNA_JEDNOTKA.getId(), c.FAKTURA_POLOZKA.MERNA_JEDNOTKA);
        query.addField(FakturaPolozka.JEDNOTKOVA_CENA.getId(), c.FAKTURA_POLOZKA.JEDNOTKOVA_CENA);
        query.addField(FakturaPolozka.CELKOVA_CENA.getId(), c.FAKTURA_POLOZKA.CELKOVA_CENA);
        query.addOrdering(c.FAKTURA_POLOZKA.NAZOV);
        query.setExpression(SQLExpressionBuilder.get(c.FAKTURA_POLOZKA.FAKTURA).equal(this.dokladId));
        return ((EclipseLinkSession) session).execute(query);
    }	

    private String convertValueToString(ViewRow row, Attribute prop) {
    	return ComponentBuilder.convertValueToString(prop, row.getValueAt(row.getColumnIndex(prop.getId())), session);
    }

    private PRComponent createTitle(ViewRow headerRow) {
        String cislo = convertValueToString(headerRow, OdberatelskaFaktura.CISLO);
        PRLabel title = new PRLabel();       
        title.setFont(new PRFont("Dialog", java.awt.Font.BOLD, 14));
        title.setText(session.translateText(ResourceConstants.FAKTURA_) + cislo);
        title.setWidth(500);
        title.setHeight(18);
    	return title;
    }
    
    @Override
    protected PRReport createPage(ViewRow headerRow, int pageIndex) throws Exception {
        PRFlowPanel titleForm = new PRFlowPanel(javax.swing.SwingConstants.VERTICAL);       
        titleForm.add(new PREmptyComponent(0, 80));
        titleForm.add(createTitle(headerRow));
        titleForm.addGap(20);

        PRFlowCaptionComp zakaznikForm = new PRFlowCaptionComp(SwingConstants.VERTICAL);
        zakaznikForm.addItem(session.translateText(Zakaznik.NAZOV.getCaption()), convertValueToString(headerRow, Zakaznik.NAZOV), 450);
        zakaznikForm.addItem(session.translateText(Zakaznik.ADRESA.getCaption()), convertValueToString(headerRow, Zakaznik.ADRESA), 450);
        
        PRBorderPanel zakaznikPanel = new PRBorderPanel(zakaznikForm);
        zakaznikPanel.setPaintBorder(true);
        zakaznikPanel.setTitle(session.translateText(ResourceConstants.ZAKAZNIK));
        zakaznikPanel.setInsets(new Insets(20, 10, 10, 10));
        titleForm.add(zakaznikPanel);
        
        PRReport page = new PRReport(); 
        page.setVerticalGap(10);
        page.setHeader(titleForm);
        page.setFooter(createFooter());
        return page; 
    }

   private PRComponent createFooter() {
	   PRMultiLineLabel label = new PRMultiLineLabel();
       label.setRowCount(3);
       label.setInsets(new Insets(2,2,2,2));
       label.setWidth(520);
       label.setPaintBorder(true);
       label.setText(session.translateText(ResourceConstants.VYSTAVIL_));
       return label;              
    }   
    
    protected ItemBuilder createItemBuilder() {
       return new PolozkyBuilder(); 	
    }
    
    
    
	protected class PolozkyBuilder implements ItemBuilder {
		
	    private int widthPC = 20;
	    private int widthNazov = 500;
	    private int widthMnozstvo = 130;
	    private int widthMJ = 130;
	    private int widthJednotkovaCena = 130;
	    private int widthCelkovaCena = 130;
	    private int rowHeight = 14;
	    private int widthTotal = 520; 
	    private PRFont font = new PRFont("Dialog", Font.PLAIN, 9);
	    private PRFlowPanel header;
	    
	    public PolozkyBuilder() {
	        PRFlowPanel headerForm1 = new PRFlowPanel(javax.swing.SwingConstants.HORIZONTAL);               
	        headerForm1.add(createHeaderLabel(session.translateText(ResourceConstants.P_C_), widthPC, 1));
	        headerForm1.add(createHeaderLabel(session.translateText(FakturaPolozka.NAZOV.getCaption()), widthNazov, 1));        
	        
	        PRFlowPanel headerForm2 = new PRFlowPanel(javax.swing.SwingConstants.HORIZONTAL);       
	        headerForm2.add(createHeaderLabel(session.translateText(FakturaPolozka.MNOZSTVO.getCaption()), widthMnozstvo, 1));
	        headerForm2.add(createHeaderLabel(session.translateText(FakturaPolozka.MERNA_JEDNOTKA.getCaption()), widthMJ, 1));
	        headerForm2.add(createHeaderLabel(session.translateText(FakturaPolozka.JEDNOTKOVA_CENA.getCaption()), widthJednotkovaCena, 1));
	        headerForm2.add(createHeaderLabel(session.translateText(FakturaPolozka.CELKOVA_CENA.getCaption()), widthCelkovaCena, 1));
	        
	        header = new PRFlowPanel(javax.swing.SwingConstants.VERTICAL);       
	        header.add(headerForm1);
	        header.add(headerForm2);
	    } 
	    
	    private PRMultiLineLabel createHeaderLabel(String text, int width, int rowCount) {
	        PRMultiLineLabel label = new PRMultiLineLabel(text);
	        label.setWidth(width);
	        label.setRowHeight(rowHeight);        
	        label.setRowCount(rowCount);        
	        label.setHorizontalAlign(javax.swing.SwingConstants.CENTER);
	        label.setVerticalAlign(javax.swing.SwingConstants.CENTER);
	        label.setPaintBorder(true);       
	        label.setFont(font);
	        return label;
	    }
	    
	    private PRLabel createItemLabel(String text, int width, int horizontalAlign) {
	        PRLabel label = new PRLabel(text);
	        label.setWidth(width);
	        label.setHeight(rowHeight);
	        label.setHorizontalAlign(horizontalAlign);
	        label.setVerticalAlign(javax.swing.SwingConstants.CENTER);
	        label.setPaintBorder(true);       
	        label.setFont(font);
	        return label;
	    }
	    
	    @Override
	    public PRComponent createRow(ViewRow row, ViewRow headerRow, boolean isLastRow, int pc) throws Exception {     
	    	String nazov = convertValueToString(row, FakturaPolozka.NAZOV); 
	    	String mnozstvo = convertValueToString(row, FakturaPolozka.MNOZSTVO);
	    	String mernaJednotka = convertValueToString(row, FakturaPolozka.MERNA_JEDNOTKA);
	    	String jednotkovaCena = convertValueToString(row, FakturaPolozka.JEDNOTKOVA_CENA);
	    	String celkovaCena = convertValueToString(row, FakturaPolozka.CELKOVA_CENA);
	    	
	        PRFlowPanel rowForm1 = new PRFlowPanel(javax.swing.SwingConstants.HORIZONTAL);
	        rowForm1.add(createItemLabel(""  + pc + ".", widthPC, javax.swing.SwingConstants.LEFT));
	        rowForm1.add(createItemLabel(nazov, widthNazov, javax.swing.SwingConstants.LEFT));
	
	        PRFlowPanel rowForm2 = new PRFlowPanel(javax.swing.SwingConstants.HORIZONTAL);
	        rowForm2.add(createItemLabel(mnozstvo, widthMnozstvo, javax.swing.SwingConstants.RIGHT));
	        rowForm2.add(createItemLabel(mernaJednotka, widthMJ, javax.swing.SwingConstants.LEFT));
	        rowForm2.add(createItemLabel(jednotkovaCena, widthJednotkovaCena, javax.swing.SwingConstants.RIGHT));
	        rowForm2.add(createItemLabel(celkovaCena, widthCelkovaCena, javax.swing.SwingConstants.RIGHT));
	        
	        PRFlowPanel rowForm = new PRFlowPanel(javax.swing.SwingConstants.VERTICAL);               
	        rowForm.add(rowForm1);
	        rowForm.add(rowForm2);
	        
	        if (isLastRow) {        	
		        PRLabel celkovaCenaComp = new PRLabel();
		        celkovaCenaComp.setHeight(rowHeight);
		        celkovaCenaComp.setText(session.translateText(OdberatelskaFaktura.CELKOVA_SUMA.getCaption()) + ':' + convertValueToString(headerRow, SumaVMene.SUMA));
		        celkovaCenaComp.setFont(font);        
		        celkovaCenaComp.setHorizontalAlign(javax.swing.SwingConstants.RIGHT);	        
		        celkovaCenaComp.setWidth(widthTotal);  
		        celkovaCenaComp.setPaintBorder(true);
		        PRFlowPanel rowForm4 = new PRFlowPanel(javax.swing.SwingConstants.VERTICAL);       
		        rowForm4.add(rowForm);
		        rowForm4.add(celkovaCenaComp);
		        return rowForm4;
	        }  
	        return rowForm;
	    }    
	    
	    @Override
		public int getHeaderHeight() {
			return header.getSize().height;
		}	
		
	    @Override
		public PRComponent getHeader() {
			return header;
		}	
	}
}
