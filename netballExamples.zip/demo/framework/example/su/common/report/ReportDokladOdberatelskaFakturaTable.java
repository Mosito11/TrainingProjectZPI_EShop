package demo.framework.example.su.common.report;

import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;

import javax.swing.SwingConstants;

import demo.framework.example.bo.ciselniky.Mena;
import demo.framework.example.bo.ciselniky.Zakaznik;
import demo.framework.example.bo.common.Helper;
import demo.framework.example.bo.fakturacia.FakturaPolozka;
import demo.framework.example.bo.fakturacia.OdberatelskaFaktura;
import demo.framework.example.bo.fakturacia.SumaVMene;
import demo.framework.example.su.db.DBSkolenieCatalog;
import demo.framework.translate.ResourceConstants;
import netball.server.print.PRBorderPanel;
import netball.server.print.PRComponent;
import netball.server.print.PRDecoratePage;
import netball.server.print.PREmptyComponent;
import netball.server.print.PRFlowCaptionComp;
import netball.server.print.PRFlowPanel;
import netball.server.print.PRFont;
import netball.server.print.PRLabel;
import netball.server.print.PRMultiLineLabel;
import netball.server.print.PRPage;
import netball.server.print.PRPageFormat;
import netball.server.print.PRReport;
import netball.server.print.PRTable;
import netball.server.print.table.PRGroupTableFooter;
import netball.server.print.table.PRTableCell;
import netball.server.print.table.PRTableHeader;
import netball.server.print.table.PRTableHeaderColumn;
import netball.server.print.table.PRValueTableRow;
import netframework.bo.attributes.Attribute;
import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.ComponentBuilder;
import netframework.mediator.SessionObject;
import netframework.sql.SQLExpressionBuilder;
import netframework.sql.SQLJoinCondition;
import netframework.sql.SQLQuery;
import netframework.view.ViewCursor;
import netframework.view.ViewRow;


public class ReportDokladOdberatelskaFakturaTable {

    private SessionObject session;
    private Object dokladId;
    
    public PRPage[] execute(SessionObject session, Object dokladId) throws Exception {        
        this.session = session;
        this.dokladId = dokladId;        
        ViewRow headerRow = readHeader().next();
        ViewCursor polozky = readItems();        
        PRPageFormat pageFormat = getPageFormat();
        
        PRReport report = createPage(headerRow);        
        PRTable grid = (PRTable) report.getBody();
        int pocetRiadkovNaStranu = report.camputeBodyHeight(pageFormat.createPageFormat());
        pocetRiadkovNaStranu -= grid.getHeader().getSize().getHeight();
        pocetRiadkovNaStranu = pocetRiadkovNaStranu / grid.getRowHeight();
        pocetRiadkovNaStranu --;  // koli suma na konci
        List<PRPage> pages = new ArrayList<PRPage>(1);
        pages.add(report);      
        int pocetRiadkov = 0;
        while(polozky.hasNext()) {
           pocetRiadkov ++;
           if (pocetRiadkov > pocetRiadkovNaStranu) {
              pocetRiadkov = 0;
              report = createPage(headerRow);
              grid = (PRTable) report.getBody();
              pages.add(report);        
           }
           grid.addRow(createGridRow(polozky.next(), pocetRiadkov));
        } 
        // celkova suma
        int indexCelkovaSuma = 5;
        PRGroupTableFooter groupGridFooter = new PRGroupTableFooter(session.translateText(OdberatelskaFaktura.CELKOVA_SUMA.getCaption()), javax.swing.SwingConstants.RIGHT);
        PRTableCell cell = new PRTableCell(convertValueToString(headerRow, SumaVMene.SUMA));
        cell.setFont(grid.getFont());
        groupGridFooter.addItem(cell, indexCelkovaSuma);        
        grid.addRow(groupGridFooter);
        return addPageNumbers(pages);
    }
    
    private PRPage[] addPageNumbers(List<PRPage> pages) {     
        PRDecoratePage reports[] = new PRDecoratePage[pages.size()];
        for (int i = 0; i < pages.size(); i++) {
           reports[i] = new PRDecoratePage((PRPage) pages.get(i));
           reports[i].setRightTopCorner(new PRLabel(session.translateText(ResourceConstants.STRANA_) + (i + 1) + " / " + pages.size() + "  "));
        }       
        return reports;        
    }    
    
    public PRPageFormat getPageFormat() {
        return new PRPageFormat();
    }    
    
    private ViewCursor readHeader() throws Exception {
    	DBSkolenieCatalog c = DBSkolenieCatalog.getInstance();
        SQLQuery query = new SQLQuery();
        query.addTable(new SQLJoinCondition(c.FAKTURA)); 
        query.addTable(new SQLJoinCondition(c.ZAKAZNIK, SQLJoinCondition.LEFT_OUTER_JOIN, c.ZAKAZNIK.ID, c.FAKTURA.ZAKAZNIK));
        query.addTable(new SQLJoinCondition(c.MENA, SQLJoinCondition.LEFT_OUTER_JOIN, c.MENA.ID, c.FAKTURA.MENA));
        query.addField(OdberatelskaFaktura.OBDOBIE.getId(), c.FAKTURA.OBDOBIE);
        query.addField(OdberatelskaFaktura.STAV.getId(), c.FAKTURA.STAV);
        query.addField(OdberatelskaFaktura.CISLO.getId(), c.FAKTURA.CISLO);
        query.addField(OdberatelskaFaktura.DATUM_VYSTAVENIA.getId(), c.FAKTURA.DATUM_VYSTAVENIA);
        query.addField(SumaVMene.SUMA.getId(), c.FAKTURA.CELKOVA_SUMA);
        query.addField(Mena.KOD.getId(), c.MENA.KOD);
        query.addField(Zakaznik.NAZOV.getId(), c.ZAKAZNIK.NAZOV);
        query.addField(Zakaznik.ADRESA.getId(), c.ZAKAZNIK.ADRESA);
        query.setExpression(SQLExpressionBuilder.get(c.FAKTURA.ID).equal(this.dokladId));
        ViewCursor cursor = ((EclipseLinkSession) session).execute(query);
        if (!cursor.hasNext())
           throw new IllegalArgumentException(Helper.createMessage(session, ResourceConstants.NEPODARILO_SA_NACITAT_DOKLAD_S_ID_____0___, dokladId));
        return cursor;   
    }
    
    private ViewCursor readItems() throws Exception {
    	DBSkolenieCatalog c = DBSkolenieCatalog.getInstance();
    	SQLQuery query = new SQLQuery();
        query.addTable(new SQLJoinCondition(c.FAKTURA_POLOZKA));
        query.addField(FakturaPolozka.NAZOV.getId(), c.FAKTURA_POLOZKA.NAZOV);
        query.addField(FakturaPolozka.MNOZSTVO.getId(), c.FAKTURA_POLOZKA.MNOZSTVO);
        query.addField(FakturaPolozka.MERNA_JEDNOTKA.getId(), c.FAKTURA_POLOZKA.MERNA_JEDNOTKA);
        query.addField(FakturaPolozka.JEDNOTKOVA_CENA.getId(), c.FAKTURA_POLOZKA.JEDNOTKOVA_CENA);
        query.addField(FakturaPolozka.CELKOVA_CENA.getId(), c.FAKTURA_POLOZKA.CELKOVA_CENA);
        query.addOrdering(c.FAKTURA_POLOZKA.NAZOV);
        query.setExpression(SQLExpressionBuilder.get(c.FAKTURA_POLOZKA.FAKTURA).equal(this.dokladId));
        return ((EclipseLinkSession) session).execute(query);
    }	

    private PRTableHeader createGridHeader() {
    	PRTableHeader gridHeader = new PRTableHeader();       
        gridHeader.setFont(new PRFont("Dialog", java.awt.Font.PLAIN, 8));
        gridHeader.setRowHeight(14);
        gridHeader.add(new PRTableHeaderColumn(session.translateText(ResourceConstants.P_C_), 20, SwingConstants.LEFT));
        gridHeader.add(new PRTableHeaderColumn(session.translateText(FakturaPolozka.NAZOV.getColumnName()), 300, SwingConstants.LEFT));
   		gridHeader.add(new PRTableHeaderColumn(session.translateText(FakturaPolozka.MNOZSTVO.getColumnName()), 55, SwingConstants.RIGHT));
		gridHeader.add(new PRTableHeaderColumn(session.translateText(FakturaPolozka.MERNA_JEDNOTKA.getColumnName()), 30, SwingConstants.LEFT));
		gridHeader.add(new PRTableHeaderColumn(session.translateText(FakturaPolozka.JEDNOTKOVA_CENA.getColumnName()), 55, SwingConstants.RIGHT));
		gridHeader.add(new PRTableHeaderColumn(session.translateText(FakturaPolozka.CELKOVA_CENA.getColumnName()), 55, SwingConstants.RIGHT));
        return gridHeader;
    } 

    private PRValueTableRow createGridRow(ViewRow row, int pc) {
    	PRValueTableRow gridRow = new PRValueTableRow();
        gridRow.add("" + pc + ".");
        gridRow.add(convertValueToString(row, FakturaPolozka.NAZOV));
        gridRow.add(convertValueToString(row, FakturaPolozka.MNOZSTVO));
        gridRow.add(convertValueToString(row, FakturaPolozka.MERNA_JEDNOTKA));
        gridRow.add(convertValueToString(row, FakturaPolozka.JEDNOTKOVA_CENA));
        gridRow.add(convertValueToString(row, FakturaPolozka.CELKOVA_CENA));
	    return gridRow;
    }
    
    private String convertValueToString(ViewRow row, Attribute prop) {
    	return ComponentBuilder.convertValueToString(prop, row.getValueAt(row.getColumnIndex(prop.getId())), session);
    }

    private PRComponent createTitle(ViewRow headerRow) {
        String cislo = convertValueToString(headerRow, OdberatelskaFaktura.CISLO);
        PRLabel title = new PRLabel();       
        title.setFont(new PRFont("Dialog", java.awt.Font.BOLD, 14));
        title.setText(session.translateText(ResourceConstants.FAKTURA_) + cislo);
        title.setWidth(500);
        title.setHeight(18);
    	return title;
    }
    
    private PRReport createPage(ViewRow headerRow) throws Exception {
        PRFlowPanel titleForm = new PRFlowPanel(javax.swing.SwingConstants.VERTICAL);       
        titleForm.add(new PREmptyComponent(0, 80));
        titleForm.add(createTitle(headerRow));
        titleForm.addGap(20);

        PRFlowCaptionComp zakaznikForm = new PRFlowCaptionComp(SwingConstants.VERTICAL);
        zakaznikForm.addItem(session.translateText(Zakaznik.NAZOV.getCaption()), convertValueToString(headerRow, Zakaznik.NAZOV), 450);
        zakaznikForm.addItem(session.translateText(Zakaznik.ADRESA.getCaption()), convertValueToString(headerRow, Zakaznik.ADRESA), 450);
        
        PRBorderPanel zakaznikPanel = new PRBorderPanel(zakaznikForm);
        zakaznikPanel.setPaintBorder(true);
        zakaznikPanel.setTitle(session.translateText(ResourceConstants.ZAKAZNIK));
        zakaznikPanel.setInsets(new Insets(20, 10, 10, 10));
        titleForm.add(zakaznikPanel);
        
        PRReport page = new PRReport(); 
        page.setVerticalGap(10);
        page.setHeader(titleForm);
        page.setFooter(createFooter());
        
        PRTable table = new PRTable(this.createGridHeader());
        table.setRowHeight(table.getHeader().getRowHeight());
        table.setFont(table.getHeader().getFont());
        table.setColumnMargin(1);
        table.setPaintCellBorders(true);
        page.setBody(table);
        return page; 
    }

   private PRComponent createFooter() {
	   PRMultiLineLabel label = new PRMultiLineLabel();
       label.setRowCount(3);
       label.setInsets(new Insets(2,2,2,2));
       label.setWidth(520);
       label.setPaintBorder(true);
       label.setText(session.translateText(ResourceConstants.VYSTAVIL_));
       return label;              
    }   
}
