package demo.framework.example.su.common.report;

import java.awt.Font;
import java.awt.Insets;

import javax.swing.SwingConstants;

import netball.server.print.PRBorderPanel;
import netball.server.print.PRComponent;
import netball.server.print.PREmptyComponent;
import netball.server.print.PRFlowPanel;
import netball.server.print.PRFont;
import netball.server.print.PRLabel;
import netball.server.print.PRMultiLineLabel;
import netball.server.print.PRPage;
import netball.server.print.PRReport;
import netball.server.print.PRSignature;
import netball.server.print.PRSimpleMultiLineGrid;
import netball.server.utilities.TextCutter;
import netframework.bo.attributes.Attribute;
import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.ComponentBuilder;
import netframework.mediator.SessionObject;
import netframework.sql.SQLExpressionBuilder;
import netframework.sql.SQLJoinCondition;
import netframework.sql.SQLQuery;
import netframework.view.ViewCursor;
import netframework.view.ViewRow;
import demo.framework.example.bo.ciselniky.Mena;
import demo.framework.example.bo.ciselniky.Zakaznik;
import demo.framework.example.bo.common.Helper;
import demo.framework.example.bo.fakturacia.FakturaPolozka;
import demo.framework.example.bo.fakturacia.OdberatelskaFaktura;
import demo.framework.example.bo.fakturacia.SumaVMene;
import demo.framework.example.su.db.DBSkolenieCatalog;
import demo.framework.translate.ResourceConstants;


public class ReportDokladOdberatelskaFakturaSimpleMultiLineGrid extends ReportDokladSimpleMultiLineGrid {
    
	@Override
    public PRPage[] execute(SessionObject session, Object dokladId) throws Exception {        
        return super.execute(session, dokladId);
    }
    
    @Override
    protected ViewCursor readItems() throws Exception {
    	DBSkolenieCatalog c = DBSkolenieCatalog.getInstance();
        SQLQuery query = new SQLQuery();
        query.addTable(new SQLJoinCondition(c.FAKTURA_POLOZKA));
        query.addField(FakturaPolozka.NAZOV.getId(), c.FAKTURA_POLOZKA.NAZOV);
        query.addField(FakturaPolozka.MNOZSTVO.getId(), c.FAKTURA_POLOZKA.MNOZSTVO);
        query.addField(FakturaPolozka.MERNA_JEDNOTKA.getId(), c.FAKTURA_POLOZKA.MERNA_JEDNOTKA);
        query.addField(FakturaPolozka.JEDNOTKOVA_CENA.getId(), c.FAKTURA_POLOZKA.JEDNOTKOVA_CENA);
        query.addField(FakturaPolozka.CELKOVA_CENA.getId(), c.FAKTURA_POLOZKA.CELKOVA_CENA);
        query.addOrdering(c.FAKTURA_POLOZKA.NAZOV);
        query.setExpression(SQLExpressionBuilder.get(c.FAKTURA_POLOZKA.FAKTURA).equal(this.dokladId));
        return ((EclipseLinkSession) session).execute(query);
    }
    
    @Override
    protected ViewRow readHeader() throws Exception {
    	DBSkolenieCatalog c = DBSkolenieCatalog.getInstance();
        SQLQuery query = new SQLQuery();
        query.addTable(new SQLJoinCondition(c.FAKTURA)); 
        query.addTable(new SQLJoinCondition(c.ZAKAZNIK, SQLJoinCondition.LEFT_OUTER_JOIN, c.ZAKAZNIK.ID, c.FAKTURA.ZAKAZNIK));
        query.addTable(new SQLJoinCondition(c.MENA, SQLJoinCondition.LEFT_OUTER_JOIN, c.MENA.ID, c.FAKTURA.MENA));
        query.addField(OdberatelskaFaktura.OBDOBIE.getId(), c.FAKTURA.OBDOBIE);
        query.addField(OdberatelskaFaktura.STAV.getId(), c.FAKTURA.STAV);
        query.addField(OdberatelskaFaktura.CISLO.getId(), c.FAKTURA.CISLO);
        query.addField(OdberatelskaFaktura.DATUM_VYSTAVENIA.getId(), c.FAKTURA.DATUM_VYSTAVENIA);
        query.addField(SumaVMene.SUMA.getId(), c.FAKTURA.CELKOVA_SUMA);
        query.addField(Mena.KOD.getId(), c.MENA.KOD);
        query.addField(Zakaznik.NAZOV.getId(), c.ZAKAZNIK.NAZOV);
        query.addField(Zakaznik.ADRESA.getId(), c.ZAKAZNIK.ADRESA);
        query.setExpression(SQLExpressionBuilder.get(c.FAKTURA.ID).equal(this.dokladId));
        ViewCursor cursor = ((EclipseLinkSession) session).execute(query);
        if (!cursor.hasNext())
           throw new IllegalArgumentException(Helper.createMessage(session, ResourceConstants.NEPODARILO_SA_NACITAT_DOKLAD_S_ID_____0___, dokladId));
        return cursor.next();   
    }        
    
    @Override
    protected PRMultiLineLabel createDolnyPopisPanel() throws Exception {
         PRMultiLineLabel popisComp = new PRMultiLineLabel();
         popisComp.setFont(new PRFont("Dialog", java.awt.Font.PLAIN, 9));
         popisComp.setRowHeight(11);
         popisComp.setWidth(530);           
         popisComp.setText(session.translateText(ResourceConstants.DOLNY_POPIS_TEXT___VYTLACI_SA_ZA_POSLEDNOU_POLOZKOU_));
   	     return popisComp;
    }    

    private String convertValueToString(ViewRow row, Attribute prop) {
    	return ComponentBuilder.convertValueToString(prop, row.getValueAt(row.getColumnIndex(prop.getId())), session);
    }
    
    private PRComponent createTitle(ViewRow headerRow) {
        String cislo = convertValueToString(headerRow, OdberatelskaFaktura.CISLO);
        PRLabel title = new PRLabel();       
        title.setFont(new PRFont("Dialog", java.awt.Font.BOLD, 14));
        title.setText(session.translateText(ResourceConstants.FAKTURA_) + cislo);
        title.setWidth(500);
        title.setHeight(18);
    	return title;
    }
    
    @Override
    protected PRReport createOtherPage(ViewRow headerRow) throws Exception {    
       PRFlowPanel titleForm = new PRFlowPanel(javax.swing.SwingConstants.VERTICAL);       
       titleForm.add(new PREmptyComponent(0, 80));
       titleForm.add(createTitle(headerRow));
       titleForm.addGap(20);
       
       PRReport page = new PRReport(); 
       page.setVerticalGap(10);
       page.setHeader(titleForm);
       return page; 
    }    
    
    @Override
    protected PRReport createFirstPage(ViewRow headerRow) throws Exception {
    	PRFlowPanel titleForm = new PRFlowPanel(javax.swing.SwingConstants.VERTICAL);       
        titleForm.add(new PREmptyComponent(0, 80));
        titleForm.add(createTitle(headerRow));
        titleForm.addGap(20);

        PRMultiLineLabel zakaznikLabel = new PRMultiLineLabel();
        zakaznikLabel.setText(new String[] {convertValueToString(headerRow, Zakaznik.NAZOV),
        		                            convertValueToString(headerRow, Zakaznik.ADRESA)});
        zakaznikLabel.setRowHeight(30);
        zakaznikLabel.setWidth(200);
        
        PRBorderPanel zakaznikPanel = new PRBorderPanel(zakaznikLabel);
        zakaznikPanel.setPaintBorder(true);
        zakaznikPanel.setTitle(session.translateText(ResourceConstants.ZAKAZNIK));
        zakaznikPanel.setInsets(new Insets(20, 10, 10, 10));
        titleForm.add(zakaznikPanel);
        
        PRReport page = new PRReport(); 
        page.setVerticalGap(10);
        page.setHeader(titleForm);
        return page; 
    }       
    
    @Override
    protected PRComponent createFooterPanel(ViewRow headerRow) {
        PRSignature signature = new PRSignature(null, session.translateText(ResourceConstants.PECIATKA_A_PODPIS)); 
        signature.setLabelFont(new PRFont("Dialog", java.awt.Font.PLAIN, 8));
        signature.setWidth(200);
        signature.setInsets(new Insets(10, 0, 0, 0));
        return signature;	
    }     
    
    @Override
    protected GridBuilder createGridBuilder() {
    	return new MaterialGridBuilder();
   	}    
    
private class MaterialGridBuilder implements ReportDokladSimpleMultiLineGrid.GridBuilder {

    private int widthNazov = 300;
    private PRSimpleMultiLineGrid.Header header;
    private int headerHeight;

    public MaterialGridBuilder() {
    	header = new PRSimpleMultiLineGrid.Header();
    	header.setFont(new PRFont("Dialog", Font.PLAIN, 8));
    	header.setRowHeight(12);
    	header.addColumn(new PRSimpleMultiLineGrid.ColumnHeader(session.translateText(ResourceConstants.P_C_), 20, SwingConstants.RIGHT));
    	header.addColumn(new PRSimpleMultiLineGrid.ColumnHeader(session.translateText(FakturaPolozka.NAZOV.getColumnName()), widthNazov, SwingConstants.LEFT));
        header.addColumn(new PRSimpleMultiLineGrid.ColumnHeader(session.translateText(FakturaPolozka.MNOZSTVO.getColumnName()), 55, SwingConstants.RIGHT));
        header.addColumn(new PRSimpleMultiLineGrid.ColumnHeader(session.translateText(FakturaPolozka.MERNA_JEDNOTKA.getColumnName()), 30, SwingConstants.LEFT));
        header.addColumn(new PRSimpleMultiLineGrid.ColumnHeader(session.translateText(FakturaPolozka.JEDNOTKOVA_CENA.getColumnName()), 55, SwingConstants.RIGHT));
        header.addColumn(new PRSimpleMultiLineGrid.ColumnHeader(session.translateText(FakturaPolozka.CELKOVA_CENA.getColumnName()), 65, SwingConstants.RIGHT));
        headerHeight = header.getSize().height;
    }

    public PRSimpleMultiLineGrid.Row createRow(ViewRow row, int pc) throws Exception {
        PRSimpleMultiLineGrid.Row gridRow = new PRSimpleMultiLineGrid.Row();
        gridRow.add("" + pc + ".");
        gridRow.add(TextCutter.parse(convertValueToString(row, FakturaPolozka.NAZOV), widthNazov - 20, header.getFont()));
        gridRow.add(convertValueToString(row, FakturaPolozka.MNOZSTVO));
        gridRow.add(convertValueToString(row, FakturaPolozka.MERNA_JEDNOTKA));
        gridRow.add(convertValueToString(row, FakturaPolozka.JEDNOTKOVA_CENA));
        gridRow.add(convertValueToString(row, FakturaPolozka.CELKOVA_CENA));
        return gridRow;
    }

    public PRSimpleMultiLineGrid.Row createSumarnyRiadok(ViewRow headerRow) throws Exception {
        PRSimpleMultiLineGrid.Row gridRow = new PRSimpleMultiLineGrid.Row();
        gridRow.add("");
        gridRow.add(OdberatelskaFaktura.CELKOVA_SUMA.getCaption() + " " + convertValueToString(headerRow, Mena.KOD));
        gridRow.add("");
        gridRow.add("");
        gridRow.add("");
        gridRow.add(convertValueToString(headerRow, SumaVMene.SUMA));
        return gridRow;
    }

    public PRSimpleMultiLineGrid createGrid() {
    	PRSimpleMultiLineGrid grid = new PRSimpleMultiLineGrid(header);
    	grid.setFont(header.getFont());
    	grid.setRowHeight(header.getRowHeight());
    	return grid;
  	}

    public PRSimpleMultiLineGrid.Header getHeader() {
    	return header;
    }

    public int getHeaderHeight() {
    	return headerHeight;
   	}
}
}
