package demo.framework.example.su.common.view;

import netframework.eclipselink.EclipseLinkView;
import demo.framework.example.bo.ciselniky.Zakazka;


public class ViewZakazka extends EclipseLinkView {

    public static final String ID = Zakazka.ID.getId();
    public static final String CISLO = Zakazka.CISLO.getId();
    public static final String NAZOV = Zakazka.NAZOV.getId();
    
    public ViewZakazka(){
        super(Zakazka.class);
        put(ID, Zakazka.ID);
        put(CISLO, Zakazka.CISLO);
        put(NAZOV, Zakazka.NAZOV);
    }

}
