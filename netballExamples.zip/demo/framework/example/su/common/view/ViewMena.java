package demo.framework.example.su.common.view;

import netframework.eclipselink.EclipseLinkView;
import demo.framework.example.bo.ciselniky.Mena;


public class ViewMena extends EclipseLinkView {

    public static final String ID = Mena.ID.getId();
    public static final String KOD = Mena.KOD.getId();
    public static final String NAZOV = Mena.NAZOV.getId();
    
    public ViewMena(){
        super(Mena.class);
        put(ID, Mena.ID);
        put(KOD, Mena.KOD);
        put(NAZOV, Mena.NAZOV);
    }

}
