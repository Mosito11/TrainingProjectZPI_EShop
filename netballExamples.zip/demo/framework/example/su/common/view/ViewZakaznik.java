package demo.framework.example.su.common.view;

import netframework.eclipselink.EclipseLinkView;
import demo.framework.example.bo.ciselniky.Zakaznik;


public class ViewZakaznik extends EclipseLinkView{

    public static final String ID = Zakaznik.ID.getId();
    public static final String ICO = Zakaznik.ICO.getId();
    public static final String NAZOV = Zakaznik.NAZOV.getId();
    public static final String ADRESA = Zakaznik.ADRESA.getId();
    public static final String JE_ZAHRANICNA = Zakaznik.JE_ZAHRANICNA.getId();
    
    public ViewZakaznik(){
        super(Zakaznik.class);
        put(ID, Zakaznik.ID);
        put(ICO, Zakaznik.ICO);
        put(NAZOV, Zakaznik.NAZOV);
        put(ADRESA, Zakaznik.ADRESA);
        put(JE_ZAHRANICNA, Zakaznik.JE_ZAHRANICNA);
    }

}
