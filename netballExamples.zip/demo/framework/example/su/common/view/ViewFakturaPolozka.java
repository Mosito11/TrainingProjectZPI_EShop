package demo.framework.example.su.common.view;

import netframework.bo.attributes.Attribute;
import netframework.eclipselink.EclipseLinkView;
import demo.framework.example.bo.ciselniky.Mena;
import demo.framework.example.bo.ciselniky.Zakaznik;
import demo.framework.example.bo.fakturacia.Faktura;
import demo.framework.example.bo.fakturacia.FakturaPolozka;
import demo.framework.example.bo.fakturacia.SumaVMene;

public class ViewFakturaPolozka extends EclipseLinkView {

	public static final String ID = FakturaPolozka.ID.getId(); 	
	public static final String MNOZSTVO = FakturaPolozka.MNOZSTVO.getId();
	public static final String JEDNOTKOVA_CENA = FakturaPolozka.JEDNOTKOVA_CENA.getId();
	public static final String CELKOVA_CENA = FakturaPolozka.CELKOVA_CENA.getId();
	public static final String MERNA_JEDNOTKA = FakturaPolozka.MERNA_JEDNOTKA.getId();
	public static final String NAZOV = FakturaPolozka.NAZOV.getId();
	
	public static final String FAKTURA_DATUM_VYSTAVENIA = Faktura.DATUM_VYSTAVENIA.getId();
	public static final String FAKTURA_OBDOBIE = Faktura.OBDOBIE.getId();
	public static final String FAKTURA_STAV = Faktura.STAV.getId();
	public static final String FAKTURA_TYP = Faktura.TYP.getId();
	public static final String FAKTURA_CISLO = Faktura.CISLO.getId();
	
	public static final String ZAKAZNIK_ICO = Zakaznik.ICO.getId(); 
	public static final String ZAKAZNIK_NAZOV = Zakaznik.NAZOV.getId();
	
	public static final String MENA_KOD = Mena.KOD.getId();

	public ViewFakturaPolozka() {
		super(FakturaPolozka.class);
		put(ID, FakturaPolozka.ID); 	
		put(MNOZSTVO, FakturaPolozka.MNOZSTVO);
		put(JEDNOTKOVA_CENA, FakturaPolozka.JEDNOTKOVA_CENA);
		put(CELKOVA_CENA, FakturaPolozka.CELKOVA_CENA);
		put(MERNA_JEDNOTKA, FakturaPolozka.MERNA_JEDNOTKA);
		put(NAZOV, FakturaPolozka.NAZOV);
		put(FAKTURA_DATUM_VYSTAVENIA, new Attribute[] {FakturaPolozka.FAKTURA, Faktura.DATUM_VYSTAVENIA});
		put(FAKTURA_OBDOBIE, new Attribute[] {FakturaPolozka.FAKTURA, Faktura.OBDOBIE});
		put(FAKTURA_STAV, new Attribute[] {FakturaPolozka.FAKTURA, Faktura.STAV});
		put(FAKTURA_TYP, new Attribute[] {FakturaPolozka.FAKTURA, Faktura.TYP});
		put(FAKTURA_CISLO, new Attribute[] {FakturaPolozka.FAKTURA, Faktura.CISLO});
		put(ZAKAZNIK_ICO, new Attribute[] {FakturaPolozka.FAKTURA, Faktura.ZAKAZNIK, Zakaznik.ICO}); 
		put(ZAKAZNIK_NAZOV, new Attribute[] {FakturaPolozka.FAKTURA, Faktura.ZAKAZNIK, Zakaznik.NAZOV}); 
		put(MENA_KOD, new Attribute[] {FakturaPolozka.FAKTURA, Faktura.CELKOVA_SUMA, SumaVMene.MENA, Mena.KOD}); 
	}
}
