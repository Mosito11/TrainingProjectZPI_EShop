package demo.framework.example.su.common.view;

import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.SessionObject;
import netframework.sql.SQLJoinCondition;
import netframework.sql.SQLQuery;
import netframework.view.SQLView;
import netframework.view.ViewCursor;
import netframework.view.ViewQuery;
import demo.framework.example.bo.ciselniky.Mena;
import demo.framework.example.bo.ciselniky.Zakaznik;
import demo.framework.example.bo.fakturacia.Faktura;
import demo.framework.example.bo.fakturacia.SumaVMene;
import demo.framework.example.su.db.DBSkolenieCatalog;


public class ViewFaktura extends SQLView {

	public static final String ID = Faktura.ID.getId();
	public static final String DATUM_VYSTAVENIA = Faktura.DATUM_VYSTAVENIA.getId();
	public static final String ZAKAZNIK_ID = Zakaznik.ID.getId();
	public static final String ZAKAZNIK_ICO = Zakaznik.ICO.getId();
	public static final String ZAKAZNIK_NAZOV = Zakaznik.NAZOV.getId();
	public static final String OBDOBIE = Faktura.OBDOBIE.getId();
	public static final String STAV = Faktura.STAV.getId();
	public static final String VERSION = Faktura.VERSION.getId();
	public static final String TYP = Faktura.TYP.getId();
	public static final String CISLO = Faktura.CISLO.getId();
	public static final String MENA_KOD = Mena.KOD.getId();
	public static final String CELKOVA_SUMA = SumaVMene.SUMA.getId();
	
    public ViewFaktura() {
    	DBSkolenieCatalog c = DBSkolenieCatalog.getInstance();    	
        put(ID, Faktura.ID, c.FAKTURA.ID);
    	put(DATUM_VYSTAVENIA, Faktura.DATUM_VYSTAVENIA, c.FAKTURA.DATUM_VYSTAVENIA);
    	put(ZAKAZNIK_ID, Zakaznik.ID, c.ZAKAZNIK.ID);
    	put(ZAKAZNIK_ICO, Zakaznik.ICO, c.ZAKAZNIK.ICO);
    	put(ZAKAZNIK_NAZOV, Zakaznik.NAZOV, c.ZAKAZNIK.NAZOV);
    	put(OBDOBIE, Faktura.OBDOBIE, c.FAKTURA.OBDOBIE);
    	put(STAV, Faktura.STAV, c.FAKTURA.STAV);
    	put(VERSION, Faktura.VERSION, c.FAKTURA.VERSION);
    	put(TYP, Faktura.TYP, c.FAKTURA.TYP);
    	put(CISLO, Faktura.CISLO, c.FAKTURA.CISLO);
    	put(MENA_KOD, Mena.KOD, c.MENA.KOD);
    	put(CELKOVA_SUMA, SumaVMene.SUMA, c.FAKTURA.CELKOVA_SUMA);
    }

	@Override
	public ViewCursor execute(SessionObject sessionObject, ViewQuery query)	throws Exception {
    	DBSkolenieCatalog c = DBSkolenieCatalog.getInstance();    	
        SQLQuery sqlQuery = new SQLQuery();       
        sqlQuery.addTable(new SQLJoinCondition(c.FAKTURA));
        sqlQuery.addTable(new SQLJoinCondition(c.MENA, SQLJoinCondition.LEFT_OUTER_JOIN, c.MENA.ID, c.FAKTURA.MENA));
        sqlQuery.addTable(new SQLJoinCondition(c.ZAKAZNIK, SQLJoinCondition.LEFT_OUTER_JOIN, c.ZAKAZNIK.ID, c.FAKTURA.ZAKAZNIK));
        setViewQuery(sqlQuery, query);
        // vlozenie obmedzenia pre faktury
        //Helper.getObmedzenia(sessionObject).getTypFaktury().setObmedzeniaExpression(sqlQuery);
        return ((EclipseLinkSession) sessionObject).execute(sqlQuery);
	}
}
