package demo.framework.example.su.common.view;

import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.SessionObject;
import netframework.sql.SQLJoinCondition;
import netframework.sql.SQLQuery;
import netframework.view.SQLView;
import netframework.view.ViewCursor;
import netframework.view.ViewQuery;
import demo.framework.example.bo.uzol.Uzol;
import demo.framework.example.su.db.DBSkolenieCatalog;

public class ViewUzol extends SQLView {

    public static final String ID = Uzol.ID.getId();
    public static final String KOD = Uzol.KOD.getId();
    public static final String NAZOV = Uzol.NAZOV.getId();
    public static final String POLOZKA_1 = Uzol.POLOZKA_1.getId();
    public static final String POLOZKA_2 = Uzol.POLOZKA_2.getId();
    public static final String POLOZKA_3 = Uzol.POLOZKA_3.getId();
    public static final String RODIC = Uzol.RODIC.getId();
    
    public ViewUzol(){
    	DBSkolenieCatalog c = DBSkolenieCatalog.getInstance();    	
        put(ID, Uzol.ID, c.UZOL.ID);
        put(KOD, Uzol.KOD, c.UZOL.KOD);
        put(NAZOV, Uzol.NAZOV, c.UZOL.NAZOV);
        put(POLOZKA_1, Uzol.POLOZKA_1, c.UZOL.POLOZKA_1);
        put(POLOZKA_2, Uzol.POLOZKA_2, c.UZOL.POLOZKA_2);
        put(POLOZKA_3, Uzol.POLOZKA_3, c.UZOL.POLOZKA_3);
        put(RODIC, Uzol.ID, c.UZOL.RODIC);
    }
    
	@Override
	public ViewCursor execute(SessionObject sessionObject, ViewQuery query)	throws Exception {
    	DBSkolenieCatalog c = DBSkolenieCatalog.getInstance();    	
        SQLQuery sqlQuery = new SQLQuery();       
        sqlQuery.addTable(new SQLJoinCondition(c.UZOL));
        setViewQuery(sqlQuery, query);
        return ((EclipseLinkSession) sessionObject).execute(sqlQuery);
	}
    
}
