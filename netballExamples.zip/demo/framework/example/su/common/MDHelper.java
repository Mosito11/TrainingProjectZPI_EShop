package demo.framework.example.su.common;

import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.MDButton;
import demo.framework.example.bo.obmedzenie.Obmedzenia;
import demo.framework.translate.ResourceConstants;


public class MDHelper {

	public static final String MESSAGE_VYMAZ_ZAZNAM = ResourceConstants.SKUTOCNE_SI_PRAJETE_VYMAZAT_ZAZNAM_;
	public static final String MESSAGE_SPRACOVANY = ResourceConstants.SKUTOCNE_SI_PRAJETE_NASTAVIT_ZAZNAM_NA_SPRACOVANY_;
	public static final String MESSAGE_STORNO = ResourceConstants.SKUTOCNE_SI_PRAJETE_STORNOVAT_ZAZNAM_;
	
	public static final MDButton STAV_BUTTON = new MDButton("stav", ResourceConstants.STAV, 'T', ResourceConstants.UMOZNUJE_ZMENIT_STAV_DOKLADU_);
	public static final MDButton DETAIL_BUTTON = new MDButton("detail", ResourceConstants.DETAIL, 'D', ResourceConstants.UMOZNUJE_ZOBRAZIT_DETAIL_ZAZNAMU_);
	public static final MDButton TLAC_DOKLADU_BUTTON = new MDButton("tlacDokladu", ResourceConstants.TLAC_DOKLADU, 'D', ResourceConstants.UMOZNUJE_VYTLACIT_DOKLAD_);
	public static final MDButton OBMEDZENIA_BUTTON = new MDButton("obmedzenieButton", ResourceConstants.OBMEDZENIA, 'B', ResourceConstants.UMOZNUJE_SPRAVOVAT_OBMEDZENIA_);
  
    public static Obmedzenia getObmedzenia(EclipseLinkSession session) {
    	return (Obmedzenia) session.getProperty("obmedzenia");
    }  
}
