package demo.framework.example.su.komponenty;


import netball.server.component.XCompoundField;
import netframework.mediator.BasicMediator;
import netframework.mediator.ViewCompoundFieldWithClientServerTable;
import netframework.view.View;
import demo.framework.example.su.common.view.ViewMena;
import demo.framework.translate.ResourceConstants;

public class ComponentMena extends ViewCompoundFieldWithClientServerTable { 

    public ComponentMena(Object componentId, BasicMediator mediator) {
    	super(componentId, mediator);
    }        

    @Override
	protected String[] getColumns() {
		return new String[] {ViewMena.KOD, ViewMena.NAZOV};	
	}
	
    @Override
	protected View getView() {
		return new ViewMena();
	}	

    @Override
	protected String getTitleText() {
		return ResourceConstants.MENY; 
	} 	
	
	public static XCompoundField createComponent(Object componentId, BasicMediator mediator) {
		return new ComponentMena(componentId, mediator).createComponent();
	}
	
	public static XCompoundField createExpressionComponent(Object componentId, BasicMediator mediator) {
		return new ComponentMena(componentId, mediator).createExpressionComponent();
	}
} 
