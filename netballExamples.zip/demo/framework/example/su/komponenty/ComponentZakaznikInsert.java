package demo.framework.example.su.komponenty;

import netball.server.component.XBoxPanel;
import netball.server.component.XCompoundField;
import netball.server.component.XPanel;
import netball.server.event.ClientActionEvent;
import netball.server.pack.ServerPack;
import netframework.mediator.BasicMediator;
import netframework.mediator.MDCompoundFieldWithFilter;
import netframework.mediator.MediatorCallBackObject;
import netframework.mediator.ViewCompoundFieldWithFilter;
import netframework.mediator.resource.MediatorResourceBuilder;
import netframework.view.View;
import demo.framework.example.su.ciselniky.md.MDZakaznik;
import demo.framework.example.su.common.view.ViewZakaznik;
import demo.framework.translate.ResourceConstants;

public class ComponentZakaznikInsert extends ViewCompoundFieldWithFilter {

	public ComponentZakaznikInsert(Object componentId, BasicMediator mediator) {
		super(componentId, mediator);
	}

	@Override
	protected View getView() {
		return new ViewZakaznik();
	}

	@Override
	protected String[] getColumns() {
	    return new String[] {ViewZakaznik.ICO,
						    ViewZakaznik.NAZOV,
						    ViewZakaznik.ADRESA,
						    ViewZakaznik.JE_ZAHRANICNA};
	}

	@Override
	protected String getTitleText() {
		return ResourceConstants.ZAKAZNICI;
	}
	
	public static XCompoundField createComponent(Object componentId, BasicMediator mediator) {
		return new ComponentZakaznikInsert(componentId, mediator).createComponent();
	}

	public static XCompoundField createComponent(Object componentId, String caption, BasicMediator mediator) {
		return new ComponentZakaznikInsert(componentId, mediator).createComponent(caption);
	}
	
	@Override
	protected Class<? extends MDCompoundFieldWithFilter> getMediatorClass() {
		return MDComponent.class;
	}

	public static class MDComponent extends MDCompoundFieldWithFilter {

		private String ADD_ACTION = createId(MediatorResourceBuilder.ADD_BUTTON); 
		
		@Override
		protected XPanel createEastPanel() {
			XBoxPanel panel = new XBoxPanel();
			panel.add(MediatorResourceBuilder.createButton(ADD_ACTION, MediatorResourceBuilder.ADD_BUTTON, getLocale()));
			return panel;
		}

		@Override
		public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
			if (event.getSourceId().equals(ADD_ACTION)) {
			    runNext(MDZakaznik.class, null, pack);
			}else{	
			    super.actionEventExecuted(event, pack);
			}
		}

		@Override
		protected boolean receiveCallBack(BasicMediator mediator, MediatorCallBackObject callBackObject, ServerPack pack) {
			if (callBackObject instanceof MDZakaznik.CallBack) {
				MDZakaznik.CallBack callBack = (MDZakaznik.CallBack) callBackObject;
				this.addInsertedPack(ViewZakaznik.ID, callBack.zakaznikId, pack);
				return true;
			}else {
			   return super.receiveCallBack(mediator, callBackObject, pack);
			}
		}
	}
	

}
