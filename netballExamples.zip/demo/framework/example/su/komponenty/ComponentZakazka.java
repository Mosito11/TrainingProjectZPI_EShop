package demo.framework.example.su.komponenty;

import netball.server.component.XCompoundField;
import netframework.mediator.BasicMediator;
import netframework.mediator.ViewCompoundFieldWithFilter;
import netframework.view.View;
import demo.framework.example.su.common.view.ViewZakazka;
import demo.framework.translate.ResourceConstants;


public class ComponentZakazka extends ViewCompoundFieldWithFilter { 


    public ComponentZakazka(Object componentId, BasicMediator mediator) {
    	super(componentId, mediator);
    }        
	
    @Override
	protected View getView() {
		return new ViewZakazka();
	}
	
    @Override
	protected String[] getColumns() {
		return new String[] {ViewZakazka.CISLO, ViewZakazka.NAZOV};
	}
	
    @Override
	protected String getTitleText() {
		return ResourceConstants.ZAKAZKY; 
	}	 	
    
	public static XCompoundField createComponent(Object componentId, BasicMediator mediator) {
		return new ComponentZakazka(componentId, mediator).createComponent();
	}
	
	public static XCompoundField createExpressionComponent(Object componentId, BasicMediator mediator) {
		return new ComponentZakazka(componentId, mediator).createExpressionComponent();
	}
}
