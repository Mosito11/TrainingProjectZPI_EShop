package demo.framework.example.su.komponenty;

import netball.server.component.XMultiColumnComboBox;
import netball.server.event.ClientPopupEvent;
import netball.server.event.ServerPopupEvent;
import netball.server.pack.ServerPack;
import netframework.mediator.BasicMediator;
import netframework.mediator.ViewMultiColumnComboBox;
import netframework.view.View;
import netframework.view.ViewExpression;
import netframework.view.ViewExpressionBuilder;
import demo.framework.example.su.common.view.ViewFaktura;

public class ComponentFakturaZakaznik extends ViewMultiColumnComboBox {

	private Object zakaznikComponentId;
	private Object zakaznikIco;
	
	public ComponentFakturaZakaznik(Object componentId, Object zakaznikComponentId, BasicMediator mediator) {
		super(componentId, mediator);
		this.zakaznikComponentId = zakaznikComponentId;
	}
	
	@Override
	protected ViewExpression getRestrictionExpression() {
		if (zakaznikIco != null)
		   return ViewExpressionBuilder.get(ViewFaktura.ZAKAZNIK_ICO).equal(zakaznikIco);
		return null;
	}

	@Override
	protected void handlePopupEvent(ClientPopupEvent event) throws Exception {
		Object zakaznikIcoNew = event.getValuePack().getValue(zakaznikComponentId);
		if (zakaznikIcoNew != null && !zakaznikIcoNew.equals(zakaznikIco)) {
			this.wasRead = false; 
		}
		zakaznikIco = zakaznikIcoNew; 
	}

	@Override
	protected ServerPopupEvent createPopupEvent() {
		ServerPopupEvent event = new ServerPopupEvent();
		event.addReturnValue(zakaznikComponentId); 
		return event;
	}

	@Override
	protected View getView() {
		return new ViewFaktura();
	}

	@Override
    public void readData(ViewExpression exp, ServerPack serverPack, BasicMediator mediator) {
		if (zakaznikIco != null) {
			super.readData(exp, serverPack, mediator);
		}else{
			this.deleteAllItems(serverPack);
		}
	}
	
	@Override
	protected String[] getColumns() {
        return new String[] {    
        		ViewFaktura.CISLO,		    	
		    	ViewFaktura.ZAKAZNIK_ICO,
		    	ViewFaktura.ZAKAZNIK_NAZOV,
		    	ViewFaktura.OBDOBIE,
		    	ViewFaktura.STAV,		    	
		    	ViewFaktura.MENA_KOD,
		    	ViewFaktura.DATUM_VYSTAVENIA,
		    	ViewFaktura.CELKOVA_SUMA};
	}
	
	public static XMultiColumnComboBox createComponent(Object componentId, Object zakaznikComponentId, String caption, BasicMediator mediator) {
		return new ComponentFakturaZakaznik(componentId, zakaznikComponentId, mediator).createComponent(caption);
	}

	public static XMultiColumnComboBox createComponent(Object componentId, Object zakaznikComponentId, BasicMediator mediator) {
		return new ComponentFakturaZakaznik(componentId, zakaznikComponentId, mediator).createComponent();
	}
}
