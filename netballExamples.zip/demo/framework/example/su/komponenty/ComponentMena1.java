package demo.framework.example.su.komponenty;

import netball.server.component.XMultiColumnComboBox;
import netframework.mediator.BasicMediator;
import netframework.mediator.ViewMultiColumnComboBox;
import netframework.view.View;
import demo.framework.example.su.common.view.ViewMena;

public class ComponentMena1 extends ViewMultiColumnComboBox {

    public ComponentMena1(Object componentId, BasicMediator mediator) {
    	super(componentId, mediator);
    }        

    @Override
	protected String[] getColumns() {
		return new String[] {ViewMena.KOD, ViewMena.NAZOV};	
	}
	
    @Override
	protected View getView() {
		return new ViewMena();
	}	
	
	public static XMultiColumnComboBox createComponent(Object componentId, BasicMediator mediator) {
		return new ComponentMena1(componentId, mediator).createComponent();
	}

	public static XMultiColumnComboBox createExpressionComponent(Object componentId, BasicMediator mediator) {
		return new ComponentMena1(componentId, mediator).createExpressionComponent();
	}
}
