package demo.framework.example.su.komponenty;

import java.awt.Insets;

import netball.server.component.XCompoundField;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XPanel;
import netframework.mediator.BasicMediator;
import netframework.mediator.MDCompoundFieldWithFilter;
import netframework.mediator.ViewCompoundFieldWithFilter;
import netframework.view.View;
import demo.framework.example.bo.fakturacia.Faktura;
import demo.framework.example.bo.fakturacia.SumaVMene;
import demo.framework.example.su.common.view.ViewFaktura;
import demo.framework.translate.ResourceConstants;

public class ComponentFaktura extends ViewCompoundFieldWithFilter { 


    public ComponentFaktura(Object componentId, BasicMediator mediator) {
    	super(componentId, mediator);
    }        
	
    @Override
	protected View getView() {
		return new ViewFaktura();
	}
	
    @Override
	protected String[] getColumns() {
        return new String[] {    
        		ViewFaktura.CISLO,		    	
		    	ViewFaktura.ZAKAZNIK_ICO,
		    	ViewFaktura.ZAKAZNIK_NAZOV,
		    	ViewFaktura.OBDOBIE,
		    	ViewFaktura.STAV,		    	
		    	ViewFaktura.MENA_KOD,
		    	ViewFaktura.DATUM_VYSTAVENIA,
		    	ViewFaktura.CELKOVA_SUMA};
	}
    
    @Override
	protected String getTitleText() {
		return ResourceConstants.FAKTURY; 
	}	 	
    
    @Override
    protected Class<? extends MDCompoundFieldWithFilter> getMediatorClass() { 
    	return MDComponentFaktura.class;  // nastavenie noveho mediatora
    }
    
	public static XCompoundField createComponent(Object componentId, BasicMediator mediator) {
		return new ComponentFaktura(componentId, mediator).createComponent();
	}

	public static XCompoundField createExpressionComponent(Object componentId, BasicMediator mediator) {
		return new ComponentFaktura(componentId, mediator).createExpressionComponent();
	}
	
	public static class MDComponentFaktura extends MDCompoundFieldWithFilter {
		
		// iny panel ako default
		@Override
		protected XPanel createFilterPanel() {
			XDualComponentPanel panel = new XDualComponentPanel();
			panel.setInsets(new Insets(10, 10, 10, 10));
			panel.add(createExpressionComponent(ViewFaktura.DATUM_VYSTAVENIA, Faktura.DATUM_VYSTAVENIA));
			panel.add(ComponentZakaznik.createComponent(ViewFaktura.ZAKAZNIK_ICO, this));
			panel.add(createExpressionComponent(ViewFaktura.OBDOBIE, Faktura.OBDOBIE));
			panel.add(createComponent(ViewFaktura.STAV, Faktura.STAV));
			panel.add(ComponentMena.createComponent(ViewFaktura.MENA_KOD, this));
			panel.add(createExpressionComponent(ViewFaktura.CELKOVA_SUMA, SumaVMene.SUMA));
		    return panel; 
			
		}
	}
}
