package demo.framework.example.su.dynamicreport;

import java.sql.Types;

import demo.framework.example.bo.ciselniky.Zakazka;
import demo.framework.example.su.komponenty.ComponentZakazka;
import netball.server.component.XComponent;
import netframework.dynamicreport.DRField;
import netframework.dynamicreport.DRField.ComponentCreator;
import netframework.dynamicreport.DRTable;
import netframework.dynamicreport.MDDynamicReport;
import netframework.sql.SQLField;


public class DRZakazka extends DRTable {
	
	public static final SQLField ID = new SQLField("id", Types.INTEGER, 11);
	public static final DRField CISLO = new DRField("cislo", Types.CHAR, 10, Zakazka.CISLO);
	public static final DRField NAZOV = new DRField("nazov", Types.VARCHAR, 50, Zakazka.NAZOV);
	
	public DRZakazka() {
		super("zakazka_", /*~~*/"Zakazka");
	    addField(Zakazka.ID.getId(), ID);	
	    addField(Zakazka.CISLO.getId(), CISLO);	
	    addField(Zakazka.NAZOV.getId(), NAZOV);
	    
	    CISLO.setComponentCreator(new ComponentCreator() {
			@Override
			public XComponent createFilterComponent(Object id, MDDynamicReport mediator) {
				return ComponentZakazka.createExpressionComponent(id, mediator);
			}
		});			    
	}    
}
