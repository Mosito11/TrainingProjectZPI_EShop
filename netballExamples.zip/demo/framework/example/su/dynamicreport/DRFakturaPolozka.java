package demo.framework.example.su.dynamicreport;

import java.sql.Types;

import demo.framework.example.bo.fakturacia.FakturaPolozka;
import netframework.dynamicreport.DRField;
import netframework.dynamicreport.DRTable;
import netframework.sql.SQLAliasField;
import netframework.sql.SQLAliasTable;
import netframework.sql.SQLExpressionBuilder;
import netframework.sql.SQLField;
import netframework.sql.SQLValueConvertor;


public class DRFakturaPolozka extends DRTable {
	
	public static final SQLField ID = new SQLField("id", Types.INTEGER, 11);
	public static final DRField MNOZSTVO = new DRField("mnozstvo", Types.DECIMAL, 10, 5, FakturaPolozka.MNOZSTVO);
	public static final DRField JEDNOTKOVA_CENA = new DRField("jednotkova_cena", Types.DECIMAL, 12, 2, FakturaPolozka.JEDNOTKOVA_CENA);
	public static final DRField CELKOVA_CENA = new DRField("celkova_cena", Types.DECIMAL, 12, 2, FakturaPolozka.CELKOVA_CENA);
	public static final DRField MERNA_JEDNOTKA = new DRField("merna_jednotka", Types.CHAR, 5, FakturaPolozka.MERNA_JEDNOTKA);
	public static final DRField NAZOV = new DRField("nazov", Types.VARCHAR, 100, FakturaPolozka.NAZOV);
	public static final DRField FAKTURA = new DRField("faktura_id", Types.INTEGER, 10, FakturaPolozka.FAKTURA);
	
	public DRFakturaPolozka() {
		super("faktura_polozka", /*~~*/"Polozka faktury");
	    addField(FakturaPolozka.ID.getId(), ID);	
		addField(FakturaPolozka.MNOZSTVO.getId(), MNOZSTVO);
		addField(FakturaPolozka.JEDNOTKOVA_CENA.getId(), JEDNOTKOVA_CENA);
		addField(FakturaPolozka.CELKOVA_CENA.getId(), CELKOVA_CENA);
		addField(FakturaPolozka.MERNA_JEDNOTKA.getId(), MERNA_JEDNOTKA);
		addField(FakturaPolozka.NAZOV.getId(), NAZOV);
		addField(FakturaPolozka.FAKTURA.getId(), FAKTURA);
		
		// nastavenie cudzich klucov
		DRSkolenieCatalog c = DRSkolenieCatalog.getInstance(); 
		FAKTURA.setForeignKey(c.FAKTURA.ID);
		
		// ukazka ako vytvorit stlpec, ktory nie v tabulke  
		CELKOVA_CENA.setAliasExpression(new CelkovaCena());
	}    
	
	private class CelkovaCena implements DRField.AliasExpression {

		public String toSqlSyntax(int sqlType, SQLValueConvertor convertor, SQLAliasTable aliasTable) {
			SQLAliasField mnozstvo = new SQLAliasField(MNOZSTVO, aliasTable);  
			SQLAliasField jednotkovaCena = new SQLAliasField(JEDNOTKOVA_CENA, aliasTable);
			return (SQLExpressionBuilder.get(mnozstvo).mutiply(jednotkovaCena).round(2)).toSqlSyntax(sqlType, convertor); 
		}
	}
}