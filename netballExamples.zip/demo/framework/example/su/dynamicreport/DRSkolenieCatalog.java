package demo.framework.example.su.dynamicreport;

import demo.framework.example.bo.ciselniky.Mena;
import demo.framework.example.bo.ciselniky.Zakazka;
import demo.framework.example.bo.ciselniky.Zakaznik;
import demo.framework.example.bo.fakturacia.Faktura;
import demo.framework.example.bo.fakturacia.FakturaPolozka;
import netframework.FrameworkUtilities;
import netframework.sql.SQLCatalog;

public class DRSkolenieCatalog extends SQLCatalog {
	
	public static final DRFaktura FAKTURA = new DRFaktura(); 
	public static final DRFakturaPolozka FAKTURA_POLOZKA = new DRFakturaPolozka(); 
	public static final DRFakturaZakazka FAKTURA_ZAKAZKA = new DRFakturaZakazka(); 
	public static final DRMena MENA = new DRMena(); 
	public static final DRZakazka ZAKAZKA = new DRZakazka(); 
	public static final DRZakaznik ZAKAZNIK = new DRZakaznik(); 
	
	private static DRSkolenieCatalog catalog = new DRSkolenieCatalog();
	
	private DRSkolenieCatalog(){
		addTable(FrameworkUtilities.getShortClassName(Faktura.class), FAKTURA);
		addTable(FrameworkUtilities.getShortClassName(FakturaPolozka.class), FAKTURA_POLOZKA);
		addTable(FrameworkUtilities.getShortClassName(DRFakturaZakazka.class), FAKTURA_ZAKAZKA);
		addTable(FrameworkUtilities.getShortClassName(Mena.class), MENA);
		addTable(FrameworkUtilities.getShortClassName(Zakazka.class), ZAKAZKA);
		addTable(FrameworkUtilities.getShortClassName(Zakaznik.class), ZAKAZNIK);
	}
	   
	public static DRSkolenieCatalog getInstance() {
	    return catalog;
    }
}	
