package demo.framework.example.su.dynamicreport;

import java.sql.Types;

import demo.framework.example.bo.ciselniky.Mena;
import demo.framework.example.su.komponenty.ComponentMena;
import netball.server.component.XComponent;
import netframework.dynamicreport.DRField;
import netframework.dynamicreport.DRField.ComponentCreator;
import netframework.dynamicreport.DRTable;
import netframework.dynamicreport.MDDynamicReport;
import netframework.sql.SQLField;

public class DRMena extends DRTable {
	
	public static final SQLField ID = new SQLField("id", Types.INTEGER, 11);
	public static final DRField KOD = new DRField("kod", Types.CHAR, 3, Mena.KOD);
	public static final DRField NAZOV = new DRField("nazov", Types.VARCHAR, 50, Mena.NAZOV);
	
	public DRMena() {
		super("mena", /*~~*/"Mena");
	    addField(Mena.ID.getId(), ID);	
	    addField(Mena.KOD.getId(), KOD);	
	    addField(Mena.NAZOV.getId(), NAZOV);	
	    
	    KOD.setComponentCreator(new ComponentCreator() {
			@Override
			public XComponent createFilterComponent(Object id, MDDynamicReport mediator) {
				return ComponentMena.createExpressionComponent(id, mediator);
			}
		});			    
	}    
}
