package demo.framework.example.su.dynamicreport;

import java.sql.Types;

import demo.framework.example.bo.ciselniky.Zakaznik;
import demo.framework.example.su.komponenty.ComponentZakaznik;
import netball.server.component.XComponent;
import netframework.dynamicreport.DRField;
import netframework.dynamicreport.DRField.ComponentCreator;
import netframework.dynamicreport.DRTable;
import netframework.dynamicreport.MDDynamicReport;
import netframework.sql.SQLField;


public class DRZakaznik extends DRTable {
	
	public static final SQLField ID = new SQLField("id", Types.INTEGER, 11);
	public static final DRField ICO = new DRField("ico", Types.CHAR, 10, Zakaznik.ICO);
	public static final DRField NAZOV = new DRField("nazov", Types.VARCHAR, 50, Zakaznik.NAZOV);
	public static final DRField ADRESA = new DRField("adresa", Types.VARCHAR, 100, Zakaznik.ADRESA);
	public static final DRField JE_ZAHRANICNA = new DRField("je_zahranicny", Types.CHAR, 1, Zakaznik.JE_ZAHRANICNA);
	
	public DRZakaznik() {
		super("zakaznik", /*~~*/"Zakaznik");
	    addField(Zakaznik.ID.getId(), ID);	
	    addField(Zakaznik.ICO.getId(), ICO);	
	    addField(Zakaznik.NAZOV.getId(), NAZOV);	
	    addField(Zakaznik.ADRESA.getId(), ADRESA);	
	    addField(Zakaznik.JE_ZAHRANICNA.getId(), JE_ZAHRANICNA);
	    
	    ICO.setComponentCreator(new ComponentCreator() {
			@Override
			public XComponent createFilterComponent(Object id, MDDynamicReport mediator) {
				return ComponentZakaznik.createExpressionComponent(id, mediator);
			}
		});			    
	}    
}
