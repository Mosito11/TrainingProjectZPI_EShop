package demo.framework.example.su.dynamicreport;

import java.sql.Types;

import demo.framework.example.bo.fakturacia.Faktura;
import demo.framework.example.bo.fakturacia.SumaVMene;
import netframework.dynamicreport.DRField;
import netframework.dynamicreport.DRTable;
import netframework.sql.SQLField;


public class DRFaktura extends DRTable {
	
	public static final SQLField ID = new SQLField("id", Types.INTEGER, 11);
	public static final DRField DATUM_VYSTAVENIA = new DRField("datum_vystavenia", Types.DATE, 11, Faktura.DATUM_VYSTAVENIA);
	public static final DRField CELKOVA_SUMA = new DRField("celkova_cena", Types.DECIMAL, 12, 2, SumaVMene.SUMA);
	public static final DRField MENA = new DRField("mena_id", Types.INTEGER, 11, SumaVMene.MENA);
	public static final DRField ZAKAZNIK = new DRField("zakaznik_id", Types.INTEGER, 11, Faktura.ZAKAZNIK);
	public static final DRField OBDOBIE = new DRField("obdobie", Types.CHAR, 6, Faktura.OBDOBIE);
	public static final DRField STAV = new DRField("stav", Types.CHAR, 1, Faktura.STAV);
	public static final SQLField VERSION = new SQLField("version", Types.INTEGER, 11);
	public static final DRField TYP = new DRField("class_id", Types.CHAR, 1, Faktura.TYP);
	public static final DRField CISLO = new DRField("cislo", Types.CHAR, 10, Faktura.CISLO);
	
	public DRFaktura() {
		super("faktura", /*~~*/"Faktura");
	    addField(Faktura.ID.getId(), ID);	
		addField(Faktura.DATUM_VYSTAVENIA.getId(), DATUM_VYSTAVENIA);
		addField(SumaVMene.SUMA.getId(), CELKOVA_SUMA);
		addField(SumaVMene.MENA.getId(), MENA);
		addField(Faktura.ZAKAZNIK.getId(), ZAKAZNIK);
		addField(Faktura.OBDOBIE.getId(), OBDOBIE);
		addField(Faktura.STAV.getId(), STAV);
		addField(Faktura.VERSION.getId(), VERSION);
		addField(Faktura.TYP.getId(), TYP);
		addField(Faktura.CISLO.getId(), CISLO);
		
		// nastavenie cudzich klucov
		DRSkolenieCatalog c = DRSkolenieCatalog.getInstance(); 
		MENA.setForeignKey(c.MENA.ID);
		ZAKAZNIK.setForeignKey(c.ZAKAZNIK.ID);
	}    
}
