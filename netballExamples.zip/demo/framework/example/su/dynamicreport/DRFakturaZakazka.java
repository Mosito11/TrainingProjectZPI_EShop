package demo.framework.example.su.dynamicreport;

import java.sql.Types;

import demo.framework.example.bo.ciselniky.Zakazka;
import demo.framework.example.bo.fakturacia.Faktura;
import netframework.dynamicreport.DRField;
import netframework.dynamicreport.DRTable;

public class DRFakturaZakazka extends DRTable {
  
	public static final DRField FAKTURA = new DRField("faktura_id", Types.INTEGER, 11, Faktura.ID);
	public static final DRField ZAKAZKA = new DRField("zakazka_id", Types.INTEGER, 11, Zakazka.ID);
	
	public DRFakturaZakazka() {
		super("faktura_zakazka", /*~~*/"Faktura zakazka");
		addField("DBFakturaZakazka.faktura", FAKTURA);
		addField("DBFakturaZakazka.zakazka", ZAKAZKA);
		
		// nastavenie cudzich klucov
		DRSkolenieCatalog c = DRSkolenieCatalog.getInstance(); 
		FAKTURA.setForeignKey(c.FAKTURA.ID, /*~~*/"Faktura");
		ZAKAZKA.setForeignKey(c.ZAKAZKA.ID, /*~~*/"Zakazka");
	}
	
}
