package demo.framework.example.su.ine.md;


import java.io.File;

import netball.client.ui.XFile;
import netball.client.ui.transferfile.ListClientServerTransferFile;
import netball.client.ui.transferfile.TransferFileCloser;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XFileChooser;
import netball.server.component.XPanel;
import netball.server.component.border.XTitleBorder;
import netball.server.pack.EnabledPack;
import netball.server.pack.RequiredPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.mediator.MDOkCancel;
import netframework.mediator.MediatorParameters;

public class MDClientServerTransferFileExample extends MDOkCancel {
	
	private final String FILE_CHOOSER = "fileChooser"; 
	
	@Override
    public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
		this.putFormToPack(serverPack);
    }    

	@Override
	protected XPanel createPanel(ServerPack pack) throws Exception {
        XDualComponentPanel panel = new XDualComponentPanel();
        panel.setBorder(new XTitleBorder());
        XFileChooser  fc = new XFileChooser(FILE_CHOOSER);
   	    fc.setSelectionMode(XFileChooser.FILES_ONLY);
   	    fc.setMultiSelectionEnabled(true);
        fc.setType(XFileChooser.SAVE);
        panel.add(fc);
        return panel;
    }

	@Override
    protected void execute(ValuePack valuePack, ServerPack pack) throws Exception {
		XFile[] files = (XFile[]) valuePack.getValue(FILE_CHOOSER);  
		if (files == null)
			return;
		ListClientServerTransferFile listFiles = new ListClientServerTransferFile();  
		for (int i = 0; i < files.length; i++) {
			listFiles.add(files[i], new File(System.getProperty("java.io.tmpdir") + System.getProperty("file.separator") + files[i].getName()));
		}
		
		TransferFileCloser transferFileCloser = new TransferFileCloser() { // aby sa zavrel formular, po prenose
			@Override
			public void close(ServerPack pack) {
				MDClientServerTransferFileExample.this.close(pack);
			}
		};
		listFiles.setFileCloser(transferFileCloser);
		UpdatedPack updatePack = new UpdatedPack(this.getId());
		updatePack.setClientServerTransferFiles(this, listFiles);
		pack.addUpdatedPack(updatePack);
    }
    
	@Override
    protected String getTitleText() {
       return "Client server transfer file"; 
    }    
    
	@Override
    protected ValuePack getValuePack() {
        return null;
    }

	@Override
    protected EnabledPack getEnabledPack() {
    	return null;
    }

	@Override
    protected RequiredPack getRequiredPack() {
    	return null;    
    }
}    
