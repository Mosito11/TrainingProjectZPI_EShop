package demo.framework.example.su.ine.md;

import netball.client.ui.XFile;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XFileChooser;
import netball.server.component.XPanel;
import netball.server.component.border.XTitleBorder;
import netball.server.pack.EnabledPack;
import netball.server.pack.RequiredPack;
import netball.server.pack.ServerPack;
import netball.server.pack.ValuePack;
import netframework.mediator.BasicMediator;
import netframework.mediator.MDOkCancel;
import netframework.mediator.MDServerClientTransferFiles;
import netframework.mediator.MediatorCallBackObject;
import netframework.mediator.MediatorParameters;

public class MDServerClientTransferFileExampleWithWaitDialog extends MDOkCancel {
	
	private final String FILE_CHOOSER = "fileChooser"; 
	
	@Override
    public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
		this.putFormToPack(serverPack);
    }    

	@Override
	protected XPanel createPanel(ServerPack pack) throws Exception {
        XDualComponentPanel panel = new XDualComponentPanel();
        panel.setBorder(new XTitleBorder());
        XFileChooser  fc = new XFileChooser(FILE_CHOOSER);
   	    fc.setSelectionMode(XFileChooser.FILES_ONLY);
   	    fc.setMultiSelectionEnabled(true);
        fc.setType(XFileChooser.SAVE);
        panel.add(fc);
        return panel;
    }

	@Override
    protected void execute(ValuePack valuePack, ServerPack pack) throws Exception {
		XFile[] files = (XFile[]) valuePack.getValue(FILE_CHOOSER);  
		if (files == null)
			return;
		MDServerClientTransferFiles.Parameters prmts = new MDServerClientTransferFiles.Parameters("Cakajte prosim, prenasam subory."); 
		for (int i = 0; i < files.length; i++) {
//			prmts.getTransferFiles().add(files[i], getClientSystemProperties().temporaryDirectory + files[i].getName()); // pozor pouzit properties klienta !!!
			prmts.getTransferFiles().add(files[i].getName(), files[i].getAbsolutePath()); // zmena pre testovanie v prostredi servera(v adresari servra sa musi nachadzat subor s menom ako je zadane vo FileChooser)
		}
		this.runNext(MDServerClientTransferFiles.class, prmts, pack);
    }
    
	@Override
    protected String getTitleText() {
       return "Server client transfer file with wait dialog"; 
    }    
    
	@Override
    protected ValuePack getValuePack() {
        return null;
    }

	@Override
    protected EnabledPack getEnabledPack() {
    	return null;
    }

	@Override
    protected RequiredPack getRequiredPack() {
    	return null;    
    }

	@Override
	protected boolean receiveCallBack(BasicMediator mediator, MediatorCallBackObject callBackObject, ServerPack pack) {
		if (callBackObject instanceof MDServerClientTransferFiles.CallBack)
			close(pack);
		return false;	
	}
	
	
}    
