package demo.framework.example.su.ine.md;

import java.awt.Font;
import java.awt.Insets;

import netball.server.component.XDualComponentPanel;
import netball.server.component.XNumberField;
import netball.server.component.XPanel;
import netball.server.pack.EnabledPack;
import netball.server.pack.RequiredPack;
import netball.server.pack.ServerPack;
import netball.server.pack.ValuePack;
import netball.server.print.PRFont;
import netball.server.print.PRLabel;
import netball.server.print.PRPageFormat;
import netball.server.print.PRReport;
import netframework.mediator.MDOkCancel;
import netframework.mediator.MDReportPreview;
import netframework.mediator.MediatorParameters;
import netframework.report.PageBuffer;

public class MDUsePageBuffer extends MDOkCancel {

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
		this.putFormToPack(serverPack);
	}

	@Override
	protected XPanel createPanel(ServerPack pack) throws Exception {
		XDualComponentPanel panel = new XDualComponentPanel();
		panel.setInsets(new Insets(10, 10, 10, 10));
		XNumberField field = new XNumberField("pocetStran", XNumberField.INTEGER, 2, 0);
		field.setValueRequired(true);
		panel.add("Pocet stran", field);
		return panel;
	}

	@Override
	protected String getTitleText() {
		return "Pouzitie PageBuffer";
	}

	@Override
	protected void execute(ValuePack valuePack, ServerPack pack) throws Exception {
		int pocetStran = (int) valuePack.getValue("pocetStran");
		PageBuffer buffer = new PageBuffer();
		for (int i = 0; i < pocetStran; i++) {
			PRReport report = new PRReport();
			PRLabel label = new PRLabel("strana " + (i + 1));
			label.setFont(new PRFont("Dialog", Font.BOLD, 20));
			report.setBody(label);
			buffer.addPage(report);
		}
		runNext(MDReportPreview.class, new MDReportPreview.PageSourceParameters(buffer, new PRPageFormat()), pack);
	}

	@Override
	protected ValuePack getValuePack() {
		return null;
	}

	@Override
	protected EnabledPack getEnabledPack() {
		return null;
	}

	@Override
	protected RequiredPack getRequiredPack() {
		return null;
	}

}
