package demo.framework.example.su.ine.md;

import java.io.File;

import netball.client.ui.XFile;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XFileChooser;
import netball.server.component.XPanel;
import netball.server.component.border.XTitleBorder;
import netball.server.pack.EnabledPack;
import netball.server.pack.RequiredPack;
import netball.server.pack.ServerPack;
import netball.server.pack.ValuePack;
import netframework.mediator.BasicMediator;
import netframework.mediator.MDClientServerTransferFiles;
import netframework.mediator.MDOkCancel;
import netframework.mediator.MediatorCallBackObject;
import netframework.mediator.MediatorParameters;

public class MDClientServerTransferFileExampleWithWaitDialog extends MDOkCancel {
	
	private final String FILE_CHOOSER = "fileChooser"; 
	
	@Override
    public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
		this.putFormToPack(serverPack);
    }    

	@Override
	protected XPanel createPanel(ServerPack pack) throws Exception {
        XDualComponentPanel panel = new XDualComponentPanel();
        panel.setBorder(new XTitleBorder());
        XFileChooser  fc = new XFileChooser(FILE_CHOOSER);
   	    fc.setSelectionMode(XFileChooser.FILES_ONLY);
   	    fc.setMultiSelectionEnabled(true);
        fc.setType(XFileChooser.SAVE);
        panel.add(fc);
        return panel;
    }

	@Override
    protected void execute(ValuePack valuePack, ServerPack pack) throws Exception {
		XFile[] files = (XFile[]) valuePack.getValue(FILE_CHOOSER);  
		if (files == null)
			return;
		MDClientServerTransferFiles.Parameters prmts = new MDClientServerTransferFiles.Parameters("Cakajte prosim, prenasam subory."); 
		for (int i = 0; i < files.length; i++) {
			prmts.getTransferFiles().add(files[i], new File(System.getProperty("java.io.tmpdir")+System.getProperty("file.separator") + files[i].getName()));
		}
		this.runNext(MDClientServerTransferFiles.class, prmts, pack);
    }
    
	@Override
    protected String getTitleText() {
       return "Client server transfer file with wait dialog"; 
    }    
    
	@Override
    protected ValuePack getValuePack() {
        return null;
    }

	@Override
    protected EnabledPack getEnabledPack() {
    	return null;
    }

	@Override
    protected RequiredPack getRequiredPack() {
    	return null;    
    }

	@Override
	protected boolean receiveCallBack(BasicMediator mediator, MediatorCallBackObject callBackObject, ServerPack pack) {
		if (callBackObject instanceof MDClientServerTransferFiles.CallBack)
			close(pack);
		return false;	
	}
	
	
}    
