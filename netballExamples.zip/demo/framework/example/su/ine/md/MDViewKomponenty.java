package demo.framework.example.su.ine.md;

import java.awt.Insets;

import demo.framework.example.bo.ciselniky.Zakaznik;
import demo.framework.example.su.komponenty.ComponentFaktura;
import demo.framework.example.su.komponenty.ComponentFakturaZakaznik;
import demo.framework.example.su.komponenty.ComponentMena;
import demo.framework.example.su.komponenty.ComponentMena1;
import demo.framework.example.su.komponenty.ComponentZakazka;
import demo.framework.example.su.komponenty.ComponentZakaznik;
import demo.framework.example.su.komponenty.ComponentZakaznikInsert;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XPanel;
import netball.server.component.border.XTitleBorder;
import netball.server.pack.EnabledPack;
import netball.server.pack.RequiredPack;
import netball.server.pack.ServerPack;
import netball.server.pack.ValuePack;
import netframework.mediator.MDOkCancel;
import netframework.mediator.MediatorParameters;
import zelpo.eclipselink.autorizacia.md.ComponentUzivatel;

public class MDViewKomponenty extends MDOkCancel{
	
	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
		putFormToPack(serverPack);
	}

	@Override
	protected XPanel createPanel(ServerPack pack) throws Exception {
		XDualComponentPanel panel = new XDualComponentPanel();
		panel.setInsets(new Insets(10, 10, 10, 10));
		panel.setBorder(new XTitleBorder());
		panel.add(ComponentZakaznik.createComponent("ComponentZakaznik", this));
		panel.add(ComponentFakturaZakaznik.createComponent("ComponentFakturaZakaznik", Zakaznik.ICO.getId(), "Faktura zakaznik", this));
		panel.add(ComponentFaktura.createComponent("ComponentFaktura", this));
		panel.add(ComponentMena.createComponent("ComponentMena", this));
		panel.add(ComponentMena1.createExpressionComponent("ComponentMena1", this));
		panel.add(ComponentZakazka.createComponent("ComponentZakazka", this));
		panel.add(ComponentZakaznikInsert.createComponent("ComponentZakaznikInsert", "Zakaznik insert", this));
		panel.add(ComponentFaktura.createExpressionComponent("ComponentFakturaExpression", this));
		panel.add(ComponentMena.createExpressionComponent("ComponentMenaExpression", this));
		panel.add(ComponentUzivatel.createExpressionComponent("ComponentUzivatel", this));
		return panel;
	}

	@Override
	protected String getTitleText() {
		return "View komponenty";
	}

	@Override
	protected void execute(ValuePack valuePack, ServerPack pack) throws Exception {
		System.out.println(valuePack);
	}

	@Override
	protected ValuePack getValuePack() {
		return null;
	}

	@Override
	protected EnabledPack getEnabledPack() {
		return null;
	}

	@Override
	protected RequiredPack getRequiredPack() {
		return null;
	}
}
