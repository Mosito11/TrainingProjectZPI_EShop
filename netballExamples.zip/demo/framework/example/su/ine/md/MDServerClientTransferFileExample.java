package demo.framework.example.su.ine.md;

import netball.client.ui.XFile;
import netball.client.ui.transferfile.ListServerClientTransferFile;
import netball.client.ui.transferfile.TransferFileCloser;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XFileChooser;
import netball.server.component.XPanel;
import netball.server.component.border.XTitleBorder;
import netball.server.pack.EnabledPack;
import netball.server.pack.RequiredPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.mediator.MDOkCancel;
import netframework.mediator.MediatorParameters;

public class MDServerClientTransferFileExample extends MDOkCancel {
	
	private final String FILE_CHOOSER = "fileChooser"; 
	
	@Override
    public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
		this.putFormToPack(serverPack);
    }    

	@Override
	protected XPanel createPanel(ServerPack pack) throws Exception {
        XDualComponentPanel panel = new XDualComponentPanel();
        panel.setBorder(new XTitleBorder());
        XFileChooser  fc = new XFileChooser(FILE_CHOOSER);
   	    fc.setSelectionMode(XFileChooser.FILES_ONLY);
   	    fc.setMultiSelectionEnabled(true);
        fc.setType(XFileChooser.SAVE);
        panel.add(fc);
        return panel;
    }

	@Override
    protected void execute(ValuePack valuePack, ServerPack pack) throws Exception {
		XFile[] files = (XFile[]) valuePack.getValue(FILE_CHOOSER);  
		if (files == null)
			return;
		ListServerClientTransferFile listFiles = new ListServerClientTransferFile();  
		for (int i = 0; i < files.length; i++) {
//			listFiles.add(files[i], getClientSystemProperties().temporaryDirectory + files[i].getName()); // pozor pouzit properties klienta !!!
			listFiles.add(files[i].getName(), files[i].getAbsolutePath()); // zmena pre testovanie v prostredi servera(v adresary servra sa musi nachadzat subor s menom ako je zadane vo FileChooser)
		}
		TransferFileCloser transferFileCloser = new TransferFileCloser() { // aby sa zavrel formular, po prenose
			@Override
			public void close(ServerPack pack) {
				MDServerClientTransferFileExample.this.close(pack);
			}
		};
		listFiles.setFileCloser(transferFileCloser);
		UpdatedPack updatePack = new UpdatedPack(this.getId());
		updatePack.setServerClientTransferFiles(this, listFiles);
		pack.addUpdatedPack(updatePack);
    }
    
	@Override
    protected String getTitleText() {
       return "Server client transfer file"; 
    }    
    
	@Override
    protected ValuePack getValuePack() {
        return null;
    }

	@Override
    protected EnabledPack getEnabledPack() {
    	return null;
    }

	@Override
    protected RequiredPack getRequiredPack() {
    	return null;    
    }
}    
