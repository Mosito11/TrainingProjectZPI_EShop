package demo.framework.example.su.ine.md;

import java.util.Arrays;

import netball.server.component.XDualComponentPanel;
import netball.server.component.XPanel;
import netball.server.component.XTextField;
import netball.server.pack.ClientRemoteObject;
import netball.server.pack.ClientRemoteObjectReceiver;
import netball.server.pack.ClientRemoteObjectRunner;
import netball.server.pack.EnabledPack;
import netball.server.pack.RequiredPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.mediator.MDOkCancel;
import netframework.mediator.MediatorParameters;

/**
 * Spustenie triedy na klientovi. Trieda musi byt na klientovi.     
 * @author Cernak
 */
public class MDClientRemoteObject extends MDOkCancel {

	private final String FIELD = "field"; 
	private final String REMOTE_OBJECT_RECEIVER_ID = "remoteObjectReceiverId";
	
	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
		putFormToPack(serverPack);
		// zaregistrovanie objektu, ktory bude spracovavat vysledok z MyClientRemoteObject 
		this.registerRemoteObject(REMOTE_OBJECT_RECEIVER_ID, new MyClientRemoteObjectReceiver());
	}
	
	@Override
	protected XPanel createPanel(ServerPack pack) throws Exception {
		XDualComponentPanel panel = new XDualComponentPanel();
		XTextField field = new XTextField(FIELD, /*~~*/"Result", 30);
		panel.add(field);
		return panel;
	}

	@Override
	protected String getTitleText() {
		return /*~~*/"ClientRemoteObject";
	}

	@Override
	protected void execute(ValuePack valuePack, ServerPack pack) throws Exception {
		ClientRemoteObjectRunner runner = new ClientRemoteObjectRunner(REMOTE_OBJECT_RECEIVER_ID, getId(), MyClientRemoteObject.class.getName(), new String[] {"parameter0", "parameter1"});
		pack.addClientRemoteObjectRunners(runner);
	}

	@Override
	protected ValuePack getValuePack() {
		return null;
	}

	@Override
	protected EnabledPack getEnabledPack() {
		return null;
	}

	@Override
	protected RequiredPack getRequiredPack() {
		return null;
	}

	/**
	 * Spracovanie vysledku z objektu MyClientRemoteObject, ktory bol spusteny na klientovi.  
	 */
	private class MyClientRemoteObjectReceiver extends ClientRemoteObjectReceiver {

		public MyClientRemoteObjectReceiver() {
			super(REMOTE_OBJECT_RECEIVER_ID);
		}

		@Override
		public void actionExecuted(Object result, ServerPack serverPack) {
			ValuePack pack = new ValuePack();
			pack.put(FIELD, result);
			serverPack.addUpdatedPack(new UpdatedPack(MDClientRemoteObject.this.getId(), pack));
		}
		
	}
	
	public static class MyClientRemoteObject extends ClientRemoteObject {

		@Override
		public Object execute(Object[] prmts) throws Exception {
			return Arrays.toString(prmts);
		}

	}	
}
