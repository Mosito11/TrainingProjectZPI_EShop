package demo.framework.example.bo.uzol;

import java.util.Vector;

import netframework.bo.PersistentObject;
import netframework.bo.attributes.NumberAttribute;
import netframework.bo.attributes.RelationAttribute;
import netframework.bo.attributes.TextAttribute;
import netframework.eclipselink.EclipseLinkSession;

import org.eclipse.persistence.zpi.expressions.Expression;
import org.eclipse.persistence.zpi.expressions.ExpressionBuilder;
import org.eclipse.persistence.zpi.indirection.ValueHolder;
import org.eclipse.persistence.zpi.indirection.ValueHolderInterface;
import org.eclipse.persistence.zpi.sessions.UnitOfWork;

public class Uzol extends PersistentObject {
	
	public static final NumberAttribute ID = new NumberAttribute("Uzol.id", "id");
	public static final TextAttribute KOD = new TextAttribute("Uzol.kod", "kod");
    public static final TextAttribute NAZOV = new TextAttribute("Uzol.nazov", "nazov");
    public static final TextAttribute POLOZKA_1 = new TextAttribute("Uzol.polozka1", "polozka1");
    public static final TextAttribute POLOZKA_2 = new TextAttribute("Uzol.polozka2", "polozka2");
    public static final TextAttribute POLOZKA_3 = new TextAttribute("Uzol.polozka3", "polozka3");
    public static final RelationAttribute RODIC = new RelationAttribute("Uzol.rodic", "rodic");
	
    static{
		KOD.setCaption("Kod");
		KOD.setLimit(3);
		KOD.setRequired(true);
		KOD.setFixedLimit(true);
		
		NAZOV.setCaption("Nazov");
		NAZOV.setLimit(40);
		NAZOV.setRequired(true);
		
		POLOZKA_1.setCaption("Polozka 1");
		POLOZKA_1.setLimit(20);
		POLOZKA_1.setRequired(true);

		POLOZKA_2.setCaption("Polozka 2");
		POLOZKA_2.setLimit(20);
		POLOZKA_2.setRequired(true);

		POLOZKA_3.setCaption("Polozka 3");
		POLOZKA_3.setLimit(20);
		POLOZKA_3.setRequired(true);
		
		RODIC.setCaption("Rodic");
    }
    
	private String kod;
	private String nazov;
	private String polozka1;
	private String polozka2;
	private String polozka3;
	private ValueHolderInterface rodic = new ValueHolder();
	
	public void setRodic(Uzol rodic) {
		this.rodic.setValue(rodic);
	}

	public Uzol getRodic() {
		return (Uzol) this.rodic.getValue();
	}
	
	public String getPolozka1() {
		return polozka1;
	}

	public void setPolozka1(String polozka1) {
		this.polozka1 = polozka1;
	}

	public String getPolozka2() {
		return polozka2;
	}

	public void setPolozka2(String polozka2) {
		this.polozka2 = polozka2;
	}

	public String getPolozka3() {
		return polozka3;
	}

	public void setPolozka3(String polozka3) {
		this.polozka3 = polozka3;
	}
	
	public String getKod() {
		return kod;
	}
	
	public void setKod(String kod) {
		if (kod != null) {
			kod = kod.trim();
		}
		this.kod = kod;
	}
	
	public String getNazov() {
		return nazov;
	}
	
	public void setNazov(String nazov) {
		if (nazov != null)
			nazov = nazov.trim();
		this.nazov = nazov;
	}

     public void validate(EclipseLinkSession session) throws Exception {
        KOD.checkValue(getKod(), session);
        NAZOV.checkValue(getNazov(), session);
        POLOZKA_1.checkValue(getPolozka1(), session);
        POLOZKA_1.checkValue(getPolozka2(), session);
        POLOZKA_1.checkValue(getPolozka3(), session);
     }

     public void delete(EclipseLinkSession session, UnitOfWork uow) throws Exception {
 		ExpressionBuilder builder = new ExpressionBuilder();
		Expression exp = builder.get(RODIC.getName()).equal(this);
		Vector uzly = session.getSession().readAllObjects(Uzol.class, exp);
		uow.deleteAllObjects(uzly);
		for (int i = 0;i < uzly.size(); i++) {
			((Uzol)uzly.get(i)).delete(session, uow);
		}
     }
}
