package demo.framework.example.bo.obmedzenie;

import netframework.mediator.SessionObject;
import netframework.sql.SQLExpression;
import netframework.sql.SQLExpressionBuilder;
import netframework.sql.SQLQuery;
import netframework.view.ViewExpression;
import netframework.view.ViewExpressionBuilder;
import netframework.view.ViewQuery;
import zelpo.eclipselink.autorizacia.Restriction;
import demo.framework.example.bo.common.Helper;
import demo.framework.example.bo.fakturacia.Faktura;
import demo.framework.example.su.db.DBSkolenieCatalog;
import demo.framework.translate.ResourceConstants;

public class ObmedzeniaTypFaktury  {
    
    private String string;
    private String[] typy; 

    public void setString(String text) {
        if (text == null) {
           string = null;
           typy = null;
           return;
        }
        typy = Restriction.getValues(text);
        string = text;
    }
    
    public String getString() {
        return string;
    }
    
    public String[] getObmedzenia() {
        return typy;
    }
    
    public void isMozneEditovat(Faktura faktura, SessionObject session) throws IllegalArgumentException {
    	String typ = faktura.getTyp().getKey(); 
        if (typy == null)
           throw new IllegalArgumentException(session.translateText(ResourceConstants.NEMATE_PRAVA_NA_VYSTAVENIE_A_EDITOVANIE_ZAZNAMOV__));
        if (typ == null)
           throw new IllegalArgumentException(session.translateText(ResourceConstants.NIE_JE_DEFINOVANY_TYP_FAKTURY__PRETO_NIE_JE_MOZNE_OVERIT__CI_MOZEDE_MODIFIKOVAT_FAKURY_));
        for (int i = 0; i < typy.length; i++) {                         	              
            if (typ.equals(typy[i]))              
                return;
        }
        throw new IllegalArgumentException(Helper.createMessage(session, ResourceConstants.NEMATE_PRAVO_MODIFIKOVAT_TYPU_FAKTURY___0___, typ));
        
    }

    public ViewExpression getObmedzeniaExpression() {
        if (typy == null)
           return null;
        return ViewExpressionBuilder.get(Faktura.TYP.getId()).in(typy);
    }

    public void setObmedzeniaExpression(ViewQuery query) {
    	ViewExpression exp = getObmedzeniaExpression();
    	if (exp != null) {
    		query.setSelectionCriteria(query.getSelectionCriteria() == null ? exp : query.getSelectionCriteria().and(exp)); 
    	}
    }
    
    public SQLExpression getObmedzeniaSqlExpression() {
        if (typy == null)
           return null;
        DBSkolenieCatalog c = DBSkolenieCatalog.getInstance();  
        return SQLExpressionBuilder.get(c.FAKTURA.TYP).in(typy);
    }
    
    public void setObmedzeniaExpression(SQLQuery query) {
    	SQLExpression exp = getObmedzeniaSqlExpression();
    	if (exp != null) {
    		query.setExpression(query.getExpression() == null ? exp : query.getExpression().and(exp)); 
    	}
    }
}
