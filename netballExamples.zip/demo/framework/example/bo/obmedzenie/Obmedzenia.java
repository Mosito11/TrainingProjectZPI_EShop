package demo.framework.example.bo.obmedzenie;
import netframework.bo.attributes.TextAttribute;
import netframework.eclipselink.EclipseLinkSession;

import org.eclipse.persistence.zpi.sessions.Session;
import org.eclipse.persistence.zpi.sessions.UnitOfWork;

import zelpo.eclipselink.autorizacia.Restriction;
import demo.framework.translate.ResourceConstants;

public class Obmedzenia extends Restriction {

    public static final TextAttribute TYP_FAKTURY = new TextAttribute("Obmedzenia.typFaktury", "typFaktury");

    public static final String TYP_FAKTURY_TAG = "typ";

    static{
    	TYP_FAKTURY.setCaption(ResourceConstants.TYP_FAKUTRY);
    	TYP_FAKTURY.setRequired(false);        
    	TYP_FAKTURY.setLimit(5);
    	TYP_FAKTURY.setTypeLetters(TextAttribute.CAPITAL_LETTERS);
    }

    private ObmedzeniaTypFaktury typFaktury = new ObmedzeniaTypFaktury();

    public ObmedzeniaTypFaktury getTypFaktury() {
       return typFaktury;
    }
    
    @Override
    public String convertToString() {
    	String text = addAttribute("", TYP_FAKTURY_TAG, typFaktury.getString());  
    	return text;
    } 

	@Override
	public void validateAttributes(EclipseLinkSession session, UnitOfWork uow)throws Exception {
	}
    
    public static Obmedzenia parse(Session session, String string) throws Exception {
        Obmedzenia obmedzenie = new Obmedzenia();
        obmedzenie.getTypFaktury().setString(getValue(string, TYP_FAKTURY_TAG));
        return obmedzenie;         
    }

}
