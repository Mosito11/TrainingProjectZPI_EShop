package demo.framework.example.bo.ciselniky;

import java.util.Vector;

import netframework.bo.PersistentObject;
import netframework.bo.ValueException;
import netframework.bo.attributes.LogicalAttribute;
import netframework.bo.attributes.NumberAttribute;
import netframework.bo.attributes.TextAttribute;
import netframework.eclipselink.EclipseLinkSession;

import org.eclipse.persistence.zpi.expressions.Expression;
import org.eclipse.persistence.zpi.expressions.ExpressionBuilder;
import org.eclipse.persistence.zpi.queries.ReportQuery;
import org.eclipse.persistence.zpi.queries.ReportQueryResult;

import demo.framework.example.bo.common.Helper;
import demo.framework.example.bo.fakturacia.Faktura;
import demo.framework.translate.ResourceConstants;


public class Zakaznik extends PersistentObject {

	public static final NumberAttribute ID = new NumberAttribute("Zakaznik.id", "id");
	public static final TextAttribute ADRESA = new TextAttribute("Zakaznik.adresa", "adresa");
    public static final TextAttribute NAZOV = new TextAttribute("Zakaznik.nazov", "nazov");
    public static final TextAttribute ICO = new TextAttribute("Zakaznik.ico", "ico");
    public static final LogicalAttribute JE_ZAHRANICNA = new LogicalAttribute("Zakaznik.jeZahranicny", "jeZahranicny");
	
    static {
    	ICO.setCaption(ResourceConstants.ICO);
    	ICO.setLongCaption(ResourceConstants.ICO_ZAKAZNIKA);
    	ICO.setColumnName(ICO.getCaption());
    	ICO.setLongColumnName(ICO.getLongCaption());
    	ICO.setLimit(10);
    	ICO.setRequired(true);
    	ICO.setFixedLimit(true);
    	ICO.setAllowableChars("#");
		
		NAZOV.setCaption(ResourceConstants.NAZOV);
		NAZOV.setLongCaption(ResourceConstants.NAZOV_ZAKAZNIKA);
		NAZOV.setColumnName(NAZOV.getCaption());
		NAZOV.setLongColumnName(NAZOV.getLongCaption());
		NAZOV.setLimit(50);
		NAZOV.setRequired(true);
		
		ADRESA.setCaption(ResourceConstants.ADRESA);
		ADRESA.setLongCaption(ResourceConstants.ADRESA_ZAKAZNIKA);
		ADRESA.setColumnName(ADRESA.getCaption());
		ADRESA.setLongColumnName(ADRESA.getLongCaption());
		ADRESA.setLimit(100);
		ADRESA.setRequired(true);
		
		JE_ZAHRANICNA.setCaption(ResourceConstants.JE_ZAHRANICNY);
    }
    
	private String ico;
	private String nazov;
	private String adresa;
	private boolean jeZahranicny;
	
	public String getIco() {
		return ico;
	}
	
	public void setIco(String ico) {
		if (ico != null)
			ico = ico.trim();
		this.ico = ico;
	}
	
	public String getNazov() {
		return nazov;
	}
	
	public void setNazov(String nazov) {
		if (nazov != null)
			nazov = nazov.trim();
		this.nazov = nazov;
	}
	
	public String getAdresa() {
		return adresa;
	}
	
	public void setAdresa(String adresa) {
		if (adresa != null)
			adresa = adresa.trim();
		this.adresa = adresa;
	}
	
	public boolean getJeZahranicny() {
		return jeZahranicny;
	}
	
	public void setJeZahranicny(boolean jeZahranicny) {
		this.jeZahranicny = jeZahranicny;
	}

    public void validate(EclipseLinkSession session) throws Exception {
        ICO.checkValue(getIco(), session);
        NAZOV.checkValue(getNazov(), session);
        ADRESA.checkValue(getAdresa(), session);
        validateDuplicity(session);
     }

     public void delete(EclipseLinkSession session) throws Exception {
 		ExpressionBuilder builder = new ExpressionBuilder();
		Expression exp = builder.get(Faktura.ZAKAZNIK.getName()).equal(this);
		ReportQuery query = new ReportQuery();
		query.setReferenceClass(Faktura.class);
		query.addAttribute(Faktura.CISLO.getName());
		query.setSelectionCriteria(exp);
		Vector<ReportQueryResult> result = (Vector<ReportQueryResult>) session.getSession().executeQuery(query);
		if (result.size() == 0)
			return;
		StringBuilder buffer = new StringBuilder(); 
		for (int i = 0; i < result.size(); i++) {
			ReportQueryResult row = result.get(i);
			buffer.append("\n\t");
			buffer.append(row.getByIndex(0));
		}
		throw new IllegalArgumentException(Helper.createMessage(session, "Nie je mozne vymazat zakaznika, pretoze sa nachadza v nasledujucich fakturach:") + buffer);
     }
     
     private void validateDuplicity(EclipseLinkSession session) throws Exception {
    	if (this.getIco() == null)
    		return;
        ExpressionBuilder builder = new ExpressionBuilder();
        Expression exp = builder.get(ICO.getName()).equal(getIco());
        if (isPersisted()) 
          exp = exp.and(builder.get(ID.getName()).notEqual(getId()));       
        ReportQuery query = new ReportQuery();                
        query.setReferenceClass(getClass());
        query.addAttribute(ID.getName());
        query.setSelectionCriteria(exp);
        Vector vector = (Vector) session.getSession().executeQuery(query);
        if (vector.size() > 0) {
            throw new ValueException(ICO.getId(), Helper.createMessage(session, ResourceConstants.V_CISELNIKU_SA_UZ_NACHADZA_ZAZNAM_S_ICOM___0___, getIco()));              
        }   
    }             
}
