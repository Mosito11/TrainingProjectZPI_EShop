package demo.framework.example.bo.ciselniky;

import java.util.Vector;

import netframework.bo.PersistentObject;
import netframework.bo.ValueException;
import netframework.bo.attributes.FormattedTextAttribute;
import netframework.bo.attributes.NumberAttribute;
import netframework.bo.attributes.TextAttribute;
import netframework.eclipselink.EclipseLinkSession;

import org.eclipse.persistence.zpi.expressions.Expression;
import org.eclipse.persistence.zpi.expressions.ExpressionBuilder;
import org.eclipse.persistence.zpi.queries.ReportQuery;
import org.eclipse.persistence.zpi.queries.ReportQueryResult;

import demo.framework.example.bo.common.Helper;
import demo.framework.example.bo.fakturacia.OdberatelskaFaktura;
import demo.framework.translate.ResourceConstants;

public class Zakazka extends PersistentObject {

	public static final NumberAttribute ID = new NumberAttribute("Zakazka.id", "id");
	public static final FormattedTextAttribute CISLO = new FormattedTextAttribute("Zakazka.cislo", "cislo");
    public static final TextAttribute NAZOV = new TextAttribute("Zakazka.nazov", "nazov");
	
    static{
		CISLO.setCaption(ResourceConstants.KOD);
		CISLO.setLongCaption(ResourceConstants.ZAKAZKA);
		CISLO.setColumnName(CISLO.getCaption());
		CISLO.setLongColumnName(CISLO.getLongCaption());
		CISLO.setRequired(true);
		CISLO.setMask("##-##-######");
		
		NAZOV.setCaption(ResourceConstants.NAZOV);
		NAZOV.setLongCaption(ResourceConstants.NAZOV_ZAKAZKY);
		NAZOV.setColumnName(NAZOV.getCaption());
		NAZOV.setLongColumnName(NAZOV.getLongCaption());
		NAZOV.setLimit(50);
		NAZOV.setRequired(true);
    }
	
	private String cislo;
	private String nazov;
    
	public String getCislo() {
		return cislo;
	}
	
	public void setCislo(String cislo) {
		if (cislo != null)
			cislo = cislo.trim();
		this.cislo = cislo;
	}
	
	public String getNazov() {
		return nazov;
	}
	
	public void setNazov(String nazov) {
		if (nazov != null)
			nazov = nazov.trim();
		this.nazov = nazov;
	}

    public void validate(EclipseLinkSession session) throws Exception {
        CISLO.checkValue(getCislo(), session);
        NAZOV.checkValue(getNazov(), session);
        validateDuplicity(session);
    }

    public void delete(EclipseLinkSession session) throws Exception {
 		ExpressionBuilder builder = new ExpressionBuilder();
		Expression exp = builder.anyOf(OdberatelskaFaktura.ZAKAZKY.getName()).equal(this);
		ReportQuery query = new ReportQuery();
		query.setReferenceClass(OdberatelskaFaktura.class);
		query.addAttribute(OdberatelskaFaktura.CISLO.getName());
		query.setSelectionCriteria(exp);
		Vector<ReportQueryResult> result = (Vector<ReportQueryResult>) session.getSession().executeQuery(query);
		if (result.size() == 0)
			return;
		StringBuilder buffer = new StringBuilder(); 
		for (int i = 0; i < result.size(); i++) {
			ReportQueryResult row = result.get(i);
			buffer.append("\n\t");
			buffer.append(row.getByIndex(0));
		}
		throw new IllegalArgumentException(Helper.createMessage(session, ResourceConstants.NIE_JE_MOZNE_VYMAZAT_ZAKAZKU__PRETOZE_SA_NACHADZA_V_NASLEDUJUCICH_FAKTURACH_) + buffer);
    }
     
    private void validateDuplicity(EclipseLinkSession session) throws Exception {
    	if (this.getCislo() == null)
    		return;
        ExpressionBuilder builder = new ExpressionBuilder();
        Expression exp = builder.get(CISLO.getName()).equal(getCislo());
        if (isPersisted()) 
          exp = exp.and(builder.get(ID.getName()).notEqual(getId()));       
        ReportQuery query = new ReportQuery();                
        query.setReferenceClass(getClass());
        query.addAttribute(ID.getName());
        query.setSelectionCriteria(exp);
        Vector vector = (Vector) session.getSession().executeQuery(query);
        if (vector.size() > 0) {
            throw new ValueException(CISLO.getId(), Helper.createMessage(session, ResourceConstants.V_CISELNIKU_SA_UZ_NACHADZA_ZAZNAM_S_KODOM___0___, getCislo()));              
        }   
     }             
}
