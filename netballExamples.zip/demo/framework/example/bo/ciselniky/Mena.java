package demo.framework.example.bo.ciselniky;

import java.util.Vector;

import netframework.bo.PersistentObject;
import netframework.bo.ValueException;
import netframework.bo.attributes.NumberAttribute;
import netframework.bo.attributes.TextAttribute;
import netframework.eclipselink.EclipseLinkSession;

import org.eclipse.persistence.zpi.expressions.Expression;
import org.eclipse.persistence.zpi.expressions.ExpressionBuilder;
import org.eclipse.persistence.zpi.queries.ReportQuery;
import org.eclipse.persistence.zpi.queries.ReportQueryResult;

import demo.framework.example.bo.common.Helper;
import demo.framework.example.bo.fakturacia.Faktura;
import demo.framework.example.bo.fakturacia.SumaVMene;
import demo.framework.translate.ResourceConstants;

public class Mena extends PersistentObject {

	public static final NumberAttribute ID = new NumberAttribute("Mena.id", "id");
	public static final TextAttribute KOD = new TextAttribute("Mena.kod", "kod");
    public static final TextAttribute NAZOV = new TextAttribute("Mena.nazov", "nazov");
	
    static{
		KOD.setCaption(ResourceConstants.KOD);
		KOD.setLongCaption(ResourceConstants.MENA);
		KOD.setColumnName(KOD.getCaption());
		KOD.setLongColumnName(KOD.getLongCaption());
		KOD.setTypeLetters(TextAttribute.CAPITAL_LETTERS);
		KOD.setLimit(3);
		KOD.setRequired(true);
		KOD.setFixedLimit(true);
		
		NAZOV.setCaption(ResourceConstants.NAZOV);
		NAZOV.setLongCaption(ResourceConstants.NAZOV_MENY);
		NAZOV.setColumnName(NAZOV.getCaption());
		NAZOV.setLongColumnName(NAZOV.getLongCaption());
		NAZOV.setLimit(50);
		NAZOV.setRequired(true);
    }
    
	private String kod;
	private String nazov;
	
	public String getKod() {
		return kod;
	}
	
	public void setKod(String kod) {
		if (kod != null) {
			kod = kod.trim();
		}
		this.kod = kod;
	}
	
	public String getNazov() {
		return nazov;
	}
	
	public void setNazov(String nazov) {
		if (nazov != null)
			nazov = nazov.trim();
		this.nazov = nazov;
	}

     public void validate(EclipseLinkSession session) throws Exception {
        KOD.checkValue(getKod(), session);
        NAZOV.checkValue(getNazov(), session);
        validateDuplicity(session);
     }

     public void delete(EclipseLinkSession session) throws Exception {
 		ExpressionBuilder builder = new ExpressionBuilder();
		Expression exp = builder.get(Faktura.CELKOVA_SUMA.getName()).get(SumaVMene.MENA.getName()).equal(this);
		ReportQuery query = new ReportQuery();
		query.setReferenceClass(Faktura.class);
		query.addAttribute(Faktura.CISLO.getName());
		query.setSelectionCriteria(exp);
		Vector<ReportQueryResult> result = (Vector<ReportQueryResult>) session.getSession().executeQuery(query);
		if (result.size() == 0)
			return;
		StringBuilder buffer = new StringBuilder(); 
		for (int i = 0; i < result.size(); i++) {
			ReportQueryResult row = result.get(i);
			buffer.append("\n\t");
			buffer.append(row.getByIndex(0));
		}
		throw new IllegalArgumentException(Helper.createMessage(session, ResourceConstants.NIE_JE_MOZNE_VYMAZAT_MENU__PRETOZE_SA_NACHADZA_V_NASLEDUJUCICH_FAKTURACH_) + buffer);
     }
     
     private void validateDuplicity(EclipseLinkSession session) throws Exception {
    	if (this.getKod() == null)
    		return;
        ExpressionBuilder builder = new ExpressionBuilder();
        Expression exp = builder.get(KOD.getName()).equal(getKod());
        if (isPersisted()) 
          exp = exp.and(builder.get(ID.getName()).notEqual(getId()));       
        ReportQuery query = new ReportQuery();                
        query.setReferenceClass(getClass());
        query.addAttribute(ID.getName());
        query.setSelectionCriteria(exp);
        Vector vector = (Vector) session.getSession().executeQuery(query);
        if (vector.size() > 0) {
            throw new ValueException(KOD.getId(), Helper.createMessage(session, ResourceConstants.V_CISELNIKU_SA_UZ_NACHADZA_ZAZNAM_S_KODOM___0___, getKod()));              
        }   
     }             
}
