package demo.framework.example.bo.common;
import java.math.BigDecimal;
import java.text.MessageFormat;

import netframework.eclipselink.EclipseLinkSession;
import netframework.mediator.SessionObject;

import org.eclipse.persistence.zpi.expressions.Expression;
import org.eclipse.persistence.zpi.expressions.ExpressionBuilder;
import org.eclipse.persistence.zpi.sessions.Session;

import demo.framework.example.bo.obmedzenie.Obmedzenia;
import demo.framework.translate.ResourceConstants;

public class Helper {

	public static final BigDecimal DEFAULT_VALUE = new BigDecimal("0");  
	public static final String OBMEDZENIA = "obmedzenia";
	
	public static String createMessage(SessionObject session, String message, Object...prmts) {
		return MessageFormat.format(session.translateText(message), prmts); 
	} 
	
    public static Object readObject(Object value, String nazovCiselnika, Class relacnaTrieda, String atribut, Session session, SessionObject sessionObject) throws Exception{
        if(value == null)
            return null;
        ExpressionBuilder expBuilder = new ExpressionBuilder();   
        Expression exp = (expBuilder.get(atribut).equal(value));
        Object object = session.readObject(relacnaTrieda, exp);
        if(object == null)
            throw new IllegalArgumentException(createMessage(sessionObject, ResourceConstants.V_EVIDENCII__0__SA_NENACHADZA_ZAZNAM_S_HODNOTOU___1___, nazovCiselnika, value));
        return object;
    }
    
    public static Obmedzenia getObmedzenia(SessionObject sessionObject) {
    	return (Obmedzenia) ((EclipseLinkSession) sessionObject).getProperty(OBMEDZENIA);
    }
}
