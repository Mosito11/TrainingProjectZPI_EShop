package demo.framework.example.bo.fakturacia;

import java.math.BigDecimal;

import org.eclipse.persistence.zpi.indirection.ValueHolder;
import org.eclipse.persistence.zpi.indirection.ValueHolderInterface;

import demo.framework.example.bo.common.Helper;
import demo.framework.translate.ResourceConstants;
import netframework.bo.PersistentObject;
import netframework.bo.attributes.NumberAttribute;
import netframework.bo.attributes.RelationAttribute;
import netframework.bo.attributes.TextAttribute;
import netframework.eclipselink.EclipseLinkSession;

public class FakturaPolozka extends PersistentObject {

	public static final NumberAttribute ID = new NumberAttribute("FakturaPolozka.id", "id");
	public static final NumberAttribute MNOZSTVO = new NumberAttribute("FakturaPolozka.mnozstvo", "mnozstvo", NumberAttribute.BIG_DECIMAL);
	public static final NumberAttribute JEDNOTKOVA_CENA = new NumberAttribute("FakturaPolozka.jednotkovaCena", "jednotkovaCena", NumberAttribute.BIG_DECIMAL);
	public static final NumberAttribute CELKOVA_CENA = new NumberAttribute("FakturaPolozka.celkovaCena", "celkovaCena", NumberAttribute.BIG_DECIMAL);
	public static final TextAttribute MERNA_JEDNOTKA = new TextAttribute("FakturaPolozka.mernaJednotka", "mernaJednotka");
	public static final TextAttribute NAZOV = new TextAttribute("FakturaPolozka.nazov", "nazov");
	public static final RelationAttribute FAKTURA = new RelationAttribute("FakturaPolozka.faktura", "faktura");
	
	static {
		MNOZSTVO.setCaption(ResourceConstants.MNOZSTVO);
		MNOZSTVO.setRequired(true);
		MNOZSTVO.setZeroAccepted(false);
		MNOZSTVO.setLength(10);
		MNOZSTVO.setScale(3);
		MNOZSTVO.setMask("#,###,##0.000");
		
		JEDNOTKOVA_CENA.setCaption(ResourceConstants.JEDNOTKOVA_CENA);
		JEDNOTKOVA_CENA.setColumnName(ResourceConstants.JEDNOTKOVA__CENA);
		JEDNOTKOVA_CENA.setRequired(true);
		JEDNOTKOVA_CENA.setZeroAccepted(false);
		JEDNOTKOVA_CENA.setLength(12);
		JEDNOTKOVA_CENA.setScale(2);
		JEDNOTKOVA_CENA.setMask("#,###,###,##0.00");
		
		CELKOVA_CENA.setCaption(ResourceConstants.CELKOVA_CENA);
		CELKOVA_CENA.setRequired(true);
		CELKOVA_CENA.setZeroAccepted(false);
		CELKOVA_CENA.setLength(12);
		CELKOVA_CENA.setScale(2);
		CELKOVA_CENA.setMask("#,###,###,##0.00");
		
		MERNA_JEDNOTKA.setCaption(ResourceConstants.MARNA_JEDNOTKA);
		MERNA_JEDNOTKA.setColumnName(ResourceConstants.MARNA__JEDNOTKA);
		MERNA_JEDNOTKA.setRequired(true);
		MERNA_JEDNOTKA.setLimit(5);
		MERNA_JEDNOTKA.setTypeLetters(TextAttribute.CAPITAL_LETTERS);
		
		NAZOV.setCaption(ResourceConstants.NAZOV_TOVARU);
		NAZOV.setRequired(true);
		NAZOV.setLimit(100);

		FAKTURA.setRequired(true);
	}
	
	private BigDecimal mnozstvo = Helper.DEFAULT_VALUE;
	private BigDecimal jednotkovaCena = Helper.DEFAULT_VALUE;
	private BigDecimal celkovaCena = Helper.DEFAULT_VALUE;
	private String mernaJednotka;
	private String nazov;
	private ValueHolderInterface faktura = new ValueHolder();
	
	public BigDecimal getMnozstvo() {
		return mnozstvo;
	}
	
	public void setMnozstvo(BigDecimal mnozstvo) {
		if (mnozstvo == null)
			mnozstvo = Helper.DEFAULT_VALUE;
		this.mnozstvo = mnozstvo;
	}
	
	public BigDecimal getJednotkovaCena() {
		return jednotkovaCena;
	}
	
	public void setJednotkovaCena(BigDecimal jednotkovaCena) {
		if (jednotkovaCena == null)
			jednotkovaCena = Helper.DEFAULT_VALUE;
		this.jednotkovaCena = jednotkovaCena;
	}
	
	public BigDecimal getCelkovaCena() {
		return celkovaCena;
	}
	
	public String getMernaJednotka() {
		return mernaJednotka;
	}
	
	public void setMernaJednotka(String mernaJednotka) {
		if (mernaJednotka != null)
			mernaJednotka = mernaJednotka.trim();
		this.mernaJednotka = mernaJednotka;
	}
	
	public String getNazov() {
		return nazov;
	}
	
	public void setNazov(String nazov) {
		if (nazov != null)
			nazov = nazov.trim();
		this.nazov = nazov;
	}
	
	public Faktura getFaktura() {
		return (Faktura) faktura.getValue();
	}
	
	public void setFaktura(Faktura faktura) {
		this.faktura.setValue(faktura);
	}
	
    public void validate(EclipseLinkSession session) throws Exception {
    	MNOZSTVO.checkValue(getMnozstvo(), session);
        NAZOV.checkValue(getNazov(), session);
        JEDNOTKOVA_CENA.checkValue(getJednotkovaCena(), session);
        MERNA_JEDNOTKA.checkValue(getMernaJednotka(), session);
        FAKTURA.checkValue(getFaktura(), session);
		celkovaCena = this.getMnozstvo().multiply(this.getJednotkovaCena());
		celkovaCena = celkovaCena.setScale(CELKOVA_CENA.getScale(), BigDecimal.ROUND_HALF_UP);
    }
}
