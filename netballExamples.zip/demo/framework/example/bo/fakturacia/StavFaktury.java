package demo.framework.example.bo.fakturacia;

import netframework.bo.Constant;
import demo.framework.translate.ResourceConstants;


public class StavFaktury implements Constant<String> {
    
    private String kod;
    private String nazov;
   
    public static final StavFaktury ROZPRACOVANA = new StavFaktury("R", ResourceConstants.ROZPRACOVANA);
    public static final StavFaktury SPRACOVANA = new StavFaktury("S", ResourceConstants.SPRACOVANA);
    public static final StavFaktury STORNOVANA = new StavFaktury("T", ResourceConstants.STORNOVANA);
    public static final StavFaktury[] ZOZNAM = new  StavFaktury[] {ROZPRACOVANA, SPRACOVANA, STORNOVANA};     
   
    private StavFaktury(String kod, String nazov){
        this.kod = kod;
        this.nazov = nazov;
    }
    
    public static StavFaktury convert(String kod)  {
        if (kod == null)
           return null;        
        for(int i = 0; i < ZOZNAM.length; i++  ) {
            if(ZOZNAM[i].getKey().equals(kod)){
                return ZOZNAM[i];
            } 
        }
        return null;
    }
    
    @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((kod == null) ? 0 : kod.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StavFaktury other = (StavFaktury) obj;
		if (kod == null) {
			if (other.kod != null)
				return false;
		} else if (!kod.equals(other.kod))
			return false;
		return true;
	}
    
    @Override
    public String toString(){
        return kod +"-"+ nazov;
    }

	@Override
	public String getKey() {
		return kod;
	}

	@Override
	public String getText() {
		return nazov;
	}

	@Override
	public String getTextForReport() {
		return nazov;
	}

	@Override
	public String getTextForTable() {
		return nazov;
	}
}
