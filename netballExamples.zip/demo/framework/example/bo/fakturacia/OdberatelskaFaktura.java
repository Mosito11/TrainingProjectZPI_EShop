package demo.framework.example.bo.fakturacia;

import java.util.Vector;

import netframework.bo.attributes.ContainerAttribute;
import netframework.eclipselink.EclipseLinkSession;

import org.eclipse.persistence.zpi.indirection.ValueHolder;
import org.eclipse.persistence.zpi.indirection.ValueHolderInterface;

import demo.framework.example.bo.ciselniky.Zakazka;
import demo.framework.example.bo.common.Helper;
import demo.framework.translate.ResourceConstants;


public class OdberatelskaFaktura extends Faktura {

	public static final ContainerAttribute ZAKAZKY = new ContainerAttribute("OdberatelskaFaktura.zakazky", "zakazky");
	
	private ValueHolderInterface zakazky = new ValueHolder();
	
	public OdberatelskaFaktura() {
		this.setTyp(TypFaktury.ODBERATELSKA);
	}
	
	public Vector<Zakazka> getZakazky() {
		if (zakazky.getValue() == null)
			zakazky.setValue(new Vector<Zakazka>());
		return (Vector<Zakazka>) zakazky.getValue();
	}

	@Override
	public void validateAttributes(EclipseLinkSession session) throws Exception {
		super.validateAttributes(session);
		Vector<Zakazka> zakazky = this.getZakazky();
		if (zakazky.size() > 0) {
			// kontrola ci zakazka sa nenachdza viackrat
			for (int i = 0; i < zakazky.size(); i++) {
			   Zakazka zakazka = zakazky.get(i);
			   for (int k = i + 1; k < zakazky.size(); k++) {
				   Zakazka zakazka1 = zakazky.get(k);
				   if (zakazka.equals(zakazka1)) {
					   throw new IllegalArgumentException(Helper.createMessage(session, ResourceConstants.ZAKAZKA__0__VO_FAKTURE_SA_VYSKYTUJE_VIACKRAT_, zakazka.getCislo()));
				   }
			   }
			}
		}
	}
}
