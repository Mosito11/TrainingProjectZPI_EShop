package demo.framework.example.bo.fakturacia;

public class DodavatelskaFaktura extends Faktura {
	
	public DodavatelskaFaktura() {
		this.setTyp(TypFaktury.DOVATELSKA);
	}
}
