package demo.framework.example.bo.fakturacia;

import java.math.BigDecimal;

import netframework.bo.attributes.NumberAttribute;
import netframework.bo.attributes.RelationAttribute;
import netframework.eclipselink.EclipseLinkSession;

import org.eclipse.persistence.zpi.indirection.ValueHolder;
import org.eclipse.persistence.zpi.indirection.ValueHolderInterface;

import demo.framework.example.bo.ciselniky.Mena;
import demo.framework.example.bo.common.Helper;
import demo.framework.translate.ResourceConstants;


public class SumaVMene {

	public static final NumberAttribute SUMA = new NumberAttribute("SumaVMene.suma", "suma", NumberAttribute.BIG_DECIMAL);
	public static final RelationAttribute MENA = new RelationAttribute("SumaVMene.mena", "mena");
	
	static {
		SUMA.setCaption(ResourceConstants.SUMA);
		SUMA.setRequired(true);
		SUMA.setLength(12);
		SUMA.setScale(2);
		SUMA.setZeroAccepted(false);
		SUMA.setMask("#,###,###,##0.00");
		
		MENA.setCaption(Mena.KOD.getLongCaption());
		MENA.setColumnName(Mena.KOD.getLongCaption());
		MENA.setRequired(true);
	}
	
	private BigDecimal suma = Helper.DEFAULT_VALUE;
	private ValueHolderInterface mena = new ValueHolder();
	
	public BigDecimal getSuma() {
		return suma;
	}
	
	public void setSuma(BigDecimal suma) {
		if (suma == null)
			suma = Helper.DEFAULT_VALUE;
		this.suma = suma;
	}
	
	public Mena getMena() {
		return (Mena) mena.getValue();
	}
	
	public void setMena(Mena mena) {
		this.mena.setValue(mena);
	}

	public void validate(EclipseLinkSession session) throws Exception {
		MENA.checkValue(this.getMena(), session);
		SUMA.checkValue(this.getSuma(), session);
	}
	
	@Override
	public String toString() {
		return "SumaVMene [mena=" + getMena() + ", suma=" + suma + "]";
	}
}
