package demo.framework.example.bo.fakturacia;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.Vector;

import netball.server.utilities.AccountDate;
import netframework.bo.PersistentObject;
import netframework.bo.ValueException;
import netframework.bo.attributes.AggregateAttribute;
import netframework.bo.attributes.Attribute;
import netframework.bo.attributes.ConstantAttribute;
import netframework.bo.attributes.ContainerAttribute;
import netframework.bo.attributes.DateAttribute;
import netframework.bo.attributes.FormattedTextAttribute;
import netframework.bo.attributes.NumberAttribute;
import netframework.bo.attributes.RelationAttribute;
import netframework.eclipselink.EclipseLinkSession;

import org.eclipse.persistence.zpi.expressions.Expression;
import org.eclipse.persistence.zpi.expressions.ExpressionBuilder;
import org.eclipse.persistence.zpi.indirection.ValueHolder;
import org.eclipse.persistence.zpi.indirection.ValueHolderInterface;
import org.eclipse.persistence.zpi.queries.ReportQuery;

import demo.framework.example.bo.ciselniky.Mena;
import demo.framework.example.bo.ciselniky.Zakaznik;
import demo.framework.example.bo.common.Helper;
import demo.framework.translate.ResourceConstants;

public abstract class Faktura extends PersistentObject {

	public static final NumberAttribute ID = new NumberAttribute("Faktura.id", "id");
	public static final DateAttribute DATUM_VYSTAVENIA = new DateAttribute("Faktura.datumVystavenia", "datumVystavenia");
	public static final AggregateAttribute CELKOVA_SUMA = new AggregateAttribute("Faktura.celkovaSuma", "celkovaSuma");
	public static final RelationAttribute ZAKAZNIK = new RelationAttribute("Faktura.zakaznik", "zakaznik");
	public static final DateAttribute OBDOBIE = new DateAttribute("Faktura.obdobie", "obdobie", DateAttribute.ACCOUNT_DATE);
	public static final ConstantAttribute STAV = new ConstantAttribute("Faktura.stav", "stav", StavFaktury.ZOZNAM);
	public static final ContainerAttribute POLOZKY = new ContainerAttribute("Faktura.polozky", "polozky");
	public static final NumberAttribute VERSION = new NumberAttribute("Faktura.version", "version");
	public static final ConstantAttribute TYP = new ConstantAttribute("Faktura.typ", "typ", TypFaktury.ZOZNAM);
	public static final FormattedTextAttribute CISLO = new FormattedTextAttribute("Faktura.cislo", "cislo");
	
	static {
		DATUM_VYSTAVENIA.setCaption(ResourceConstants.DATUM_VYSTAVENIE);
		DATUM_VYSTAVENIA.setColumnName(ResourceConstants.DATUM__VYSTAVENIE);
		DATUM_VYSTAVENIA.setRequired(true);
		
		CELKOVA_SUMA.setCaption(ResourceConstants.CELKOVA_SUMA);
        Attribute attr = SumaVMene.SUMA.cloneWithNullCaptions();
        attr.setCaption(ResourceConstants.CELKOVA_SUMA);
        attr.setRequired(true);
        CELKOVA_SUMA.put(attr);
        attr = (Attribute) SumaVMene.MENA.cloneWithNullCaptions();
        attr.setCaption(ResourceConstants.CELKOVA_SUMA_MENA);
        attr.setRequired(true);
        CELKOVA_SUMA.put(attr);
		
		ZAKAZNIK.setCaption(ResourceConstants.ZAKAZNIK);
		ZAKAZNIK.setRequired(true);
		
		OBDOBIE.setCaption(ResourceConstants.UCTOVNE_OBDOBIE);
		OBDOBIE.setColumnName(ResourceConstants.UCTOVNE__OBDOBIE);
		OBDOBIE.setRequired(true);
		
		STAV.setCaption(ResourceConstants.STAV);
		STAV.setRequired(true);
		
		POLOZKY.setCaption(ResourceConstants.POLOZKY);
		POLOZKY.setRequired(true);
		
		VERSION.setCaption(ResourceConstants.VERZIA);
		
		TYP.setCaption(ResourceConstants.TYP);
		TYP.setRequired(true);
		
		CISLO.setCaption(ResourceConstants.CISLO);
		CISLO.setLongCaption(ResourceConstants.FAKTURA);
		CISLO.setMask("####/######");
		CISLO.setRequired(true);
	}
	
	private String cislo;
	private Date datumVystavenia;
	private SumaVMene celkovaSuma;
	private ValueHolderInterface zakaznik = new ValueHolder();
	private AccountDate obdobie;
	private StavFaktury stav = StavFaktury.ROZPRACOVANA;
	private ValueHolderInterface polozky = new ValueHolder();
	private int version;  // sluzi pre oprtimisticke zamikanie
	private TypFaktury typ;
	
	public TypFaktury getTyp() {
		return typ;
	}

	protected void setTyp(TypFaktury typ) {
		this.typ = typ;
	}
	
	public int getVersion() {
		return version;
	}

	public String getCislo() {
		return cislo;
	}
	
	public void setCislo(String cislo) {
		this.cislo = cislo;
	}
	
	public Date getDatumVystavenia() {
		return datumVystavenia;
	}
	
	public void setDatumVystavenia(Date datumVystavenia) {
		this.datumVystavenia = datumVystavenia;
	}
	
	private SumaVMene getCelkovaSumaVMene() {
		if (celkovaSuma == null)
			celkovaSuma = new SumaVMene();
		return celkovaSuma;
	}
	
	public void setMena(Mena mena) {
		getCelkovaSumaVMene().setMena(mena);
	}
	
	public Mena getMena() {
		return getCelkovaSumaVMene().getMena();
	}
	
	public BigDecimal getCelkovaSuma() {
		return getCelkovaSumaVMene().getSuma();
	}

	private void setCelkovaSuma(BigDecimal suma) {
		getCelkovaSumaVMene().setSuma(suma);
	}
	
	public Zakaznik getZakaznik() {
		return (Zakaznik) zakaznik.getValue();
	}
	
	public void setZakaznik(Zakaznik zakaznik) {
		this.zakaznik.setValue(zakaznik);
	}
	
	public AccountDate getObdobie() {
		return obdobie;
	}
	
	public StavFaktury getStav() {
		return stav;
	}
	
	public void setStav(StavFaktury stav) {
		this.stav = stav;
	}
	
	// transformacne metody pte toplink zaciatok ---------------------------------------
	
    public void setStavTL(String stav) {
        try {
            this.stav = StavFaktury.convert(stav);
        }catch(Exception e) {
            e.printStackTrace();
        }
    }

    public String getStavTL() {
        if (stav == null)
            return null;
        return stav.getKey();
    }

    public String getTypTL() {
        if (typ == null)
            return null;
        return typ.getKey();
    }

    public void setTypTL(String typ) {
        try {
            this.typ = TypFaktury.convert(typ);
        }catch(Exception e) {
            e.printStackTrace();
        }
    }
    
	public String getObdobieTL() {
		return obdobie != null ? obdobie.toString() : null;
	}
	
	public void setObdobieTL(String obdobie) {
		try {
		   this.obdobie = AccountDate.parseText(obdobie);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
    
	// transformacne metody pte toplink koniec ---------------------------------------
	
	public Vector<FakturaPolozka> getPolozky() {
		if (polozky.getValue() == null)
			polozky.setValue(new Vector<FakturaPolozka>());
		return (Vector<FakturaPolozka>) polozky.getValue();
	}
	
    protected void validateAttributes(EclipseLinkSession session) throws Exception {
    	ZAKAZNIK.checkValue(this.getZakaznik(), session);
    	STAV.checkValue(this.getStav(), session);
    	POLOZKY.checkValue(this.getPolozky(), session);
    	CISLO.checkValue(this.getCislo(), session);
    	DATUM_VYSTAVENIA.checkValue(this.getDatumVystavenia(), session);
    	CELKOVA_SUMA.getAttribute(SumaVMene.MENA.getId()).checkValue(getCelkovaSumaVMene().getMena(), session); 
    	if (this.getDatumVystavenia() != null) {
    		obdobie = new AccountDate(this.getDatumVystavenia());
    	}
    }
	
	public void validate(EclipseLinkSession session) throws Exception {
		validateAttributes(session);
		validateDuplicity(session);
		Vector<FakturaPolozka> polozky = this.getPolozky();
		BigDecimal celkovaSuma = Helper.DEFAULT_VALUE;
		for (int i = 0; i < polozky.size(); i++) {
			FakturaPolozka polozka = polozky.get(i);
			polozka.validate(session);
			celkovaSuma = celkovaSuma.add(polozka.getCelkovaCena());
		} 
		celkovaSuma = celkovaSuma.setScale(SumaVMene.SUMA.getScale(), BigDecimal.ROUND_UP);
		this.setCelkovaSuma(celkovaSuma);
	}
    
	public void delete(EclipseLinkSession session) throws Exception {
		if (this.getStav().equals(StavFaktury.SPRACOVANA)) {
			throw new IllegalArgumentException(Helper.createMessage(session, ResourceConstants.SPRACOVANU_FAKTURU_NIE_JE_MOZNE_VYMAZAT_));
		}
	}
	
	public void setSpracovana(EclipseLinkSession session) throws Exception {
		if (!this.getStav().equals(StavFaktury.ROZPRACOVANA)) {
			throw new IllegalArgumentException(Helper.createMessage(session, ResourceConstants.LEN_ROZPRACOVANA_FAKTURA_MOZE_BYT_SPRACOVANA_));
		}
		this.setStav(StavFaktury.SPRACOVANA);
	}

	public void setStornovana(EclipseLinkSession session) throws Exception {
		if (!this.getStav().equals(StavFaktury.SPRACOVANA)) {
			throw new IllegalArgumentException(Helper.createMessage(session, ResourceConstants.LEN_SPRACOVANA_FAKTURA_MOZE_BYT_STORNOVANA_));
		}
		this.setStav(StavFaktury.STORNOVANA);
	}
	
    private void validateDuplicity(EclipseLinkSession session) throws Exception {
    	if (this.getCislo() == null)
    		return;
        ExpressionBuilder builder = new ExpressionBuilder();
        Expression exp = builder.get(CISLO.getName()).equal(getCislo());
        if (isPersisted()) 
          exp = exp.and(builder.get(ID.getName()).notEqual(getId()));       
        ReportQuery query = new ReportQuery();                
        query.setReferenceClass(getClass());
        query.addAttribute(ID.getName());
        query.setSelectionCriteria(exp);
        Vector vector = (Vector) session.getSession().executeQuery(query);
        if (vector.size() > 0) {
            throw new ValueException(CISLO.getId(), Helper.createMessage(session, ResourceConstants.FAKTURA_S_CISLOM___0___UZ_EXISTUJE_, getCislo()));              
        }   
    }             
}
