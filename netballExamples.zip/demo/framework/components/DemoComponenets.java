package demo.framework.components;

import java.awt.Dimension;
import java.util.ArrayList;

import netball.server.component.XForm;
import netball.server.component.XMenu;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.FrameworkUtilities;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;
public class DemoComponenets extends BasicMediator {
	
	
	
	@Override
    public AccessAction[] getAccessActions() {
    	return FrameworkUtilities.createAccessActions(createMenu()).getAccessActions();
    }	     
	
	@Override
    public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
   	   XForm form = new XForm();
   	   form.setMenu(createMenu());
   	   form.setTitle("Demo");   	      	   
   	   form.setSize(new Dimension(600, 400));
   	   form.setType(XForm.FRAME);
   	   serverPack.addFormPack(new FormPack(getId(), form));   	      	      	
    }		
	
	@Override
    public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
    	if (event.getUserObject() != null && event.getUserObject() instanceof String) {
    	   runNext(event.getUserObject().toString(), null, pack);
    	}
    }		
	
	private java.util.List<XMenu> createMenu() {
	   java.util.List<XMenu> mainMenu = new ArrayList<XMenu>();
	   XMenu menu = new XMenu("components", "Components");	   
	   menu.add(createMenuItem("DemoButton", "Button", DemoButton.class));
       menu.add(createMenuItem("DemoToolBarButton", "Tool bar button", DemoToolBarButton.class));
       menu.add(createMenuItem("DemoCheckBox", "Check box", DemoCheckBox.class));
	   menu.add(createMenuItem("DemoLabel", "Label", DemoLabel.class));
	   menu.add(createMenuItem("DemoRadioButtonGroup", "Radio button group", DemoRadioButtonGroup.class));
       menu.add(createMenuItem("DemoReadOnlyField", "Read only field", DemoReadOnlyField.class));
	   mainMenu.add(menu);
	   
	   menu = new XMenu("text", "Text");
	   menu.add(createMenuItem("DemoTextArea", "Text area", DemoTextArea.class));
	   menu.add(createMenuItem("DemoTextField", "Text field", DemoTextField.class));
       menu.add(createMenuItem("DemoFormattedTextField", "Formatted text field", DemoFormattedTextField.class));
	   menu.add(createMenuItem("DemoPasswordField", "Password field", DemoPasswordField.class));
	   mainMenu.add(menu);

	   menu = new XMenu("number", "Number");	   
	   menu.add(createMenuItem("DemoNumberField", "Number field", DemoNumberField.class));
	   menu.add(createMenuItem("DemoNumberSpinner", "Number spinner", DemoNumberSpinner.class));
       mainMenu.add(menu);

	   menu = new XMenu("date", "Date");	   
       menu.add(createMenuItem("DemoDateField", "Date field", DemoDateField.class));
	   menu.add(createMenuItem("DemoDateSpinner", "Date spinner", DemoDateSpinner.class));
	   menu.add(createMenuItem("DemoDateFieldWithCalendar", "Date field with calendar", DemoDateFieldWithCalendar.class));
	   mainMenu.add(menu);

	   menu = new XMenu("list", "List");	   
	   menu.add(createMenuItem("DemoList", "List", DemoList.class));
	   menu.add(createMenuItem("DemoCheckList", "Check list", DemoCheckList.class));
	   menu.add(createMenuItem("DemoDualList", "Dual list", DemoDualList.class));
	   menu.add(createMenuItem("DemoColumnOrdering", "Column ordering list", DemoColumnOrdering.class));
	   mainMenu.add(menu);

	   menu = new XMenu("compoundField", "Complex fields");	   
	   menu.add(createMenuItem("DemoComboBox", "Combo box", DemoComboBox.class));
	   menu.add(createMenuItem("DemoComboBox1", "Combo box", DemoComboBox1.class));
	   menu.add(createMenuItem("DemoMultiColumnComboBox", "Multi column combo box", DemoMultiColumnComboBox.class));
	   menu.add(createMenuItem("DemoMultiColumnComboBoxAlaGoogle", "Multi column combo box", DemoMultiColumnComboBoxAlaGoogle.class));
	   menu.add(createMenuItem("DemoExpressionField", "Expression field", DemoExpressionField.class));
	   menu.add(createMenuItem("DemoCompoundField", "Compound field", DemoCompoundField.class));
       menu.add(createMenuItem("DemoFileChooser", "File chooser", DemoFileChooser.class));
	   mainMenu.add(menu);

	   menu = new XMenu("tree", "Tree");	   
       menu.add(createMenuItem("DemoTree", "Tree", DemoTree.class));
	   menu.add(createMenuItem("DemoDynamicTree", "Dynamic tree", DemoDynamicTree.class));
	   menu.add(createMenuItem("DemoLazyTree", "Lazy tree", DemoLazyTree.class));
	   menu.add(createMenuItem("DemoAllowableAccessActionTree", "Allowable access action tree", DemoAllowableAccessActionTree.class));
	   menu.add(createMenuItem("DemoTreeTableWithPopupMenu", "Tree table with popup menu", DemoTreeTableWithPopupMenu.class));
	   menu.add(createMenuItem("DemoTreeWithReordingTreeNodeController", "Tree with reording node controller", DemoTreeWithReordingNodeController.class));
	   menu.add(createMenuItem("DemoTreeTableWithReordingNodeController", "Tree table with reording node controller", DemoTreeTableWithReordingNodeController.class));
	   mainMenu.add(menu);

	   menu = new XMenu("table", "Table");	   
	   menu.add(createMenuItem("DemoClientTable", "Client table", DemoClientTable.class));
	   menu.add(createMenuItem("DemoClientServerTable", "Client server table", DemoClientServerTable.class));
	   menu.add(createMenuItem("DemoEditableClientTable", "Editable client table", DemoEditableClientTable.class));
       menu.add(createMenuItem("DemoEditableClientServerTable", "Editable client server table", DemoEditableClientServerTable.class));
       menu.add(createMenuItem("DemoTreeTable", "Tree table", DemoTreeTable.class));
       menu.add(createMenuItem("DemoLazyTreeTable", "Lazy Tree table", DemoLazyTreeTable.class));
       menu.add(createMenuItem("DemoClientTableWithHeaderFilter", "Client table with header filter", DemoClientTableWithHeaderFilter.class));
       menu.add(createMenuItem("DemoClientServerTableWithHeaderFilter", "Client server table with header filter", DemoClientServerTableWithHeaderFilter.class));
       menu.add(createMenuItem("DemoTableWithPopupMenu", "Demo table with popup menu", DemoTableWithPopupMenu.class));
       menu.add(createMenuItem("DemoTreeTableWithPopupMenu", "Demo tree table with popup menu", DemoTreeTableWithPopupMenu.class));
	   mainMenu.add(menu);

	   menu = new XMenu("panel", "Panel");	   
       menu.add(createMenuItem("DemoBorderPanel", "Border panel", DemoBorderPanel.class));
	   menu.add(createMenuItem("DemoBoxPanel", "Box panel", DemoBoxPanel.class));
	   menu.add(createMenuItem("DemoDualComponentPanel", "Dual component panel", DemoDualComponentPanel.class));
	   menu.add(createMenuItem("DemoScrollPane", "Scroll pane", DemoScrollPane.class));
	   menu.add(createMenuItem("DemoSplitPane", "Split pane", DemoSplitPane.class));
	   menu.add(createMenuItem("DemoTabbedPane", "Tabbed pane", DemoTabbedPane.class));
	   menu.add(createMenuItem("DemoDesktopPanel", "Desktop panel", DemoDesktopPanel.class));
	   menu.add(createMenuItem("DemoDynamicPane", "Dynamic pane", DemoDynamicPane.class));
	   menu.add(createMenuItem("DemoDynamicPanel", "Dynamic panel", DemoDynamicPanel.class));
	   menu.add(createMenuItem("DemoDynamicPanelAndDesktopPanel", "Dynamic panel and Desktop panel", DemoDynamicPanelAndDesktopPanel.class));
	   menu.add(createMenuItem("DemoBorder", "Borders", DemoBorder.class));
	   menu.add(createMenuItem("DemoRollablePanel", "Rollable panel", DemoRollablePanel.class));
	   menu.add(createMenuItem("DemoShowFormsAtTheSameTime", "Show forms at the same time", DemoShowFormsAtTheSameTime.class));
	   mainMenu.add(menu);
			   
	   menu = new XMenu("menu", "Menu");
	   menu.add(createMenuItem("DemoMenuBar", "Menu bar", DemoMenuBar.class));
       menu.add(createMenuItem("DemoPopupMenu", "Popup menu", DemoPopupMenu.class));
       mainMenu.add(menu);
	   
   	   return mainMenu;   	      	   
	}
	
	private XMenu createMenuItem(String id, String text, Class<? extends BasicMediator> classMediator) {
	   XMenu menuItem = new XMenu(createId(id), text);
       ServerActionEvent event = new ServerActionEvent();
       if (classMediator != null)
   	      event.setUserObject(classMediator.getName());
   	   menuItem.addActionEvent(event);
   	   return menuItem;
	}
	
	public static void main(String...strings) {
		MediatorRunner.run(DemoComponenets.class);
	}
}
