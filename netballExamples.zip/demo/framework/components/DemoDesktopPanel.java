package demo.framework.components;

import java.awt.Dimension;
import java.awt.Insets;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

import javax.swing.SwingConstants;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XDateField;
import netball.server.component.XDesktopPanel;
import netball.server.component.XForm;
import netball.server.component.XMenu;
import netball.server.component.XTextField;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientWindowEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerWindowEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.utilities.TypeValues;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoDesktopPanel extends BasicMediator { 
	 
	    private Object hiddenFormId;
	
		@Override
		public AccessAction[] getAccessActions() {
			return null;
		}

		@Override
		public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
		   	  //InfraDebug.getInstance().addDebugLevel(InfraDebug.CIENT_ENGINE);
		   	  //InfraDebug.getInstance().addDebugLevel(InfraDebug.SERVER_ENGINE);
		   	   XBoxPanel buttonPanel = new XBoxPanel(SwingConstants.HORIZONTAL);
		   	   buttonPanel.setHorizontalAlignment(SwingConstants.RIGHT);
		   	   buttonPanel.setInsets(new Insets(10, 10, 10, 10));
		   	   buttonPanel.setGapForAll(5);
		   	   buttonPanel.add(new XButton("noveOkno", "Nove okno ", new ServerActionEvent()));
		   	   buttonPanel.add(new XButton("hiddenOkno", "Hidden okno ", new ServerActionEvent()));
		   	   
		   	   XBorderPanel panel = new XBorderPanel(10, 10);
		   	   panel.setSouth(buttonPanel);
		   	   XDesktopPanel desktopPanel = new XDesktopPanel("desktopPanel");
		   	   desktopPanel.setSize(new Dimension(1000, 200));
		   	   desktopPanel.setMode(XDesktopPanel.TABBED_MODE);
		   	   //desktopPanel.setAllowedChangeMode(false);
		   	   panel.setCenter(desktopPanel);
		   	   
		   	   XForm form = new XForm();
		   	   form.setPanel(panel); 
		   	   form.setTitle("Desktop panel");
		   	   form.setType(XForm.FRAME);
		   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
		   	   this.runNext(InternalFrame.class, null, serverPack, this.getId(), "desktopPanel");
		}

	    @Override
		public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
	   	   if (event.getSourceId().equals("noveOkno")) {
	   		   this.runNext(InternalFrame.class, null, pack, this.getId(), "desktopPanel");
	   	   }else if (event.getSourceId().equals("hiddenOkno")) {
	   		   if (hiddenFormId == null) {
	   			   hiddenFormId = this.runNext(InternalHiddenFrame.class, null, pack, this.getId(), "desktopPanel", BasicMediator.HIDE_ON_CLOSE);
	   		   }else{
	   		       pack.addShownForm(hiddenFormId);
	   		   }
	   	   }
	   }
	   
	   public static class InternalFrame extends BasicMediator { 
			 
			@Override
			public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
		   	   XBoxPanel panel = new XBoxPanel(SwingConstants.VERTICAL);
		   	   panel.setGapForAll(5);
		   	   panel.setInsets(new Insets(10, 10, 10, 10));
		   	   XTextField field = new XTextField("textField" + getId());
		   	   field.setDescription("desription");
		   	   //field.setValueRequired(true);
		   	   //ServerFocusEvent event = new ServerFocusEvent(ServerFocusEvent.FOCUS_LAST_EVENT);
		       //event.addReturnValue(field.getId());
		       //field.addFocusEvent(event);
		   	   panel.add(field);
		   	   panel.add(new XDateField("dateField1", "dd.MM.yyyy", TypeValues.SQL_DATE));		   	   
		   	   XForm form = new XForm();
		   	   form.setPanel(panel);
		   	   form.setTitle("Internal form " + this.getId());
		   	   //form.setResizable(false);
		   	   form.setLocation(new Point(10,10));
		   	   List<XMenu> mainMenu = new ArrayList<XMenu>();
		   	   XMenu menu = new XMenu("1111");
		   	   menu.add(new XMenu("2222"));
		   	   menu.add(new XMenu("3333"));
		   	   menu.add(new XMenu("4444"));
		   	   mainMenu.add(menu);
		   	   //form.setMenu(mainMenu);
		   	   
		   	   form.addWindowEvent(new ServerWindowEvent(ServerWindowEvent.WINDOW_OPENED_EVENT));
		   	   form.addWindowEvent(new ServerWindowEvent(ServerWindowEvent.WINDOW_ACTIVATED_EVENT));
		   	   form.addWindowEvent(new ServerWindowEvent(ServerWindowEvent.WINDOW_DEACTIVATED_EVENT));
		   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	       }

		   @Override
		   public AccessAction[] getAccessActions() {
				return null;
		   }

		  @Override
		  public void windowEventExecuted(ClientWindowEvent event, ServerPack pack) {
			  System.out.println(event); 
			  super.windowEventExecuted(event, pack);
		  }
	   }
			
	   public static class InternalHiddenFrame extends BasicMediator { 
					 
			@Override
			public void init(MediatorParameters parameters,	ServerPack serverPack) throws Exception {
			   	   XBoxPanel panel = new XBoxPanel(SwingConstants.VERTICAL);
			   	   panel.setGapForAll(5);
			   	   panel.setInsets(new Insets(10, 10, 10, 10));
			   	   XTextField field = new XTextField("textField");
			   	   field.setText("Hidden form");
			   	   panel.add(field);
			   	   panel.add(new XTextField("textField1"));		   	   
			   	   XForm form = new XForm();
			   	   form.setPanel(panel); 
			   	   form.setLocation(new Point(30,30));
			   	   form.setTitle("Internal hidden form " + this.getId());
			   	   form.addWindowEvent(new ServerWindowEvent(ServerWindowEvent.WINDOW_OPENED_EVENT));
			   	   form.addWindowEvent(new ServerWindowEvent(ServerWindowEvent.WINDOW_ACTIVATED_EVENT));
			   	   form.addWindowEvent(new ServerWindowEvent(ServerWindowEvent.WINDOW_DEACTIVATED_EVENT));
			   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
		    }

			@Override
			public AccessAction[] getAccessActions() {
				return null;
			}
			
			@Override
			public void windowEventExecuted(ClientWindowEvent event, ServerPack pack) {
			    System.out.println(event); 
				super.windowEventExecuted(event, pack);
			}
		}
	   
	    public static void main(String...strings) {
	    	MediatorRunner.run(DemoDesktopPanel.class, null, null, "flat" ); 
	    } 
}
