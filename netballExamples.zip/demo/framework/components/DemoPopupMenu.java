package demo.framework.components;

import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;

import netball.server.component.XBorderPanel;
import netball.server.component.XButton;
import netball.server.component.XForm;
import netball.server.component.XMenu;
import netball.server.component.XPopupMenu;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ServerEvent;
import netball.server.event.ServerMouseEvent;
import netball.server.pack.EnabledPack;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoPopupMenu extends BasicMediator { 
   
	
    @Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
   	   if (event.getSourceId().equals("Potvrd") && event.isPopupTrigger()) {
   		  ClientMouseEvent mouseEvent  = (ClientMouseEvent) event;
		  pack.setPopupMenu(createPopupMenu(mouseEvent));
   	   }
   }

   @Override
   public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
   	   XBorderPanel panel = new XBorderPanel();
   	   panel.setInsets(new Insets(100, 100, 100, 100));
   	   XButton button = new XButton("Potvrd", "Potvrd");
   	   ServerMouseEvent event = new ServerMouseEvent(true);  // posle event len v pripade, ze su splnene podmienky pre vysvietenie popup (Windows je to prave tlacitko mysi v Mac OS je to Control + tlacitko mysi)
   	   button.addMouseEvent(event);
   	   panel.setCenter(button);
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Popup menu");   	   
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }
   
   public XPopupMenu createPopupMenu(ClientMouseEvent mouseEvent) {
   	   List<XMenu> menu = new ArrayList<XMenu>();
   	   menu.add(new XMenu("1111"));
   	   
   	   XMenu menuItem = new XMenu("2222");
   	   menuItem.setSeparator(true);
   	   menuItem.setDescription("Description");
   	   menu.add(menuItem);
   	   menu.add(new XMenu("3333"));
   	   
   	   XPopupMenu popupMenu = new XPopupMenu("Potvrd");
   	   popupMenu.setMenu(menu);
   	   popupMenu.setX(mouseEvent.getX());
   	   popupMenu.setY(mouseEvent.getY());
   	   
   	   EnabledPack enabledPack = new EnabledPack();
   	   enabledPack.put("1111", false);
   	   popupMenu.setEnabledPack(enabledPack);
   	   return popupMenu;
   }

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	public static void main(String...strings) {
		MediatorRunner.run(DemoPopupMenu.class, null, null, "flat");
	} 
}

