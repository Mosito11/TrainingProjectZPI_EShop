package demo.framework.components;

import java.awt.Dimension;
import java.awt.Insets;

import javax.swing.SwingConstants;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XDynamicPane;
import netball.server.component.XForm;
import netball.server.component.XLabel;
import netball.server.component.XList;
import netball.server.component.XTextArea;
import netball.server.component.XTextField;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientWindowEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerWindowEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.utilities.InfraDebug;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoDynamicPane extends BasicMediator { 
	
	    private Object hiddenFormId;  
	
		@Override
		public AccessAction[] getAccessActions() {
			return null;
		}
		
		@Override
		public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
	   	   InfraDebug.getInstance().addDebugLevel(InfraDebug.CIENT_ENGINE);
	   	   InfraDebug.getInstance().addDebugLevel(InfraDebug.SERVER_ENGINE);
	   	   // center by namal byt vypnneny komponentom, pretoze tam pridu vnutorne okna 
	   	   XBoxPanel buttonPanel = new XBoxPanel(SwingConstants.VERTICAL);
	   	   buttonPanel.setSameSizeForAllComponents(true);
	   	   buttonPanel.setGapForAll(5);
	   	   buttonPanel.add(new XButton("internalForm1", "Internal form 1", new ServerActionEvent()));
	   	   buttonPanel.add(new XButton("internalForm2", "Internal form 2", new ServerActionEvent()));
	   	   buttonPanel.add(new XButton("internalForm3", "Internal form 3", new ServerActionEvent()));
	   	   buttonPanel.add(new XButton("internalForm4", "Hidden form", new ServerActionEvent()));
	   	   buttonPanel.add(new XButton("reset", "Reset", new ServerActionEvent()));
	   	   ServerActionEvent event = new ServerActionEvent();
	   	   event.setReturnAllValues(true);
	   	   buttonPanel.add(new XButton("values", "Values", event));
	   	   
	   	   XDynamicPane dynamicPane = new XDynamicPane("dynamicPane");
	   	   dynamicPane.setSize(new Dimension(700, 500));
	   	   
	   	   XBorderPanel mainPanel = new XBorderPanel(10, 10);
	   	   mainPanel.setInsets(new Insets(10, 10, 10, 10));
	   	   mainPanel.setCenter(dynamicPane);
	   	   mainPanel.setWest(buttonPanel);
	   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(mainPanel); 
	   	   form.setTitle("Dymanic frame");
	   	   form.setType(XForm.FRAME);
	   	   
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	   }

	    @Override
		public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
	   	   if (event.getSourceId().equals("internalForm1")) {
	   		   this.runNext(InternalForm1.class, null, pack, this.getId(), "dynamicPane");
	   	   }else if (event.getSourceId().equals("internalForm2")) {
		   	   this.runNext(InternalForm2.class, null, pack, this.getId(), "dynamicPane");
	   	   }else if (event.getSourceId().equals("internalForm3")) {
		   	   this.runNext(InternalForm3.class, null, pack, this.getId(), "dynamicPane");
	   	   }else if (event.getSourceId().equals("internalForm4")) {
   			   if (hiddenFormId == null || this.getMediator(hiddenFormId) == null) {
			   	   hiddenFormId =  this.runNext(InternalForm4.class, null, pack, this.getId(), "dynamicPane", BasicMediator.HIDE_ON_CLOSE);
   			   }else{
   				   pack.addShownForm(hiddenFormId);
	   		   }
	   	   }else if (event.getSourceId().equals("reset")) {
	   		   this.closeAllChild(pack);
	   	   }else if (event.getSourceId().equals("values")) {
	   		   System.out.println("values=" + event.getValuePack());
	   	   }
	   }

	   
	   public static class InternalForm1 extends BasicMediator { 
			 
			@Override
			public void init(MediatorParameters parameters,	ServerPack serverPack) throws Exception {
		   	   XBoxPanel panel = new XBoxPanel(SwingConstants.VERTICAL);
		   	   panel.setInsets(new Insets(10, 10, 10, 10));
		   	   XTextField field = new XTextField("textField");
		   	   field.setDescription("description");
		   	   field.setText("Internal form 1");
		   	   panel.add(field);
		   	   panel.add(new XTextField("textField1"));		   	   
		   	   XForm form = new XForm();
		   	   form.setPanel(panel); 
		   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	       }

			@Override
			public AccessAction[] getAccessActions() {
				return null;
			}
	   }
	   
	   public static class InternalForm2 extends BasicMediator { 
			 
			@Override
			public void init(MediatorParameters parameters,	ServerPack serverPack) throws Exception {
		   	   XBoxPanel panel = new XBoxPanel(SwingConstants.VERTICAL);
		   	   panel.setInsets(new Insets(10, 10, 10, 10));
		   	   XTextArea field = new XTextArea("textField");
		   	   field.setVisibleRowCount(5);
		   	   field.setVisibleCharCount(100);
		   	   field.setDescription("description");
		   	   field.setText("Internal form 2");
		   	   panel.add(field);
		   	   XForm form = new XForm();
		   	   form.setPanel(panel); 
		   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	       }
			
			@Override
			public AccessAction[] getAccessActions() {
				return null;
			}
	   }
	   
	   public static class InternalForm3 extends BasicMediator { 
			 
			@Override
			public void init(MediatorParameters parameters,	ServerPack serverPack) throws Exception {
		   	   XBoxPanel panel = new XBoxPanel(SwingConstants.VERTICAL);
		   	   panel.setInsets(new Insets(10, 10, 10, 10));
		   	   XList list = new XList("list");
		   	   list.addItem("Internal form3.1");
		   	   list.addItem("Internal form3.2");
		   	   list.addItem("Internal form3.3");
		   	   list.addItem("Internal form3.4");
		   	   list.addItem("Internal form3.5");
		   	   list.addItem("Internal form3.6");
		   	   list.setVisibleRowCount(5);
		   	   list.setWidth(200);
		   	   panel.add(list);
		   	   XForm form = new XForm();
		   	   form.setPanel(panel); 
		   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	       }
			
			@Override
			public AccessAction[] getAccessActions() {
				return null;
			}
	   }
	   
	   public static class InternalForm4 extends BasicMediator { 
			 
			@Override
			public void init(MediatorParameters parameters,	ServerPack serverPack) throws Exception {
		   	   XBoxPanel panel = new XBoxPanel(SwingConstants.VERTICAL);
		   	   panel.setInsets(new Insets(10, 10, 10, 10));
		   	   XLabel label = new XLabel("label");
		   	   label.setText("Hidden form");
		   	   panel.add(label);
		   	   panel.add(new XTextField("textField"));
		   	   XForm form = new XForm();
		   	   form.setPanel(panel); 
		   	   form.addWindowEvent(new ServerWindowEvent(ServerWindowEvent.WINDOW_OPENED_EVENT));
		   	   form.addWindowEvent(new ServerWindowEvent(ServerWindowEvent.WINDOW_ACTIVATED_EVENT));
		   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	       }
			
			@Override
			public void windowEventExecuted(ClientWindowEvent event, ServerPack pack) {
				System.out.println(event);
			}

			@Override
			public AccessAction[] getAccessActions() {
				return null;
			}
	   }
	   
	   public static void main(String...strings) {
		   MediatorRunner.run(DemoDynamicPane.class, null, null, "flat");
	   }
}	
