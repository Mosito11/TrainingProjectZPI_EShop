package demo.framework.components;

import java.awt.Insets;
import java.math.BigDecimal;

import javax.swing.SwingConstants;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XForm;
import netball.server.component.XPanel;
import netball.server.component.XRangeSlider;
import netball.server.component.XReadOnlyField;
import netball.server.component.border.XTitleBorder;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientStateChangedEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerStateChangedEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netball.server.utilities.Range;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoRangeSlider extends BasicMediator { 

	
	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
		if (event.getSourceId().equals("OK")) {
			System.out.println(event.getValuePack());
		}else if (event.getSourceId().equals("update")) {
			ValuePack valuePack = new ValuePack();
			valuePack.put("intslider", new Range<Integer>(null, 545));
			valuePack.put("decslider", new Range<BigDecimal>(new BigDecimal("0.6"), new BigDecimal("2.3")));
			pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
		}
	}

	@Override
	public void stateChangedEventExecuted(ClientStateChangedEvent event, ServerPack pack) {
		if (event.getSourceId().equals("decslider")) {
			Range range = (Range) event.getValuePack().getValue("decslider");
			ValuePack valuePack = new ValuePack();
			valuePack.put("lowerInrerval", range.getLowerValue());
			valuePack.put("upperInrerval", range.getUpperValue());
			pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
		}
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
   	   XBoxPanel boxPanel = new XBoxPanel(SwingConstants.VERTICAL);
   	   boxPanel.add(createIntegerSlider());
   	   boxPanel.addGap(10);
   	   boxPanel.add(createDecimalSlider());
   	   
   	   XBoxPanel buttonPanel = new XBoxPanel(SwingConstants.HORIZONTAL);
   	   buttonPanel.setHorizontalAlignment(SwingConstants.RIGHT);
   	   buttonPanel.setGapForAll(5);
   	   
   	   XButton button = new XButton("OK", "OK");
   	   ServerActionEvent actionEvent = new ServerActionEvent();
   	   actionEvent.setReturnAllValues(true);
   	   button.addActionEvent(actionEvent);
   	   buttonPanel.add(button);

   	   button = new XButton("update", "Update");
   	   button.addActionEvent(new ServerActionEvent());
   	   buttonPanel.add(button);
   	   
   	   XBorderPanel panel = new XBorderPanel(10, 10);
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.setCenter(boxPanel);   	   
   	   panel.setSouth(buttonPanel);
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Range Slider");
   	   
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
    }
	
	private XRangeSlider createIntegerSlider() {
		XRangeSlider slider = new XRangeSlider("intslider");
	   	slider.setMinimum(500);
	   	slider.setMaximum(550);
	   	slider.setValue(new Range<Integer>(520, 540));
	    slider.setPaintTicks(true);
	    slider.setPaintLabels(true);
	    slider.setMinorTickSpacing(1);
	    slider.setMajorTickSpacing(5);
	    slider.setBlockIncrement(10);
	    slider.addLabelTableItem(500, "500");
	    slider.addLabelTableItem(510, "510");
	    slider.addLabelTableItem(520, "520");
	    slider.addLabelTableItem(530, "530");
	    slider.addLabelTableItem(540, "540");
	    slider.addLabelTableItem(550, "550");
	   	slider.setEnabled(true);
	   	slider.setUseValueToolTip(true);
	   	return slider;
	}		

	private XPanel createDecimalSlider() {
		XRangeSlider slider = new XRangeSlider("decslider");
	    slider.setPaintTicks(true);
	    slider.setPaintLabels(true);
	    slider.setMinorTickSpacing(1);
	    slider.setMajorTickSpacing(10);
	    slider.setBlockIncrement(20);
	    BigDecimal bd = new BigDecimal("0");
	    BigDecimal d = new BigDecimal("0.1");
	    for (int i = 0; i <= 30; i++) {
	    	slider.addItem(bd);
	    	if (i % 10 == 0)
	    		slider.addLabelTableItem(i, bd.toString());
	    	bd = bd.add(d);
	    }
	   	slider.setValue(new Range<BigDecimal>(new BigDecimal("0.3"), new BigDecimal("1.5")));
	   	
   	    ServerStateChangedEvent changedEvent = new ServerStateChangedEvent();
   	    changedEvent.addReturnValue("decslider");
   	    slider.addStateChangedEvent(changedEvent);
	   	
	   	XBorderPanel labelPanel = new XBorderPanel();  
	   	
	   	XReadOnlyField field = new XReadOnlyField("lowerInrerval", null);
	   	field.setVisibleCharCount(5);
	   	field.setHorizontalAlignment(SwingConstants.RIGHT);
	   	field.setValue(slider.getValue().getLowerValue());
	   	labelPanel.setWest(field);

	   	field = new XReadOnlyField("upperInrerval", null);
	   	field.setVisibleCharCount(5);
	   	field.setHorizontalAlignment(SwingConstants.RIGHT);
	   	field.setValue(slider.getValue().getUpperValue());
	   	labelPanel.setEast(field);
	   	
	   	XBoxPanel panel = new XBoxPanel(SwingConstants.VERTICAL);
	   	panel.setInsets(new Insets(10, 10, 10, 10));
	   	panel.setBorder(new XTitleBorder(true, true, true, true));
	   	panel.setSameWidthForAllComponents(true);
	   	panel.add(slider);
	   	panel.addGap(5);
	   	panel.add(labelPanel);
	   	
	   	return panel;
	}		
	
	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	public static void main(String...strings) {
		//UIManager.put(MetalLookAndFeelNew.DEFAULT_FONT, new Font("Dialog", Font.PLAIN, 25));
		//UIManager.put("Slider.font", new Font("Dialog", Font.PLAIN, 25));
		MediatorRunner.run(DemoRangeSlider.class, null, null, "flat");
	} 
}
