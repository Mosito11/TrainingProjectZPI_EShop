package demo.framework.components;

import java.awt.Insets;

import netball.client.ui.jtc.awt.AWTUtilities;
import netball.server.component.XClientTable;
import netball.server.component.XComboBox;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XExpressionField;
import netball.server.component.XForm;
import netball.server.component.XList;
import netball.server.component.XNumberSpinner;
import netball.server.component.XTableColumn;
import netball.server.component.XTextField;
import netball.server.component.XTree;
import netball.server.component.renderer.LogicalRenderer;
import netball.server.component.table.TableContainer;
import netball.server.component.tree.TreeContainer;
import netball.server.component.tree.TreeNode;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MDUtilities;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoDisableComponent extends BasicMediator { 

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
   	   XDualComponentPanel panel = new XDualComponentPanel();
   	   panel.setInsets(new Insets(10,10,10,10));
   	   XTextField field = new XTextField("textField");
   	   field.setCaption("Text Field");
   	   field.setText("text");
   	   field.setEnabled(false);
   	   panel.add(field);

   	   XComboBox comboBox = new XComboBox("comboBox");
   	   comboBox.setCaption("Combo box");
   	   comboBox.setValue("comboBox");
   	   comboBox.setEditable(true);
   	   comboBox.setEnabled(false);
   	   panel.add(comboBox);

   	   XNumberSpinner spinner = new XNumberSpinner("spinner", XNumberSpinner.BIG_INTEGER, 6, 0);
   	   spinner.setCaption("Spiner");
   	   spinner.setNumber(6);
   	   spinner.setEnabled(false);
   	   panel.add(spinner);
   	   
   	   XExpressionField expressionField = new XExpressionField("expressionField", "Expression field");
   	   expressionField.setEnabled(false);
   	   panel.add(expressionField);
   	   
   	   XList list = new XList("list");
   	   list.setCaption("List");
   	   list.addItem("list 1");
	   list.addItem("list 2");
	   list.addItem("list 3");
	   list.addItem("list 4");
	   list.addItem("list 5");
	   list.addItem("list 6");
	   list.setWidth(100);
	   list.setVisibleRowCount(5);
	   list.setEnabled(false);
	   panel.add(list);

	   XClientTable table = new XClientTable("table");
	   table.setCaption("Table");
	   table.addColumn(new XTableColumn("text", "Text", 70));
	   XTableColumn column = new XTableColumn("boolean", "Boolean", 80);
	   column.setRenderer(new LogicalRenderer());
	   table.addColumn(column);
	   TableContainer container = new TableContainer(new String[] {"text", "boolean"});
	   container.addNewRow(new Object[] {"text1", true});
	   container.addNewRow(new Object[] {"text2", true});
	   container.addNewRow(new Object[] {"text3", false});
	   container.addNewRow(new Object[] {"text4", true});
	   container.addNewRow(new Object[] {"text5", false});
	   container.addNewRow(new Object[] {"text6", true});
	   table.setDataSource(container);
	   table.setEnabled(false);
	   table.setWidth(200);
	   table.setHeight(200);
	   panel.add(table);
	   
   	   XTree tree = new XTree("tree");
   	   tree.setCaption("Tree");
       TreeNode rootNode = new TreeNode("JavaReference");
       TreeNode forums = new TreeNode("Forum");
       forums.add(new TreeNode("Thread 1"));
       forums.add(new TreeNode("Thread 2"));
       TreeNode node = new TreeNode("Thread 3");
       node.setDescription("description");
       forums.add(node);
       TreeNode articles = new TreeNode("Articles");
       articles.setIcon(MDUtilities.loadIcon(AWTUtilities.ARRANGE_WINDOWS_CASCADE_ICON, getSessionObject()));
       articles.add(new TreeNode("Article 1"));
       articles.add(new TreeNode("Article 2"));
       TreeNode examples = new TreeNode("Examples");
       node  = new TreeNode("Examples 1 enabled");
       node.setEnabled(false);
       node.setToolTipText("enabled node");
       examples.add(node);
       examples.add(new TreeNode("Examples 2"));
       examples.add(new TreeNode("Examples 3"));
       rootNode.add(forums);
       rootNode.add(articles);
       rootNode.add(examples);
       tree.setDataSource(new TreeContainer(rootNode));
       tree.setWidth(300);
       tree.setHeight(200);
       tree.setEnabled(false);
       panel.add(tree);
	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("DemoDisableComponent");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }
	
	public static void main(String...strings) {
		MediatorRunner.run(DemoDisableComponent.class, null, null, "flat");
	}

}
