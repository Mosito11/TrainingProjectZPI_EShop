package demo.framework.components;

import java.awt.Font;
import java.awt.Insets;
import java.awt.print.PageFormat;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;
import java.util.Locale;

import netball.client.ui.jtc.awt.AWTUtilities;
import netball.client.ui.print.ReportDataSource;
import netball.server.component.XBorderPanel;
import netball.server.component.XForm;
import netball.server.component.XReportPreview;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.print.OptimalReportPrmts;
import netball.server.print.PRFont;
import netball.server.print.PRPage;
import netball.server.print.PRPageFormat;
import netball.server.print.PRReport;
import netball.server.print.PRTable;
import netball.server.print.PrintTableRatio;
import netball.server.print.ReportPrmts;
import netball.server.print.table.PRTableHeader;
import netball.server.print.table.PRTableHeaderColumn;
import netball.server.print.table.PRValueTableRow;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoReportPreview extends BasicMediator {

	private Source dataSource;

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
		dataSource = new Source();
		XReportPreview preview = new XReportPreview("viewer");
		preview.setDataSource(new XReportPreview.ReportSource(dataSource, null), this);
		preview.setWidth(700);
		preview.setHeight(500);

		preview.setShowPrinterJobAfterOpening(true); //Nastavi, ci sa ma ihned vysvietit okno s tlaciarnami
		//preview.setPrintCopiesAfterOpening(3); //Nastavi, kolko kopii sa ma automaticky vytlacit hned po otvoreni okna na predvolenej tlaciarni. 

		//preview.setCanOptimalSettingBeSet(false);
		//preview.setCanPageFormatBeChanged(false);
		//preview.setCanReportPrmtsBeChanged(false);
		//preview.setCanReportBeSaved(false);
		//preview.setCanOutputScreenBeSet(false);
		XBorderPanel panel = new XBorderPanel();
		panel.setCenter(preview);

		XForm form = new XForm();
		form.setPanel(panel);
		form.setTitle("Report preview");

		serverPack.addFormPack(new FormPack(getId(), form));
		/*   	   
		   	   PRReport[] report = new PRReport[3];
		   	   report[0] = new PRReport();
		   	   report[1] = new PRReport();
		   	   report[2] = new PRReport();
		   	   preview.setPages(report);
		*/
	}

	static class Source extends ReportDataSource {

		private final Column[] cols;
		private final Object[][] data;
		private int pageCount;
		private FileInputStream stream;

		public Source() {
			cols = new Column[5];
			cols[0] = new Column("Text", 70);
			cols[1] = new Column("Number", 70);
			cols[2] = new Column("Date", 250);
			cols[3] = new Column("Logic", 70);
			cols[4] = new Column("Text", 70);

			Calendar calendar = Calendar.getInstance();
			data = new Object[1000][5];
			for (int i = 0; i < 1000; i++) {
				for (int k = 0; k < 5; k++) {
					calendar.add(Calendar.DATE, 1);
					data[i][0] = "text " + i;
					data[i][1] = new Integer(i);
					data[i][2] = calendar.getTime();
					data[i][3] = i % 2 == 0 ? Boolean.FALSE : Boolean.TRUE;
					data[i][4] = "text " + i;
				}
			}
		}

		@Override
		public PRPage getPage(PRPageFormat page, int pageIndex, ReportPrmts prmts) throws Exception {
			PRReport report = new PRReport();
			PrintTableRatio ratio = this.getRatio(prmts.getFontSize());
			PageFormat pageFormat = page.createPageFormat();
			// vyska riadku       
			int rowHeight = 18 - ratio.getRowCoefficient();
			// header
			//    PRFont font = new PRFont("Dialog", Font.PLAIN, ratio.getFontSize()); 
			PRFont font = new PRFont("monospaced", Font.PLAIN, ratio.getFontSize());
			PRTableHeader tableHeader = new PRTableHeader();
			for (int i = 0; i < cols.length; i++) {
				int colWidth = (int) (ratio.getColCoefficient() * cols[i].width);
				PRTableHeaderColumn col = new PRTableHeaderColumn(cols[i].caption, colWidth);
				tableHeader.add(col);
			}
			tableHeader.setFont(font);
			tableHeader.setRowHeight(rowHeight);
			tableHeader.setBackground(prmts.getHeaderCellColor());
			// table
			PRTable table = new PRTable(tableHeader);
			table.setPaintCellBorders(prmts.getPrintCellLines());
			table.setFont(font);
			table.setRowHeight(rowHeight);
			table.setColumnMargin(2);
			// vypocita potrebny pocet riadkov pre tlac        
			int height = report.camputeBodyHeight(pageFormat);
			height -= tableHeader.getSize().height;
			int pageRowCount = height / rowHeight;
			pageCount = AWTUtilities.divide(data.length, pageRowCount);
			int fromRow = pageIndex * pageRowCount;
			if (fromRow >= data.length)
				return null;
			int batchSize = pageRowCount;
			if (pageRowCount * (pageIndex + 1) > data.length)
				batchSize = data.length - (pageRowCount * pageIndex);
			// vytvoria sa riadky   
			int toRow = fromRow + batchSize;
			for (int i = fromRow; i < toRow; i++) {
				PRValueTableRow row = new PRValueTableRow();
				for (int k = 0; k < cols.length; k++) {
					row.add(data[i][k].toString());
				}
				table.addRow(row);
			}
			report.setBody(table);
			return report;
		}

		private PrintTableRatio getRatio(int fontSize) {
			for (int i = 0; i < PrintTableRatio.LIST.length; i++) {
				if (PrintTableRatio.LIST[i].getFontSize() == fontSize)
					return PrintTableRatio.LIST[i];
			}
			return null;
		}

		@Override
		public int getPageCount() throws Exception {
			return pageCount;
		}

		@Override
		public int getWidth(ReportPrmts prmts) throws Exception {
			return 1000;
		}

		@Override
		public OptimalReportPrmts getOptimalReportPrmts(Insets margins) throws Exception {
			OptimalReportPrmts prmts = new OptimalReportPrmts(8, new PRPageFormat());
			return prmts;
		}

		public void close() {
			if (stream != null) {
				try {
					stream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		@Override
		public void openFile(int typeFile, PRPageFormat pageFormat, ReportPrmts prmts) throws Exception {
			File file = new File("data.txt");
			PrintWriter writer = new PrintWriter(new FileOutputStream(file));
			for (int i = 0; i < data.length; i++) {
				StringBuffer buffer = new StringBuffer();
				for (int k = 0; k < cols.length; k++) {
					buffer.append(data[i][k].toString());
					if (k < cols.length - 1)
						buffer.append('|');
				}
				writer.println(buffer.toString());
			}
			writer.close();
			stream = new FileInputStream(file);
		}

		@Override
		public byte[] nextFileBatch() throws Exception {
			if (stream == null)
				return null;
			if (stream.available() > 0) {
				byte[] batch = new byte[1024];
				stream.read(batch);
				return batch;
			}
			stream.close();
			return null;
		}

		@Override
		public int[] getSaveFormats() {
			return null;
		}
	}

	private static class Column {
		int width;
		String caption;

		public Column(String caption, int width) {
			this.width = width;
			this.caption = caption;
		}
	}

	public static void main(String... strings) {
		Locale.setDefault(Locale.GERMANY);
		MediatorRunner.run(DemoReportPreview.class, null, null, "flat");
	}
}
