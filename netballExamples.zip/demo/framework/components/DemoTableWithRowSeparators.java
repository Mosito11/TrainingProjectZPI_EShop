package demo.framework.components;

import java.awt.Insets;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XClientTable;
import netball.server.component.XForm;
import netball.server.component.XTableColumn;
import netball.server.component.setting.ClientTableSettings;
import netball.server.component.table.TableContainer;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netball.server.rowexpression.RowExpression;
import netball.server.rowexpression.RowExpressionBuilder;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoTableWithRowSeparators extends BasicMediator { 
	
	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}
   
	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
   	   XClientTable table = new XClientTable("table");
   	   table.addColumn(new XTableColumn("col0", "col0", 70));
   	   table.addColumn(new XTableColumn("col1", "col1", 70));
   	   table.addColumn(new XTableColumn("col2", "col2", 70));
   	   table.addColumn(new XTableColumn("col3", "col3", 70));
   	   table.addColumn(new XTableColumn("col4", "col4", 70));
   	   table.addColumn(new XTableColumn("col5", "col5", 70));
   	   
   	   TableContainer container = new TableContainer(new String[] {"col0","col1","col2","col3","col4","col5"});
   	   container.addNewRow(new Object[] {"1","a","b","c","d","e"});
   	   container.addNewRow(new Object[] {"2","f","g","h","i","j"});
   	   container.addNewRow(new Object[] {"3","k","l","m","n","o"});
   	   container.addNewRow(new Object[] {"4","p","q","r","s","t"});
   	   container.addNewRow(new Object[] {"1","a","b","c","d","e"});
   	   container.addNewRow(new Object[] {"2","f","g","h","i","j"});
   	   container.addNewRow(new Object[] {"3","k","l","m","n","o"});
   	   container.addNewRow(new Object[] {"4","p","q","r","s","t"});
   	   table.setDataSource(container);
   	   
   	   RowExpressionBuilder builder = new RowExpressionBuilder();
   	   RowExpression exp = builder.get("col0").equal("1"); 
   	   table.setRowSeparatorExpression(exp);
	    
   	   table.setWidth(600);
   	   table.setHeight(400);
   	   table.setVisibilityOfColumnsAllowed(true);
       table.setFreezeColumnsAllowed(false);
       
       XBoxPanel buttonPanel = new XBoxPanel();
       XButton button = new XButton("update", "Update");
       button.addActionEvent(new ServerActionEvent());
       buttonPanel.add(button);
       
   	   XBorderPanel panel = new XBorderPanel(10, 10);
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.setCenter(table);
   	   panel.setSouth(buttonPanel);
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("DemoTableWithRowSeparators");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }
	
    @Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
    	if (event.getSourceId().equals("update")) {
    		ClientTableSettings settings = new ClientTableSettings();
    	   	RowExpressionBuilder builder = new RowExpressionBuilder();
    	   	RowExpression exp1 = builder.get("col0").equal("2");
    	   	RowExpression exp2 = builder.get("col0").equal("4");
    	   	settings.setRowSeparatorExpression(exp1.or(exp2));
   	        ValuePack valuePack = new ValuePack();
   	        valuePack.put("table", settings);
    		pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
    	}
	}

	public static void main(String...strings) {
    	MediatorRunner.run(DemoTableWithRowSeparators.class, null, null, "flat");    	
    } 
}
