package demo.framework.components;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;
import java.sql.Timestamp;

import javax.swing.SwingConstants;
import javax.swing.UIManager;

import netball.client.ui.jtc.awt.lookandfeel.MetalLookAndFeelNew;
import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XForm;
import netball.server.component.XReadOnlyField;
import netball.server.component.XTextArea;
import netball.server.component.renderer.DateRenderer;
import netball.server.component.renderer.DurationTimeRenderer;
import netball.server.component.renderer.FormattedTextRenderer;
import netball.server.component.renderer.LogicalRenderer;
import netball.server.component.renderer.NumberRenderer;
import netball.server.component.setting.ReadOnlyFieldSettings;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoReadOnlyField extends BasicMediator { 

   @Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	   if (event.getSourceId().equals("Potvrd")) {
   	   	  System.out.println("value = " + event.getValuePack().getValue("field"));
   	   }else if (event.getSourceId().equals("Update")) {
   		   ReadOnlyFieldSettings settings = new ReadOnlyFieldSettings();
   		   settings.setBackground(Color.RED);
   		   settings.setForeground(Color.ORANGE);
   		   ValuePack vp = new ValuePack();
   		   vp.put("formattedField", settings);
   		   pack.addUpdatedPack(new UpdatedPack(getId(), vp));
   	   }
   }

   public Object executeMethod(Object itemId, Object parm) {
   	   return null;
   }

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
	   XDualComponentPanel componentPanel = new XDualComponentPanel();
		
   	   XReadOnlyField numberField = new XReadOnlyField("numberField", "numberField");
   	   //numberField.setVisibleCharCount(50);
   	   numberField.setBackground(Color.yellow);
   	   numberField.setForeground(Color.blue);
	   //numberField.setFont(new XFont("Courier", Font.BOLD, 12));
	   numberField.setDescription("ja som read only field");
	   numberField.setValue(new Integer(123456789));
	   numberField.setHasToRetunValue(true);
	   numberField.setRenderer(new NumberRenderer("###,###,###"));   	   
  	   //field.setWidth(600);
	   numberField.setHorizontalAlignment(javax.swing.SwingUtilities.RIGHT);
   	   componentPanel.add("Number", numberField);
   	   
   	   XReadOnlyField formattedField = new XReadOnlyField("formattedField", "formattedField");
   	   formattedField.setValue("WWww00wwWW");
   	   formattedField.setRenderer(new FormattedTextRenderer("??-!!-##-~~-^^"));
   	   componentPanel.add("Formatted text", formattedField);

   	   XReadOnlyField dateField = new XReadOnlyField("dateField", "dateField");
       dateField.setValue(new Timestamp(System.currentTimeMillis()));
	   dateField.setRenderer(new DateRenderer("dd.MM.yyyy  hh:mm:ss"));
   	   componentPanel.add("Timestamp", dateField);

   	   XReadOnlyField textField = new XReadOnlyField("textField", "textField");
   	   textField.setShowPopupWindow(true);
   	   textField.setValue("aaaaaaaa\nbbbbbbbbbbbbbbb\ncccccccccccccccc\nddddddddddddddddd");
   	   textField.setPopupWindowTextArea(new XTextArea());
   	   componentPanel.add("Text field", textField);
   	   
   	   XReadOnlyField checkField = new XReadOnlyField("checkField", "checkField");
   	   LogicalRenderer renderer = new LogicalRenderer(true); 
   	   checkField.setRenderer(renderer);
   	   checkField.setValue(true);
   	   componentPanel.add("Check box", checkField);
   	   
   	   XReadOnlyField durationField = new XReadOnlyField("durationField", "durationField");
   	   durationField.setValue(10000000);
   	   durationField.setRenderer(new DurationTimeRenderer("HH:mm:ss", DurationTimeRenderer.MILLIS));
   	   componentPanel.add("Duration time", durationField);
   	   
   	   XBorderPanel panel = new XBorderPanel(10, 10);
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.setCenter(componentPanel);

   	   XBoxPanel buttonPanel = new XBoxPanel(SwingConstants.HORIZONTAL);

   	   ServerActionEvent event = new ServerActionEvent();
   	   event.setReturnAllValues(true);
   	   buttonPanel.add(new XButton("Potvrd", "Potvrd", event));
   	   buttonPanel.addGap(5);
   	   buttonPanel.add(new XButton("Update", "Update", new ServerActionEvent()));
   	   
   	   panel.setSouth(buttonPanel);
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Read only field");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }
	
   public static void main(String...strings) {
		UIManager.put(MetalLookAndFeelNew.DEFAULT_FONT, new Font("Dialog", Font.PLAIN, 25));
		UIManager.put("Slider.font", new Font("Dialog", Font.PLAIN, 25));
	   MediatorRunner.run(DemoReadOnlyField.class, null, null, "flat");
   } 	
}
