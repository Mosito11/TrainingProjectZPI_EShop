package demo.framework.components;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;

import netball.server.component.XBoxPanel;
import netball.server.component.XDateField;
import netball.server.component.XDateSpinner;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XFont;
import netball.server.component.XForm;
import netball.server.component.XFormattedTextField;
import netball.server.component.XNumberField;
import netball.server.component.XNumberSpinner;
import netball.server.component.XReadOnlyField;
import netball.server.component.XTextArea;
import netball.server.component.XTextField;
import netball.server.component.border.XTitleBorder;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoDualComponentPanel extends BasicMediator { 

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
   	   XDualComponentPanel panel = new XDualComponentPanel();
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.setCaptionLacation(XDualComponentPanel.CAPTION_ON_LEFT);
   	   //panel.setCaptionLacation(XDualComponentPanel.CAPTION_ON_TOP);
   	   //panel.setBackground(Color.red);
   	   //panel.setCaptionFont(new XFont("Courier", Font.BOLD, 12));
   	   panel.setBorder(new XTitleBorder());
   	   panel.setFixRowGaps(false);
   	   //panel.setFixComponentWidth(false);
   	   //panel.setFixColumnGaps(false);
   	   panel.setColumnCount(2);
   	   panel.setCaptionAlignment(javax.swing.SwingConstants.LEFT);
   	   panel.add(new XNumberField("numberField", "Number field", XNumberField.INTEGER, 10, 0));
   	   panel.add(new XNumberSpinner("spinnerNumberField", "Spinner number field", XNumberSpinner.INTEGER, 10, 2));
   	   panel.addGap(30);   // medzera
       panel.add(new XDateField("dateField", "Date field", "dd.MM.yyyy", XDateField.SQL_DATE));   	   
       panel.add(new XDateSpinner("spinnerDateField", "Spinner date field", "dd.MM.yyyy", XDateSpinner.DATE));   	   
       panel.add(new XTextField("textField", "Text field", 10));
       
       XTextArea ta = new XTextArea("textArea");
       ta.setCaption("Text Area");
       ta.setVisibleRowCount(5);
       ta.setWidth(300);
       panel.add(ta);

       XBoxPanel box = new XBoxPanel(javax.swing.SwingConstants.HORIZONTAL);
       //box.setBackground(Color.red);
       box.add(new XFormattedTextField("formTextField1", null, "####.####"));
       box.addGap(10);
       box.add(new XFormattedTextField("formTextField2", null, "####.####"));
       panel.add("Form text field", box);   	   

   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("DualComponentPanel");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }
	
	public static void main(String...strings) {
		MediatorRunner.run(DemoDualComponentPanel.class, null, null, "flat");
	}

}
