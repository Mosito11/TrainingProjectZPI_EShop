package demo.framework.components;

import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;

import netball.server.component.XBorderPanel;
import netball.server.component.XForm;
import netball.server.component.XTableColumn;
import netball.server.component.XTreeTable;
import netball.server.component.treetable.LazyLoadingTreeTableController;
import netball.server.component.treetable.LazyLoadingTreeTableNode;
import netball.server.component.treetable.TreeTableClientNode;
import netball.server.component.treetable.TreeTableContainer;
import netball.server.component.treetable.TreeTableNode;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoLazyTreeTable extends BasicMediator { 

	int lastId = 100; 
	
	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)throws Exception {
	   	   TreeTableNode root = new TreeTableNode("root", "Root");
	   	   LazyLoadingTreeTableNode node = new LazyLoadingTreeTableNode("0", "Lazy Item 0");
	   	   node.addValue("col0");
	   	   node.addValue("col1");
	   	   root.add(node);
	   	   
	   	   node = new LazyLoadingTreeTableNode("1", "Lazy Item 1");
	   	   node.addValue("col0");
	   	   node.addValue("col1");
	   	   root.add(node);
	   	   
	   	   node = new LazyLoadingTreeTableNode("2", "Lazy Item 2");
	   	   node.addValue("col0");
	   	   node.addValue("col1");
	   	   root.add(node);

	   	   XTreeTable tree = new XTreeTable("tree");
	   	   tree.setTreeColumnWidth(200);
	   	   tree.setTreeHeaderText("tree");
	   	   tree.setRootVisible(false);
	   	   tree.addColumn(new XTableColumn("col0", "Column0", 80));
	   	   tree.addColumn(new XTableColumn("col1", "Column1", 80));

	   	   String[] cols = new String[] {"col0", "col1"};
	   	   TreeTableContainer treeContainer = new TreeTableContainer(root, cols);
	   	   
	   	   tree.setDataSource(treeContainer);
	   	   tree.setWidth(600);
	   	   tree.setHeight(200);
	   	   tree.setLazyLoadingTreeTableController(new Controller(), this);
	   	   
	   	   XBorderPanel panel = new XBorderPanel();
	   	   panel.setInsets(new Insets(10, 10, 10, 10));
	   	   panel.setCenter(tree);   	   
	   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel); 
	   	   form.setTitle("TreeTable");
	   	   
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	   }   
	   
	   private class Controller extends LazyLoadingTreeTableController {

			@Override
			public List<TreeTableNode> readNodes(TreeTableClientNode node) throws Exception {
				List<TreeTableNode> nodes = new ArrayList<TreeTableNode>();
				for (int i = 0; i < 4; i++) {
					lastId++;
					TreeTableNode addNode = new TreeTableNode("" + lastId , "Child Item " + i);
					addNode.addValue("addCol0");
					addNode.addValue("addCol1");
				    nodes.add(addNode);
				}
				LazyLoadingTreeTableNode addNode = new LazyLoadingTreeTableNode("4", "Lazy child Item 4");
				addNode.addValue("addCol2");
				addNode.addValue("addCol3");
				nodes.add(addNode);
				return nodes;
			}
	   }

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}
	
	public static void main(String...strings) {
		MediatorRunner.run(DemoLazyTreeTable.class, null, null, "flat");
	}
}
