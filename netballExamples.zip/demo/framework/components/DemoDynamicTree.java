package demo.framework.components;


import java.awt.Color;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;

import javax.swing.SwingConstants;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XForm;
import netball.server.component.XTree;
import netball.server.component.setting.TreeSettings;
import netball.server.component.tree.TreeClientNode;
import netball.server.component.tree.TreeContainer;
import netball.server.component.tree.TreeNode;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerMouseEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;


public class DemoDynamicTree extends BasicMediator { 

   private int lastId;	
	
   @Override
   public AccessAction[] getAccessActions() {
   	   return null;
   }

   @Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
	    if (event.getSourceId().equals("add")) {
	   	   	  Object value = event.getValuePack().getValue("tree");
	   	   	  if (value != null) {
	   	   	      TreeClientNode path = ((TreeClientNode[]) value)[0];
	   		      TreeSettings settings = new TreeSettings();
	   		      List<TreeNode> nodes = new ArrayList<TreeNode>();
	   		      nodes.add(new TreeNode(getNextId(), "addItem1"));
	   		      nodes.add(new TreeNode(getNextId(), "addItem2"));
	   		      settings.setAddedNode(new TreeSettings.AddedNode(path.getPath(), nodes));
	   		      settings.setExpandPath(path.getPath());
	   		      settings.setScrollPathToVisible(path.getPath());
	   		      
	   		      ValuePack valuePack = new ValuePack();
	   		      valuePack.put("tree", settings);
	   		      pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
	   	   	  }
	   	   }else if (event.getSourceId().equals("delete")) {
	   	   	  Object value = event.getValuePack().getValue("tree");
	   	   	  if (value != null) {
	   	   	      TreeClientNode path = ((TreeClientNode[]) value)[0];
	   		      TreeSettings settings = new TreeSettings();
	   		      settings.setDeletedNode(path.getPath());
	   		      
	   		      ValuePack valuePack = new ValuePack();
	   		      valuePack.put("tree", settings);
	   		      pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
	   	   	  }
	   	   }else if (event.getSourceId().equals("deleteChildren")) {
	    	   	  Object value = event.getValuePack().getValue("tree");
	    	   	  if (value != null) {
	    	   	      TreeClientNode path = ((TreeClientNode[]) value)[0];
	    		      TreeSettings settings = new TreeSettings();
	    		      settings.setDeleteAllChildren(path.getPath());
	    		      
	    		      ValuePack valuePack = new ValuePack();
	    		      valuePack.put("tree", settings);
	    		      pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
	    	   	  }   	      	   	  
	   	   }else if (event.getSourceId().equals("clear")) {
		      TreeSettings settings = new TreeSettings();
		      settings.setClearAllNodes(true);
			      
		      ValuePack valuePack = new ValuePack();
		      valuePack.put("tree", settings);
		      pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
	   	   }else if (event.getSourceId().equals("update")) {
	  	   	  Object value = event.getValuePack().getValue("tree");
	   	   	  if (value != null) {
	   	   	      TreeClientNode path = ((TreeClientNode[]) value)[0];
	   	   	      if (!path.isRoot() && path.isLeaf()) {
	   	   	           TreeSettings settings = new TreeSettings();
	   	   	           TreeSettings.UpdatedNode node = new TreeSettings.UpdatedNode(path.getPath());
	   	   	           node.setUserObject("updateItem " + path.getUserObject());
	   	   	           node.setForeground(Color.RED); 
	   	   	           settings.setUpdatedNode(node);
	   	   	           
		   	  	       ValuePack valuePack = new ValuePack();
		   		       valuePack.put("tree", settings);
		   		       pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
	   	   	      }
	   	   	  }
	   	   }else if (event.getSourceId().equals("expandAllPath")) {
		   	   	  Object value = event.getValuePack().getValue("tree");
		   	   	  if (value != null) {
		   	   	       TreeClientNode path = ((TreeClientNode[]) value)[0];
		   	           TreeSettings settings = new TreeSettings();
		   	           settings.setExpandAllPath(path.getPath());
		   	   	           
		  	  	       ValuePack valuePack = new ValuePack();
		  		       valuePack.put("tree", settings);
		  		       pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
		   	   	  }   		
		    }else if (event.getSourceId().equals("collapseAllPath")) {
		   	   	  Object value = event.getValuePack().getValue("tree");
		   	   	  if (value != null) {
		   	   	       TreeClientNode path = ((TreeClientNode[]) value)[0];
		   	           TreeSettings settings = new TreeSettings();
		   	           settings.setCollapsePath(path.getPath());
		   	   	           
		   	  	       ValuePack valuePack = new ValuePack();
		   		       valuePack.put("tree", settings);
		   		       pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
		   	   	  }   		
	   	   }
	}
	
	
	@Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
	   	   if (event.getCode() == ServerMouseEvent.MOUSE_CLICKED_EVENT && event.getSourceId().equals("tree")) {
	    	   	  Object value = event.getValuePack().getValue("tree");
	    	   	  if (value != null) {
	    	   	     TreeClientNode[] paths = (TreeClientNode[]) value;  
	    	   	  	 for (int i = 0; i < paths.length; i++) {
	    	   	        System.out.println("paths = " + paths[i]);
	    	   	     }   
	    	   	  }
	   	   }
   }

   @Override
   public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
   	   XTree tree = new XTree("tree");
   	   tree.setDataSource(createContainer());
   	   tree.setWidth(600);
   	   tree.setHeight(200);
   	   tree.setHorizontalAlignment(javax.swing.SwingUtilities.RIGHT);
   	   
   	   XBoxPanel panel = new XBoxPanel();
   	   panel.add(tree);   	   
   	   
   	   XBoxPanel buttonPanel = new XBoxPanel(SwingConstants.VERTICAL);
   	   buttonPanel.setGapForAll(5);
   	   buttonPanel.setSameSizeForAllComponents(true);
   	   
   	   ServerActionEvent actionEvent = new ServerActionEvent();
   	   actionEvent.addReturnValue("tree");
   	   
   	   XButton button = new XButton("add", "Pridaj");
   	   button.addActionEvent(actionEvent);
   	   buttonPanel.add(button);

   	   button = new XButton("delete", "Vymaz");
   	   button.addActionEvent(actionEvent);
   	   buttonPanel.add(button);

   	   button = new XButton("deleteChildren", "Vymaz deticky");
   	   button.addActionEvent(actionEvent);
   	   buttonPanel.add(button);
   	   
   	   button = new XButton("update", "Oprava");
   	   button.addActionEvent(actionEvent);
   	   buttonPanel.add(button);

   	   button = new XButton("expandAllPath", "Rozbal");
   	   button.addActionEvent(actionEvent);
   	   buttonPanel.add(button);

   	   button = new XButton("collapseAllPath", "Zbal");
   	   button.addActionEvent(actionEvent);
   	   buttonPanel.add(button);
   	   
   	   buttonPanel.add(new XButton("clear", "Vymaz vsetko"));
   	   
   	   XBorderPanel mainPanel = new XBorderPanel(10, 10);
   	   mainPanel.setInsets(new Insets(10, 10, 10, 10));
   	   mainPanel.setCenter(tree);
   	   mainPanel.setEast(buttonPanel);
   	   
   	   XForm form = new XForm();
   	   form.setPanel(mainPanel); 
   	   form.setTitle("Dynamic tree");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }   
   
   private TreeContainer createContainer() {
       TreeNode rootNode = new TreeNode(getNextId(), "Root");
       rootNode.add(new TreeNode(getNextId(), "Item1"));
       rootNode.add(new TreeNode(getNextId(), "Item2"));
       rootNode.add(new TreeNode(getNextId(), "Item3"));
       return new TreeContainer(rootNode);
   }
   
   public int getNextId() {
	   lastId++;
	   return lastId;
   }

   public static void main(String...strings) {
	   MediatorRunner.run(DemoDynamicTree.class, null, null, "flat");
   }
}
