package demo.framework.components;

import java.awt.Color;
import java.awt.Insets;
import java.text.DecimalFormatSymbols;

import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XForm;
import netball.server.component.XNumberField;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientFocusEvent;
import netball.server.event.ClientKeyEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerEvent;
import netball.server.event.ServerFocusEvent;
import netball.server.event.ServerKeyEvent;
import netball.server.event.ServerMouseEvent;
import netball.server.event.ServerValueUpdatedEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.utilities.TypeValues;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoNumberField extends BasicMediator { 

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void focusEventExecuted(ClientFocusEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void keyEventExecuted(ClientKeyEvent event, ServerPack pack) {
		System.out.println(event);
	}
 
	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	   if (event.getSourceId().equals("Potvrd")) {
   	   	  System.out.println(event.getValuePack());
   	   }
   }

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
   	   XBoxPanel panel = new XBoxPanel();
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   
   	   XNumberField field = new XNumberField("celeCislo", "cele cislo", TypeValues.INTEGER, 5, 0);
   	   panel.add(field);
   	   panel.addGap(5);
   	   
   	   field.setMinimum(new Integer(0));
   	   field.setMaximum(new Integer(100));
   	   field.setLength(3);
   	   field.setDescription("ja som number field");
   	   
   	   field.addMouseEvent(new ServerMouseEvent(ServerEvent.MOUSE_CLICKED_EVENT));
   	   field.addFocusEvent(new ServerFocusEvent(ServerEvent.FOCUS_GAINED_EVENT));
   	   field.addKeyEvent(new ServerKeyEvent(ServerEvent.KEY_TYPED_EVENT));
   	   field.addValueUpdatedEvent(new ServerValueUpdatedEvent());   	   
   	   
   	   field = new XNumberField("desatineCislo", "desatine cislo", TypeValues.BIG_DECIMAL, 10, 2);
   	   field.setIsMinusSignAllowed(false);
   	   field.setNumber(new java.math.BigDecimal("100"));
   	   field.setFormattedMask("###,###.00");
   	   field.setLength(8);
   	   field.setScale(2);
       DecimalFormatSymbols symbols =  new java.text.DecimalFormatSymbols(new java.util.Locale("us","US"));
       symbols.setDecimalSeparator(',');
       symbols.setGroupingSeparator(' ');      
   	   field.setDecimalFormatSymbols(symbols);
   	   field.setBackground(Color.red);
   	   field.setForeground(Color.yellow);
   	   field.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
   	   
   	   panel.add(field);
   	   panel.addGap(20);
   	   
   	   ServerActionEvent event = new ServerActionEvent();
   	   event.setReturnAllValues(true);
   	   panel.add(new XButton("Potvrd", "Potvrd", event));   	   
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Number field");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }

   public static void main(String...strings) {
	   MediatorRunner.run(DemoNumberField.class, null, null, "flat");
   } 	
}
