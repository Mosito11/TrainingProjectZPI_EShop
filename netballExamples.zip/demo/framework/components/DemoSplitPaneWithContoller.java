package demo.framework.components;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.SwingConstants;

import netball.client.ui.jtc.SplitPaneVisibleSidesController;
import netball.server.component.XForm;
import netball.server.component.XLabel;
import netball.server.component.XProportionaPanel;
import netball.server.component.XScrollPane;
import netball.server.component.XSplitPane;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoSplitPaneWithContoller extends BasicMediator { 
	
    @Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
   	   XSplitPane verticalSplit = new XSplitPane("verticalSplit", XSplitPane.VERTICAL_SPLIT);
   	   verticalSplit.setController(new VerticalSplitPaneController(), this);
   	   
   	   XSplitPane horizontalSplit = new XSplitPane("horizontalSplit", XSplitPane.HORIZONTAL_SPLIT);
   	   horizontalSplit.setController(new HorizontalSplitPaneController(), this);
   	   
   	   XLabel label = new XLabel("LEFT SIDE");
   	   label.setVerticalAlignment(SwingConstants.CENTER);
   	   label.setHorizontalAlignment(SwingConstants.CENTER);
   	   label.setBackground(Color.RED);
   	   horizontalSplit.setLeft(label);

   	   label = new XLabel("RIGHT SIDE");
   	   label.setVerticalAlignment(SwingConstants.CENTER);
   	   label.setHorizontalAlignment(SwingConstants.CENTER);
   	   label.setBackground(Color.YELLOW);
   	   horizontalSplit.setRight(new XScrollPane(label));   	   
   	   
   	   label = new XLabel("BOTTOM SIDE");
   	   label.setVerticalAlignment(SwingConstants.CENTER);
   	   label.setHorizontalAlignment(SwingConstants.CENTER);
   	   label.setBackground(Color.GRAY);
   	   verticalSplit.setBottom(label);
   	   
   	   label = new XLabel("TOP SIDE");
   	   label.setVerticalAlignment(SwingConstants.CENTER);
   	   label.setHorizontalAlignment(SwingConstants.CENTER);
   	   label.setBackground(Color.CYAN);
   	   verticalSplit.setTop(label);
   	   
   	   XProportionaPanel panel = new XProportionaPanel(SwingConstants.HORIZONTAL);
   	   panel.add(horizontalSplit, 0.5, true);
   	   panel.add(verticalSplit, 0.5, true);
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("DemoSplitPaneWithContoller");
   	   form.setSize(new Dimension(400, 200));
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }
	
   private class HorizontalSplitPaneController extends SplitPaneVisibleSidesController {

		@Override
		public void visibleSides(int visibleSides, ServerPack serverPack) throws Exception {
			if (visibleSides == SplitPaneVisibleSidesController.BOTH_SIDES_ARE_VYSIBLE) {
				System.out.println("BOTH_SIDES_ARE_VYSIBLE");
			}else if (visibleSides == SplitPaneVisibleSidesController.LEFT_SIDE_IS_VYSIBLE) {
				System.out.println("LEFT_SIDE_IS_VYSIBLE");
			}else if (visibleSides == SplitPaneVisibleSidesController.RIGHT_SIDE_IS_VYSIBLE) {
				System.out.println("RIGHT_SIDE_IS_VYSIBLE");
			}
		}
   }	

   private class VerticalSplitPaneController extends SplitPaneVisibleSidesController {

		@Override
		public void visibleSides(int visibleSides, ServerPack serverPack) throws Exception {
			if (visibleSides == SplitPaneVisibleSidesController.BOTH_SIDES_ARE_VYSIBLE) {
				System.out.println("BOTH_SIDES_ARE_VYSIBLE");
			}else if (visibleSides == SplitPaneVisibleSidesController.TOP_SIDE_IS_VYSIBLE) {
				System.out.println("TOP_SIDE_IS_VYSIBLE");
			}else if (visibleSides == SplitPaneVisibleSidesController.BOTTOM_SIDE_IS_VYSIBLE) {
				System.out.println("BOTTOM_SIDE_IS_VYSIBLE");
			}
		}
   }	
   
   public static void main(String...strings) {
	   MediatorRunner.run(DemoSplitPaneWithContoller.class, null, null, "flat");
   }	
}
