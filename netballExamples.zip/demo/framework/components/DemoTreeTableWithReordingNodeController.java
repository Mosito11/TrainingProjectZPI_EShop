package demo.framework.components;

import netball.server.component.XBorderPanel;
import netball.server.component.XForm;
import netball.server.component.XTableColumn;
import netball.server.component.XTreeTable;
import netball.server.component.setting.TreeTableSettings;
import netball.server.component.treetable.ReordingTreeTableNodeController;
import netball.server.component.treetable.TreeTableClientNode;
import netball.server.component.treetable.TreeTableContainer;
import netball.server.component.treetable.TreeTableNode;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoTreeTableWithReordingNodeController extends BasicMediator { 

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
	   	   XTreeTable treeTable = new XTreeTable("tree");
	   	   treeTable.setDataSource(createModel());
	   	   treeTable.setTreeColumnWidth(200);
	   	   treeTable.setRootVisible(true);
	   	   treeTable.setTreeHeaderText("tree header");
	   	   treeTable.addColumn(new XTableColumn("col0", "Column0", 80));
	   	   treeTable.addColumn(new XTableColumn("col1", "Column1", 80));
	   	   treeTable.setReordingTreeNodeController(new MyReordingTreeTableNodeController(), this);
	   	   treeTable.setSelectionMode(XTreeTable.MULTIPLE_INTERVAL_SELECTION);
	   	   XBorderPanel panel = new XBorderPanel(10, 10);
	   	   panel.setCenter(treeTable);   	   
	   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel); 
	   	   form.setTitle("TreeTableWithReordingNodeController");
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	 }
	   
	 public TreeTableContainer createModel() {
		 String[] cols = new String[] {"col0", "col1"};
		 TreeTableNode node = new TreeTableNode("root"); 
		 TreeTableContainer container = new TreeTableContainer(node, cols);
		 node = new TreeTableNode("1", "Node 1", new Object[] {"A", "B"});
		 node.add(new TreeTableNode("1.1", "Node 1.1", new Object[] {"C", "D"}));
		 node.add(new TreeTableNode("1.2", "Node 1.2", new Object[] {"E", "F"}));
		 node.add(new TreeTableNode("1.3", "Node 1.3", new Object[] {"G", "H"}));
		 container.getRootNode().add(node);
		 
		 node = new TreeTableNode("2", "Node 2", new Object[] {"I", "J"});
		 node.add(new TreeTableNode("2.1", "Node 2.1", new Object[] {"K", "L"}));
		 node.add(new TreeTableNode("2.2", "Node 2.2", new Object[] {"M", "N"}));
		 node.add(new TreeTableNode("2.3", "Node 2.3", new Object[] {"O", "P"}));
		 container.getRootNode().add(node);
		 
		 node = new TreeTableNode("3", "Node 3", new Object[] {"R", "S"});
		 node.add(new TreeTableNode("3.1", "Node 3.1", new Object[] {"T", "X"}));
		 node.add(new TreeTableNode("3.2", "Node 3.2", new Object[] {"Y", "Z"}));
		 node.add(new TreeTableNode("3.3", "Node 3.3", new Object[] {"Q", "W"}));
		 container.getRootNode().add(node);
		 return container;
	 }
	 
    private class MyReordingTreeTableNodeController extends ReordingTreeTableNodeController {

			@Override
			public UpdatedPack reorderNodes(TreeTableClientNode[] sourceNodes, TreeTableClientNode targetNode) throws Exception {
	 		    TreeTableSettings settings = new TreeTableSettings();
	 		    settings.setReordingNodes(sourceNodes, targetNode);
	 		    settings.setScrollRowToVisible(targetNode.getId());
	 		    settings.setSelectedRow(targetNode.getId());
	 		    settings.setExpandPath(targetNode.getId());
	 		    ValuePack valuePack = new ValuePack();
	 		    valuePack.put("tree", settings);
				return new UpdatedPack(getId(), valuePack);
			}
    }
	   
	 public static void main(String...strings) {
		   MediatorRunner.run(DemoTreeTableWithReordingNodeController.class, null, null, "flat");
     }
}
