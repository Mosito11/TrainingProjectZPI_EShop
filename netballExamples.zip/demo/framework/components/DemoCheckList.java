package demo.framework.components;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;

import netball.server.component.ListItem;
import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XCheckList;
import netball.server.component.XFont;
import netball.server.component.XForm;
import netball.server.component.setting.ListSettings;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientFocusEvent;
import netball.server.event.ClientKeyEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ClientSelectionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerEvent;
import netball.server.event.ServerFocusEvent;
import netball.server.event.ServerKeyEvent;
import netball.server.event.ServerMouseEvent;
import netball.server.event.ServerSelectionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoCheckList extends BasicMediator { 

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void selectionEventExecuted(ClientSelectionEvent event,	ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void focusEventExecuted(ClientFocusEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void keyEventExecuted(ClientKeyEvent event, ServerPack pack) {
		System.out.println(event);
	}
 
	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	   if (event.getSourceId().equals("Potvrd")) {
   	   	  Object[] values = (Object[]) event.getValuePack().getValue("list");
   	   	  if (values != null) {
   	   	    for (int i = 0; i < values.length; i++) {
   	   	       System.out.println("value = " + values[i]);
   	   	    }   
   	   	  }else{
   	   	  	System.out.println("value = null"); 
   	   	  }  
	   	  System.out.println(event.getProperties().get("list"));   	   	  
   	   }else if (event.getSourceId().equals("Update")) {	  
   	      update(pack);
   	   }
   }

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
   	   XCheckList list = new XCheckList("list");
   	   list.setVisibleRowCount(8);
   	   list.setBackground(Color.yellow);
   	   list.setForeground(Color.blue);
   	   list.setFont(new XFont("Courier", Font.BOLD, 12));
   	   list.addItem("111111111");
   	   list.addItem("222222222");
   	   list.addItem("333333333");
   	   list.addItem("444444444");
   	   list.setLayoutOrientation(XCheckList.HORIZONTAL_WRAP);
   	   list.setSearchable(true);
   	   //list.setSelectedIndex(1);
   	   list.addSelectedItem(list.getDataSource().get(2));
   	   list.setDescription("ja som list" );   	   
   	   list.setSelectionMode(XCheckList.MULTIPLE_INTERVAL_SELECTION);
   	   
   	   list.setWidth(200);
   	   list.addMouseEvent(new ServerMouseEvent(ServerEvent.MOUSE_CLICKED_EVENT));
   	   list.addFocusEvent(new ServerFocusEvent(ServerEvent.FOCUS_GAINED_EVENT));
   	   list.addKeyEvent(new ServerKeyEvent(ServerEvent.KEY_TYPED_EVENT));
   	   list.addSelectionEvent(new ServerSelectionEvent());
   	   
   	   XBoxPanel buttonPanel = new XBoxPanel();
   	   buttonPanel.setGapForAll(5);
   	   
   	   ServerActionEvent event = new ServerActionEvent();
   	   event.setReturnAllValues(true);
   	   event.addReturnProperty("list");   	   
   	   buttonPanel.add(new XButton("Potvrd", "Potvrd", event));   	   
   	   buttonPanel.add(new XButton("Update", "Update"));   	   
   	   
   	   XBorderPanel panel = new XBorderPanel(10, 10);
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.setCenter(list);
   	   panel.setSouth(buttonPanel);
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Check list");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }
   
   private void update(ServerPack pack) {
   	   ListSettings cbp = new ListSettings();
   	   cbp.addInsertedItem(new ListItem("55555555"));
   	   cbp.addInsertedItem(new ListItem("66666666"));
   	   cbp.addDeletedItem("222222222");
   	   cbp.addSelectedItem("55555555");
   	   cbp.setBackground(Color.green);
   	   cbp.setForeground(Color.white);
   	   cbp.setFont(new XFont("Courier", Font.ITALIC, 12));
   	   ValuePack valuePack = new ValuePack();
   	   valuePack.put("list", cbp);
   	   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
   }   
   
   public static void main(String...strings) {
	   MediatorRunner.run(DemoCheckList.class, null, null, "flat");
   } 
}
