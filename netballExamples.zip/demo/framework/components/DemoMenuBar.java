package demo.framework.components;

import java.awt.Dimension;
import java.util.ArrayList;
import java.util.List;

import javax.swing.SwingConstants;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XForm;
import netball.server.component.XMenu;
import netball.server.component.setting.MenuBarSettings;
import netball.server.event.ClientActionEvent;
import netball.server.pack.EnabledPack;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoMenuBar extends BasicMediator { 

	   @Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
    	   if (event.getSourceId().equals("enabledButton") ) {
   		      UpdatedPack updatedPack = new UpdatedPack(this.getId());
	   		  EnabledPack enabledPack = new EnabledPack();
	   		  enabledPack.put("3333", false);
	   		  enabledPack.put("8888", false);
	   		  updatedPack.setEnabledPack(enabledPack);
	   		  pack.addUpdatedPack(updatedPack);
	   	   }else if (event.getSourceId().equals("deleteButton")) {
	   		  MenuBarSettings settings = new MenuBarSettings();
	   		  settings.addDeletedItem("XXXX");
	   		  settings.addDeletedItem("CCCC");
	   		  UpdatedPack updatedPack = new UpdatedPack(getId());
	   		  updatedPack.setMenuBarSettings(settings);
	   		  pack.addUpdatedPack(updatedPack);
	   	   }else if (event.getSourceId().equals("clearButton")) {
	   		  MenuBarSettings settings = new MenuBarSettings();
	   		  settings.addDeletedAllChildren("ZZZZ");
	   		  UpdatedPack updatedPack = new UpdatedPack(getId());
	   		  updatedPack.setMenuBarSettings(settings);
	   		  pack.addUpdatedPack(updatedPack);
	   	   }else if (event.getSourceId().equals("addButton")) {
	   		  List<XMenu> menuItems = new ArrayList<>();
	   		  menuItems.add(new XMenu("add1"));
	   		  menuItems.add(new XMenu("add2"));
	   		  menuItems.add(new XMenu("add3"));
	   		  MenuBarSettings settings = new MenuBarSettings();
	   		  settings.addAddedItem(new MenuBarSettings.AddedMenu("1111", menuItems));

		   	  XMenu menu = new XMenu("addB");
		   	  menu.add(new XMenu("addC"));
		   	  menu.add(new XMenu("addD"));
		   	  menuItems = new ArrayList<>();
		   	  menuItems.add(menu);
	   		  settings.addAddedItem(new MenuBarSettings.AddedMenu(null, menuItems));
	   		  
	   		  UpdatedPack updatedPack = new UpdatedPack(getId());
	   		  updatedPack.setMenuBarSettings(settings);
	   		  EnabledPack enabledPack = new EnabledPack();
	   		  enabledPack.put("addButton", false);
	   		  updatedPack.setEnabledPack(enabledPack);
	   		  pack.addUpdatedPack(updatedPack);
	   	   }else if (event.getSourceId().equals("updateButton")) {
	   		  MenuBarSettings settings = new MenuBarSettings();
	   		  settings.addUpdadedItem(new MenuBarSettings.UpdadedItem("3333", "update3333"));
	   		  UpdatedPack updatedPack = new UpdatedPack(getId());
	   		  updatedPack.setMenuBarSettings(settings);
	   		  pack.addUpdatedPack(updatedPack);
	   	   }
	   }

		@Override
		public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
	   	   XBoxPanel buttonPanel = new XBoxPanel(SwingConstants.HORIZONTAL);
	   	   buttonPanel.setGapForAll(5);
	   	   XButton button = new XButton("enabledButton", "Disable polozky");
	   	   buttonPanel.add(button);

	   	   button = new XButton("addButton", "Add");
	   	   buttonPanel.add(button);

	   	   button = new XButton("updateButton", "Update");
	   	   buttonPanel.add(button);
	   	   
	   	   button = new XButton("deleteButton", "Delete");
	   	   buttonPanel.add(button);

	   	   button = new XButton("clearButton", "Clear");
	   	   buttonPanel.add(button);
	   	   
	   	   XBorderPanel panel = new XBorderPanel();
	   	   panel.setSouth(buttonPanel);
	   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel); 
	   	   form.setTitle("Menu bar");
	   	   form.setMenu(createMenuBar());
	   	   form.setSize(new Dimension(700, 400));
	   	   
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	   }
	   
	   public List<XMenu> createMenuBar() {
	   	   List<XMenu> mainMenu = new ArrayList<XMenu>();
	   	   XMenu menu = new XMenu("1111");
	   	   menu.add(new XMenu("2222"));
	   	   menu.add(new XMenu("3333"));
	   	   menu.add(new XMenu("4444"));
	   	   mainMenu.add(menu);
	   	   
	   	   menu = new XMenu("5555");
	   	   menu.add(new XMenu("6666"));
	   	   XMenu menu1 = new XMenu("7777");
	   	   menu1.setDescription("ssssssssssssssssssssssssssssssss");
	   	   menu1.add(new XMenu("8888"));
	   	   menu1.add(new XMenu("9999"));
	   	   menu.add(menu1);
	   	   mainMenu.add(menu);
	   	   
	   	   menu = new XMenu("AAAA");
	   	   menu.add(new XMenu("BBBB"));
	   	   menu.add(new XMenu("GGGG"));
	   	   menu1 = new XMenu("CCCC");
	   	   menu1.add(new XMenu("DDDD"));
	   	   menu1.add(new XMenu("EEEE"));
	   	   menu.add(menu1);
	   	   mainMenu.add(menu);
	   	   
	   	   menu = new XMenu("XXXX");
	   	   menu.add(new XMenu("YYYY"));
	   	   menu1 = new XMenu("ZZZZ");
	   	   menu1.add(new XMenu("TTTT"));
	   	   menu1.add(new XMenu("RRRR"));
	   	   menu.add(menu1);
	   	   mainMenu.add(menu);

	   	   return mainMenu;
	   }

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	public static void main(String...strings) {
		MediatorRunner.run(DemoMenuBar.class, null, null, "flat");
	}
}

