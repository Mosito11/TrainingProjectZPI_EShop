package demo.framework.components;

import java.awt.Insets;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import netball.server.component.ListItem;
import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XCheckBox;
import netball.server.component.XClientTable;
import netball.server.component.XComboBox;
import netball.server.component.XCompoundField;
import netball.server.component.XDateFieldWithCalendar;
import netball.server.component.XForm;
import netball.server.component.XFormattedTextField;
import netball.server.component.XMultiColumnComboBox;
import netball.server.component.XNumberField;
import netball.server.component.XNumberSpinner;
import netball.server.component.XTableColumn;
import netball.server.component.XTextField;
import netball.server.component.renderer.DateRenderer;
import netball.server.component.renderer.FormattedTextRenderer;
import netball.server.component.renderer.ListRenderer;
import netball.server.component.renderer.LogicalRenderer;
import netball.server.component.renderer.NumberRenderer;
import netball.server.component.setting.ClientTableSettings;
import netball.server.component.table.ClientTableEditableModel;
import netball.server.component.table.TableContainer;
import netball.server.component.table.TableRow;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientPopupEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerPopupEvent;
import netball.server.event.alert.StopTableCellEditingAlert;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoEditableClientTable extends BasicMediator { 

	public AccessAction[] getAccessActions() {
		return null;
	}
	
	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)throws Exception {
	   	   XClientTable table = new XClientTable("table");
	   	   
           XTableColumn column = new XTableColumn("id", "id", 70);
           column.setVisible(false);
	   	   table.addColumn(column);
	   	   
           column = new XTableColumn("TextField", "TextField", 70);
	   	   column.setEditable(true);
	   	   column.setEditor(new XTextField());
	   	   table.addColumn(column);
	   	   
	   	   column = new XTableColumn("NumberField", "NumberField", 70);
	   	   column.setRenderer(new NumberRenderer("####.00")); 
	   	   column.setEditable(true);
	   	   column.setEditor(new XNumberField(XNumberField.BIG_DECIMAL, 6, 2));
	   	   column.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
	   	   table.addColumn(column);
	   	   
	   	   column = new XTableColumn("DateField", "DateField", 90);
	   	   column.setEditable(true);
	   	   column.setEditor(new XDateFieldWithCalendar());
	   	   column.setRenderer(new DateRenderer("dd.MM.yyyy"));
	   	   table.addColumn(column);
	   	   
	   	   column = new XTableColumn("CheckBox", "CheckBox", 70);   	   
	   	   column.setRenderer(new LogicalRenderer(Boolean.TRUE));
	   	   XCheckBox checkBoxEditor = new XCheckBox();
	   	   checkBoxEditor.setDeselectedStateValue(false);
	   	   checkBoxEditor.setSelectedStateValue(true);
	   	   column.setEditor(checkBoxEditor);
	   	   column.setEditable(true);
	   	   table.addColumn(column);
	   	   
	   	   column = new XTableColumn("ComboBox", "ComboBox", 70);   	   
	   	   ListRenderer listRenderer = new ListRenderer();    	   
	   	   listRenderer.put("1", "Jar");
	   	   listRenderer.put("2", "Leto");
	   	   listRenderer.put("3", "Jesen");
	   	   listRenderer.put("4", "Zima");
	   	   XComboBox comboBoxEditor = new XComboBox();
	   	   comboBoxEditor.addItem(new ListItem("1", "Jar"));
	   	   comboBoxEditor.addItem(new ListItem("2", "Leto"));
	   	   comboBoxEditor.addItem(new ListItem("3", "Jesen"));
	   	   comboBoxEditor.addItem(new ListItem("4", "Zima"));
	   	   comboBoxEditor.setEditable(false);
	   	   column.setEditable(true);
	   	   column.setEditor(comboBoxEditor);
	   	   column.setRenderer(listRenderer);
	   	   table.addColumn(column);
	   	   
	   	   column = new XTableColumn("FormattedTextField", "FormattedTextField", 70);  
	   	   column.setEditable(true);
	   	   column.setEditor(new XFormattedTextField("???-###"));
	   	   column.setRenderer(new FormattedTextRenderer("???-###"));
	   	   table.addColumn(column);

	   	   column = new XTableColumn("MultiColumnComboBox", "MultiColumnComboBox", 70);  
	   	   column.setEditable(true);
	   	   XMultiColumnComboBox multiComboBoxEditor = new XMultiColumnComboBox();
	   	   List<XTableColumn> cols = new ArrayList<XTableColumn>();   
	   	   cols.add(new XTableColumn("kod", "Kod", 40));
	   	   cols.add(new XTableColumn("nazov", "Nazov", 100));
	   	   multiComboBoxEditor.setColumns(cols);
	   	   TableContainer source = new TableContainer(new Object[] {"kod", "nazov"});
	   	   source.addNewRow(new Object[] {"V", "Vychod"});
	   	   source.addNewRow(new Object[] {"Z", "Zapad"});
	   	   source.addNewRow(new Object[] {"S", "Sever"});
	   	   source.addNewRow(new Object[] {"J", "Juh"});
		   multiComboBoxEditor.setDataSource(source);
		   multiComboBoxEditor.setPrimaryKey("kod");
		   //multiComboBoxEditor.setEditable(true);
		   multiComboBoxEditor.setEditable(false);
		   column.setEditor(multiComboBoxEditor);
		   table.addColumn(column);
	   	      	   
	   	   column = new XTableColumn("Spinner", "Spinner", 70);
	   	   column.setRenderer(new NumberRenderer("######")); 
	   	   column.setEditable(true);
	   	   column.setEditor(new XNumberSpinner(XNumberSpinner.BIG_INTEGER, 6, 0));
	   	   column.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
	   	   table.addColumn(column);
		   
	   	   column = new XTableColumn("CompoundField", "CompoundField", 100);
	   	   column.setEditable(true);
	   	   XCompoundField field = new XCompoundField("compoundField");  // je potrebne definovat identifikator pre komponent, ak chcene s nim komunikovat
	   	   ServerPopupEvent event = new ServerPopupEvent();
	   	   event.addReturnValue("compoundField");
	   	   field.addPopupEvent(event);
	   	   column.setEditor(field);
	   	   table.addColumn(column);
	   	   
	   	   table.setDataSource(createContainer());
	   	   table.setEditableModel(new EditableModel(), this);
	   	   table.setPrimaryKey("id");
	   	   table.setShowStatusRow(true);
	   	   table.setWidth(700);
	   	   table.setHeight(400);
	   	   table.setFreezeColumnsAllowed(false);
	   	  // table.setVisibilityOfColumnIsAllowed(true);

	   	   XBoxPanel buttonPanel = new XBoxPanel(javax.swing.SwingConstants.HORIZONTAL);
	   	   buttonPanel.setGapForAll(5);
	   	   buttonPanel.add(new XButton("button", "Edit cell at", new ServerActionEvent()));
	   	   
	   	   XButton button = new XButton("stopCellEditing", "Stop cell editing");
	   	   ServerActionEvent buttonEvent = new ServerActionEvent();
	   	   buttonEvent.addAlert(new StopTableCellEditingAlert("table"));
	   	   button.addActionEvent(buttonEvent);
	   	   buttonPanel.add(button);
	   	   
	   	   XBorderPanel panel = new XBorderPanel(10, 10);
	   	   panel.setInsets(new Insets(10, 10, 10, 10));
	   	   panel.setCenter(table);
	   	   panel.setSouth(buttonPanel);
	   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel); 
	   	   form.setType(XForm.FRAME);
	   	   form.setTitle("Editable client table");
	   	   
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
    }
	
    @Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
    	if (event.getSourceId().equals("button")) {
    		ClientTableSettings settings = new ClientTableSettings();
    		settings.setSelectedItem(80);
    		settings.setSelectedColumn("DateField");
    		settings.setScrollRowToVisible(80);
    		settings.setEditCellAt(80, "DateField");
    		ValuePack valuePack = new ValuePack();
    		valuePack.put("table", settings);
    		UpdatedPack updatedPack = new UpdatedPack(getId(), valuePack);
    		pack.addUpdatedPack(updatedPack);
    	}
	}

	private TableContainer createContainer() {
	       TableContainer container = new TableContainer(new String[] {"id", "TextField", "NumberField", "DateField", "CheckBox", "ComboBox", "FormattedTextField", "MultiColumnComboBox", "Spinner", "CompoundField"});
	       Calendar c = Calendar.getInstance();
	       for (int i = 0; i < 100; i++) {
	       	   c.add(Calendar.DATE, 1);
	       	   Object[] row = new Object[10];
	       	   row[0] = i;
	       	   row[1] = "String " + i;
	       	   row[2] = new BigDecimal("" + i);       	   
	       	   row[3] = c.getTime();
	       	   row[4] = Boolean.TRUE;
	       	   row[5] = "1";
	       	   row[6] = "AAA000";
	       	   row[7] = "V";
	       	   row[8] = i;
	       	   row[9] = "text " + i;
	       	   container.addNewRow(row);
	       }
	       return container;
	   }   
	   
	   private class EditableModel extends ClientTableEditableModel {

			@Override
			public boolean isCellEditable(Object columnId, TableRow row) throws Exception {
				 if (columnId.equals("NumberField")) {
				     BigDecimal number = (BigDecimal) row.getValueAt(columnId);	 
				     if (number.doubleValue() <= 10) {
				    	 throw new IllegalArgumentException("Len cislo > 10 je mozne editovat.");
				     }
				 }
				 return true;
			}
	
			@Override
			public UpdatedPack setValue(Object value, Object columnId, TableRow row) throws Exception {
			   if (columnId.equals("NumberField")) {
				     BigDecimal number = (BigDecimal) value;	 
				     if (number.doubleValue() <= 10) {
				    	 throw new IllegalArgumentException("Cislo musi byt > 10.");
				     }
			   } 	
			   ClientTableSettings tablePack = new ClientTableSettings();
			   TableRow newRow = new TableRow(row.getId()); 
		   	   newRow.add(columnId, value);
		   	   tablePack.setUpdatedRow(newRow);
		   	   ValuePack valuePack = new ValuePack();
		   	   valuePack.put("table", tablePack);
		   	   return new UpdatedPack(getId(), valuePack);   	   
			}

			@Override
			public UpdatedPack editorWasInstalled(Object value,	Object columnId, TableRow row, Object editorId) throws Exception {
				return null;
			}
	   }
	   
	 @Override
	 public void popupEventExecuted(ClientPopupEvent event, ServerPack pack) {
   	    if (event.getSourceId().equals("compoundField")) {
   		   Object value = event.getValuePack().getValue("compoundField");
   		   ValuePack valuePack = new ValuePack();
   		   valuePack.put("compoundField", "new Text " + value);
   		   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
   	    }
	 }

	public static void main(String...strings) {
		   MediatorRunner.run(DemoEditableClientTable.class, null, null, "flat");
   } 
}
