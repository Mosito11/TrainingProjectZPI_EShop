package demo.framework.components;


import java.awt.Insets;

import javax.swing.SwingConstants;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XClientTable;
import netball.server.component.XForm;
import netball.server.component.XTableColumn;
import netball.server.component.setting.ClientTableSettings;
import netball.server.component.table.TableContainer;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoClientTableInsertRows extends BasicMediator {
   
    @Override
    public AccessAction[] getAccessActions() {
        return null;
    }

   @Override
    public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
          if (event.getSourceId().equals("insertButton")) {
                ClientTableSettings settings = new ClientTableSettings();
                ClientTableSettings.InsertedRow[] rows = new ClientTableSettings.InsertedRow[2]; 
                rows[0] = new ClientTableSettings.InsertedRow(0);  
                rows[0].add("col0", "c1");
                rows[0].add("col1", "c2");

                rows[1] = new ClientTableSettings.InsertedRow(1);
                rows[1].add("col0", "d1");
                rows[1].add("col1", "d2");
                
                settings.setInsertedRows(rows);
                ValuePack valuePack = new ValuePack();
                valuePack.put("table", settings);
                pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
          }
   }
  
    @Override
    public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
          XClientTable table = new XClientTable("table");
          table.addColumn(new XTableColumn("col0", "col0", 70));
          table.addColumn(new XTableColumn("col1", "col1", 70));
         
          TableContainer tableContainer = new TableContainer(new String[] {"col0", "col1"});
          tableContainer.addNewRow(new String[] {"a0", "a1"});
          tableContainer.addNewRow(new String[] {"b0", "b1"});
          table.setDataSource(tableContainer);
         
          XButton insertButton = new XButton("insertButton", "Insert");
          ServerActionEvent event = new ServerActionEvent();
          insertButton.addActionEvent(event);
          
          XBoxPanel buttonPanel = new XBoxPanel(SwingConstants.HORIZONTAL);
          buttonPanel.setHorizontalAlignment(SwingConstants.RIGHT);
          buttonPanel.add(insertButton);
         
          XBorderPanel panel = new XBorderPanel(10, 10);
          panel.setInsets(new Insets(10, 10, 10, 10));
          panel.setCenter(table);
          panel.setSouth(buttonPanel);
         
          XForm form = new XForm();
          form.setPanel(panel);
          form.setTitle("Client table");
         
          serverPack.addFormPack(new FormPack(getId(), form));         
   }

    public static void main(String...strings) {
        MediatorRunner.run(DemoClientTableInsertRows.class, null, null, "flat");
    }
}
