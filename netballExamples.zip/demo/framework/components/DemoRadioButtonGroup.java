package demo.framework.components;

import java.awt.Color;
import java.awt.Font;

import javax.swing.SwingConstants;

import netball.server.component.KeyItem;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XFont;
import netball.server.component.XForm;
import netball.server.component.XRadioButtonGroup;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientSelectionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerEvent;
import netball.server.event.ServerFocusEvent;
import netball.server.event.ServerKeyEvent;
import netball.server.event.ServerMouseEvent;
import netball.server.event.ServerSelectionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoRadioButtonGroup extends BasicMediator { 
	
   @Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	   if (event.getSourceId().equals("Potvrd")) {
   	   	  System.out.println("value = " + event.getValuePack().getValue("radioButtonGroup"));
   	   }
   }

   		@Override
	public void selectionEventExecuted(ClientSelectionEvent event,	ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
   	   XRadioButtonGroup radioButtonGroup = new XRadioButtonGroup("radioButtonGroupV", SwingConstants.VERTICAL);
   	   radioButtonGroup.setBackground(Color.yellow);
   	   radioButtonGroup.setForeground(Color.blue);
   	   radioButtonGroup.setFont(new XFont("Courier", Font.BOLD, 12));
   	   radioButtonGroup.addItem(new KeyItem(new Integer(1), "AAAAA"));
   	   radioButtonGroup.addItem(new KeyItem(new Integer(2), "BBBBB"));
   	   radioButtonGroup.addItem(new KeyItem(new Integer(3), "CCCCC"));
   	   radioButtonGroup.addItem(new KeyItem(new Integer(4), "DDDDD"));
   	   radioButtonGroup.setValue(new Integer(2));
   	   radioButtonGroup.setGap(10);   	   
   	   radioButtonGroup.setDescription("ja som radio button group");
   	   radioButtonGroup.addMouseEvent(new ServerMouseEvent(ServerEvent.MOUSE_CLICKED_EVENT));
   	   radioButtonGroup.addFocusEvent(new ServerFocusEvent(ServerEvent.FOCUS_GAINED_EVENT));
   	   radioButtonGroup.addKeyEvent(new ServerKeyEvent(ServerEvent.KEY_TYPED_EVENT));
   	   radioButtonGroup.addSelectionEvent(new ServerSelectionEvent());
   	   
   	   XBoxPanel panel = new XBoxPanel();
   	   panel.add(radioButtonGroup);   	   
   	   panel.addGap(10);
   	   
   	   XRadioButtonGroup radioButtonGroup1 = new XRadioButtonGroup("radioButtonGroupH", SwingConstants.HORIZONTAL);
   	   radioButtonGroup1.setFont(new XFont("Courier", Font.BOLD, 12));
   	   radioButtonGroup1.addItem(new KeyItem(new Integer(1), "AAAAA"));
   	   radioButtonGroup1.addItem(new KeyItem(new Integer(2), "BBBBB"));
   	   radioButtonGroup1.addItem(new KeyItem(new Integer(3), "CCCCC"));
   	   radioButtonGroup1.addItem(new KeyItem(new Integer(4), "DDDDD"));
   	   radioButtonGroup1.setEnabled(true);
   	   panel.add(radioButtonGroup1);   	   
   	   panel.addGap(20);
   	   
   	   ServerActionEvent event = new ServerActionEvent();
   	   event.setReturnAllValues(true);
   	   panel.add(new XButton("Potvrd", "Potvrd", event));   	   
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Radio button group");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }
	
   public static void main(String...strings) {
	   MediatorRunner.run(DemoRadioButtonGroup.class, null, null, "flat");
   }	
}
