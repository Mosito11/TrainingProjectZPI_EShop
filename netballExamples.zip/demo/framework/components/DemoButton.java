package demo.framework.components;

import java.awt.Color;
import java.awt.Font;

import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XFont;
import netball.server.component.XForm;
import netball.server.component.XIcon;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientFocusEvent;
import netball.server.event.ClientKeyEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerEvent;
import netball.server.event.ServerFocusEvent;
import netball.server.event.ServerKeyEvent;
import netball.server.event.ServerMouseEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.utilities.Utilities;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoButton extends BasicMediator { 

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
   	   byte[] icon = Utilities.loadIcon("src/demo/framework/components/duke.gif");   	      	       	   
   	   
   	   XButton button = new XButton("Hore", "<html>Hore</html>");
   	   button.setBackground(Color.yellow);
   	   button.setForeground(Color.blue);
   	   button.setFont(new XFont("Courier", Font.BOLD, 12));
   	   button.setMnemonic('H');
   	   button.setVerticalTextPosition(javax.swing.SwingConstants.TOP);                
   	   button.setIcon(new XIcon(icon));
   	   button.setDescription("ja som tlacitko");
   	   //button.setWidth(200);
   	   button.setHorizontalAlignment(javax.swing.SwingUtilities.RIGHT);
   	   button.addMouseEvent(new ServerMouseEvent(ServerEvent.MOUSE_CLICKED_EVENT));   	   
   	   button.addFocusEvent(new ServerFocusEvent(ServerEvent.FOCUS_GAINED_EVENT));
   	   button.addKeyEvent(new ServerKeyEvent(ServerEvent.KEY_TYPED_EVENT));
   	   button.addActionEvent(new ServerActionEvent());
   	   XBoxPanel panel = new XBoxPanel(javax.swing.SwingConstants.VERTICAL);
   	   panel.setSameSizeForAllComponents(true);   	   
   	   panel.add(button);
   	   
   	   button = new XButton("Dole", "Dole");
   	   button.setBackground(Color.red);
   	   button.setForeground(Color.blue);
   	   button.setFont(new XFont("Courier", Font.BOLD, 12));
   	   button.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);                
   	   button.setMnemonic('D');
   	   button.setIcon(new XIcon(icon));
   	   panel.add(button);
   	   
   	   button = new XButton("Vlavo", "Vlavo");
   	   button.setBackground(Color.green);
   	   button.setForeground(Color.blue);
   	   button.setFont(new XFont("Courier", Font.BOLD, 12));
   	   button.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);        
   	   button.setMnemonic('L');
   	   button.setIcon(new XIcon(icon));
   	   panel.add(button);

   	   button = new XButton("Vpravo", "Vpravo");
   	   button.setBackground(Color.darkGray);
   	   button.setForeground(Color.blue);
   	   button.setFont(new XFont("Courier", Font.BOLD, 12));
   	   button.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);        
   	   button.setMnemonic('P');
   	   button.setIcon(new XIcon(icon));
   	   panel.add(button);


   	   button = new XButton("DoleCentrovany", "DoleCentrovany");
   	   button.setBackground(Color.pink);
   	   button.setForeground(Color.blue);
   	   button.setFont(new XFont("Courier", Font.BOLD, 12));
       button.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
       button.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);		
   	   button.setMnemonic('C');
   	   button.setIcon(new XIcon(icon));
   	   panel.add(button);

   	   button = new XButton("HoreCentrovany", "HoreCentrovany");
   	   button.setBackground(Color.cyan);
   	   button.setForeground(Color.blue);
   	   button.setFont(new XFont("Courier", Font.BOLD, 12));
       button.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
       button.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);		
   	   button.setMnemonic('H');
   	   button.setIcon(new XIcon(icon));
   	   panel.add(button);
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Button");
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }
	
	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void focusEventExecuted(ClientFocusEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void keyEventExecuted(ClientKeyEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}
	
	public static void main(String...strings) {
		MediatorRunner.run(DemoButton.class, null, null, "metal");
	}
}
