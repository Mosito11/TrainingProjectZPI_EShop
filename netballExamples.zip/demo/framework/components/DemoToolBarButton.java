package demo.framework.components;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;

import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.plaf.FontUIResource;

import netball.client.ui.jtc.awt.lookandfeel.MetalLookAndFeelNew;
import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XFont;
import netball.server.component.XForm;
import netball.server.component.XMenu;
import netball.server.component.XTextArea;
import netball.server.component.XToolBarButton;
import netball.server.component.XToolBarPopupMenuButton;
import netball.server.component.XToolBarToggleButton;
import netball.server.component.property.ToolBarToggleButtonProperties;
import netball.server.component.setting.ToolBarToggleButtonSettings;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MDUtilities;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoToolBarButton extends BasicMediator {

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}
	
	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
		System.out.println(event);
		if (event.getSourceId().equals("updateButton")) {
			ToolBarToggleButtonProperties properties = (ToolBarToggleButtonProperties) event.getPropertie("button0");
			ToolBarToggleButtonSettings settings = new ToolBarToggleButtonSettings();
			settings.setIcon(!properties.isSelected ? MDUtilities.loadIcon(MDUtilities.ADD_ICON, getSessionObject()) : MDUtilities.loadIcon(MDUtilities.PRINT_ICON, getSessionObject()));
			settings.setSelected(!properties.isSelected);
			ValuePack valuePack = new ValuePack();
			valuePack.put("button0", settings);
			pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
		}
	}



	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
		XBoxPanel panel = new XBoxPanel(SwingConstants.HORIZONTAL);
		
		XToolBarToggleButton button = new XToolBarToggleButton("button0", MDUtilities.loadIcon(MDUtilities.READ_ICON, getSessionObject()), "button0");
		button.addActionEvent(new ServerActionEvent());
		button.setSelected(true);
		panel.add(button);

		XToolBarButton button1 = new XToolBarButton("button1", MDUtilities.loadIcon(MDUtilities.PRINT_ICON, getSessionObject()), "button1");
		button1.setText("Print");
		button1.setEnabled(true);
		button1.setHeight(60);
		button1.setWidth(60);
		button1.setFont(new XFont("Dialog", Font.BOLD, 12));
    	button1.setVerticalTextPosition(SwingConstants.BOTTOM);    	
    	button1.setHorizontalTextPosition(SwingConstants.CENTER);
    	button1.setVerticalAlignment(SwingConstants.CENTER);
    	button1.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(button1);

		XToolBarPopupMenuButton button2 = new XToolBarPopupMenuButton("button2", MDUtilities.loadIcon(MDUtilities.REFRESH_ICON, getSessionObject()), "button2");
		button2.setText("Popup menu");
		button2.addMenuItem(new XMenu("Popup menu item0"));
		button2.addMenuItem(new XMenu("Popup menu item1"));		   	   
		panel.add(button2);

		XButton buttonUpdate = new XButton("updateButton", "Update button");
		ServerActionEvent event = new ServerActionEvent();
		event.addReturnProperty("button0");
		buttonUpdate.addActionEvent(event);		
		
		XBorderPanel mainPanel = new XBorderPanel(10, 10);
		mainPanel.setInsets(new Insets(10, 10, 10, 10));
		mainPanel.setNorth(panel);
		mainPanel.setSouth(buttonUpdate);
		mainPanel.setCenter(new XTextArea("textArea", "TextArea"));
		
   	    XForm form = new XForm();
   	    form.setPanel(mainPanel);
   	    form.setSize(new Dimension(400, 400));
   	    form.setTitle("Tool tip text button");
   	    serverPack.addFormPack(new FormPack(getId(), form));   	   
	}

	public static void main(String...strings) {
		MediatorRunner.run(DemoToolBarButton.class, null, null, "metal");
	} 
}
