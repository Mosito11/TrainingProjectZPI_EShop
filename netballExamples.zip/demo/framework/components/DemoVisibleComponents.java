package demo.framework.components;

import java.awt.Insets;

import javax.swing.SwingConstants;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XForm;
import netball.server.component.XTextField;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoVisibleComponents extends BasicMediator { 

	boolean isVisble = true; 
	
	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
	   XBoxPanel panel = new XBoxPanel(SwingConstants.VERTICAL);  	
   	   panel.add(new XTextField("tf1", null, 20));
   	   panel.addGap(5);
   	   panel.add(new XTextField("tf2", null, 10));
   	   
   	   XDualComponentPanel panel1 = new XDualComponentPanel();
       panel1.add(new XTextField("tf3", "Text 1", 20));
       panel1.add(new XTextField("tf4", "Text 2", 15));
       panel1.add(new XTextField("tf5", "Text 3", 15));
       panel.addGap(5);
       panel.add(panel1);

   	   XBoxPanel buttonPanel = new XBoxPanel(SwingConstants.VERTICAL);
   	   buttonPanel.setHorizontalAlignment(SwingConstants.RIGHT);

   	   XButton button = new XButton("button", "Visible");
   	   button.addActionEvent(new ServerActionEvent());
   	   buttonPanel.add(button);
   	   
   	   XBorderPanel mainPanel = new XBorderPanel(10, 10);
   	   mainPanel.setInsets(new Insets(10, 10, 10, 10));
   	   mainPanel.setCenter(panel);
   	   mainPanel.setSouth(buttonPanel);
   	   
   	   XForm form = new XForm();
   	   form.setPanel(mainPanel); 
   	   form.setTitle("DemoVisibleComponents");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }

	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
		if (event.getSourceId().equals("button")) {
			isVisble = !isVisble;
			UpdatedPack updatedPack = new UpdatedPack(getId());
			updatedPack.addVisibleComponent("tf2", isVisble);
			updatedPack.addVisibleComponent("tf4", isVisble);
			pack.addUpdatedPack(updatedPack);
		}
	}

	public static void main(String...strings) {
		MediatorRunner.run(DemoVisibleComponents.class, null, null, "flat");
	}

}

