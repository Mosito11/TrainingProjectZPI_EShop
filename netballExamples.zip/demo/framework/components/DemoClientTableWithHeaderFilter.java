package demo.framework.components;

import java.awt.Insets;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XClientTable;
import netball.server.component.XExpressionField;
import netball.server.component.XForm;
import netball.server.component.XPrintTablePreview;
import netball.server.component.XTableColumn;
import netball.server.component.expressionfield.NumberExpressionConvertor;
import netball.server.component.renderer.LogicalRenderer;
import netball.server.component.setting.ClientTableSettings;
import netball.server.component.table.ClientTableRowCountChanger;
import netball.server.component.table.ClientTableSelectedRow;
import netball.server.component.table.TableContainer;
import netball.server.component.table.TableRow;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.alert.YesNoAlert;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netball.server.utilities.TypeValues;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoClientTableWithHeaderFilter extends BasicMediator { 
	
	
	private int lastId = 4; 
	
	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

   @Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	   if (event.getSourceId().equals("Pridaj")) {
   	   	  addNewRow(pack);
   	   }else if (event.getSourceId().equals("Vymaz")) {
   	   	  Object key = this.getSelectedKey(event.getValuePack());
   	   	  deleteRow(key, pack);
   	   }else if (event.getSourceId().equals("Oprav")) {
   	   	  Object key = this.getSelectedKey(event.getValuePack());
   	   	  updateRow(key, pack);
   	   }else if (event.getSourceId().equals("Refresh")) {
   	   	  refresh(pack);
   	   }else if (event.getSourceId().equals("Print")) {
   		  this.runNext(PrintMediator.class, new PrintMediator.Parameters("table", getId()), pack);
   	   }
   }
   
	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
   	   XClientTable table = new XClientTable("table");
   	   XTableColumn column = new XTableColumn("id");
   	   column.setVisible(false);
   	   table.addColumn(column);
   	   
   	   column = new XTableColumn("firstName", "First Name", 150);
   	   column.setFilterComponent(new XExpressionField());
   	   table.addColumn(column);
   	   
   	   column = new XTableColumn("lastName", "Last Name", 150);
   	   column.setFilterComponent(new XExpressionField());
   	   table.addColumn(column);
   	   
   	   column = new XTableColumn("sport", "Sport", 150);
   	   column.setFilterComponent(new XExpressionField());
   	   table.addColumn(column);
   	   
   	   column = new XTableColumn("years", "# of Years", 150);
   	   XExpressionField field = new XExpressionField();
   	   field.setConvertor(new NumberExpressionConvertor(TypeValues.INTEGER));
   	   column.setFilterComponent(field);
   	   table.addColumn(column);
   	
   	   column = new XTableColumn("vegetarian", "Vegetarian", 70);
   	   column.setRenderer(new LogicalRenderer());
   	   table.addColumn(column);
   	      	   
   	   table.setDataSource(createContainer());
   	   table.setSortable(true);
   	   table.setPrimaryKey("id");
   	   table.setVisibilityOfColumnsAllowed(true);
   	   table.setFreezeColumnsAllowed(true);
   	   table.setShowStatusRow(true);
   	   table.setWidth(700);
   	   table.setHeight(400);
   	   table.setShowRowNumber(true);
   	   // zaregistrovanie objektu, ktorych nas bude informovate o zmene poctu riadkov v tabulke
       ClientTableRowCountChanger changer = new ClientTableRowCountChanger() {
			@Override
			public void tableRowCountChanged(int rowCount, ServerPack pack) {
				// tu moze byt napr. znepristupnenie/zpristupnenie tlacitiek 
				System.out.println("rowCount=" + rowCount);
			}
       }; 
       table.setTableRowCountChanger(changer, this);
   	   
   	   XBoxPanel buttonPanel = new XBoxPanel();
   	   buttonPanel.setGapForAll(5);
   	   buttonPanel.setSameSizeForAllComponents(true);
   	   XButton button = new XButton("Pridaj", "Pridaj");   	      	   
   	   buttonPanel.add(button); 
   	   ServerActionEvent event = new ServerActionEvent();
   	   event.addReturnValue("table");   	      	   
   	   event.addAlert(new YesNoAlert("Skutocne si prajete vymazat polozku?"));
   	   button = new XButton("Vymaz", "Vymaz", event);   	   
   	   buttonPanel.add(button); 
   	   event = new ServerActionEvent();
   	   event.addReturnValue("table");   	      	   
   	   button = new XButton("Oprav", "Oprav", event);   	   
   	   buttonPanel.add(button); 
   	   buttonPanel.add(new XButton("Refresh", "Refresh")); 
   	   buttonPanel.add(new XButton("Print", "Print")); 

   	   XBorderPanel panel = new XBorderPanel(10, 10);
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.setCenter(table);   	      	      	      	   
   	   panel.setSouth(buttonPanel);
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Client table with header filter");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }
   
   private TableContainer createContainer() {
	   TableContainer container = new TableContainer(new String[]{"id", "firstName", "lastName", "sport", "years", "vegetarian"});
	   container.addNewRow(new Object[] {0, "Kathy", "Smith", "Snowboarding", 5, false});
	   container.addNewRow(new Object[] {1, "John", "Doe",	"Rowing", 3, true});
	   container.addNewRow(new Object[] {2, "Sue", "Black", "Knitting", 2, false});
	   container.addNewRow(new Object[] {3, "Jane", "White", "Speed reading", 20, true});
	   container.addNewRow(new Object[] {4, "Joe", "Brown", "Pool", 10, false});
       return container;
   }   
   
   private Object getSelectedKey(ValuePack pack) {
   	   ClientTableSelectedRow rows[] = (ClientTableSelectedRow[]) pack.getValue("table");
   	   if (rows  == null) 
   	      return null;
   	   return rows[0].getId();   
   }
   
   private void refresh(ServerPack pack) {
   	   ValuePack valuePack = new ValuePack();
   	   valuePack.put("table", createContainer());
   	   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
   }	
   
   private void addNewRow(ServerPack pack) {
   	   ClientTableSettings settings = new ClientTableSettings();
   	   TableRow row = new TableRow();
   	   lastId ++;
   	   row.add("id", lastId);
   	   row.add("firstName", "Juraj");
   	   row.add("lastName", "Janosik");
   	   row.add("sport", "Zbojnik");
   	   row.add("years", 15);
   	   row.add("vegetarian", false);
   	   settings.setInsertedRow(row);
   	   settings.setScrollRowToVisible(lastId);
   	   settings.setSelectedItem(lastId);
   	   ValuePack valuePack = new ValuePack();
   	   valuePack.put("table", settings);
   	   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
   } 
   
   private void deleteRow(Object key, ServerPack pack) {
   	   ClientTableSettings settings = new ClientTableSettings();
   	   settings.setDeletedRow(key);
   	   ValuePack valuePack = new ValuePack();
   	   valuePack.put("table", settings);
   	   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
   }
   
   private void updateRow(Object key, ServerPack pack) {
   	   ClientTableSettings settings = new ClientTableSettings();
   	   TableRow row = new TableRow(key);
   	   row.add("firstName", "Janko");
   	   row.add("lastName", "Hrasko");
   	   settings.setUpdatedRow(row);
   	   ValuePack valuePack = new ValuePack();
   	   valuePack.put("table", settings);
   	   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
   }	

   public static class PrintMediator extends BasicMediator {    

		@Override
		public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
		   Parameters prmts = (Parameters) parameters;
	   	   XPrintTablePreview preview = new XPrintTablePreview("viewer", prmts.tableId, prmts.mediatorId);
	   	   preview.setWidth(700);
	   	   preview.setHeight(500);
	   	   preview.setHeaderText("Zoznam");
	   	   XBorderPanel panel = new XBorderPanel();   	   
	   	   panel.setCenter(preview);
	   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel); 
	   	   form.setTitle("Preview");   	   
	   	   serverPack.addFormPack(new FormPack(getId(), form)); 
	    }

		@Override
		public AccessAction[] getAccessActions() {
			return null;
		}
		
		public static class Parameters implements MediatorParameters {
			public Object tableId;
			public Object mediatorId;
			
			public Parameters(Object tableId, Object mediatorId) {
				this.tableId = tableId;
				this.mediatorId = mediatorId; 
			}
		}
	}

    public static void main(String...strings) {
    	MediatorRunner.run(DemoClientTableWithHeaderFilter.class, null, null, "flat");
    } 
}
