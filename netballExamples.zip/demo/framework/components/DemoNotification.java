package demo.framework.components;

import java.awt.Dimension;
import java.awt.Insets;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XForm;
import netball.server.component.XTextField;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.Notification;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoNotification extends BasicMediator { 

		private int messageNumber = 1;
	
		public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
			if (event.getSourceId().equals("send")) {
				Notification notification = new Notification("Titulok", "Toto je sprava:" + messageNumber, Notification.INFORMATION_MESSAGE);
				messageNumber++;
				pack.setNotification(notification);
			}
		}

	   @Override
	   public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
		   XDualComponentPanel panel1 = new XDualComponentPanel();
		   panel1.add(new XTextField("firstName", "First Name", 20));
		   panel1.add(new XTextField("lastName", "Last Name", 30));		   

	   	   XBoxPanel buttonPanel = new XBoxPanel();
	   	   buttonPanel.setGapForAll(5);
		   
		   XButton button = new XButton("send", "Send message");
	   	   button.addActionEvent(new ServerActionEvent());
	   	   buttonPanel.add(button);
		   
	   	   XBorderPanel panel = new XBorderPanel(10, 10);
	   	   panel.setInsets(new Insets(10, 10, 10, 10));
	   	   panel.setCenter(panel1);
	   	   panel.setSouth(buttonPanel);
   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel);
	   	   form.setTitle("DemoNotification");
	   	   form.setSize(new Dimension(500, 500));	   	   
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	   	}

		@Override
		public AccessAction[] getAccessActions() {
			return null;
		}

		public static void main(String...strings) {
			MediatorRunner.run(DemoNotification.class, null, null, "flat");
		}
}