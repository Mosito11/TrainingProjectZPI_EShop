package demo.framework.components;

import java.awt.Color;

import javax.swing.SwingConstants;

import netball.server.print.PRAreaChart;
import netball.server.print.PRBarChart;
import netball.server.print.PRBubbleChart;
import netball.server.print.PRFlowPanel;
import netball.server.print.PRLineChart;
import netball.server.print.PRPage;
import netball.server.print.PRPageFormat;
import netball.server.print.PRPageSize;
import netball.server.print.PRPieChart;
import netball.server.print.PRReport;
import netball.server.print.PRScatterChart;
import netball.server.print.PRStackedBarChart;
import netball.server.print.PRXYChartFX.Group;
import netframework.mediator.MDReportPreview;
import netframework.mediator.MediatorRunner;

public class DemoPrintGraphChart {

	public PRPage createFirstPage() {
		PRReport page = new PRReport();
		PRFlowPanel panel = new PRFlowPanel(SwingConstants.VERTICAL);

		panel.addGap(20);
		panel.add(createAreaChart().createPRImage());

		panel.addGap(20);
		panel.add(createPieChart().createPRImage());

		panel.addGap(20);
		panel.add(createBarChart().createPRImage());

		panel.addGap(20);
		panel.add(createBubleChart().createPRImage());

		panel.addGap(20);
		panel.add(createLineChart().createPRImage());

		panel.addGap(15);
		panel.add(createScatterChart().createPRImage());

		panel.addGap(15);
		panel.add(createStackedBarChart().createPRImage());

		page.setBody(panel);		
		return page;
	}

	private PRAreaChart createAreaChart() {
		PRAreaChart chart = new PRAreaChart("PRAreaChart");

		chart.addGroup(createChartData1());
		chart.addGroup(createChartData2());

		return chart;
	}

	private PRBarChart createBarChart() {
		PRBarChart chart = new PRBarChart("PRBarChart");

		chart.addGroup(createChartData1());
		chart.addGroup(createChartData2());

		/*Group data = new Group("Data male");
		data.add("hodnota1", 2);
		data.add("hodnota2", 1);
		chart.addGroup(data);*/

		chart.getYAxis().setMinorTickVisible(false); //nebude zobrazovat male ciarky medzi hodnotami
		chart.getYAxis().setAutoRanging(false); //vypne automaticek nastavenie osi - v dalsich riadkoch treba nastavit rozsah osi
		chart.getYAxis().setUpperBound(3); //nastavi max rozsah osi
		chart.getYAxis().setTickUnit(1); //nastavi rozostup hodnot

		chart.setCategoryGap(150); //nastavi medzeru medzi stlpcekmi - podla medzery sa potom upravi sirka stlpcekov

		return chart;
	}

	private PRBubbleChart createBubleChart() {
		PRBubbleChart chart = new PRBubbleChart("PRBubbleChart");

		PRBubbleChart.Group data = new PRBubbleChart.Group("Data1");
		data.add(1, 1, 3);
		data.add(2, 2, 1);
		data.add(6, 6);
		chart.addGroup(data);

		data = new PRBubbleChart.Group("Data2", Color.BLUE);

		data.add(7, 6);
		chart.addGroup(data);

		return chart;
	}

	private PRLineChart createLineChart() {
		PRLineChart chart = new PRLineChart("PRLineChart");

		chart.addGroup(createChartData1());
		chart.addGroup(createChartData2());

		return chart;
	}

	private PRScatterChart createScatterChart() {
		PRScatterChart chart = new PRScatterChart("PRScatterChart");

		chart.addGroup(createChartData1());
		chart.addGroup(createChartData2());

		return chart;
	}

	private PRStackedBarChart createStackedBarChart() {
		PRStackedBarChart chart = new PRStackedBarChart("PRStackedBarChart", new String[] {
				"Kategoria1",
				"Kategoria2" });

		Group data = new Group("Data1");
		data.add("Kategoria1", 1);
		data.add("Kategoria2", 2);
		chart.addGroup(data);

		data = new Group("Data2");
		data.add("Kategoria1", 3);
		data.add("Kategoria2", 4);
		chart.addGroup(data);

		return chart;
	}

	private PRPieChart createPieChart() {
		PRPieChart chart = new PRPieChart("PieChart");

		chart.addValue("hodnota1", 3);
		chart.addValue("hodnota2", 1);
		chart.addValue("hodnota3", 4);
		chart.addValue("hodnota4", 1);

		return chart;
	}

	private Group createChartData1() {
		Group data = new Group("Data1");
		data.add("hodnota1", 1);
		data.add("hodnota2", 2);
		data.add("hodnota3", 7);
		data.add("hodnota4", 4);
		data.add("hodnota5", 9);
		data.add("hodnota6", 6);

		return data;
	}

	private Group createChartData2() {
		Group data = new Group("Data2");
		data.add("hodnota1", 3);
		data.add("hodnota2", 1);
		data.add("hodnota3", 6);
		data.add("hodnota4", 8);
		data.add("hodnota5", 5);
		data.add("hodnota6", 4);

		return data;
	}

	public PRPage[] getPages() {
		PRPage[] pages = new PRPage[1];
		pages[0] = createFirstPage();
		return pages;
	}

	public PRPageFormat getPageFormat() {
		PRPageSize size = new PRPageSize(210, 1100, "Custom");
		return new PRPageFormat(size);
	}

	public static void main(String... strings) {
		DemoPrintGraphChart print = new DemoPrintGraphChart();
		MediatorRunner.run(MDReportPreview.class, new MDReportPreview.ArrayPageParameters(print.getPages(), print.getPageFormat()), null, "metal");
	}

}
