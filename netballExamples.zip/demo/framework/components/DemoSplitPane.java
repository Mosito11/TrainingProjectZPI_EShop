package demo.framework.components;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.SwingConstants;

import netball.server.component.XForm;
import netball.server.component.XLabel;
import netball.server.component.XProportionaPanel;
import netball.server.component.XSplitPane;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoSplitPane extends BasicMediator { 
	
    @Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
   	   XSplitPane verticalSplit = new XSplitPane(XSplitPane.VERTICAL_SPLIT);
   	   XSplitPane horizontalSplit = new XSplitPane(XSplitPane.HORIZONTAL_SPLIT);
   	   
   	   XLabel label = new XLabel("LEFT SIDE");
   	   label.setVerticalAlignment(SwingConstants.CENTER);
   	   label.setHorizontalAlignment(SwingConstants.CENTER);
   	   label.setBackground(Color.RED);
   	   horizontalSplit.setLeft(label);

   	   label = new XLabel("RIGHT SIDE");
   	   label.setVerticalAlignment(SwingConstants.CENTER);
   	   label.setHorizontalAlignment(SwingConstants.CENTER);
   	   label.setBackground(Color.YELLOW);
   	   horizontalSplit.setRight(label);   	   
   	   
   	   label = new XLabel("BOTTOM SIDE");
   	   label.setVerticalAlignment(SwingConstants.CENTER);
   	   label.setHorizontalAlignment(SwingConstants.CENTER);
   	   label.setBackground(Color.GRAY);
   	   verticalSplit.setBottom(label);
   	   
   	   label = new XLabel("TOP SIDE");
   	   label.setVerticalAlignment(SwingConstants.CENTER);
   	   label.setHorizontalAlignment(SwingConstants.CENTER);
   	   label.setBackground(Color.CYAN);
   	   verticalSplit.setTop(label);
   	   
   	   XProportionaPanel panel = new XProportionaPanel(SwingConstants.HORIZONTAL);
   	   panel.add(horizontalSplit, 0.5, true);
   	   panel.add(verticalSplit, 0.5, true);
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("DemoSplitPane");
   	   form.setSize(new Dimension(400, 200));
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }
	
   public static void main(String...strings) {
	   MediatorRunner.run(DemoSplitPane.class, null, null, "flat");
   }	
}
