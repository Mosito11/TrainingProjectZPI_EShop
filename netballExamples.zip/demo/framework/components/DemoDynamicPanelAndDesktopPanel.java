package demo.framework.components;

import java.awt.Dimension;
import java.util.ArrayList;
import java.util.List;

import javax.swing.SwingConstants;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XClientTable;
import netball.server.component.XDesktopPanel;
import netball.server.component.XDynamicPanel;
import netball.server.component.XForm;
import netball.server.component.XMenu;
import netball.server.component.XPanel;
import netball.server.component.XTableColumn;
import netball.server.component.XToolBarButton;
import netball.server.component.setting.DynamicPanelSettings;
import netball.server.component.table.TableContainer;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientWindowEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerWindowEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MDUtilities;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoDynamicPanelAndDesktopPanel extends BasicMediator { 

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
		   XMenu mainMenu = new XMenu("menu", "Menu"); 
		   mainMenu.add(new XMenu("zakaznik", "Zakaznik"));
		   mainMenu.add(new XMenu("osoba", "Osoba"));
		   mainMenu.add(new XMenu("auto", "Auto"));
		   List<XMenu> menu = new ArrayList<>(1);
		   menu.add(mainMenu);
		
	   	   XDesktopPanel desktopPanel = new XDesktopPanel("desktopPanel");
	   	   desktopPanel.setSize(new Dimension(700, 500));
	   	   
	   	   XDynamicPanel dynamicPanel = new XDynamicPanel("dynamicPanel");
	   	   dynamicPanel.setSize(new Dimension(0, 30));
	   	   
		   XBorderPanel panel = new XBorderPanel();
		   panel.setNorth(dynamicPanel);
		   panel.setCenter(desktopPanel);
		   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel); 
	   	   form.setTitle("Dynamic panel and desktop panel");
	   	   form.setMenu(menu);
	   	   
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	}

	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
		System.out.println("MainMediator:" + event);
		if (event.getSourceId().equals("zakaznik")) {
			this.runNext(InternalMediatorZakaznik.class, null, pack, this.getId(), "desktopPanel");
		}else if (event.getSourceId().equals("osoba")) {
			this.runNext(InternalMediatorOsoba.class, null, pack, this.getId(), "desktopPanel");
		}else if (event.getSourceId().equals("auto")) {
			this.runNext(InternalMediatorAuto.class, null, pack, this.getId(), "desktopPanel");
		}
	}
	
	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
    protected void childMediatorRemoved(ServerPack pack) {
	   if (getChildrenCount() == 0) {
		   DynamicPanelSettings settings = new DynamicPanelSettings();
		   settings.setComponent(null);
		   ValuePack valuePack = new ValuePack();
		   valuePack.put("dynamicPanel", settings);
		   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
	   }
    }
	
	public static void main(String...strings) {
		MediatorRunner.run(DemoDynamicPanelAndDesktopPanel.class, null, null, "flat");
	}
	
	public abstract static class InternalAbstracMediator extends BasicMediator { 
		 
		protected String TABLE = "table";
		
		@Override
		public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
		   XBorderPanel panel = new XBorderPanel();
		   panel.setCenter(createTable());
		   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel);
	   	   form.setTitle(getTitle() + " " + getId());
	   	   
	   	   form.addWindowEvent(new ServerWindowEvent(ServerWindowEvent.WINDOW_ACTIVATED_EVENT));
	   	   form.addWindowEvent(new ServerWindowEvent(ServerWindowEvent.WINDOW_DEACTIVATED_EVENT));
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
       }
		
	   protected abstract XClientTable createTable();
	   
	   protected abstract String getTitle();

	   protected XPanel createToolButtonPanel() {
		   XBoxPanel panel = new XBoxPanel(SwingConstants.HORIZONTAL);
		   panel.setSameSizeForAllComponents(true);
		   
		   XToolBarButton button = new XToolBarButton("pridaj", MDUtilities.loadIcon(MDUtilities.ADD_ICON, getSessionObject()));
		   button.setText("Pridaj");
		   button.addActionEvent(new ServerActionEvent(getId()));
		   panel.add(button);
		   
		   button = new XToolBarButton("oprav", MDUtilities.loadIcon(MDUtilities.CORRECT_ICON, getSessionObject()));
		   button.setText("Oprav");
		   ServerActionEvent event = new ServerActionEvent(getId());
		   event.addReturnValue(TABLE);
		   button.addActionEvent(event);
		   panel.add(button);

		   button = new XToolBarButton("vymaz", MDUtilities.loadIcon(MDUtilities.DELETE_ICON, getSessionObject()));
		   button.setText("Vymaz");
		   event = new ServerActionEvent(getId());
		   event.addReturnValue(TABLE);
		   button.addActionEvent(event);
		   panel.add(button);
		   return panel;
	   }	
		
	   @Override
	   public AccessAction[] getAccessActions() {
			return null;
	   }
	   
	   protected Object getMainMediatorId() {
		  return getMediatorIds(DemoDynamicPanelAndDesktopPanel.class)[0];
	   }

	   @Override
	   public void windowEventExecuted(ClientWindowEvent event, ServerPack pack) {
		  if (event.getCode() == ServerWindowEvent.WINDOW_ACTIVATED_EVENT) {
			   DynamicPanelSettings settings = new DynamicPanelSettings();
			   settings.setComponent(createToolButtonPanel());
			   ValuePack valuePack = new ValuePack();
			   valuePack.put("dynamicPanel", settings);
			   // pozor nastavi sa is hlavneho okna !!!  
			   pack.addUpdatedPack(new UpdatedPack(getMainMediatorId(), valuePack));
		  }
		  super.windowEventExecuted(event, pack);
	   }
	}
	
	public static class InternalMediatorOsoba extends InternalAbstracMediator { 

		@Override
		protected XClientTable createTable() {
			   XClientTable table = new XClientTable(TABLE);
			   table.addColumn(new XTableColumn("meno", "Meno", 200));
			   table.addColumn(new XTableColumn("priezvisko", "Priezvisko", 200));
			   
			   TableContainer container = new TableContainer(new Object[] {"meno", "priezvisko"});
			   container.addNewRow(new Object[] {"Janko", "Hrasko"});
			   container.addNewRow(new Object[] {"Juraj", "Janosik"});
			   table.setDataSource(container);
			   return table; 
		}
		
		@Override
		public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
			System.out.println("Osoby " + getId() + ":" + event);
		}
		
		@Override
		protected String getTitle() {
			return "Osoby";
		}
	}
	
	public static class InternalMediatorZakaznik extends InternalAbstracMediator { 

		@Override
		protected XClientTable createTable() {
			   XClientTable table = new XClientTable(TABLE);
			   table.addColumn(new XTableColumn("ico", "Ico", 200));
			   table.addColumn(new XTableColumn("nazov", "Nazov", 200));
			   
			   TableContainer container = new TableContainer(new Object[] {"ico", "nazov"});
			   container.addNewRow(new Object[] {"123456", "Coca colo"});
			   container.addNewRow(new Object[] {"654321", "IBM"});
			   table.setDataSource(container);
			   return table; 
		}

		@Override
	    protected XPanel createToolButtonPanel() {
			 XBoxPanel panel = (XBoxPanel) super.createToolButtonPanel();
			 XToolBarButton button = new XToolBarButton("tlac", MDUtilities.loadIcon(MDUtilities.PRINT_ICON, getSessionObject()));
			 button.setText("Tlac");
			 button.addActionEvent(new ServerActionEvent(getId()));
			 panel.add(button);
			 return panel;
		}
		
		@Override
		public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
			System.out.println("zakaznici " + getId() + ":" + event);
		}
		
		@Override
		protected String getTitle() {
			return "Zakaznici";
		}
	}

	public static class InternalMediatorAuto extends InternalAbstracMediator { 

		@Override
		protected XClientTable createTable() {
			   XClientTable table = new XClientTable(TABLE);
			   table.addColumn(new XTableColumn("znacka", "Znacka", 200));
			   table.addColumn(new XTableColumn("typ", "Typ", 200));
			   
			   TableContainer container = new TableContainer(new Object[] {"znacka", "Znacka"});
			   container.addNewRow(new Object[] {"Ford", "Focus"});
			   container.addNewRow(new Object[] {"Skoda", "Oktavia"});
			   table.setDataSource(container);
			   return table; 
		}

		@Override
	    protected XPanel createToolButtonPanel() {
			 XBoxPanel panel = (XBoxPanel) super.createToolButtonPanel();
			 XToolBarButton button = new XToolBarButton("filter", MDUtilities.loadIcon(MDUtilities.FILTER_ICON, getSessionObject()));
			 button.setText("Filter");
			 button.addActionEvent(new ServerActionEvent(getId()));
			 panel.add(button);
			 return panel;
		}
		
		@Override
		public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
			System.out.println("Auta " + getId() + ":" + event);
		}
		
		@Override
		protected String getTitle() {
			return "Auta";
		}
	}
	
}
