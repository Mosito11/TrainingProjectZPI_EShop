package demo.framework.components;

import java.io.File;
import java.util.Locale;

import netframework.classbuilder.bo.ConstantAttributeProperties;
import netframework.classbuilder.bo.ContainerAttributeProperties;
import netframework.classbuilder.bo.DateAttributeProperties;
import netframework.classbuilder.bo.DateType;
import netframework.classbuilder.bo.DirectToFieldMap;
import netframework.classbuilder.bo.GeneratedClass;
import netframework.classbuilder.bo.GeneratedClassAttribute;
import netframework.classbuilder.bo.GeneratedRules;
import netframework.classbuilder.bo.GeneratedRules.TypeMD;
import netframework.classbuilder.bo.GeneratedRules.TypeMapping;
import netframework.classbuilder.bo.GeneratedRules.TypeUC;
import netframework.classbuilder.bo.GeneratedRules.TypeView;
import netframework.classbuilder.bo.ManyToManyMap;
import netframework.classbuilder.bo.NumberAttributeProperties;
import netframework.classbuilder.bo.OneToManyMap;
import netframework.classbuilder.bo.OneToOneMap;
import netframework.classbuilder.bo.RelationAttributeProperties;
import netframework.classbuilder.bo.TextAttributeProperties;
import netframework.classbuilder.md.MDClassCreator;
import netframework.classbuilder.md.UCComponentCreator;
import netframework.classbuilder.md.UCCreator;
import netframework.classbuilder.md.UCMappingCreator;
import netframework.classbuilder.md.UCMediatorCreator;
import netframework.classbuilder.md.UCPersistentObjectCreator;
import netframework.classbuilder.md.UCTableCreator;
import netframework.classbuilder.md.UCViewCreator;
import netframework.mediator.MediatorRunner;

public class DemoClassGenerator {

	private GeneratedClass generatedClass = new GeneratedClass();
	
	public DemoClassGenerator(String dir) {
		if (dir == null) 
			dir = "C:/TEST/src";
		generatedClass.setName("Test");
		generatedClass.setPackage("bo");
		//generatedClass.setImports("eeee,rrrr,cccc");
		//generatedClass.setAbstract(true);
		//generatedClass.setExtendClass("Extend");
		//generatedClass.setImplementInterfaces("Implemnt1, Implement2");
		generatedClass.setTable("test");
		generatedClass.setPrimaryKeyField("id");
		
		GeneratedClassAttribute attribute = new GeneratedClassAttribute();
		attribute.setName("text");
		attribute.setType("String");
		TextAttributeProperties textAttributeProperties = new TextAttributeProperties();
		textAttributeProperties.setCaption("Text caption");
		textAttributeProperties.setLongCaption("Text long caption");
		textAttributeProperties.setColumnName("Text\ncolumn");
		textAttributeProperties.setLongColumnName("Text\nlong\ncolumn");
		textAttributeProperties.setName("TEXT");
		attribute.setAttribute(textAttributeProperties);
		DirectToFieldMap directToFieldMap = new DirectToFieldMap();
		directToFieldMap.setField("text");
		attribute.setMapping(directToFieldMap);
		generatedClass.getAttributes().add(attribute);
		
		attribute = new GeneratedClassAttribute();
		attribute.setName("number");
		attribute.setType("int");
		NumberAttributeProperties numberAttributeProperties = new NumberAttributeProperties();
		numberAttributeProperties.setName("NUMBER");
		numberAttributeProperties.setCaption("Number caption");
		numberAttributeProperties.setLongCaption("Number long caption");
		attribute.setAttribute(numberAttributeProperties);
		directToFieldMap = new DirectToFieldMap();
		directToFieldMap.setField("number");
		attribute.setMapping(directToFieldMap);		
		generatedClass.getAttributes().add(attribute);
		
		attribute = new GeneratedClassAttribute();
		attribute.setName("relation");
		attribute.setType("Relation");
		RelationAttributeProperties relationAttributeProperties = new RelationAttributeProperties();
		relationAttributeProperties.setName("RELATION");
		attribute.setAttribute(relationAttributeProperties);
		generatedClass.getAttributes().add(attribute);
		OneToOneMap oneToOneMap = new OneToOneMap();
		oneToOneMap.setSourceForeignKeyField("relation_id");
		oneToOneMap.setTargetPrimaryKeyField("id");
		attribute.setMapping(oneToOneMap);

		attribute = new GeneratedClassAttribute();
		attribute.setName("container");
		attribute.setType("ContainerTrieda");
		ContainerAttributeProperties containerAttributeProperties = new ContainerAttributeProperties();
		containerAttributeProperties.setName("CONTAINER");
		attribute.setAttribute(containerAttributeProperties);
		generatedClass.getAttributes().add(attribute);
		OneToManyMap oneToManyMap = new OneToManyMap();
		oneToManyMap.setTargetPrimaryKeyField("test_id");
		attribute.setMapping(oneToManyMap);

		attribute = new GeneratedClassAttribute();
		attribute.setName("containerManyToMany");
		attribute.setType("ContainerManyToManyTrieda");
		containerAttributeProperties = new ContainerAttributeProperties();
		containerAttributeProperties.setName("CONTAINER_MANY_TO_MANY");
		attribute.setAttribute(containerAttributeProperties);
		generatedClass.getAttributes().add(attribute);
		ManyToManyMap manyToMany = new ManyToManyMap();
		manyToMany.setRelationTable("ManyToMany");
		manyToMany.setSourceForeignKeyField("test_id");
		manyToMany.setTargetPrimaryKeyField("container_id");
		manyToMany.setRelationTable("container_many_to_many");
		attribute.setMapping(manyToMany);
		
		attribute = new GeneratedClassAttribute();
		attribute.setName("konstant");
		attribute.setType("Konstant");
		ConstantAttributeProperties constantAttributeProperties = new ConstantAttributeProperties();
		constantAttributeProperties.setName("KONSTANT");
		constantAttributeProperties.setConstants("Konstant.ZOZNAM");		
		attribute.setAttribute(constantAttributeProperties);
		directToFieldMap = new DirectToFieldMap();
		directToFieldMap.setField("konstant");
		attribute.setMapping(directToFieldMap);		
		generatedClass.getAttributes().add(attribute);

		attribute = new GeneratedClassAttribute();
		attribute.setName("accountDate");
		attribute.setType("AccountDate");
		DateAttributeProperties dateAttributeProperties = new DateAttributeProperties();
		dateAttributeProperties.setName("ACCOUNT_DATE");
		dateAttributeProperties.setType(DateType.ACCOUNT_DATE);
		attribute.setAttribute(dateAttributeProperties);
		directToFieldMap = new DirectToFieldMap();
		directToFieldMap.setField("account_date");
		attribute.setMapping(directToFieldMap);
		generatedClass.getAttributes().add(attribute);
		
		generatedClass.setDirectory(dir + "/bo");
		GeneratedRules rules = generatedClass.getGeneratedRules();
		//rules.typeUC = TypeUC.EXTENDS_PERSISTENT_OBJECT;
		rules.typeUC = TypeUC.EXTENDS_PERSISTENT_OBJECT_ITEM;
		rules.packageUC = "uc";
		rules.directoryUC = dir + "/" + rules.packageUC;
		rules.hasGeneratedUC = true;
		
		rules.packageDB = "db";
		rules.directoryDB = dir + "/" + rules.packageDB;
		rules.hasGeneratedDB = true;

		//rules.typeView = TypeView.EXTENDS_ECLIPSELINK_VIEW;
		rules.typeView = TypeView.EXTENDS_VIEW_SQL;
		rules.packageView = "view";
		rules.directoryView = dir + "/" + rules.packageView;
		rules.hasGeneratedView = true;
		
		//rules.typeMD = TypeMD.BASE;
		//rules.typeMD = TypeMD.LIKE_ITEM;
		rules.typeMD = TypeMD.WITH_ITEMS;
		rules.packageMD = "md";
		rules.directoryMD = dir + "/" + rules.packageMD;
		rules.hasGeneratedMD = true;
		rules.hasGeneratedMDView = true;
		rules.hasGeneratedMDFilter = true;
		
		rules.packageComponent = "comp";
		rules.directoryComponent = dir + "/" + rules.packageComponent;
		rules.hasGeneratedComponent = true;
		
		rules.packageMapping = "mapping";
		rules.directoryMapping = dir + "/" + rules.packageMapping;
		rules.hasGeneratedMapping = true;
		rules.typeMapping = TypeMapping.USE_CONSTANTS;
		//rules.typeMapping = TypeMapping.DO_NOT_USE_CONSTANTS;
	}
	
	public void run() {
		Locale.setDefault(Locale.UK);
		createDirectories();
		MediatorRunner.run(MDClassCreator.class, new MDClassCreator.Parameters(generatedClass));
	} 
	
	private void createDirectories() {
		GeneratedRules rules = generatedClass.getGeneratedRules();
		new File(generatedClass.getDirectory()).mkdirs();
		new File(rules.directoryUC).mkdirs();
		new File(rules.directoryDB).mkdirs();
		new File(rules.directoryView).mkdirs();
		new File(rules.directoryMD).mkdirs();
		new File(rules.directoryComponent).mkdirs();
		new File(rules.directoryMapping).mkdirs();
	}
	
	private void generate() {
		createDirectories();
		try {
			new UCPersistentObjectCreator().execute(generatedClass);
			new UCMappingCreator().execute(generatedClass);
			new UCTableCreator().execute(generatedClass);
			new UCCreator().execute(generatedClass);
			new UCViewCreator().execute(generatedClass);
			new UCComponentCreator().execute(generatedClass);
			new UCMediatorCreator().execute(generatedClass);
			System.out.println("koniec");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String...strings) {
		new DemoClassGenerator(null).run(); 
		//new DemoClassGenerator(null).generate(); 
	} 
}

