package demo.framework.components;

import java.awt.Font;
import java.awt.Insets;

import javax.swing.UIManager;

import netball.client.ui.jtc.awt.lookandfeel.MetalLookAndFeelNew;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XForm;
import netball.server.component.XToggleSwitch;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientFocusEvent;
import netball.server.event.ClientKeyEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ClientStateChangedEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerStateChangedEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoToggleSwitch extends BasicMediator { 

	@Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void focusEventExecuted(ClientFocusEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void keyEventExecuted(ClientKeyEvent event, ServerPack pack) {
		System.out.println(event);
	}
 
	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	   if (event.getSourceId().equals("Potvrd")) {
   	   	   System.out.println(event.getValuePack());
   	   	   System.out.println(event.getProperties());
   	   }	  
    }
	
	@Override
	public void stateChangedEventExecuted(ClientStateChangedEvent event, ServerPack pack) {
		if (event.getSourceId().equals("toggleSwitch")) {
			Object value = event.getValuePack().getValue("toggleSwitch");
			System.out.println(value);
		}
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
   	   XToggleSwitch toggleSwitch = new XToggleSwitch("toggleSwitch", "Toggle switch");
   	   //toggleSwitch.setBackground(Color.yellow);
   	   //toggleSwitch.setForeground(Color.blue);
   	   //toggleSwitch.setFont(new XFont("Courier", Font.BOLD, 25));
   	   toggleSwitch.setDescription("ja som toggle swith");
   	   //toggleSwitch.addMouseEvent(new ServerMouseEvent(ServerEvent.MOUSE_CLICKED_EVENT));
   	   //toggleSwitch.addFocusEvent(new ServerFocusEvent(ServerEvent.FOCUS_GAINED_EVENT));
   	   //toggleSwitch.addKeyEvent(new ServerKeyEvent(ServerEvent.KEY_TYPED_EVENT));
   	   
   	   ServerStateChangedEvent changeEvent = new ServerStateChangedEvent();
   	   changeEvent.addReturnValue("toggleSwitch");
   	   toggleSwitch.addStateChangedEvent(changeEvent);
   	   
   	   toggleSwitch.setSelectedStateValue(new Integer(1));
   	   toggleSwitch.setDeselectedStateValue(new Integer(0));
   	   toggleSwitch.setSelected(true);
   	   //toggleSwitch.setEnabled(false);
   	   XBoxPanel panel = new XBoxPanel();
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.add(toggleSwitch);
   	   panel.addGap(20);
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Toggle Switch");
   	   
   	   ServerActionEvent event = new ServerActionEvent();
   	   event.setReturnAllValues(true);
   	   event.addReturnProperty("toggleSwitch");
   	   panel.add(new XButton("Potvrd", "Potvrd", event));   	   
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }

   @Override
	public AccessAction[] getAccessActions() {
		return null;
	}

    public static void main(String...strings) {
		UIManager.put(MetalLookAndFeelNew.DEFAULT_FONT, new Font("Dialog", Font.PLAIN, 13));
		UIManager.put("Slider.font", new Font("Dialog", Font.PLAIN, 13));

    	MediatorRunner.run(DemoToggleSwitch.class, null, null, "flat");
    }
}
