package demo.framework.components;

import java.awt.Insets;

import javax.swing.SwingConstants;

import netball.server.component.XClientTable;
import netball.server.component.XForm;
import netball.server.component.XList;
import netball.server.component.XProportionaPanel;
import netball.server.component.XTableColumn;
import netball.server.component.table.TableContainer;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoProportionalPanel extends BasicMediator { 


	  @Override
	  public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
           XClientTable table1 = new XClientTable("table1");
           table1.addColumn(new XTableColumn("col1", "Column 1", 70));
           table1.addColumn(new XTableColumn("col2", "Column 2", 70));
           table1.addColumn(new XTableColumn("col3", "Column 3", 70));
           TableContainer container = new TableContainer(new String[] {"col1", "col2", "col3"});
           for (int i = 0; i < 100; i ++) {
        	   container.addNewRow(new String[] {"value1", "value2", "value3"});
           }
           table1.setDataSource(container);
           
           XClientTable table2 = new XClientTable("table2");
           table2.addColumn(new XTableColumn("col1", "Column 1", 100));
           table2.addColumn(new XTableColumn("col2", "Column 2", 100));
           table2.addColumn(new XTableColumn("col3", "Column 3", 100));
           table2.addColumn(new XTableColumn("col4", "Column 4", 100));
           container = new TableContainer(new String[] {"col1", "col2", "col3", "col4"});
           for (int i = 0; i < 100; i ++) {
        	   container.addNewRow(new String[] {"value1", "value2", "value3", "valus4"});
           }
           table2.setDataSource(container);
           
           XList list = new XList("list");
           for (int i = 0; i < 20; i++) {
        	   list.addItem("item " + i);
           }
		   
           //XProportionaPanel panel = new XProportionaPanel(SwingConstants.HORIZONTAL);
           XProportionaPanel panel = new XProportionaPanel(SwingConstants.VERTICAL);
           panel.setInsets(new Insets(10, 10, 10, 10));
           panel.add(table1, 0.2);
           panel.addGap(10);
           panel.add(table2, 0.5);
           panel.addGap(10);
           panel.add(list, 0.3, false);
           panel.setHeight(700);
           panel.setWidth(600);
		  
	   	   XForm form = new XForm();
	   	   form.setPanel(panel); 
	   	   form.setTitle("Proportional panel");
	   	   
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	   }

		@Override
		public AccessAction[] getAccessActions() {
			return null;
		}
		
		public static void main(String...strings) {
			MediatorRunner.run(DemoProportionalPanel.class, null, null, "flat");
		} 
}	
