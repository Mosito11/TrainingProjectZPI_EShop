package demo.framework.components;

import java.awt.Insets;

import javax.swing.SwingConstants;

import netball.server.component.XBoxPanel;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XForm;
import netball.server.component.XTextArea;
import netball.server.component.XTextField;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MDUtilities;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoDualComponentPanel1 extends BasicMediator { 

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
   	   XDualComponentPanel panel1 = new XDualComponentPanel();
       panel1.add(new XTextField("item11", "Item panel 1.1", 200));
       panel1.add(new XTextField("item12", "Item panel 1.2", 25));
       
   	   XDualComponentPanel panel2 = new XDualComponentPanel();
   	   panel2.add(new XTextField("item21", "Item panel 2.1", 10));
   	   panel2.add(new XTextField("item22", "Item panel 2.2 max", 9));
       panel2.add(new XTextField("item23", "Item panel 2.3", 8));
       panel2.addGap(10);
       panel2.add(new XTextField("item24", "Item panel 2.4", 7));
       
       XDualComponentPanel panel3 = new XDualComponentPanel();
   	   panel3.add(new XTextField("item31", "Item panel 3.1", 8));
   	   panel3.add(new XTextField("item32", "Item panel 3.2", 9));
       panel3.add(new XTextField("item33", "Item panel 3.3", 10));
       
       XDualComponentPanel panel4 = new XDualComponentPanel();
       XTextArea ta = new XTextArea("item41");
       ta.setCaption("Item panel 4.1 max max");
       ta.setVisibleRowCount(5);
       ta.setWidth(400);
       panel4.add(ta.getCaption(), ta);

       MDUtilities.setMaxCaptionWidth(null, panel1, panel2, panel4);

       XBoxPanel boxPanel1 = new XBoxPanel(SwingConstants.HORIZONTAL);
       boxPanel1.add(panel2);
       boxPanel1.addGap(10);
       boxPanel1.add(panel3);
       
       XBoxPanel boxPanel2 = new XBoxPanel(SwingConstants.VERTICAL);
       boxPanel2.setInsets(new Insets(10, 10, 10, 10));
       boxPanel2.add(panel1);
       boxPanel2.addGap(5);
       boxPanel2.add(boxPanel1);
       boxPanel2.addGap(5);
       boxPanel2.add(panel4);

   	   XForm form = new XForm();
   	   form.setPanel(boxPanel2); 
   	   form.setTitle("DualComponentPanel1");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }
	
	public static void main(String...strings) {
		MediatorRunner.run(DemoDualComponentPanel1.class, null, null, "flat");
	}

}
