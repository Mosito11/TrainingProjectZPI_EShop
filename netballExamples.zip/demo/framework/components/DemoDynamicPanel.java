package demo.framework.components;

import java.awt.Dimension;
import java.awt.Insets;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XDynamicPanel;
import netball.server.component.XForm;
import netball.server.component.XTextField;
import netball.server.component.setting.DynamicPanelSettings;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoDynamicPanel extends BasicMediator { 

	   @Override
	   public AccessAction[] getAccessActions() {
	   	   return null;
	   }

	   @Override
		public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
		   if (event.getSourceId().equals("form1")) {
			   DynamicPanelSettings settings = new DynamicPanelSettings();
			   XDualComponentPanel panel = new XDualComponentPanel();
			   panel.add(new XTextField("menoField", "Meno", 20));
			   panel.add(new XTextField("priezviskoField", "Priezvisko", 20));
			   settings.setComponent(panel);
			   ValuePack valuePack = new ValuePack();
			   valuePack.put("dynamicPanel", settings);
			   valuePack.put("menoField", "Janko");
			   valuePack.put("priezviskoField", "Hrasko");
			   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
		   }else if (event.getSourceId().equals("form2")) {
			   DynamicPanelSettings settings = new DynamicPanelSettings();
			   XDualComponentPanel panel = new XDualComponentPanel();
			   panel.add(new XTextField("znackaField", "Znacka vozidla", 15));
			   panel.add(new XTextField("typField", "Typ vozidla", 15));
			   settings.setComponent(panel);
			   ValuePack valuePack = new ValuePack();
			   valuePack.put("dynamicPanel", settings);
			   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
		   }else if (event.getSourceId().equals("reset")) {
			   DynamicPanelSettings settings = new DynamicPanelSettings();
			   settings.setComponent(null);
			   ValuePack valuePack = new ValuePack();
			   valuePack.put("dynamicPanel", settings);
			   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
		   }else if (event.getSourceId().equals("returnValues")) {
			   System.out.println(event.getValuePack());
		   }else if (event.getSourceId().equals("setValues")) {
			   ValuePack valuePack = new ValuePack();
			   valuePack.put("znackaField", "znacka");
			   valuePack.put("typField", "typ");
			   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
		   }
	   }

	   @Override
	   public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
	   	   XBorderPanel mainPanel = new XBorderPanel();
	   	   XDynamicPanel dynamicPanel = new XDynamicPanel("dynamicPanel");
	   	   dynamicPanel.setSize(new Dimension(500, 200));
	   	   dynamicPanel.setInsets(new Insets(10, 10, 10, 10));
	   	   
	   	   XBoxPanel buttonPanel = new XBoxPanel();
	   	   buttonPanel.setSameSizeForAllComponents(true);
	   	   buttonPanel.setGapForAll(5);
	   	   
	   	   XButton button = new XButton("form1", "Form 1");
	   	   button.addActionEvent(new ServerActionEvent());
	   	   buttonPanel.add(button);
	   	   
	   	   button = new XButton("form2", "Form 2");
	   	   button.addActionEvent(new ServerActionEvent());
	   	   buttonPanel.add(button);

	   	   button = new XButton("reset", "Reset");
	   	   button.addActionEvent(new ServerActionEvent());
	   	   buttonPanel.add(button);

	   	   button = new XButton("returnValues", "Retun values");
	   	   ServerActionEvent event = new ServerActionEvent();
	   	   event.setReturnAllValues(true);
	   	   button.addActionEvent(event);
	   	   buttonPanel.add(button);

	   	   button = new XButton("setValues", "Set values");
	   	   button.addActionEvent(new ServerActionEvent());
	   	   buttonPanel.add(button);
	   	   
	   	   mainPanel.setCenter(dynamicPanel);
	   	   mainPanel.setSouth(buttonPanel);
	   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(mainPanel); 
	   	   form.setTitle("Dynamic panel");
	   	   
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	   }   

	   public static void main(String...strings) {
		   MediatorRunner.run(DemoDynamicPanel.class, null, null, "flat");
	   }
}
