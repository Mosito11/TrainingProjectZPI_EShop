package demo.framework.components;

import java.awt.Dimension;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XForm;
import netball.server.component.XScrollPane;
import netball.server.component.XTextField;
import netball.server.component.setting.DualComponentPanelSettings;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoDualComponentPanelDynamic extends BasicMediator { 
	
	private List<Integer> comps = new ArrayList<>();
	private int id;

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
		if (event.getSourceId().equals("add")) {
			DualComponentPanelSettings settings = new DualComponentPanelSettings();
			id++;
			settings.addComponent(new XTextField(id, "Text " + id, 40));
   		   	comps.add(id);
			ValuePack valuePack = new ValuePack();
			valuePack.put("panel", settings);
			pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
		}else if (event.getSourceId().equals("remove")) {
			if (comps.size() > 0) {
				Integer id = comps.get(0);
				comps.remove(0);
				DualComponentPanelSettings settings = new DualComponentPanelSettings();
				settings.setRemoveComponents(new Integer[] {id});
				ValuePack valuePack = new ValuePack();
				valuePack.put("panel", settings);
				pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
			}
		}else if (event.getSourceId().equals("values")) {
			System.out.println(event.getValuePack());
		}
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
   	   XDualComponentPanel panel = new XDualComponentPanel("panel", new Dimension(450, 200)); // je potrebne nastavit id, ak chceme dynamicky pouzivat panel
   	   for (int i = 0; i < 5; i++) {
   		   id++;
   		   panel.add(new XTextField(id, "Text " + id, 50));
   		   comps.add(id);
   	   }
   	   
   	   XBoxPanel buttonPanel = new XBoxPanel();
   	   buttonPanel.setGapForAll(5);
   	   XButton button = new XButton("add", "Add");
   	   button.addActionEvent(new ServerActionEvent());
   	   buttonPanel.add(button);

   	   button = new XButton("remove", "Remove");
   	   button.addActionEvent(new ServerActionEvent());
   	   buttonPanel.add(button);
   	   
   	   button = new XButton("values", "Values");
   	   ServerActionEvent event = new ServerActionEvent();
   	   event.setReturnAllValues(true);
   	   button.addActionEvent(event);
   	   buttonPanel.add(button);

   	   XBorderPanel mainPanel = new XBorderPanel(10, 10);
   	   mainPanel.setInsets(new Insets(10,10,10,10));
   	   mainPanel.setCenter(new XScrollPane(panel));
   	   mainPanel.setSouth(buttonPanel);
   	   
   	   XForm form = new XForm();
   	   form.setPanel(mainPanel); 
   	   form.setTitle("DualComponentPanelDynamic");
   	  // form.setSize(new Dimension(600, 500));
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }
	
	public static void main(String...strings) {
		MediatorRunner.run(DemoDualComponentPanelDynamic.class, null, null, "flat");
	}

}
