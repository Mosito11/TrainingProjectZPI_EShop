package demo.framework.components;

import java.awt.Font;
import java.awt.Insets;

import javax.swing.SwingConstants;
import javax.swing.UIManager;

import netball.client.ui.jtc.awt.lookandfeel.MetalLookAndFeelNew;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XForm;
import netball.server.component.XProgressBar;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ClientTimerEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerTimerEvent;
import netball.server.pack.EnabledPack;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoProgressBarWithTimer extends BasicMediator { 

	@Override
	public void timerEventExecuted(ClientTimerEvent event, ServerPack pack) {
		int value = (Integer) event.getValuePack().getValue("progressBar");
		value += 20;
		UpdatedPack updatedPack = new UpdatedPack(getId());
		if (value > 100) {
			updatedPack.setHasStopTimer(true);
		}else{
			ValuePack valuePack = new ValuePack();
			valuePack.put("progressBar", value);
			valuePack.put("circularProgressBar", value);
			updatedPack.setValuePack(valuePack);
		}
		pack.addUpdatedPack(updatedPack);
	}

	@Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
		System.out.println(event);
	}
	
	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
		if (event.getSourceId().equals("Run")) {
			UpdatedPack updatedPack = new UpdatedPack(getId());
			EnabledPack enabledPack = new EnabledPack();
			enabledPack.put("Run", false);
			updatedPack.setEnabledPack(enabledPack);
			updatedPack.setHasStartTimer(true);
			pack.addUpdatedPack(updatedPack);
		}
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
   	   XBoxPanel barPanel = new XBoxPanel(SwingConstants.HORIZONTAL);
   	   barPanel.add(createBar());   	   
   	   barPanel.addGap(10);
   	   barPanel.add(createCircularBar());

   	   XBoxPanel panel = new XBoxPanel(SwingConstants.VERTICAL);
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.add(barPanel);
   	   panel.addGap(10);
   	   
   	   XButton button = new XButton("Run", "Run");
   	   button.addActionEvent(new ServerActionEvent());
   	   panel.add(button);
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("ProgressBar");
   	   
   	   ServerTimerEvent timerEvent = new ServerTimerEvent(1);
   	   timerEvent.addReturnValue("progressBar");
   	   timerEvent.addReturnValue("circularProgressBar");
   	   form.addTimerEvent(timerEvent);
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	}
	
	protected XProgressBar createBar() {  
		   XProgressBar progressBar = new XProgressBar("progressBar");
		   //progressBar.setBackground(Color.yellow);
		   //progressBar.setForeground(Color.blue);
		   //progressBar.setFont(new XFont("Courier", Font.BOLD, 20));
		   progressBar.setMinimum(0);
		   progressBar.setMaximum(100);
		   progressBar.setValue(20);
		   //progressBar.setWidth(500);
		   //progressBar.setHeight(100);
		   //progressBar.setCircular(true);	
		   progressBar.setOrientation(SwingConstants.HORIZONTAL);
		   //progressBar.addMouseEvent(new ServerMouseEvent(ServerEvent.MOUSE_ENTERED_EVENT));
		   progressBar.setEnabled(true);
		   return progressBar;
	}

	protected XProgressBar createCircularBar() {  
		   XProgressBar progressBar = new XProgressBar("circularProgressBar");
		   progressBar.setMinimum(0);
		   progressBar.setMaximum(100);
		   progressBar.setValue(20);
		   //progressBar.setWidth(200);
		   //progressBar.setHeight(200);
		   progressBar.setCircular(true);	
		   progressBar.setEnabled(true);
		   return progressBar;
	}
	
	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	public static void main(String...strings) {
		//UIManager.put(MetalLookAndFeelNew.DEFAULT_FONT, new Font("Dialog", Font.PLAIN, 25));
		//UIManager.put("Slider.font", new Font("Dialog", Font.PLAIN, 25));
		MediatorRunner.run(DemoProgressBarWithTimer.class, null, null, "metal");
	} 
}
