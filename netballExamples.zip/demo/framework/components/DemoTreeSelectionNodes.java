package demo.framework.components;

import java.awt.Insets;

import netball.server.component.XBorderPanel;
import netball.server.component.XButton;
import netball.server.component.XForm;
import netball.server.component.XTree;
import netball.server.component.setting.TreeSettings;
import netball.server.component.tree.TreeContainer;
import netball.server.component.tree.TreeNode;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoTreeSelectionNodes extends BasicMediator {

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}
	
	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
	    if (event.getSourceId().equals("Oznac")) {
	    	TreeSettings settings = new TreeSettings();
	    	Object[] selectionPath = new Object[] {-1, 9, 1}; 
	    	settings.setSelectionPath(selectionPath);
	    	settings.setScrollPathToVisible(selectionPath);
	    	ValuePack valuePack = new ValuePack();
	    	valuePack.put("tree", settings);
	    	pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
	    }
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
	   	   XTree tree = new XTree("tree");
	   	   tree.setWidth(500);
	   	   tree.setHeight(300);
	   	   TreeNode rootNode = new TreeNode(-1, "Root");   
	   	   for (int i = 0; i < 10; i++) {
	   		   TreeNode node0 = new TreeNode(i, "" + i + " Item");
	   		   rootNode.add(node0);
	   		   for (int j = 0; j < 5; j++) {
	   			   TreeNode node1 = new TreeNode(j, "" + i + "." + j + " Item");
	   			   node0.add(node1);
	   			   for (int k = 0; k < 3; k++) {
		   			   TreeNode node2 = new TreeNode(k, "" + i + "." + j + "." + k + " Item");
		   			   node1.add(node2);
	   			   }
	   		   }
	   	   }
	   	   tree.setDataSource(new TreeContainer(rootNode));
	   	   
	   	   XBorderPanel panel = new XBorderPanel(10, 10);
	   	   panel.setInsets(new Insets(10, 10, 10, 10));
	   	   panel.setCenter(tree);   	   
	   	   
	   	   panel.setSouth(new XButton("Oznac", "Oznac", new ServerActionEvent()));   	   
	   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel); 
	   	   form.setTitle("Tree");
	   	   
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	} 

    public static void main(String...strings) {
	   MediatorRunner.run(DemoTreeSelectionNodes.class, null, null, "flat");
    }
	
}
