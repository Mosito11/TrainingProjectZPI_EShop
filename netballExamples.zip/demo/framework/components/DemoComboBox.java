package demo.framework.components;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;

import netball.server.component.ListItem;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XComboBox;
import netball.server.component.XFont;
import netball.server.component.XForm;
import netball.server.component.XFormattedTextField;
import netball.server.component.renderer.FormattedTextRenderer;
import netball.server.component.setting.ComboBoxSettings;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientFocusEvent;
import netball.server.event.ClientKeyEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerEvent;
import netball.server.event.ServerFocusEvent;
import netball.server.event.ServerKeyEvent;
import netball.server.event.ServerMouseEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoComboBox extends BasicMediator { 

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

    @Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	   if (event.getSourceId().equals("Potvrd")) {
   	   	  System.out.println("value = " + event.getValuePack().getValue("comboBox"));
   	   	  System.out.println("properties = " + event.getProperties().get("comboBox"));
   	   }else if (event.getSourceId().equals("Update")) {	  
   	      update(pack);
   	   }else{
   		  System.out.println(event); 
   	   }
   }
   
    @Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
		System.out.println(event);
	}
	
	@Override
	public void focusEventExecuted(ClientFocusEvent event, ServerPack pack) {
		System.out.println(event);
	}
	
	@Override
	public void keyEventExecuted(ClientKeyEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
   	   XComboBox comboBox = new XComboBox("comboBox");
   	   comboBox.setVisibleCharCount(10);
   	   //comboBox.setBackground(Color.yellow);
   	   //comboBox.setForeground(Color.blue);
   	   //comboBox.setFont(new XFont("Courier", Font.BOLD, 12));
	   comboBox.addItem("111111111");
	   comboBox.addItem("222222222");
	   comboBox.addItem("233333333");
	   comboBox.addItem("244444444");
	   comboBox.addItem("333333333");
	   comboBox.addItem("444444444"); 
   	   comboBox.setEditable(false);
   	   comboBox.setSearchable(true);
   	   comboBox.setSelectedIndex(3);
   	   comboBox.setDescription("ja som combo box" );
   	   comboBox.setEnabled(true); 
   	   comboBox.setValue("333333333");
   	   XFormattedTextField field = new XFormattedTextField("####-#####");
   	   comboBox.setEditor(field);
   	   comboBox.setRenderer(new FormattedTextRenderer("####-#####"));
   	   
   	   
   	   //comboBox.setWidth(200);
   	   comboBox.addMouseEvent(new ServerMouseEvent(ServerEvent.MOUSE_CLICKED_EVENT));
   	   comboBox.addFocusEvent(new ServerFocusEvent(ServerEvent.FOCUS_GAINED_EVENT));
   	   comboBox.addKeyEvent(new ServerKeyEvent(ServerEvent.KEY_TYPED_EVENT));
   	   comboBox.addActionEvent(new ServerActionEvent());
   	   XBoxPanel panel = new XBoxPanel();
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.add(comboBox);   	  
   	   panel.addGap(10);
   	   
   	   ServerActionEvent event = new ServerActionEvent();
   	   event.addReturnProperty("comboBox");
   	   event.setReturnAllValues(true);
   	   panel.add(new XButton("Potvrd", "Potvrd", event));
   	   panel.addGap(5);
   	   panel.add(new XButton("Update", "Update"));   	   
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("combo box");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }
	
	
   
   private void update(ServerPack pack) {
   	   ComboBoxSettings cbp = new ComboBoxSettings();
   	   cbp.addInsertedItem(new ListItem("555555555"));
   	   cbp.addInsertedItem(new ListItem("666666666"));
   	   cbp.addDeletedItem("222222222");
   	   cbp.setSelectedItem("555555555");
   	   cbp.setBackground(Color.red);
   	   cbp.setForeground(Color.yellow);
   	   cbp.setFont(new XFont("Courier", Font.PLAIN, 12));
   	   ValuePack valuePack = new ValuePack();
   	   valuePack.put("comboBox", cbp);
   	   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
   }

   public static void main(String...strings) {
	   MediatorRunner.run(DemoComboBox.class, null, null, "metal");
   }
   
}	

