package demo.framework.components;

import java.awt.Dimension;
import java.awt.Insets;

import javax.swing.SwingConstants;

import netball.client.ui.jtc.awt.AWTUtilities;
import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XForm;
import netball.server.component.XLabel;
import netball.server.component.XTabbedPage;
import netball.server.component.XTabbedPane;
import netball.server.component.setting.TabbedPageSettings;
import netball.server.component.setting.TabbedPaneSettings;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientSelectionEvent;
import netball.server.event.ClientTabEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerSelectionEvent;
import netball.server.event.ServerTabEvent;
import netball.server.pack.EnabledPack;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MDUtilities;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoTabbedPane extends BasicMediator { 

	

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
   	   XTabbedPane panel = new XTabbedPane("tabbedPane");
   	   panel.setTabPlacement(javax.swing.SwingConstants.TOP);
   	   
   	   panel.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
   	   //spanel.setBorder(new XTitleBorder());
   	   panel.addSelectionEvent(new ServerSelectionEvent());
   	   panel.addTabEvent(new ServerTabEvent());   // koli closable zalozke, pretoze zaloka sa automaticky nezavrie
   	   
   	   XLabel label = new XLabel("Toto je zolozka 1");
       XTabbedPage page = new XTabbedPage("Zalozka 1", label);
       page.setDescription("Toto je zolozka 1"); 
       panel.add(page);
   	   
       label = new XLabel("Toto je zolozka 2");
       //page = new XTabbedPage("Zalozka 2", "<html>Zalozka 2</html>", label);
       page = new XTabbedPage("Zalozka 2", label);
       page.setIcon(MDUtilities.loadIcon(AWTUtilities.PRINT_ICON, getSessionObject()));
       page.setDescription("Toto je zolozka 2"); 
       panel.add(page);

       label = new XLabel("Toto je zolozka 3");
       page = new XTabbedPage("Zalozka 3", label);
       page.setDescription("Toto je zolozka 3"); 
       panel.add(page);

//       label = new XLabel("<html>Toto je zolozka 4</html>");
       label = new XLabel("Zalozka 4", "Toto je zolozka 4");
       page = new XTabbedPage("Zalozka 4", label);
       page.setIcon(MDUtilities.loadIcon(AWTUtilities.PRINT_ICON, getSessionObject()));
       page.setDescription("Toto je zolozka 4");
       page.setClosable(true);
       panel.add(page);

       label = new XLabel("Toto je zolozka 5");
       page = new XTabbedPage("Zalozka 5", label);
       page.setDescription("Toto je zolozka 5");
       panel.add(page);
       
       XBoxPanel buttonPanel = new XBoxPanel(SwingConstants.VERTICAL);
       buttonPanel.setGapForAll(5);
       buttonPanel.setSameSizeForAllComponents(true);
       
       XButton button = new XButton("addButton", "Nova zalozka");
       button.addActionEvent(new ServerActionEvent());
       buttonPanel.add(button);

       button = new XButton("updateButton", "Oprava zalozky");
       button.addActionEvent(new ServerActionEvent());
       buttonPanel.add(button);

       button = new XButton("deleteButton", "Vymaz zalozku");
       button.addActionEvent(new ServerActionEvent());
       buttonPanel.add(button);

       button = new XButton("enabledButton", "Disanable");
       button.addActionEvent(new ServerActionEvent());
       buttonPanel.add(button);
       
       XBorderPanel mainPanel = new XBorderPanel(10, 10);
       mainPanel.setInsets(new Insets(10, 10, 10, 10));
       mainPanel.setCenter(panel);
       mainPanel.setEast(buttonPanel);
       
   	   XForm form = new XForm();
   	   form.setPanel(mainPanel); 
   	   form.setTitle("Tabbed pane");
   	   form.setSize(new Dimension(700,500));
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void selectionEventExecuted(ClientSelectionEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void tabEventExecuted(ClientTabEvent event, ServerPack pack) {
		if (event.getCode() == ServerTabEvent.TAB_CLOSING_EVENT) {
	        TabbedPaneSettings paneSettings = new TabbedPaneSettings();
	        paneSettings.addDeletedPage(event.getTabId());
	        ValuePack valuePack = new ValuePack();
	        valuePack.put("tabbedPane", paneSettings);
			UpdatedPack updatedPack = new UpdatedPack(getId());
			updatedPack.setValuePack(valuePack);
			pack.addUpdatedPack(updatedPack);
		}
	}

	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
		if (event.getSourceId().equals("addButton")) {
	        XLabel label = new XLabel("Toto je nova zolozka");
	        XTabbedPage page = new XTabbedPage("Nova zalozka", label);
	        page.setDescription("Toto je nova zolozka"); 
			
	        TabbedPaneSettings paneSettings = new TabbedPaneSettings();
	        paneSettings.addNewPage(page);
	        paneSettings.setSelectedTabId(page.getId());
	        
	        ValuePack valuePack = new ValuePack();
	        valuePack.put("tabbedPane", paneSettings);
			
			UpdatedPack updatedPack = new UpdatedPack(getId());
			updatedPack.setValuePack(valuePack);
			
			EnabledPack enabledPack = new EnabledPack();
			enabledPack.put("addButton", false);
			updatedPack.setEnabledPack(enabledPack);
			pack.addUpdatedPack(updatedPack);
		}else if (event.getSourceId().equals("updateButton")) {
			TabbedPageSettings pageSettings = new TabbedPageSettings("Zalozka 3");
			pageSettings.setCaption("Opr. zal.");
			pageSettings.setIcon(MDUtilities.loadIcon(AWTUtilities.HOME_ICON, getSessionObject()));
			pageSettings.setDescription("Oprava zalozky description");

	        TabbedPaneSettings paneSettings = new TabbedPaneSettings();
	        paneSettings.addUpdatedPage(pageSettings);
	        
	        ValuePack valuePack = new ValuePack();
	        valuePack.put("tabbedPane", paneSettings);
			
			UpdatedPack updatedPack = new UpdatedPack(getId());
			updatedPack.setValuePack(valuePack);
			
			EnabledPack enabledPack = new EnabledPack();
			enabledPack.put("updateButton", false);
			updatedPack.setEnabledPack(enabledPack);
			pack.addUpdatedPack(updatedPack);
		}else if (event.getSourceId().equals("deleteButton")) {
	        TabbedPaneSettings paneSettings = new TabbedPaneSettings();
	        paneSettings.addDeletedPage("Zalozka 2");
	        
	        ValuePack valuePack = new ValuePack();
	        valuePack.put("tabbedPane", paneSettings);
			
			UpdatedPack updatedPack = new UpdatedPack(getId());
			updatedPack.setValuePack(valuePack);
			
			EnabledPack enabledPack = new EnabledPack();
			enabledPack.put("deleteButton", false);
			updatedPack.setEnabledPack(enabledPack);
			pack.addUpdatedPack(updatedPack);
		}else if (event.getSourceId().equals("enabledButton")) {
			TabbedPageSettings pageSettings = new TabbedPageSettings("Zalozka 4");
			pageSettings.setEnabled(false);

	        TabbedPaneSettings paneSettings = new TabbedPaneSettings();
	        paneSettings.addUpdatedPage(pageSettings);
	        
	        ValuePack valuePack = new ValuePack();
	        valuePack.put("tabbedPane", paneSettings);
			
			UpdatedPack updatedPack = new UpdatedPack(getId());
			updatedPack.setValuePack(valuePack);
			
			EnabledPack enabledPack = new EnabledPack();
			enabledPack.put("enabledButton", false);
			updatedPack.setEnabledPack(enabledPack);
			pack.addUpdatedPack(updatedPack);
		}
	}

	public static void main(String...strings) {
		MediatorRunner.run(DemoTabbedPane.class, null, null, "flat");
		 //MediatorRunner.run(DemoTabbedPane.class, null, null, "metal");
	} 
}
