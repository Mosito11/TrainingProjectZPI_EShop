package demo.framework.components;

import java.awt.Dimension;
import java.util.ArrayList;
import java.util.List;

import javax.swing.SwingConstants;

import netball.client.ui.jtc.VerticalMenuBarPanelController;
import netball.client.ui.jtc.awt.AWTUtilities;
import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XForm;
import netball.server.component.XLabel;
import netball.server.component.XMenu;
import netball.server.component.XVerticalMenuBar;
import netball.server.component.setting.VerticalMenuBarSettings;
import netball.server.event.ClientActionEvent;
import netball.server.pack.EnabledPack;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MDUtilities;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoVerticalMenuBar extends BasicMediator { 

	   @Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
    	   if (event.getSourceId().equals("enabledButton") ) {
   		      UpdatedPack updatedPack = new UpdatedPack(this.getId());
	   		  EnabledPack enabledPack = new EnabledPack();
	   		  enabledPack.put("3333", false);
	   		  enabledPack.put("8888", false);
	   		  updatedPack.setEnabledPack(enabledPack);
	   		  pack.addUpdatedPack(updatedPack);
	   	   }else if (event.getSourceId().equals("deleteButton")) {
	   		  VerticalMenuBarSettings settings = new VerticalMenuBarSettings();
	   		  settings.addDeletedItem("XXXX");
	   		  settings.addDeletedItem("CCCC");
	   		  ValuePack valuePack = new ValuePack();
	   		  valuePack.put("menuBar", settings);
	   		  UpdatedPack updatedPack = new UpdatedPack(getId(), valuePack);
	   		  pack.addUpdatedPack(updatedPack);
	   	   }else if (event.getSourceId().equals("clearButton")) {
	   		  VerticalMenuBarSettings settings = new VerticalMenuBarSettings();
	   		  settings.addDeletedAllChildren("ZZZZ");
	   		  ValuePack valuePack = new ValuePack();
	   		  valuePack.put("menuBar", settings);
	   		  UpdatedPack updatedPack = new UpdatedPack(getId(), valuePack);
	   		  pack.addUpdatedPack(updatedPack);
	   	   }else if (event.getSourceId().equals("addButton")) {
	   		  List<XMenu> menuItems = new ArrayList<>();
	   		  menuItems.add(new XMenu("add1"));
	   		  menuItems.add(new XMenu("add2"));
	   		  menuItems.add(new XMenu("add3"));
	   		  VerticalMenuBarSettings settings = new VerticalMenuBarSettings();
	   		  settings.addAddedItem(new VerticalMenuBarSettings.AddedMenu("1111", menuItems));

		   	  XMenu menu = new XMenu("addB");
		   	  menu.add(new XMenu("addC"));
		   	  menu.add(new XMenu("addD"));
		   	  menuItems = new ArrayList<>();
		   	  menuItems.add(menu);
	   		  settings.addAddedItem(new VerticalMenuBarSettings.AddedMenu(null, menuItems));
	   		  ValuePack valuePack = new ValuePack();
	   		  valuePack.put("menuBar", settings);
	   		  UpdatedPack updatedPack = new UpdatedPack(getId(), valuePack);
	   		  pack.addUpdatedPack(updatedPack);
	   		  
	   		  EnabledPack enabledPack = new EnabledPack();
	   		  enabledPack.put("addButton", false);
	   		  updatedPack.setEnabledPack(enabledPack);
	   		  pack.addUpdatedPack(updatedPack);
	   	   }else if (event.getSourceId().equals("updateButton")) {
	   		  VerticalMenuBarSettings settings = new VerticalMenuBarSettings();
	   		  settings.addUpdadedItem(new VerticalMenuBarSettings.UpdadedItem("3333", "update3333"));
	   		  ValuePack valuePack = new ValuePack();
	   		  valuePack.put("menuBar", settings);
	   		  UpdatedPack updatedPack = new UpdatedPack(getId(), valuePack);
	   		  pack.addUpdatedPack(updatedPack);
	   	   }else if (event.getSourceId().equals("updateTopButtom")) {
	   		  VerticalMenuBarSettings settings = new VerticalMenuBarSettings();
	   		  settings.setBottomComponent(new XLabel("update bottom"));	
	   		  settings.setTopComponent(null);
	   		  ValuePack valuePack = new ValuePack();
	   		  valuePack.put("menuBar", settings);
	   		  UpdatedPack updatedPack = new UpdatedPack(getId(), valuePack);
	   		  pack.addUpdatedPack(updatedPack);
	   	   }else{
	   		   System.out.println(event);
	   	   }
	   }

		@Override
		public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
	   	   XBoxPanel buttonPanel = new XBoxPanel(SwingConstants.HORIZONTAL);
	   	   buttonPanel.setGapForAll(5);
	   	   XButton button = new XButton("enabledButton", "Disable polozky");
	   	   buttonPanel.add(button);

	   	   button = new XButton("addButton", "Add");
	   	   buttonPanel.add(button);

	   	   button = new XButton("updateButton", "Update");
	   	   buttonPanel.add(button);
	   	   
	   	   button = new XButton("deleteButton", "Delete");
	   	   buttonPanel.add(button);

	   	   button = new XButton("clearButton", "Clear");
	   	   buttonPanel.add(button);

	   	   button = new XButton("updateTopButtom", "Update top/bottom");
	   	   buttonPanel.add(button);
	   	   
	   	   XVerticalMenuBar menuBar = new XVerticalMenuBar("menuBar");
	   	   menuBar.setMenu(createMenuBar());	
	   	   menuBar.setTopComponent(new XLabel("Top component"));
	   	   menuBar.setBottomComponent(new XLabel("Bottom component"));
	   	   menuBar.setController(new Controller(), this);
	   	   menuBar.setHeightMenuItemBy(XVerticalMenuBar.AUTO_RESIZE_HEIGHT);
	   	   
	   	   XBorderPanel panel = new XBorderPanel();
	   	   panel.setWest(menuBar);
	   	   panel.setSouth(buttonPanel);
	   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel); 
	   	   form.setTitle("Vertical Menu bar");
	   	   form.setSize(new Dimension(700, 400));
	   	   
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	   }
	   
	   public List<XMenu> createMenuBar() {
	   	   List<XMenu> mainMenu = new ArrayList<XMenu>();
	   	   XMenu menu = new XMenu("1111");
	   	   menu.setIcon(MDUtilities.loadIcon(AWTUtilities.EXCEL_ICON, getSessionObject()));
	   	   menu.add(new XMenu("2222"));
	   	   menu.add(new XMenu("3333"));
	   	   menu.add(new XMenu("4444"));
	   	   mainMenu.add(menu);
	   	   
	   	   menu = new XMenu("5555");
	   	   menu.setIcon(MDUtilities.loadIcon(AWTUtilities.PDF_ICON, getSessionObject()));
	   	   XMenu menuItem = new XMenu("6666");
	   	   menuItem.setSeparator(true);
	   	   menu.add(menuItem);
	   	   XMenu menu1 = new XMenu("7777");
	   	   menu1.setDescription("ssssssssssssssssssssssssssssssss"); 
	   	   menu1.add(new XMenu("8888"));
	   	   menu1.add(new XMenu("9999"));
	   	   menu.add(menu1);
	   	   mainMenu.add(menu);
	   	   
	   	   menu = new XMenu("<html>riadok1<br>riadok2</html>");
	   	   menu.setIcon(MDUtilities.loadIcon(AWTUtilities.PRINT_ICON, getSessionObject()));
	   	   menu.add(new XMenu("BBBB"));
	   	   menu.add(new XMenu("GGGG"));
	   	   menu1 = new XMenu("CCCC");
	   	   menu1.add(new XMenu("DDDD"));
	   	   menu1.add(new XMenu("EEEE"));
	   	   menu.add(menu1);
	   	   mainMenu.add(menu);
	   	   
	   	   menu = new XMenu("XXXX");
	   	   menu.setIcon(MDUtilities.loadIcon(AWTUtilities.LOAD_ICON, getSessionObject()));
	   	   menu.add(new XMenu("YYYY"));
	   	   menu1 = new XMenu("ZZZZ");
	   	   menu1.add(new XMenu("TTTT"));
	   	   menu1.add(new XMenu("RRRR"));
	   	   menu.add(menu1);
	   	   mainMenu.add(menu);

	   	   return mainMenu;
	   }

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	private class Controller extends VerticalMenuBarPanelController {

		@Override
		public UpdatedPack setIconified(boolean isIconified) throws Exception {
			System.out.println("isIconified=" + isIconified);
			return null;
		}
		
	}
	
	public static void main(String...strings) {
		MediatorRunner.run(DemoVerticalMenuBar.class, null, null, "flat" );
	}
}

