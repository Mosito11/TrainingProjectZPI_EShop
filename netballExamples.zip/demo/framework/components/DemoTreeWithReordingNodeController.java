package demo.framework.components;

import netball.server.component.XBorderPanel;
import netball.server.component.XForm;
import netball.server.component.XTree;
import netball.server.component.setting.TreeSettings;
import netball.server.component.tree.ReordingTreeNodeController;
import netball.server.component.tree.TreeClientNode;
import netball.server.component.tree.TreeContainer;
import netball.server.component.tree.TreeNode;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoTreeWithReordingNodeController extends BasicMediator {
	
	
	   @Override
	   public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
	   	   XTree tree = new XTree("tree");
	   	   tree.setDataSource(createContainer());
	   	   tree.setWidth(600);
	   	   tree.setHeight(200);
	   	   tree.setHorizontalAlignment(javax.swing.SwingUtilities.RIGHT);
	   	   tree.setReordingTreeNodeController(new MyReordingTreeNodeController(), this);
	   	   tree.setSelectionMode(XTree.DISCONTIGUOUS_TREE_SELECTION);
//	   	   tree.setHelpNavigation(XTree.POPUP_WINDOW_HELP_NAVIGATION);
	   	   
	   	   XBorderPanel mainPanel = new XBorderPanel();
	   	   mainPanel.setCenter(tree);
	   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(mainPanel); 
	   	   form.setTitle("Tree with reording node controller");
	   	   
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	   }   
	   
	   private TreeContainer createContainer() {		   
		   TreeContainer container = new TreeContainer(new TreeNode("root", "Tree"));
		   TreeNode node = new TreeNode("colors", "Colors");
		   node.add(new TreeNode("blue", "Blue"));
		   node.add(new TreeNode("red", "Red"));
		   node.add(new TreeNode("yellow", "Yellow"));
		   node.add(new TreeNode("orange", "Orange"));
		   container.getRootNode().add(node);
		   
		   node = new TreeNode("sports", "Sports");
		   node.add(new TreeNode("basketball", "Basketball"));
		   node.add(new TreeNode("soccer", "Soccer"));
		   node.add(new TreeNode("football", "Football"));
		   node.add(new TreeNode("hockey", "Hockey"));
		   container.getRootNode().add(node);
		   
		   node = new TreeNode("food", "Food");
		   node.add(new TreeNode("hotdog", "Hotdog"));
		   node.add(new TreeNode("pizza", "Pizza"));
		   node.add(new TreeNode("ravioli", "Ravioli"));
		   node.add(new TreeNode("bannanas", "Bannanas"));
		   container.getRootNode().add(node);
		   
		   return container;
	   }

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

    private class MyReordingTreeNodeController extends ReordingTreeNodeController {

		@Override
		public UpdatedPack reorderNodes(TreeClientNode[] sourceNodes, TreeClientNode targetNode) throws Exception {
 		    TreeSettings settings = new TreeSettings();
 		    settings.setReordingNodes(sourceNodes, targetNode);
 		    settings.setScrollPathToVisible(targetNode.getPath());
 		    settings.setSelectionPath(targetNode.getPath());
 		    settings.setExpandPath(targetNode.getPath());
 		    ValuePack valuePack = new ValuePack();
 		    valuePack.put("tree", settings);
			return new UpdatedPack(getId(), valuePack);
		}
    }
	
    public static void main(String...strings) {
	   MediatorRunner.run(DemoTreeWithReordingNodeController.class, null, null, "flat");
    }
    
}
