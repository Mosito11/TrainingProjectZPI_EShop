package demo.framework.components;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;

import javax.swing.SwingConstants;

import netball.client.ui.jtc.spantable.BasicSpanTableCell;
import netball.client.ui.jtc.spantable.SpanTableCell;
import netball.client.ui.jtc.spantable.SpanTableDataSource;
import netball.client.ui.jtc.spantable.StyleSpanTableCell;
import netball.client.ui.jtc.spantable.StyleSpanTableCellRenderer;
import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XFont;
import netball.server.component.XForm;
import netball.server.component.XSpanTable;
import netball.server.component.setting.SpanTableSettings;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerMouseEvent;
import netball.server.pack.EnabledPack;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MDUtilities;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoSpanTable extends BasicMediator { 

	   @Override
	   public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
		   XBoxPanel buttonPanel = new XBoxPanel(SwingConstants.HORIZONTAL);
		   XButton button = new XButton("update", "Update");
		   button.addActionEvent(new ServerActionEvent());
		   buttonPanel.add(button);

		   button = new XButton("property", "Retun property");
		   ServerActionEvent event = new ServerActionEvent();
		   event.addReturnProperty("table");
		   button.addActionEvent(event);
		   buttonPanel.add(button);
		   
		   XSpanTable table = new XSpanTable("table");
		   table.setScrollableTable(createScrollableTable());
		   table.setFixedTable(createFixedTable());
		   table.setScrollableTableHeder(createScrollableTableHeader());
		   table.setFixedTableHeader(createFixedTableHeader());
		   
		   ServerMouseEvent mouseEvent = new ServerMouseEvent(ServerMouseEvent.MOUSE_CLICKED_EVENT);
		   mouseEvent.addReturnValue("table");
		   table.addMouseEvent(mouseEvent);
		   
	   	   XBorderPanel panel = new XBorderPanel(10, 10);
	   	   panel.setInsets(new Insets(10, 10, 10, 10));
	   	   panel.setCenter(table);
	   	   panel.setSouth(buttonPanel);
	   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel); 
	   	   form.setTitle("Span table");
	   	   form.setSize(new Dimension(600, 400));
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	   }
	   
	   private XSpanTable.Table createScrollableTable() {
		   XSpanTable.Table table = new XSpanTable.Table();
		   SpanTableDataSource source = new SpanTableDataSource(20, 10);
		   BasicSpanTableCell cell = new BasicSpanTableCell("BasicSpanTableCell", 1, 1, 2, 5);
		   cell.setBackground(Color.YELLOW);
		   cell.setForeground(Color.RED);
		   cell.setFont(new XFont("Dialog", Font.BOLD, 12));
		   cell.setHorizontalAlignment(SwingConstants.CENTER);
		   cell.setVerticalAlignment(SwingConstants.TOP);
		   cell.setIcon(MDUtilities.loadIcon(MDUtilities.PRINT_ICON, getSessionObject()));
		   source.addSpan(cell);
		   table.setDataSource(source);
		   return table;
	   } 

	   private XSpanTable.Header createScrollableTableHeader() {
		   XSpanTable.Header header = new XSpanTable.Header();
		   SpanTableDataSource source = new SpanTableDataSource(2, 10);
		   source.addSpan(new BasicSpanTableCell("Header", 0, 0, 1, 10));
		   header.setDataSource(source);
		   header.setBackground(Color.LIGHT_GRAY);
		   header.setColumnWidths(new int[] {20});
		   header.setResizingAllowed(true);
		   return header;
	   } 
	   
	   private XSpanTable.Table createFixedTable() {
		   XSpanTable.Table table = new XSpanTable.Table();
		   // druha moznost ako rendererovat bunky, je zaregistrovat renderer table.addRenderer("style1", renderer) a potom sa na ne alias "style1" len odvolat
		   // source.addSpan(new StyleSpanTableCell("StyleSpanTableCell", 1, 1, 2, 2, "style1")); setri to pamat a vykon. Vhodne pre pripad, ak chceme viac buniek vykresilt
		   // rovnako.
		   StyleSpanTableCellRenderer renderer = new StyleSpanTableCellRenderer();
		   renderer.setBackground(Color.GRAY );
		   renderer.setForeground(Color.GREEN);
		   renderer.setFont(new XFont("Dialog", Font.ITALIC, 12));
		   renderer.setHorizontalAlignment(SwingConstants.RIGHT);
		   renderer.setVerticalAlignment(SwingConstants.CENTER);
		   renderer.setIcon(MDUtilities.loadIcon(MDUtilities.ADD_ICON, getSessionObject()));
		   table.addRenderer("style1", renderer);
		   
		   SpanTableDataSource source = new SpanTableDataSource(20, 4);
		   source.addSpan(new StyleSpanTableCell("StyleSpanTableCell", 1, 1, 4, 2, "style1"));
		   table.setDataSource(source);
		   table.setBackground(Color.CYAN);		   
		   return table;
	   }
	   
	   private XSpanTable.Header createFixedTableHeader() {
		   XSpanTable.Header header = new XSpanTable.Header();
		   SpanTableDataSource source = new SpanTableDataSource(2, 4);
		   source.addSpan(new SpanTableCell("SpanTableCell", 0, 0, 1, 2));
		   header.setDataSource(source);
		   header.setBackground(Color.MAGENTA);
		   header.setColumnWidths(new int[] {100, 50});
		   return header;
	   }
	   
	 	@Override
		public AccessAction[] getAccessActions() {
			return null;
		}

		@Override
		public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
			System.out.println(event.getValuePack().getValue("table"));
		}
		
		@Override
		public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
			if (event.getSourceId().equals("update")) {
				addUpdate(pack);
			}else if (event.getSourceId().equals("property")) {
				System.out.println(event.getPropertie("table"));
			}
		}

		private void addUpdate(ServerPack pack) {
			SpanTableSettings settings = new SpanTableSettings();
			settings.setFixedTable(null);
			settings.setFixedTableHeader(null);
			
			XSpanTable.Table table = new XSpanTable.Table();
		    SpanTableDataSource source = new SpanTableDataSource(15, 10);
		    BasicSpanTableCell cell = new BasicSpanTableCell("Cell ", 3, 2, 5, 3);
		    cell.setBackground(Color.GRAY);
			source.addSpan(cell);		    
		    table.setDataSource(source);
		    settings.setScrollableTable(table);
		    
			XSpanTable.Header header = new XSpanTable.Header();
			source = new SpanTableDataSource(2, 10);
			source.addSpan(new BasicSpanTableCell("Header", 1, 0, 1, 10));
			header.setBackground(Color.YELLOW);
			header.setDataSource(source);
			header.setColumnWidths(new int[] {20, 40, 60, 80, 100});
			settings.setScrollableTableHeder(header);
			
			ValuePack valuePack = new ValuePack();
			valuePack.put("table", settings);
			UpdatedPack updatedPack = new UpdatedPack(getId(), valuePack);
			
			EnabledPack enabledPack = new EnabledPack();
			enabledPack.put("update", false);
			updatedPack.setEnabledPack(enabledPack);
			pack.addUpdatedPack(updatedPack);
		}
		
		public static void main(String...strings) {
			MediatorRunner.run(DemoSpanTable.class);
		}
	}
