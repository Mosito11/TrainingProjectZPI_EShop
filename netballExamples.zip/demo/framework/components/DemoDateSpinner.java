package demo.framework.components;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;
import java.sql.Date;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XDateSpinner;
import netball.server.component.XFont;
import netball.server.component.XForm;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientFocusEvent;
import netball.server.event.ClientKeyEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerEvent;
import netball.server.event.ServerFocusEvent;
import netball.server.event.ServerKeyEvent;
import netball.server.event.ServerMouseEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.utilities.TypeValues;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoDateSpinner extends BasicMediator { 

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

    @Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
		System.out.println(event);
	}
	
	@Override
	public void focusEventExecuted(ClientFocusEvent event, ServerPack pack) {
		System.out.println(event);
	}
	
	@Override
	public void keyEventExecuted(ClientKeyEvent event, ServerPack pack) {
		System.out.println(event);
	}
   
	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	   if (event.getSourceId().equals("Potvrd")) {
   	   	  System.out.println("value = " + event.getValuePack().getValue("dateSpinner"));
   	   }
    }

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
   	   XDateSpinner dateSpinner = new XDateSpinner("dateSpinner", "dateSpinner", "dd.MM.yyyy", TypeValues.SQL_DATE);
   	   
   	   dateSpinner.setBackground(Color.yellow);
   	   dateSpinner.setForeground(Color.blue);
   	   dateSpinner.setFont(new XFont("Courier", Font.BOLD, 12));   	   
   	   dateSpinner.setDate(new java.util.Date(System.currentTimeMillis()));
   	   dateSpinner.setDescription("ja som data spinner");
   	   dateSpinner.setDate(new Date(System.currentTimeMillis()));
   	   
	   java.util.Calendar c =  java.util.Calendar.getInstance();
	   c.add(java.util.Calendar.DATE, 10);
	   //dateSpinner.setMinimum(new java.util.Date(System.currentTimeMillis()));
	   //dateSpinner.setMaximum(c.getTime());   	   
	   //dateSpinner.setCalendarField(java.util.Calendar.DATE);
	   //dateSpinner.setStepSize(30);
	   //dateSpinner.setNextDateByCaretPosition(false);
   	   
   	   //dateSpinner.setWidth(200);
   	   dateSpinner.setHorizontalAlignment(javax.swing.SwingUtilities.RIGHT);
   	   dateSpinner.addMouseEvent(new ServerMouseEvent(ServerEvent.MOUSE_CLICKED_EVENT));
   	   dateSpinner.addFocusEvent(new ServerFocusEvent(ServerEvent.FOCUS_GAINED_EVENT));
   	   dateSpinner.addKeyEvent(new ServerKeyEvent(ServerEvent.KEY_TYPED_EVENT));
   	   
   	   XBoxPanel panel = new XBoxPanel();
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.add(dateSpinner);
   	   panel.addGap(10);
   	   
   	   ServerActionEvent event = new ServerActionEvent();
   	   event.setReturnAllValues(true);
   	   panel.add(new XButton("Potvrd", "Potvrd", event));   	   
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Date spinner");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }
	
   public static void main(String...strings) {
	   MediatorRunner.run(DemoDateSpinner.class, null, null, "flat" );
   }	

}	

