package demo.framework.components;

import java.awt.Insets;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XClientTable;
import netball.server.component.XColumnGroup;
import netball.server.component.XForm;
import netball.server.component.XTableColumn;
import netball.server.component.property.ClientTableProperties;
import netball.server.component.table.TableContainer;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MDTableReport;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoGroupableTableHeader extends BasicMediator { 
	
	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}
   
	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
   	   XClientTable table = new XClientTable("table");
   	   table.addColumn(new XTableColumn("col0", "col0", 70));
   	   table.addColumn(new XTableColumn("col1", "col1", 70));
   	   table.addColumn(new XTableColumn("col2", "col2", 70));
   	   table.addColumn(new XTableColumn("col3", "col3", 70));
   	   table.addColumn(new XTableColumn("col4", "col4", 70));
   	   table.addColumn(new XTableColumn("col5", "col5", 70));
   	   
   	   TableContainer container = new TableContainer(new String[] {"col0","col1","col2","col3","col4","col5"});
   	   container.addNewRow(new Object[] {"1","a","b","c","d","e"});
   	   container.addNewRow(new Object[] {"2","f","g","h","i","j"});
   	   container.addNewRow(new Object[] {"3","k","l","m","n","o"});
   	   container.addNewRow(new Object[] {"4","p","q","r","s","t"});
   	   table.setDataSource(container);
   	   
	   XColumnGroup group0 = new XColumnGroup("Group0");
	   group0.add("col1");
	   group0.add("col2");
	   XColumnGroup group1 = new XColumnGroup("Group1");
	   group1.add("col3");
	   XColumnGroup group2 = new XColumnGroup("Group2");
	   group2.add("col4");
	   group2.add("col5");
	   group1.add(group2);
       table.addColumnGroup(group0);
       table.addColumnGroup(group1);
	    
   	   table.setWidth(600);
   	   table.setHeight(200);
   	   table.setVisibilityOfColumnsAllowed(true);
       table.setFreezeColumnsAllowed(true);
    	
       XBoxPanel buttonPanel = new XBoxPanel();
       XButton button = new XButton("print", "Print");
       ServerActionEvent event = new ServerActionEvent();
       event.addReturnProperty("table");
       button.addActionEvent(event);
       buttonPanel.add(button);
       
   	   XBorderPanel panel = new XBorderPanel(10, 10);
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.setCenter(table);
   	   panel.setSouth(buttonPanel);
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("DemoGroupableTableHeader");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }
	
    @Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
    	if (event.getSourceId().equals("print")) {
			ClientTableProperties props = (ClientTableProperties) event.getPropertie("table");
			MDTableReport.ClientTableParameters prmts = new MDTableReport.ClientTableParameters(props.columns, (TableContainer) props.source, "DemoGroupableTableHeader", props.filterRowIndexes, props.columnGroup);
			runNext(MDTableReport.class, prmts, pack);
    	}
	}

	public static void main(String...strings) {
    	MediatorRunner.run(DemoGroupableTableHeader.class, null, null, "flat");
    } 
}
