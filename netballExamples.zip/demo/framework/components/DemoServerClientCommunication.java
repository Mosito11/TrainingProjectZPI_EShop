package demo.framework.components;

import java.awt.Dimension;
import java.awt.Insets;

import com.sun.jmx.snmp.Timestamp;

import netball.server.component.ListItem;
import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XForm;
import netball.server.component.XLabel;
import netball.server.component.XList;
import netball.server.component.setting.ListSettings;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.EnabledPack;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoServerClientCommunication extends BasicMediator { 

	    private MyThread myThread;
	
		@Override
		public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
			if (event.getSourceId().equals("run")) {
				EnabledPack enabledPack = new EnabledPack();
				enabledPack.put("run", false);
				pack.addUpdatedPack(new UpdatedPack(getId(), enabledPack));
				runThread();
			}
		}
	
	    private void runThread() {
	    	if (myThread == null) {
	    		myThread = new MyThread();
	    		myThread.start();
	    	}
	    }
	    
	    private void closeThread() {
	    	 if (myThread != null) {
	    		 myThread.interrupt();
	    		 myThread = null;
	    	 }
	    }
	   
	   @Override
	   public void close(ServerPack pack) {
			super.close(pack);
			closeThread();
	   }

	   @Override
	   public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
		   XList list = new XList("list");

	   	   XBoxPanel buttonPanel = new XBoxPanel();
	   	   buttonPanel.setGapForAll(5);
		   
		   XButton button = new XButton("run", "Run");
	   	   button.addActionEvent(new ServerActionEvent());
	   	   buttonPanel.add(button);
		   
	   	   XBorderPanel panel = new XBorderPanel(10, 10);
	   	   panel.setInsets(new Insets(10, 10, 10, 10));
	   	   panel.setCenter(list);
	   	   panel.setSouth(buttonPanel);
   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel);
	   	   form.setTitle("DemoServerClientCommunication");
	   	   form.setSize(new Dimension(500, 500));	   	   
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	   }

		@Override
		public AccessAction[] getAccessActions() {
			return null;
		}
		
		private class MyThread extends Thread {
		   public void run ()  {
			   try{
				   for(int i = 0; i < 10; i++) {  
					   if (isInterrupted())
						   break;
					   Thread.sleep(1000);
					   ListSettings listSettings = new ListSettings();
					   listSettings.addInsertedItem(new ListItem(new Timestamp().toString()));
					   ValuePack valuePack = new ValuePack();
					   valuePack.put("list", listSettings);
					   ServerPack serverPack = new ServerPack();
					   serverPack.addUpdatedPack(new UpdatedPack(DemoServerClientCommunication.this.getId(), valuePack));
					   getServerEngine().sendServerPackToClient(serverPack);
				   }
				   if (!isInterrupted()) {
			   		   ServerPack serverPack = new ServerPack();
					   DemoServerClientCommunication.this.runNext(KoniecMediator.class, null, serverPack);
					   getServerEngine().sendServerPackToClient(serverPack);
		   		   }
				   closeThread();
			   }catch(InterruptedException e){
				   System.out.println(e);}  
			  }  			   
		}		
		
		public static class KoniecMediator extends BasicMediator {

			@Override
			public AccessAction[] getAccessActions() {
				return null;
			}

			@Override
			public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
 
			   	   XBorderPanel panel = new XBorderPanel(10, 10);
			   	   panel.setInsets(new Insets(10, 50, 10, 50));
			   	   panel.setCenter(new XLabel("Koniec..."));
		   	   
			   	   XForm form = new XForm();
			   	   form.setPanel(panel);
			   	   form.setTitle("Koniec");
			   	   form.setStatusRow(false);
			   	   form.setResizable(false);
			   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
			}
		}

		public static void main(String...strings) {
			MediatorRunner.run(DemoServerClientCommunication.class, null, null, "flat");
		}
}