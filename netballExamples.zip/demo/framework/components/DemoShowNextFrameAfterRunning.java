package demo.framework.components;

import java.awt.Dimension;

import netball.server.component.XBorderPanel;
import netball.server.component.XForm;
import netball.server.event.ClientWindowEvent;
import netball.server.event.ServerWindowEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoShowNextFrameAfterRunning extends BasicMediator { 

		@Override
		public void windowEventExecuted(ClientWindowEvent event, ServerPack pack) {
			if (event.getCode() == ServerWindowEvent.WINDOW_OPENED_EVENT) {
				runNext(NextFrame.class, null, pack);
			}else{
				super.windowEventExecuted(event, pack);
			}
		}

	   @Override
	   public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {   
   	   	   XBorderPanel panel = new XBorderPanel(10, 10);
   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel);
	   	   form.setTitle("DemoShowNextFrameAfterRunning");
	   	   form.setSize(new Dimension(500, 500));	 
	   	   form.setType(XForm.FRAME);
	   	   form.addWindowEvent(new ServerWindowEvent(ServerWindowEvent.WINDOW_OPENED_EVENT));
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	   	}

		@Override
		public AccessAction[] getAccessActions() {
			return null;
		}

		public static class NextFrame extends BasicMediator { 
			 
			@Override
			public void init(MediatorParameters parameters,	ServerPack serverPack) throws Exception {
				   XBorderPanel panel = new XBorderPanel(10, 10);
			   	   XForm form = new XForm();
			   	   form.setPanel(panel);
			   	   form.setTitle("Next Frame");
			   	   form.setSize(new Dimension(300, 300));	 
			   	   form.setType(XForm.FRAME);
			   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
		    }

			@Override
			public AccessAction[] getAccessActions() {
				return null;
			}
		}
		
		public static void main(String...strings) {
			MediatorRunner.run(DemoShowNextFrameAfterRunning.class, null, null, "metal");
		}
}