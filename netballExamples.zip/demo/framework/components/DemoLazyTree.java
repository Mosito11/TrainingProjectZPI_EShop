package demo.framework.components;

import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;

import netball.server.component.XBorderPanel;
import netball.server.component.XForm;
import netball.server.component.XTree;
import netball.server.component.tree.LazyLoadingTreeController;
import netball.server.component.tree.LazyLoadingTreeNode;
import netball.server.component.tree.TreeClientNode;
import netball.server.component.tree.TreeContainer;
import netball.server.component.tree.TreeNode;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoLazyTree extends BasicMediator { 

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)throws Exception {
	   	   TreeNode root = new TreeNode("root", "Root");
	   	   root.add(new LazyLoadingTreeNode("0", "Lazy Item 0"));
	   	   root.add(new LazyLoadingTreeNode("1", "Lazy Item 1"));
	   	   root.add(new LazyLoadingTreeNode("2", "Lazy Item 2"));

	   	   XTree tree = new XTree("tree");
	   	   TreeContainer treeContainer = new TreeContainer(root); 
	   	   tree.setDataSource(treeContainer);
	   	   tree.setWidth(600);
	   	   tree.setHeight(200);
	   	   tree.setLazyLoadingTreeController(new Controller(), this);
	   	   
	   	   XBorderPanel panel = new XBorderPanel();
	   	   panel.setInsets(new Insets(10, 10, 10, 10));
	   	   panel.setCenter(tree);   	   
	   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel); 
	   	   form.setTitle("Tree");
	   	   
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	   }   
	   
	   private class Controller extends LazyLoadingTreeController {

			@Override
			public List<TreeNode> readNodes(TreeClientNode node) throws Exception {
				List<TreeNode> nodes = new ArrayList<TreeNode>();
				for (int i = 0; i < 4; i++) {
				    nodes.add(new TreeNode("" + i, "Child Item " + i));
				}
				nodes.add(new LazyLoadingTreeNode("4", "Lazy child Item 4"));
				return nodes;
			}
	   }

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}
	
	public static void main(String...strings) {
		MediatorRunner.run(DemoLazyTree.class, null, null, "flat");
	}
}
