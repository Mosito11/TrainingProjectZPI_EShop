package demo.framework.components;

import java.awt.Dimension;
import java.awt.Insets;

import netball.server.component.XBoxPanel;
import netball.server.component.XForm;
import netball.server.component.XScrollPane;
import netball.server.component.XTextField;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoScrollPane extends BasicMediator { 

   @Override
   public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
   	   XBoxPanel panel = new XBoxPanel(javax.swing.SwingConstants.VERTICAL);
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   for (int i = 0; i < 20; i++) {
   	   	  panel.add(new XTextField("text " + i, "text " + i));
   	   	  panel.addGap(10);
   	   } 
   	   XForm form = new XForm();
   	   form.setPanel(new XScrollPane(panel)); 
   	   form.setTitle("Scroll pane");
   	   form.setSize(new Dimension(200, 200));
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	public static void main(String...strings) {
		MediatorRunner.run(DemoScrollPane.class, null, null, "flat");
	}
}
