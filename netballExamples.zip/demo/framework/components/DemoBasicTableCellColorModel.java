package demo.framework.components;

import java.awt.Color;
import java.awt.Insets;

import netball.server.component.XBorderPanel;
import netball.server.component.XClientTable;
import netball.server.component.XForm;
import netball.server.component.XTableColumn;
import netball.server.component.table.BasicTableCellColorModel;
import netball.server.component.table.TableContainer;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoBasicTableCellColorModel extends BasicMediator{

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
		XBorderPanel panel = new XBorderPanel();
		panel.setInsets(new Insets(10, 10, 10, 10));
		panel.setCenter(creatTable());
		
   	    XForm form = new XForm();
   	    form.setPanel(panel); 
   	    form.setTitle("DemoBasicTableCellColorModelBag");
	   	   
   	    serverPack.addFormPack(new FormPack(getId(), form));   	   
		
	}
	
	public XClientTable creatTable() {
		XClientTable table = new XClientTable("table");
		table.addColumn(new XTableColumn("col0", "Col0", 70));
		table.addColumn(new XTableColumn("col1", "Col1", 70));
		table.addColumn(new XTableColumn("col2", "Col2", 70));
		table.addColumn(new XTableColumn("col3", "Col3", 70));
		table.getColumn("col0").setVisible(false);
		
		TableContainer container = new TableContainer(new String[] {"col0", "col1", "col2", "col3"});
		container.addNewRow(new Object[] {1, 2, 2, 4});
		container.addNewRow(new Object[] {5, 6, 7, 8});
		table.setDataSource(container);
		
		BasicTableCellColorModel model = new BasicTableCellColorModel();
		model.add("col0", 1, "col2", Color.BLACK, Color.YELLOW);
		model.add("col0", 5, "col2", Color.BLUE, Color.YELLOW);
		table.setTableCellColorModel(model);		
		return table;
	} 
	
	public static void main(String...strings) {
		MediatorRunner.run(DemoBasicTableCellColorModel.class, null, null, "flat");
	} 
}
