package demo.framework.components;

import java.awt.Insets;

import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XCheckBox;
import netball.server.component.XForm;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientFocusEvent;
import netball.server.event.ClientKeyEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerEvent;
import netball.server.event.ServerFocusEvent;
import netball.server.event.ServerKeyEvent;
import netball.server.event.ServerMouseEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoCheckBox extends BasicMediator { 

	@Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void focusEventExecuted(ClientFocusEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void keyEventExecuted(ClientKeyEvent event, ServerPack pack) {
		System.out.println(event);
	}
 
	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	   if (event.getSourceId().equals("Potvrd")) {
   	   	   System.out.println(event.getValuePack());
   	   	   System.out.println(event.getProperties());
   	   }else{
   		   System.out.println(event);
   	   }	  
   }

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
   	   XCheckBox checkBox = new XCheckBox("checkBox", "checkBox");
   	   //checkBox.setBackground(Color.yellow);
   	   //checkBox.setForeground(Color.blue);
   	   //checkBox.setFont(new XFont("Courier", Font.BOLD, 12));
   	   checkBox.setDescription("ja som check box");
   	   //checkBox.setWidth(200);
   	   checkBox.setHorizontalAlignment(javax.swing.SwingUtilities.RIGHT);
   	   checkBox.addMouseEvent(new ServerMouseEvent(ServerEvent.MOUSE_CLICKED_EVENT));
   	   checkBox.addFocusEvent(new ServerFocusEvent(ServerEvent.FOCUS_GAINED_EVENT));
   	   checkBox.addKeyEvent(new ServerKeyEvent(ServerEvent.KEY_TYPED_EVENT));
   	   checkBox.addActionEvent(new ServerActionEvent());
   	   checkBox.setSelectedStateValue(new Integer(1));
   	   checkBox.setDeselectedStateValue(new Integer(0));
   	   checkBox.setSelected(true);
   	   XBoxPanel panel = new XBoxPanel();
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.add(checkBox);
   	   panel.addGap(20);
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Check box");
   	   
   	   ServerActionEvent event = new ServerActionEvent();
   	   event.setReturnAllValues(true);
   	   event.addReturnProperty("checkBox");
   	   panel.add(new XButton("Potvrd", "Potvrd", event));   	   
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }

   @Override
	public AccessAction[] getAccessActions() {
		return null;
	}

    public static void main(String...strings) {
    	MediatorRunner.run(DemoCheckBox.class, null, null, "flat");
    }
}
