package demo.framework.components;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;

import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XFont;
import netball.server.component.XForm;
import netball.server.component.XFormattedTextField;
import netball.server.component.XMultiColumnComboBox;
import netball.server.component.XTableColumn;
import netball.server.component.renderer.FormattedTextRenderer;
import netball.server.component.setting.MultiColumnComboBoxSettings;
import netball.server.component.table.TableContainer;
import netball.server.component.table.TableRow;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientFocusEvent;
import netball.server.event.ClientKeyEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ClientPopupEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerEvent;
import netball.server.event.ServerFocusEvent;
import netball.server.event.ServerKeyEvent;
import netball.server.event.ServerMouseEvent;
import netball.server.event.ServerPopupEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoMultiColumnComboBox extends BasicMediator { 

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void popupEventExecuted(ClientPopupEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void focusEventExecuted(ClientFocusEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void keyEventExecuted(ClientKeyEvent event, ServerPack pack) {
		System.out.println(event);
	}
 
	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
	   	   if (event.getSourceId().equals("Potvrd")) {
	   	   	  System.out.println("value = " + event.getValuePack().getValue("comboBox"));
	   	   	  System.out.println("properties = " + event.getProperties().get("comboBox"));
	   	   }else if (event.getSourceId().equals("Update")) {	  
	   	      update(pack);
	   	   }else{
	   		  System.out.println(event);
	   	   }
	   }

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
	   	   XMultiColumnComboBox comboBox = new XMultiColumnComboBox("comboBox");
	   	   List<XTableColumn> cols = new ArrayList<XTableColumn>();   
	   	   cols.add(new XTableColumn("col1", "Column1", 70));
	   	   cols.add(new XTableColumn("col2", "Column2", 70));
	   	   cols.add(new XTableColumn("col3", "Column3", 70));
	   	   cols.get(0).setRenderer(new FormattedTextRenderer("##-##"));
	   	   comboBox.setColumns(cols);
	   	   
	   	   TableContainer source = new TableContainer(new Object[] {"col1", "col2", "col3"});
	   	   source.addNewRow(new Object[] {"1111", "abscf", "iiii"});
	   	   source.addNewRow(new Object[] {"2222", "abscf", "kkk"});
	   	   source.addNewRow(new Object[] {"3333", "abscf", "zzzz"});
	   	   source.addNewRow(new Object[] {"4444", "abscf", "cccc"});
	   	   comboBox.setDataSource(source);
	   	   comboBox.setPrimaryKey("col1");
	   	   comboBox.setValue("2222");
	   	   
	   	   comboBox.setBackground(Color.yellow);
	   	   comboBox.setForeground(Color.blue);
	   	   comboBox.setFont(new XFont("Courier", Font.BOLD, 12));
	   	   comboBox.setSearchable(true);
	   	   comboBox.setDescription("ja som combo box" );
	   	   comboBox.setValue("3333");
	   	   //comboBox.setSelectingFromListAllowed(false);
	   	   
	   	   //XTextField field = new DRTextField("editor");
	   	   //comboBox.setEditor(field);
	   	   
	   	   XFormattedTextField field = new XFormattedTextField("##-##");
	   	   comboBox.setEditor(field);
	   	   
	       comboBox.setEditable(true);
	       comboBox.setRenderer(new FormattedTextRenderer("##-##"));
	   	   
//	   	   comboBox.setWidth(200);
	   	   comboBox.addMouseEvent(new ServerMouseEvent(ServerEvent.MOUSE_CLICKED_EVENT));
	   	   comboBox.addFocusEvent(new ServerFocusEvent(ServerEvent.FOCUS_GAINED_EVENT));
	   	   comboBox.addKeyEvent(new ServerKeyEvent(ServerEvent.KEY_TYPED_EVENT));
	   	   comboBox.addActionEvent(new ServerActionEvent());
	   	   comboBox.addPopupEvent(new ServerPopupEvent());
	   	   
	   	   XBoxPanel panel = new XBoxPanel();
	   	   panel.setInsets(new Insets(10, 10, 10, 10));
	   	   panel.add(comboBox);
	   	   panel.addGap(20);
	   	   
	   	   ServerActionEvent event = new ServerActionEvent();
	   	   event.addReturnProperty("comboBox");
	   	   event.setReturnAllValues(true);
	   	   panel.add(new XButton("Potvrd", "Potvrd", event));   	
	   	   panel.addGap(5);
	   	   panel.add(new XButton("Update", "Update"));   	   
	   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel); 
	   	   form.setTitle("combo box");
	   	   
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	   }
	   
	   private void update(ServerPack pack) {
	   	   MultiColumnComboBoxSettings cbp = new MultiColumnComboBoxSettings();
	   	   TableRow row = new TableRow("2222");  
	   	   row.add("col2", "gggggg");
	   	   cbp.setUpdatedItems(new TableRow[]{row});
	   	   
	   	   row = new TableRow();
	   	   row.add("col1", "5555");
	   	   row.add("col2", "kkkkk");
	   	   row.add("col3", "zzzzz");
	   	   cbp.setInsertedItems(new TableRow[]{row});
	   	   
	   	   cbp.setDeletedItems(new String[] {"1111"});
	   	   
	   	   cbp.setSelectedItem("4444");
	   	   cbp.setBackground(Color.red);
	   	   cbp.setForeground(Color.yellow);
	   	   cbp.setFont(new XFont("Courier", Font.PLAIN, 12));
	   	   ValuePack valuePack = new ValuePack();
	   	   valuePack.put("comboBox", cbp);
	   	   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
	   }
	   
	   public static void main(String...strings) {
		   MediatorRunner.run(DemoMultiColumnComboBox.class, null, null, "flat");
	   }
}	
