package demo.framework.components;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DateFormatSymbols;
import java.util.Calendar;

import javax.swing.SwingConstants;
import javax.swing.UIManager;

import netball.client.ui.jtc.awt.lookandfeel.MetalLookAndFeelNew;
import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XForm;
import netball.server.component.XLabel;
import netball.server.component.XPanel;
import netball.server.component.XSlider;
import netball.server.component.renderer.DateRenderer;
import netball.server.component.setting.LabelSettings;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientFocusEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ClientStateChangedEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerStateChangedEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoSlider extends BasicMediator { 

	@Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void focusEventExecuted(ClientFocusEvent event, ServerPack pack) {
		System.out.println(event);
	}
	
	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
		if (event.getSourceId().equals("OK")) {
			System.out.println(event.getValuePack());
		}else if (event.getSourceId().equals("update")) {
			Calendar calendar = Calendar.getInstance();
			calendar.set(Calendar.MILLISECOND, 0);
			calendar.set(Calendar.SECOND, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.HOUR_OF_DAY, 1);
			calendar.add(Calendar.DAY_OF_WEEK, 3);
			
			ValuePack valuePack = new ValuePack();
			valuePack.put("timestampSlider", new Timestamp(calendar.getTimeInMillis()));
			valuePack.put("colorslider", 200);
			valuePack.put("intslider", 530);
			valuePack.put("decslider", new BigDecimal("0.6"));
			valuePack.put("intslider1", 25);
			valuePack.put("quartersslider", 2);
			pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
		}
	}

	@Override
	public void stateChangedEventExecuted(ClientStateChangedEvent event, ServerPack pack) {
		if (event.getSourceId().equals("colorslider")) {
			int value = (Integer) event.getValuePack().getValue("colorslider");
			Color color = new Color(value, 0, 0);
			
			LabelSettings settings = new LabelSettings();
			settings.setBackground(color);
			ValuePack valuePack = new ValuePack();
			valuePack.put("colorlabel", settings);
			pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
		}
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
   	   XBoxPanel boxPanel = new XBoxPanel(SwingConstants.VERTICAL);
   	   boxPanel.add(createIntegerSlider1());
   	   boxPanel.addGap(10);
   	   boxPanel.add(createIntegerSlider());
   	   boxPanel.addGap(10);
   	   boxPanel.add(createDecimalSlider());
   	   boxPanel.addGap(10);
   	   boxPanel.add(createTimestampSlider());
   	   boxPanel.addGap(10);
   	   boxPanel.add(createColorSlider());
   	   boxPanel.addGap(10);
   	   boxPanel.add(createQuarterSlider());
   	   
   	   XBoxPanel buttonPanel = new XBoxPanel(SwingConstants.HORIZONTAL);
   	   buttonPanel.setHorizontalAlignment(SwingConstants.RIGHT);
   	   buttonPanel.setGapForAll(5);
   	   
   	   XButton button = new XButton("OK", "OK");
   	   ServerActionEvent actionEvent = new ServerActionEvent();
   	   actionEvent.setReturnAllValues(true);
   	   button.addActionEvent(actionEvent);
   	   buttonPanel.add(button);

   	   button = new XButton("update", "Update");
   	   button.addActionEvent(new ServerActionEvent());
   	   buttonPanel.add(button);
   	   
   	   XBorderPanel panel = new XBorderPanel(10, 10);
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.setCenter(boxPanel);   	   
   	   panel.setSouth(buttonPanel);
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Slider");
   	   
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
    }

	private XSlider createIntegerSlider() {
		XSlider slider = new XSlider("intslider");
	   	//slider.setBackground(Color.yellow);
	   	//slider.setForeground(Color.blue);
	   	//slider.setFont(new XFont("Courier", Font.BOLD, 14));
	   	slider.setMinimum(500);
	   	slider.setMaximum(550);
	   	slider.setValue(520);
	    slider.setPaintTicks(true);
	    slider.setPaintLabels(true);
	    slider.setMinorTickSpacing(1);
	    slider.setMajorTickSpacing(5);
	    slider.setBlockIncrement(10);
	    //slider.setWidth(400);
	    //slider.setHeight(100);
	    //slider.setOrientation(SwingConstants.VERTICAL);
	    slider.addLabelTableItem(500, "500");
	    slider.addLabelTableItem(510, "510");
	    slider.addLabelTableItem(520, "520");
	    slider.addLabelTableItem(530, "530");
	    slider.addLabelTableItem(540, "540");
	    slider.addLabelTableItem(550, "550");
	   	//slider.addFocusEvent(new ServerFocusEvent(ServerEvent.FOCUS_GAINED_EVENT));
	   	//slider.addMouseEvent(new ServerMouseEvent(ServerEvent.MOUSE_ENTERED_EVENT));
	   	slider.setInverted(false);
	   	slider.setEnabled(true);
	   	slider.setUseValueToolTip(true);
	   	return slider;
	}		

	private XSlider createDecimalSlider() {
		XSlider slider = new XSlider("decslider");
	    slider.setPaintTicks(true);
	    slider.setPaintLabels(true);
	    slider.setMinorTickSpacing(1);
	    slider.setMajorTickSpacing(10);
	    slider.setBlockIncrement(30);
	    BigDecimal bd = new BigDecimal("0");
	    BigDecimal d = new BigDecimal("0.1");
	    for (int i = 0; i <= 10; i++) {
	    	slider.addItem(bd);
	    	if (i % 2 == 0)
	    		slider.addLabelTableItem(i, bd.toString());
	    	bd = bd.add(d);
	    }
	   	slider.setValue(new BigDecimal("0.3"));
	   	slider.setUseValueToolTip(true);
	   	return slider;
	}		
	
	private XSlider createIntegerSlider1() {
   	   XSlider slider = new XSlider("intslider1");
   	   slider.setMinimum(0);
  	   slider.setMaximum(50);
   	   slider.setValue(10);
       slider.setPaintTicks(true);
       slider.setPaintLabels(true);
       slider.setMinorTickSpacing(1);
       slider.setMajorTickSpacing(10);
       slider.setBlockIncrement(6);
   	   slider.setUseValueToolTip(true);
   	   return slider;
	}

	private XSlider createTimestampSlider() {
		XSlider slider = new XSlider("timestampSlider");
	    slider.setPaintTicks(true);
	    slider.setPaintLabels(true);
	    slider.setMinorTickSpacing(1);
	    slider.setBlockIncrement(10);
	    slider.setUseValueToolTip(true);
		
        DateFormatSymbols dateFormatSymbols = new DateFormatSymbols(getLocale());
        String[] weekdays = dateFormatSymbols.getWeekdays();
		
		Calendar calendar = Calendar.getInstance();
		int d = 3;
		int count = (24 / d) * 7;
		calendar.set(Calendar.MILLISECOND, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.HOUR_OF_DAY, 1);
		String weekday = null;
		for (int i = 0; i < count; i++) {
			Timestamp timestamp = new Timestamp(calendar.getTimeInMillis());
			String weekday1 = weekdays[calendar.get(Calendar.DAY_OF_WEEK)];
			if (!weekday1.equals(weekday)) {
				slider.addLabelTableItem(i, weekday1);
				weekday = weekday1; 
			}
			slider.addItem(timestamp);
			calendar.add(Calendar.HOUR_OF_DAY, d);
		}
		slider.setValue(slider.getItems().get(0));
	    slider.setMajorTickSpacing(24 / d);
	    slider.setRenderer(new DateRenderer("dd.MM.yyyy  HH:mm")); // aby sa naformatoval timestamp ak je zapnuty slider.setUseValueToolTip(true); 
	    return slider;
	}
	
	private XPanel createColorSlider() {
	   	   XSlider slider = new XSlider("colorslider");
	   	   slider.setMinimum(0);
	  	   slider.setMaximum(255);
	   	   slider.setValue(0);
	       slider.setPaintTicks(true);
	       slider.setPaintLabels(true);
	       slider.setMinorTickSpacing(0);
	       slider.setMajorTickSpacing(50);
	       slider.setBlockIncrement(2);
	   	   slider.setUseValueToolTip(true);
	   	   for (int i = 0; i < 255; i++) {
	   		   if (i % 50 == 0)
	   			slider.addLabelTableItem(i, "" + i);
	   	   }
	   	   XLabel label = new XLabel("colorlabel", null);
	   	   label.setBackground(Color.BLACK);
	   	   label.setWidth(50);
	   	   
	   	   XBoxPanel panel = new XBoxPanel(SwingConstants.HORIZONTAL);
	   	   panel.setSameHeightForAllComponents(true);
	   	   panel.add(slider);
	   	   panel.addGap(10);
	   	   panel.add(label);
	   	   
	   	   ServerStateChangedEvent changedEvent = new ServerStateChangedEvent();
	   	   changedEvent.addReturnValue("colorslider");
	   	   slider.addStateChangedEvent(changedEvent);
	   	   return panel;
	}

	private XSlider createQuarterSlider() {
		XSlider slider = new XSlider("quartersslider");
   	   	slider.setMinimum(0);
   	   	slider.setMaximum(3);
   	   	slider.setValue(0);
   	   	slider.setPaintTicks(false);
   	   	slider.setPaintLabels(true);
   	   	slider.setMajorTickSpacing(1);
   	   	slider.setBlockIncrement(50);
   	   	slider.addLabelTableItem(0, "QI");
   	   	slider.addLabelTableItem(1, "QII");
   	   	slider.addLabelTableItem(2, "QIII");
   	   	slider.addLabelTableItem(3, "QIV");
   	   	return slider;
	}
	
	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	public static void main(String...strings) {
		//UIManager.put(MetalLookAndFeelNew.DEFAULT_FONT, new Font("Dialog", Font.PLAIN, 25));
		//UIManager.put("Slider.font", new Font("Dialog", Font.PLAIN, 25));
		MediatorRunner.run(DemoSlider.class, null, null, "flat");
	} 
}
