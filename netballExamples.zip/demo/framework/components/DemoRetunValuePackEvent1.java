package demo.framework.components;

import java.awt.Dimension;
import java.awt.Insets;

import javax.swing.SwingConstants;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XDesktopPanel;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XForm;
import netball.server.component.XNumberField;
import netball.server.component.XTextField;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientReturnValuePackEvent;
import netball.server.event.ReturnValuePackDefinition;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerReturnValuePackEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

/**
 * Ukazka, ako vratit value pack zo vstkych zaregistrovanych deticiek v XDesktopPanel.  
 */
public class DemoRetunValuePackEvent1 extends BasicMediator { 
	
		@Override
		public AccessAction[] getAccessActions() {
			return null;
		}

		@Override
		public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
		   	   XBoxPanel buttonPanel = new XBoxPanel(SwingConstants.HORIZONTAL);
		   	   buttonPanel.setInsets(new Insets(10, 10, 10, 10));
		   	   buttonPanel.setHorizontalAlignment(SwingConstants.RIGHT);
		   	   buttonPanel.add(new XButton("retunValuePackEvent", "Run retun value pack event", new ServerActionEvent()));
		   	   
		   	   XDesktopPanel desktopPanel = new XDesktopPanel("desktopPanel");
		   	   
		   	   XBorderPanel panel = new XBorderPanel(10, 10);
		   	   panel.setSouth(buttonPanel);
		   	   panel.setCenter(desktopPanel);
		   	   
		   	   XForm form = new XForm();
		   	   form.setPanel(panel); 
		   	   form.setTitle("DemoRetunValuePackEvent1");
		   	   form.setType(XForm.FRAME);
		   	   form.setSize(new Dimension(500, 500));
		   	   serverPack.addFormPack(new FormPack(getId(), form));
		   	   runNext(InternalFrame2.class, null, serverPack, getId(), "desktopPanel");
		   	   runNext(InternalFrame1.class, null, serverPack, getId(), "desktopPanel");
		}
		
	    @Override
		public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
	   	   if (event.getSourceId().equals("retunValuePackEvent")) {
				ServerReturnValuePackEvent returnEvent = new ServerReturnValuePackEvent(getId(), "retunValuePackEvent");
				// vrat value pack zo vsetkych deticiek 
				for (int i = 0; i < getChildrenCount(); i++) {
					// definovanie co sa ma vratit z registrovanych formularov z klienta
					ReturnValuePackDefinition definition = new ReturnValuePackDefinition(getChild(i));
					definition.setReturnAllValues(true);
					returnEvent.addDefinition(definition);
				}
				pack.setSendingServerReturnValuePackEvent(returnEvent);
	   	   }
	   }

	   @Override
	   public void returnValuePackEventExecuted(ClientReturnValuePackEvent event, ServerPack pack) {
			if (event.getSourceId().equals("retunValuePackEvent")) {
				for (int i = 0; i < getChildrenCount(); i++) {
					ValuePack valuePack = event.getValuePack(getChild(i));
					System.out.println("Form id=" + getChild(i) + " " + valuePack);
				}
			}
	   }
		
	   public static class InternalFrame1 extends BasicMediator { 
			 
			@Override
			public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
			   XDualComponentPanel panel = new XDualComponentPanel();
			   panel.add(new XTextField("textField", "Text", 20));
			   
			   XBorderPanel mainPanel = new XBorderPanel(10, 10);
			   mainPanel.setInsets(new Insets(10, 10, 10, 10));
			   mainPanel.setNorth(panel);

		   	   ValuePack valuePack = new ValuePack();
		   	   valuePack.put("textField", "any text");
			   
		   	   XForm form = new XForm();
		   	   form.setPanel(mainPanel);
		   	   form.setTitle("InternalFrame1");
		   	   
		   	   FormPack fromPack = new FormPack(getId(), form);
		   	   fromPack.setValuePack(valuePack);
		   	   
		   	   serverPack.addFormPack(fromPack);   	   
	       }

		   @Override
		   public AccessAction[] getAccessActions() {
				return null;
		   }
	   }

	   public static class InternalFrame2 extends BasicMediator { 
			 
			@Override
			public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
			   XDualComponentPanel panel = new XDualComponentPanel();
			   panel.add(new XNumberField("numberField", "Number", XNumberField.INTEGER, 10, 0));
			   
			   XBorderPanel mainPanel = new XBorderPanel(10, 10);
			   mainPanel.setInsets(new Insets(10, 10, 10, 10));
			   mainPanel.setNorth(panel);

		   	   ValuePack valuePack = new ValuePack();
		   	   valuePack.put("numberField", 100);
			   
		   	   XForm form = new XForm();
		   	   form.setPanel(mainPanel);
		   	   form.setTitle("InternalFrame2");
		   	   
		   	   FormPack fromPack = new FormPack(getId(), form);
		   	   fromPack.setValuePack(valuePack);
		   	   
		   	   serverPack.addFormPack(fromPack);   	   
	       }

		   @Override
		   public AccessAction[] getAccessActions() {
				return null;
		   }
	   }
	   
	   public static void main(String...strings) {
	    	MediatorRunner.run(DemoRetunValuePackEvent1.class, null, null, "flat" ); 
	   } 
}
