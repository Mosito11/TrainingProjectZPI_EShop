package demo.framework.components;

import java.awt.Insets;

import javax.swing.SwingConstants;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XDateFieldWithCalendar;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XForm;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientFocusEvent;
import netball.server.event.ClientKeyEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerEvent;
import netball.server.event.ServerFocusEvent;
import netball.server.event.ServerKeyEvent;
import netball.server.event.ServerMouseEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.utilities.TypeValues;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoDateFieldWithCalendar extends BasicMediator { 

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	   if (event.getSourceId().equals("Potvrd")) {
   	   	  System.out.println(event.getValuePack());
   	   }else if (event.getSourceId().equals("dateField")) {
   		   System.out.println(event);
   	   }
   }

    @Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
		System.out.println(event);
	}
	
	@Override
	public void focusEventExecuted(ClientFocusEvent event, ServerPack pack) {
		System.out.println(event);
	}
	
	@Override
	public void keyEventExecuted(ClientKeyEvent event, ServerPack pack) {
		System.out.println(event);
	}
   
	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
   	   XDateFieldWithCalendar dateField = new XDateFieldWithCalendar("dateField", "Date", "dd.MM.yyyy", TypeValues.SQL_DATE);
   	   //dateField.setBackground(Color.yellow);
   	   //dateField.setForeground(Color.blue);
//   	   dateField.setFont(new XFont("Courier", Font.BOLD, 12));   	   
   	   dateField.setDate(new java.util.Date(System.currentTimeMillis()));
   	   dateField.setDescription("ja som date field");
   	   //dateField.setLocale(Locale.CHINA);
   	   dateField.setToolTipText("tool tip text");
   	   
   	   //dateField.setWidth(100);
   	   dateField.setHorizontalAlignment(javax.swing.SwingUtilities.RIGHT);
   	   dateField.addMouseEvent(new ServerMouseEvent(ServerEvent.MOUSE_CLICKED_EVENT));
   	   dateField.addFocusEvent(new ServerFocusEvent(ServerEvent.FOCUS_GAINED_EVENT));
   	   dateField.addFocusEvent(new ServerFocusEvent(ServerEvent.FOCUS_LAST_EVENT));
   	   dateField.addKeyEvent(new ServerKeyEvent(ServerEvent.KEY_TYPED_EVENT));
   	   dateField.addActionEvent(new ServerActionEvent());
   	   
   	   XDualComponentPanel datePanel = new XDualComponentPanel();
   	   datePanel.add(dateField);
   	   
   	   XDateFieldWithCalendar timestampField = new XDateFieldWithCalendar("timestampField", "Timestamp", "dd.MM.yyyy  HH:mm:ss", TypeValues.TIMESTAMP);
   	   datePanel.add(timestampField);
   	   
   	   XDateFieldWithCalendar timeField = new XDateFieldWithCalendar("timeField", "Time", "kk:mm:ss", TypeValues.TIME);
   	   datePanel.add(timeField);

   	   XDateFieldWithCalendar accountDateField = new XDateFieldWithCalendar("accountDate", "AccountDate", "yyyy.MM", TypeValues.ACCOUNT_DATE);
   	   datePanel.add(accountDateField);
   	   
   	   XBoxPanel butttonPanel = new XBoxPanel();
   	   butttonPanel.setHorizontalAlignment(SwingConstants.RIGHT);
   	   
   	   ServerActionEvent event = new ServerActionEvent();
   	   event.setReturnAllValues(true);
   	   butttonPanel.add(new XButton("Potvrd", "Potvrd", event));   	   
   	   
   	   XBorderPanel panel = new XBorderPanel(10, 10); 
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.setCenter(datePanel);
   	   panel.setSouth(butttonPanel);
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Date field with calendar");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }

   public static void main(String...strings) {
	   //UIManager.put(MetalLookAndFeelNew.DEFAULT_FONT, new Font("Dialog", Font.PLAIN, 25));
	   MediatorRunner.run(DemoDateFieldWithCalendar.class, null, null, "flat" );
   } 
}	

