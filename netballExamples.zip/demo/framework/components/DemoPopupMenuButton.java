package demo.framework.components;

import java.awt.Font;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;

import javax.swing.UIManager;
import javax.swing.plaf.FontUIResource;

import netball.client.ui.jtc.awt.lookandfeel.MetalLookAndFeelNew;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XForm;
import netball.server.component.XMenu;
import netball.server.component.XPopupMenuButton;
import netball.server.component.setting.PopupMenuButtonSettings;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientPopupEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerPopupEvent;
import netball.server.pack.EnabledPack;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MDUtilities;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoPopupMenuButton extends BasicMediator{

	private boolean menuWasReading; 
	
	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
		System.out.println(event);
		if (event.getSourceId().equals("button2")) {
			  PopupMenuButtonSettings settings = new PopupMenuButtonSettings();
			  EnabledPack enabledPack = new EnabledPack();
			  enabledPack.put("button0.item2", false);
			  settings.setEnabledMenuPack(enabledPack);
			  ValuePack valuePack = new ValuePack();
			  valuePack.put("button0", settings);
			  pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
		}
	}

	@Override
	public void popupEventExecuted(ClientPopupEvent event, ServerPack pack) {
		if (event.getSourceId().equals("button1")) {
		   if (!menuWasReading) {
			   PopupMenuButtonSettings settings = new PopupMenuButtonSettings();
			   List<XMenu> menu = new ArrayList<>();
			   menu.add(new XMenu("button1.item1", "Menu 4"));
			   menu.add(new XMenu("button1.item2", "Menu 5"));
			   menu.add(new XMenu("button1.item3", "Menu 6"));
			   settings.setMenu(menu);
			   ValuePack valuePack = new ValuePack();
			   valuePack.put("button1", settings);
			   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
		   }
		}
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
		   XBoxPanel panel = new XBoxPanel();
		   panel.setInsets(new Insets(10, 10, 10, 10));
		   panel.setGapForAll(5);
		   
		   XPopupMenuButton button = new XPopupMenuButton("button0", "button");
		   button.setIcon(MDUtilities.loadIcon(MDUtilities.ADD_ICON, getSessionObject()));
		   button.addMenuItem(new XMenu("button0.item1", "Menu 1"));
		   button.addMenuItem(new XMenu("button0.item2", "Menu 2"));
		   button.addMenuItem(new XMenu("button0.item3", "Menu 3"));
		   panel.add(button);
		   
		   button = new XPopupMenuButton("button1", "dynamic button");
		   button.addPopupEvent(new ServerPopupEvent());
		   panel.add(button);

		   panel.add(new XButton("button2", "enable items button0", new ServerActionEvent()));
		   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel); 
	   	   form.setTitle("Popup menu button");   	
	   	   
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	}
	
	public static void main(String...strings) {
		MediatorRunner.run(DemoPopupMenuButton.class, null, null, "flat");
	} 

}
