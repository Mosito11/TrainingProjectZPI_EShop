package demo.framework.components;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Insets;
import java.sql.Date;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import javax.swing.SwingConstants;

import netball.client.ui.jtc.awt.spantable.SpanCell;
import netball.client.ui.jtc.spantable.BasicSpanTableCell;
import netball.client.ui.jtc.spantable.SpanTableDataSource;
import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XColorComboBox;
import netball.server.component.XComboBox;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XForm;
import netball.server.component.XSpanTable;
import netball.server.component.XTextField;
import netball.server.component.renderer.DateRenderer;
import netball.server.component.setting.SpanTableSettings;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.RequiredPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorCallBackObject;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoSpanTableScheduler extends BasicMediator { 

	   private SimpleDateFormat headerDateFormat;
	   private SimpleDateFormat timeFormat;
	   private Calendar calendar;
	   private Date[] days;
	   private Time[] times;
	   private int headerColumnCount = 5;
	   private static final String TABLE = "table";
	   private static final String ADD_ACTION = "addAction";
	   private static final String CORRECT_ACTION = "correctAction";
	   private static final String DELETE_ACTION = "deleteAction";
	   private ObjednanieList objednania = new ObjednanieList();
	
	   @Override
	   public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
		   headerDateFormat = new SimpleDateFormat("EEEEE d.M.", new Locale("sk", "SK"));
		   timeFormat = new SimpleDateFormat("HH:mm");
		   calendar = Calendar.getInstance();
		   days = createDays();
		   times = createTimes();
		   
		   XSpanTable table = new XSpanTable(TABLE);
		   table.setScrollableTable(createScrollableTable());
		   table.setScrollableTableHeder(createScrollableTableHeader());
		   
		   XBoxPanel buttonPanel = new XBoxPanel(SwingConstants.HORIZONTAL);
		   buttonPanel.setGapForAll(5);
		   XButton button = new XButton(ADD_ACTION, "Pridaj");
		   button.addActionEvent(new ServerActionEvent());
		   buttonPanel.add(button);

		   button = new XButton(CORRECT_ACTION, "Oprav");
		   ServerActionEvent event = new ServerActionEvent();
		   event.addReturnValue(TABLE);
		   button.addActionEvent(event);
		   buttonPanel.add(button);
		   
		   button = new XButton(DELETE_ACTION, "Vymaz");
		   event = new ServerActionEvent();
		   event.addReturnValue(TABLE);
		   button.addActionEvent(event);
		   buttonPanel.add(button);
		   
	   	   XBorderPanel panel = new XBorderPanel(10, 10);
	   	   panel.setInsets(new Insets(10, 10, 10, 10));
	   	   panel.setCenter(table);
	   	   panel.setSouth(buttonPanel);
	   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel); 
	   	   form.setTitle("Span table scheduler");
	   	   form.setSize(new Dimension(800, 600));
	   	   serverPack.addFormPack(new FormPack(getId(), form));
	   }
	   
	   private XSpanTable.Table createScrollableTable() throws Exception {
		   XSpanTable.Table table = new XSpanTable.Table();
		   SpanTableDataSource source = new SpanTableDataSource(times.length - 1, headerColumnCount * days.length);
		   for (int i = 0; i < days.length; i++) {
			   for (int k = 0; k < times.length - 1; k++) {
				   String text = timeFormat.format(times[k]) + " - " + timeFormat.format(times[k + 1]);
			       BasicSpanTableCell cell = new BasicSpanTableCell(text, k, headerColumnCount * i, 1, 1);
			       cell.setHorizontalAlignment(SwingConstants.CENTER);
			       source.addSpan(cell);
			   }
		   }
		   table.setDataSource(source);
		   
		   // data
		   objednania.add(new Objednanie(days[0], times[0], times[2], "1235", "Hrasko", "125", "poznamka", Color.YELLOW));
		   objednania.add(new Objednanie(days[0], times[2], times[5], "1245", "Matovic", "456, 123", null, Color.CYAN));
		   objednania.add(new Objednanie(days[1], times[3], times[5], "7896", "Seliga", "789, 789", null, Color.YELLOW));
		   
		   List<SpanCell> cells = new ArrayList<>();
		   for (int i = 0;i < objednania.size(); i++) {
			   createCells(objednania.get(i), cells);
		   }
		   source.addSpans(cells);
		   return table;
	   } 
	   
	   private Time[] createTimes() {
		   // from 6:00 to 13:00 step 15min
		   calendar.clear();
		   calendar.set(Calendar.HOUR, 13);
		   long to = calendar.getTimeInMillis();
		   List<Time> times = new ArrayList<>();
		   boolean isFirst = true;
		   calendar.clear();
		   while(true) {
			   if (isFirst) {
				   calendar.set(Calendar.HOUR, 6);
				   isFirst = false;
			   }else {
				   calendar.add(Calendar.MINUTE, 15);
			   }
			   if (calendar.getTimeInMillis() > to)
				   break;
			   times.add(new Time(calendar.getTimeInMillis()));
		   }
		   Time[] arr = new Time[times.size()];
	       times.toArray(arr);
		   return arr;
	   } 
	   
	   private Date[] createDays() {
		   // from 2.1.2023 to 6.1.2023
		   Date[] days = new Date[5];
		   int k = 0;
		   for (int i = 2; i < 7; i++) {
			   calendar.clear();
			   calendar.set(2023, 0, i);
			   days[k] = new Date(calendar.getTimeInMillis());
			   k++; 
		   }
		   return days; 
	   } 
	   
	   private XSpanTable.Header createScrollableTableHeader() {
		   XSpanTable.Header header = new XSpanTable.Header();
		   SpanTableDataSource source = new SpanTableDataSource(2, headerColumnCount * days.length);
		   header.setDataSource(source);
		   header.setResizingAllowed(true);
		   int columnWidths[] = new int[headerColumnCount * days.length];
		   for (int i = 0; i < days.length; i++) {
			   addDayHeader(days[i], source, i * headerColumnCount);
			   // sirky stlpcov
			   int k = i * headerColumnCount;
			   columnWidths[k] = 100;
			   columnWidths[k + 1] = 60;
			   columnWidths[k + 2] = 120;
			   columnWidths[k + 3] = 80;
			   columnWidths[k + 4] = 90;
		   }
		   header.setColumnWidths(columnWidths);
		   return header;
	    } 
	   
	    private void addDayHeader(Date date, SpanTableDataSource source, int fromCol) {
	       source.addSpan(createHeaderCell("Interval", 0, fromCol, 2, 1));	
		   source.addSpan(createHeaderCell(headerDateFormat.format(date), 0, 1 + fromCol, 1, 4));
		   source.addSpan(createHeaderCell("Os. cislo", 1, 1 + fromCol, 1, 1));
		   source.addSpan(createHeaderCell("Meno", 1, 2 + fromCol, 1, 1));
		   source.addSpan(createHeaderCell("Vykon", 1, 3 + fromCol, 1, 1));
		   source.addSpan(createHeaderCell("Poznamka", 1, 4 + fromCol, 1, 1));
	    } 
	    
	    private BasicSpanTableCell createHeaderCell(String text, int row, int column, int height, int width) {
	    	BasicSpanTableCell cell = new BasicSpanTableCell(text, row, column, height, width);
			cell.setBackground(Color.LIGHT_GRAY);
			cell.setVerticalAlignment(SwingConstants.CENTER);
			cell.setHorizontalAlignment(SwingConstants.CENTER);
	    	return cell;
	    }
	   
	    private void createCells(Objednanie objednanie, List<SpanCell> cells) {
	    	int denIndex = Arrays.asList(days).indexOf(objednanie.den);
	    	int timeIndexFrom = Arrays.asList(times).indexOf(objednanie.casOd);
	    	int timeIndexTo = Arrays.asList(times).indexOf(objednanie.casDo);
	    	int height = timeIndexTo - timeIndexFrom;  
	    	
	    	int col = denIndex * headerColumnCount;
	    	BasicSpanTableCell cell = new BasicSpanTableCell(objednanie.osobneCislo, timeIndexFrom, col + 1, height, 1);
	    	cell.setBackground(objednanie.farba);
	    	cell.setUserObjekt(objednanie.id);
	    	cells.add(cell);
	    	cell = new BasicSpanTableCell(objednanie.meno, timeIndexFrom, col + 2, height, 1);
	    	cell.setBackground(objednanie.farba);
	    	cell.setUserObjekt(objednanie.id);
	    	cells.add(cell);	    	
	    	cell = new BasicSpanTableCell(objednanie.vykon, timeIndexFrom, col + 3, height, 1);
	    	cell.setBackground(objednanie.farba);
	    	cell.setUserObjekt(objednanie.id);
	    	cells.add(cell);	    	
	    	cell = new BasicSpanTableCell(objednanie.poznamka, timeIndexFrom, col + 4, height, 1);
	    	cell.setBackground(objednanie.farba);
	    	cell.setUserObjekt(objednanie.id);
	    	cells.add(cell);	    	
	    }
	    
	    private void addCells(Objednanie objednanie, ServerPack pack) {
	    	SpanTableSettings settings = new SpanTableSettings();
	    	List<SpanCell> cells = new ArrayList<SpanCell>();
	    	createCells(objednanie, cells);
	    	settings.setScrollableTableAddedCells(cells);
	    	pack.addUpdatedPack(new UpdatedPack(getId(), new ValuePack(TABLE, settings)));
	    }
	    
	    private void deleteCells(Objednanie objednanie, ServerPack pack) {
    		int denIndex = Arrays.asList(days).indexOf(objednanie.den);
	    	int col = denIndex * headerColumnCount;
	    	int row = Arrays.asList(times).indexOf(objednanie.casOd);
		    	
	    	SpanTableSettings settings = new SpanTableSettings();
	    	List<SpanTableSettings.CellLaction> cells = new ArrayList<>();
	    	for (int i = 1; i <= headerColumnCount - 1; i++) {
	    		cells.add(new SpanTableSettings.CellLaction(row, col + i));
	    	}
	    	settings.setScrollableTableDeletedCells(cells);
	    	pack.addUpdatedPack(new UpdatedPack(getId(), new ValuePack(TABLE, settings)));
	    }
	    
	 	@Override
		public AccessAction[] getAccessActions() {
			return null;
		}
		
		@Override
		public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
			if (event.getSourceId().equals(ADD_ACTION)) {
				runNext(DataMediator.class, new DataMediator.Parameters(new Objednanie(),  days, times), pack);
			}else if (event.getSourceId().equals(DELETE_ACTION)) {
				BasicSpanTableCell cell = getCell(event);
				if (cell != null) {
			    	int index = objednania.getIndex((int) cell.getUserObjekt());
			    	if (index != -1) {
						deleteCells(objednania.get(index), pack);
			    		objednania.remove(index);
			    	}
				}
			}else if (event.getSourceId().equals(CORRECT_ACTION)) {
				BasicSpanTableCell cell = getCell(event);
				if (cell != null) {
					Objednanie objednanie = objednania.get(objednania.getIndex((int) cell.getUserObjekt()));
					objednanie = (Objednanie) objednanie.clone();
					runNext(DataMediator.class, new DataMediator.Parameters(objednanie,  days, times), pack);
				}
			}
		}
		
		private BasicSpanTableCell getCell(ClientEvent event) {
			SpanCell[] cells = (SpanCell[]) event.getValuePack().getValue(TABLE);
			if (cells != null) {
				BasicSpanTableCell cell = (BasicSpanTableCell) cells[0];
				if (cell.getUserObjekt() != null)
					return cell;
			}
			return null;
		}
		
		@Override
		protected boolean receiveCallBack(BasicMediator mediator, MediatorCallBackObject callBackObject, ServerPack pack) {
			if (callBackObject instanceof DataMediator.CallBack) {
				DataMediator.CallBack cb = (DataMediator.CallBack) callBackObject;
				try {
					if (cb.objednanie.id == 0) {
						objednania.add(cb.objednanie);
						addCells(cb.objednanie, pack);
					}else {
						Objednanie objednaniePovodne = objednania.get(objednania.getIndex(cb.objednanie.id));
						objednania.update(cb.objednanie);
						deleteCells(objednaniePovodne, pack);
						addCells(cb.objednanie, pack);
					}
				}catch(Exception e) {
					addExceptionToPack(e, pack);
					return false;
				}
			}
			return true;
		}

		/**
		 * Objednanie trieda 
		 */
		public static class Objednanie implements Cloneable {
			
			public int id;
			public Date den; 
			public Time casOd; 
			public Time casDo; 
			public String osobneCislo; 
			public String meno; 
			public String vykon; 
			public String poznamka; 
			public Color farba;
			
			public Objednanie() {
			}
			
			public Objednanie(Date den, Time timeFrom, Time timeTo, String osCislo, String meno, String vykon, String poznamka, Color color) {
				this.den = den;
				this.casOd = timeFrom;
				this.casDo = timeTo;
				this.osobneCislo = osCislo;
				this.meno = meno;
				this.vykon = vykon;
				this.poznamka = poznamka;
				this.farba = color;
			}
			
			public void validate() throws Exception {
				if (this.den == null)
					throw new IllegalArgumentException("Den musi byt vyplneny.");
				if (this.casOd == null)
					throw new IllegalArgumentException("Cas od musi byt vyplneny.");
				if (this.casDo == null)
					throw new IllegalArgumentException("Cas do musi byt vyplneny.");
				if (this.osobneCislo == null)
					throw new IllegalArgumentException("Osobne cislo musi byt vyplneny.");
				if (this.meno == null)
					throw new IllegalArgumentException("Meno musi byt vyplneny.");
				if (this.vykon == null)
					throw new IllegalArgumentException("Vykon musi byt vyplneny.");
				if (this.farba == null)
					throw new IllegalArgumentException("Farba musi byt vyplneny.");
				if (this.casOd.getTime() >= this.casDo.getTime())
					throw new IllegalArgumentException("Cas od musi byt < ako cas do.");
			} 

			public void validateCasInterval(Objednanie objednanie2) throws Exception {
				if (this == objednanie2 || this.id == objednanie2.id || den.getTime() != objednanie2.den.getTime())
					return;
				if (objednanie2.casDo.getTime() <= casOd.getTime() || objednanie2.casOd.getTime() >= casDo.getTime())				
					return;
		    	throw new IllegalArgumentException("Zadajte iny casovy interval, pretoze uz je obsadeny."); 
			}

			@Override
			protected Object clone() {
				try {				
					return super.clone();
				}catch(Exception e) {
					return null; 
				}
			}

			@Override
			public String toString() {
				return "Objednanie [id=" + id + "]";
			}
		}  

		/**
		 * Objednania zoznam 
		 */
		public static class ObjednanieList {
			
			private List<Objednanie> objednania = new ArrayList<>();
			private int lastId = 0; 
			
			public void add(Objednanie objednanie) throws Exception {
				objednanie.validate();
				validateCasInterval(objednanie);
				if (objednanie.id == 0) {
					lastId++;
					objednanie.id = lastId;
				}
				objednania.add(objednanie);
			}
			
			public void update(Objednanie objednanie) throws Exception {
				objednanie.validate();
				validateCasInterval(objednanie);
				int index = getIndex(objednanie.id);
				remove(index);
				objednania.add(objednanie);
			}
			
			public int size() {
				return objednania.size();
			}
			
			public Objednanie get(int index) {
				return objednania.get(index);
			}
			
			public void remove(int index) {
				objednania.remove(index);
			}

		    public int getIndex(int id) {
			   for (int i = 0; i < objednania.size(); i++) {
				   Objednanie objednanie = objednania.get(i);
				   if (objednanie.id == id)
					   return i;
			   }
			   return -1;
		    }
		    
		    public void validateCasInterval(Objednanie objednanie) throws Exception {
		    	for (int i = 0; i < objednania.size(); i++) {
		    		objednania.get(i).validateCasInterval(objednanie);
		    	} 
		    }
		}  
		
		/**
		 * Data mediator 
		 */
		public static class DataMediator extends BasicMediator {

			public static final String DEN = "den";
			public static final String CAS_OD = "casOd";
			public static final String CAS_DO = "casDo";
			public static final String OSOBNE_CISLO = "osobneCislo";
			public static final String MENO = "meno";
			public static final String VYKON = "Vykon";
			public static final String POZNAMKA = "Poznamka";
			public static final String FARBA = "Farba";
			
			public static final String OK_ACTION = "okAction";
			public static final String CANCEL_ACTION = "cancelAction";
			
			private Date[] days;
			private Time[] times;
			private Objednanie objednanie;
			
			@Override
			public void init(MediatorParameters parameters,	ServerPack serverPack) throws Exception {
				if (parameters instanceof Parameters) {
					Parameters prmts = (Parameters) parameters;
					days = prmts.days;
					times = prmts.times;
					objednanie = prmts.objednanie;
				}
				
				XDualComponentPanel panel = new XDualComponentPanel(); 
				XComboBox denComboBox = new XComboBox(DEN, "Den");
				denComboBox.setEditable(false);
				denComboBox.setRenderer(new DateRenderer("dd.MM.yyyyy"));
				for (int i = 0; i < days.length; i++) {
					denComboBox.addItem(days[i]);
				}
				panel.add(denComboBox);
				
				XComboBox casOdComboBox = new XComboBox(CAS_OD, "Cas od");
				casOdComboBox.setRenderer(new DateRenderer("HH:mm"));
				panel.add(casOdComboBox);
				XComboBox casDoComboBox = new XComboBox(CAS_DO, "Cas do");
				casDoComboBox.setRenderer(new DateRenderer("HH:mm"));
				panel.add(casDoComboBox);
				for (int i = 0; i < times.length; i++) {
					if (i < times.length - 1) 
						casOdComboBox.addItem(times[i]);
					if (i > 0)						
						casDoComboBox.addItem(times[i]);
				}
				
				panel.add(new XTextField(OSOBNE_CISLO, "Osobne cislo", 5));
				panel.add(new XTextField(MENO, "Meno", 30));
				panel.add(new XTextField(VYKON, "Vykon", 20));
				panel.add(new XTextField(POZNAMKA, "Poznamka", 50));
				panel.add(new XColorComboBox(FARBA, "Farba"));
				
				XBoxPanel buttonPanel = new XBoxPanel(SwingConstants.HORIZONTAL);
				buttonPanel.setHorizontalAlignment(SwingConstants.RIGHT);
				XButton button = new XButton(OK_ACTION, "Potvrd");
				button.addActionEvent(new ServerActionEvent(true));
				buttonPanel.add(button);
				buttonPanel.addGap(5);
				
				button = new XButton(CANCEL_ACTION, "Navrat");
				button.addActionEvent(new ServerActionEvent());
				buttonPanel.add(button);
				
				XBorderPanel mainPanel = new XBorderPanel(10, 10);
				mainPanel.setInsets(new Insets(10, 10, 10, 10));
				mainPanel.setCenter(panel);
				mainPanel.setSouth(buttonPanel);
				
			   	XForm form = new XForm();
			   	form.setPanel(mainPanel);
			   	form.setTitle("Data");
			   	
			   	FormPack formPack = new FormPack(getId(), form);
			   	formPack.setValuePack(createValuePack());
			   	formPack.setRequiredPack(createRequiredPack());
			   	serverPack.addFormPack(formPack);
		    }
			
			private ValuePack createValuePack() {
				ValuePack vp = new ValuePack();
				vp.put(DEN, objednanie.den);
				vp.put(CAS_OD, objednanie.casOd);
				vp.put(CAS_DO, objednanie.casDo);
				vp.put(OSOBNE_CISLO, objednanie.osobneCislo);
				vp.put(MENO, objednanie.meno);
				vp.put(VYKON, objednanie.vykon);
				vp.put(POZNAMKA, objednanie.poznamka);
				vp.put(FARBA, objednanie.farba);
				return vp;
			} 
			
			private RequiredPack createRequiredPack() {
				RequiredPack rp = new RequiredPack();
				rp.put(DEN, true);
				rp.put(CAS_OD, true);
				rp.put(CAS_DO, true);
				rp.put(OSOBNE_CISLO, true);
				rp.put(MENO, true);
				rp.put(VYKON, true);
//				rp.put(POZNAMKA, true);
				rp.put(FARBA, true);
				return rp;
			}
			
			private void setValuePack(ValuePack valuePack) {
				objednanie.den = (Date) valuePack.getValue(DEN);
				objednanie.casOd = (Time) valuePack.getValue(CAS_OD);
				objednanie.casDo = (Time) valuePack.getValue(CAS_DO);
				objednanie.osobneCislo = (String) valuePack.getValue(OSOBNE_CISLO);
				objednanie.meno = (String) valuePack.getValue(MENO);
				objednanie.vykon = (String) valuePack.getValue(VYKON);
				objednanie.poznamka = (String) valuePack.getValue(POZNAMKA);;
				objednanie.farba = (Color) valuePack.getValue(FARBA);;
			}

			@Override
			public AccessAction[] getAccessActions() {
				return null;
			}

			@Override
			public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
				if (event.getSourceId().equals(OK_ACTION)) {
					setValuePack(event.getValuePack());
					try {
						objednanie.validate();
						if (sendCallBack(new CallBack(objednanie), pack))
							close(pack);
					}catch(Exception e) {
						addExceptionToPack(e, pack);
					}
				}else if (event.getSourceId().equals(CANCEL_ACTION)) {
					close(pack);
				}
			}

			public static class Parameters implements MediatorParameters {
				public Date[] days;
				public Time[] times;
				public Objednanie objednanie;
				
				public Parameters(Objednanie objednanie, Date[] days, Time[] times) {
					this.days = days;
					this.times = times;
					this.objednanie = objednanie;
				}
			} 
			
			public static class CallBack implements MediatorCallBackObject {
				public Objednanie objednanie;
				
				public CallBack(Objednanie objednanie) {
					this.objednanie = objednanie;
				}
			} 
		} 
		
		public static void main(String...strings) {
			MediatorRunner.run(DemoSpanTableScheduler.class, null, null, "flat");
		}
	}
