package demo.framework.components;

import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import netball.server.component.PopupMenuBuilder;
import netball.server.component.XBorderPanel;
import netball.server.component.XClientTable;
import netball.server.component.XForm;
import netball.server.component.XMenu;
import netball.server.component.XPopupMenu;
import netball.server.component.XTable;
import netball.server.component.XTableColumn;
import netball.server.component.property.ClientTableProperties;
import netball.server.component.property.ComponentProperties;
import netball.server.component.renderer.LogicalRenderer;
import netball.server.component.setting.ClientTableSettings;
import netball.server.component.table.ClientTableSelectedRow;
import netball.server.component.table.TableContainer;
import netball.server.component.table.TableRow;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.alert.YesNoAlert;
import netball.server.pack.EnabledPack;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoTableWithPopupMenu extends BasicMediator { 
	
	
	private int lastId = 4;
	private int rowCount = 0; 
	
	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

   @Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	   if (event.getSourceId().equals("Pridaj")) {
   	   	  addNewRow(pack);
   	   }else if (event.getSourceId().equals("Vymaz")) {
   	   	  Object key = this.getSelectedKey(event.getValuePack());
   	   	  deleteRow(key, pack);
   	   }else if (event.getSourceId().equals("Oprav")) {
   	   	  Object key = this.getSelectedKey(event.getValuePack());
   	   	  updateRow(key, pack);
   	   }else if (event.getSourceId().equals("Refresh")) {
   	   	  refresh(pack);
   	   }
   }
   
	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
   	   XClientTable table = new XClientTable("table");
   	   XTableColumn column = new XTableColumn("id");
   	   column.setVisible(false);
   	   table.addColumn(column);
   	   
   	   column = new XTableColumn("firstName", "First Name", 150);
   	   table.addColumn(column);
   	   
   	   column = new XTableColumn("lastName", "Last Name", 150);
   	   table.addColumn(column);
   	   
   	   column = new XTableColumn("sport", "Sport", 150);
   	   table.addColumn(column);
   	   
   	   column = new XTableColumn("years", "# of Years", 150);
   	   table.addColumn(column);
   	
   	   column = new XTableColumn("vegetarian", "Vegetarian", 70);
   	   column.setRenderer(new LogicalRenderer());
   	   table.addColumn(column);
   	      	   
   	   table.setDataSource(createContainer());
   	   table.setSortable(true);
   	   table.setPrimaryKey("id");
   	   table.setPopupMenuBuilder(new TablePopupMenuBuilder(), this); // zaregistruje popup menu builder
   	   table.setShowStatusRow(true);
   	   table.setWidth(700);
   	   table.setHeight(400);
   	   table.setSelectionMode(XTable.MULTIPLE_INTERVAL_SELECTION);
   	   table.setFreezeColumnsAllowed(true);

   	   XBorderPanel panel = new XBorderPanel(10, 10);
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.setCenter(table);   	      	      	      	   
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Table with popup menu");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }
   
   private TableContainer createContainer() {
	   TableContainer container = new TableContainer(new String[]{"id", "firstName", "lastName", "sport", "years", "vegetarian"});
	   container.addNewRow(new Object[] {0, "Kathy", "Smith", "Snowboarding", 5, false});
	   container.addNewRow(new Object[] {1, "John", "Doe",	"Rowing", 3, true});
	   container.addNewRow(new Object[] {2, "Sue", "Black", "Knitting", 2, false});
	   container.addNewRow(new Object[] {3, "Jane", "White", "Speed reading", 20, true});
	   container.addNewRow(new Object[] {4, "Joe", "Brown", "Pool", 10, false});
	   rowCount = container.getRowCount();
       return container;
   }   
   
   private Object getSelectedKey(ValuePack pack) {
   	   ClientTableSelectedRow rows[] = (ClientTableSelectedRow[]) pack.getValue("table");
   	   if (rows  == null) 
   	      return null;
   	   return rows[0].getId();   
   }
   
   private void refresh(ServerPack pack) {
   	   ValuePack valuePack = new ValuePack();
   	   valuePack.put("table", createContainer());
   	   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
   }	
   
   private void addNewRow(ServerPack pack) {
   	   ClientTableSettings settings = new ClientTableSettings();
   	   TableRow row = new TableRow();
   	   lastId ++;
   	   row.add("id", lastId);
   	   row.add("firstName", "Juraj");
   	   row.add("lastName", "Janosik");
   	   row.add("sport", "Zbojnik");
   	   row.add("years", 15);
   	   row.add("vegetarian", false);
   	   settings.setInsertedRow(row);
   	   settings.setScrollRowToVisible(lastId);
   	   settings.setSelectedItem(lastId);
   	   ValuePack valuePack = new ValuePack();
   	   valuePack.put("table", settings);
   	   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
   	   rowCount++;
   } 
   
   private void deleteRow(Object key, ServerPack pack) {
   	   ClientTableSettings settings = new ClientTableSettings();
   	   settings.setDeletedRow(key);
   	   ValuePack valuePack = new ValuePack();
   	   valuePack.put("table", settings);
   	   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));   	  
   	   rowCount--;
   }
   
   private EnabledPack createEnabledPack() {
	   EnabledPack pack = new EnabledPack();
	   if (rowCount > 0) {
	   	   pack.put("Vymaz", true);   	   
	   	   pack.put("Oprav", true);
	   }else{
	   	   pack.put("Vymaz", false);   	   
	   	   pack.put("Oprav", false);
	   }
	   return pack;  
   }
   
   private void updateRow(Object key, ServerPack pack) {
   	   ClientTableSettings settings = new ClientTableSettings();
   	   TableRow row = new TableRow(key);
   	   row.add("firstName", "Janko");
   	   row.add("lastName", "Hrasko");
   	   settings.setUpdatedRow(row);
   	   ValuePack valuePack = new ValuePack();
   	   valuePack.put("table", settings);
   	   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));   	   
   }	
   
   private class TablePopupMenuBuilder extends PopupMenuBuilder {

		@Override
		public XPopupMenu getPopupMenu(ValuePack valuePack, Map<Object, ComponentProperties> componentProperties) throws Exception {
			ClientTableProperties properties = (ClientTableProperties) componentProperties.get("table");
			System.out.println(properties.selectedCellColumn + " " + properties.selectedCellRow + " " + properties.selectedCellValue);
			XPopupMenu popupMenu = new XPopupMenu();
			XMenu item = new XMenu("Pridaj", "Pridaj");   	      	   
			popupMenu.addMenuItem(item);
			
		   	ServerActionEvent event = new ServerActionEvent();
		   	event.addReturnValue("table");   	      	   
		   	event.addAlert(new YesNoAlert("Skutocne si prajete vymazat polozku?"));
		   	item = new XMenu("Vymaz", "Vymaz", event);   	   
		   	popupMenu.addMenuItem(item); 
		   	
		   	event = new ServerActionEvent();
		   	event.addReturnValue("table");   	      	   
		   	item = new XMenu("Oprav", "Oprav", event);   	   
		   	popupMenu.addMenuItem(item); 
		   	
		   	popupMenu.addMenuItem(new XMenu("Refresh", "Refresh")); 
		   	popupMenu.setEnabledPack(createEnabledPack());
			return popupMenu;
		}
	
		@Override
		public List<Object> returnValues() throws Exception {
			return null;
		}

		@Override
		public List<Object> returnProperties() throws Exception {
			List<Object> props = new ArrayList<>();
			props.add("table");
			return props;
		}
   }

   public static void main(String...strings) {
    	MediatorRunner.run(DemoTableWithPopupMenu.class, null, null, "flat");
   } 
}
