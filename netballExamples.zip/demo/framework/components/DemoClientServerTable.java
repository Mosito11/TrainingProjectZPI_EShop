package demo.framework.components;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;
import java.util.Calendar;
import java.util.List;

import netball.client.ui.TableColumnOrder;
import netball.client.ui.TableHeaderFilterPrmts;
import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XClientServerTable;
import netball.server.component.XFont;
import netball.server.component.XForm;
import netball.server.component.XPrintTablePreview;
import netball.server.component.XTableColumn;
import netball.server.component.renderer.DateRenderer;
import netball.server.component.renderer.ListRenderer;
import netball.server.component.renderer.LogicalRenderer;
import netball.server.component.renderer.NumberRenderer;
import netball.server.component.setting.ClientServerTableSettings;
import netball.server.component.table.ClientServerTableDataSource;
import netball.server.component.table.ListTableCellColorModel;
import netball.server.component.table.TableColumnColorModel;
import netball.server.component.table.TableContainer;
import netball.server.component.table.ValueTableRowColorModel;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientFocusEvent;
import netball.server.event.ClientKeyEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ClientSelectionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerEvent;
import netball.server.event.ServerFocusEvent;
import netball.server.event.ServerKeyEvent;
import netball.server.event.ServerMouseEvent;
import netball.server.event.ServerSelectionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoClientServerTable extends BasicMediator { 

   private DataSource dataSource;

   @Override
   public AccessAction[] getAccessActions() {
   	   return null;
   }

   @Override
   public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
	   dataSource = new DataSource();
	   serverPack.addFormPack(createForm());
   }
   
   @Override
   public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	   if (event.getSourceId().equals("Pridaj")) {
   	   	  addNewRow(pack);
   	   }else if (event.getSourceId().equals("Vymaz")) {
   	   	  int index = this.getSelectedIndex(event.getValuePack());
   	   	  if (index >= 0)
   	   	     deleteRow(index, pack);
   	   }else if (event.getSourceId().equals("Print")) {
   		   this.runNext(PrintMediator.class, new PrintMediator.Parameters("table", getId()), pack);
   	   }else if (event.getSourceId().equals("Oprav")) {
   	   	  int index = this.getSelectedIndex(event.getValuePack());
   	   	  if (index >= 0)
   	   	     updateRow(index, pack);
   	   }else if (event.getSourceId().equals("Refresh")) {
   	   	  refresh(pack);
   	   }
   }
   
   @Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
		System.out.println(event);
	}
	
	@Override
	public void focusEventExecuted(ClientFocusEvent event, ServerPack pack) {
		System.out.println(event);
	}
	
	@Override
	public void keyEventExecuted(ClientKeyEvent event, ServerPack pack) {
		System.out.println(event);
	}
	
	@Override
	public void selectionEventExecuted(ClientSelectionEvent event, ServerPack pack) {
		System.out.println(event.getValuePack());
	}

public FormPack createForm() {
   	   XClientServerTable table = new XClientServerTable("table");
   	   XTableColumn column = new XTableColumn("String", "String", 70);
   	   table.addColumn(column);
   	   column = new XTableColumn("Number", "Number", 70);
   	   column.setRenderer(new NumberRenderer("####.00")); 
   	   column.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
   	   column.setDescription("ja som cislo");
   	   table.addColumn(column);
   	   column = new XTableColumn("Date", "Date", 70);
   	   column.setRenderer(new DateRenderer("dd.MM.yyyy"));
   	   table.addColumn(column);
   	   column = new XTableColumn("Logic", "Logic", 70);   	   
   	   column.setRenderer(new LogicalRenderer("Yes"));
   	   column.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  	   column.setFont(new XFont("Courier", Font.ITALIC, 12));
   	   table.addColumn(column);
   	   column = new XTableColumn("List", "List", 70);   	   
   	   ListRenderer listRenderer = new ListRenderer();    	   
   	   listRenderer.put(Boolean.TRUE, "1");
   	   listRenderer.put(Boolean.FALSE, "0");
   	   column.setRenderer(listRenderer);
   	   table.addColumn(column);
   	   
   	   table.setDataSource(dataSource, this);
   	   
   	   table.setShowHorizontalLines(false);
   	   table.setShowVerticalLines(false);
   	   table.setBackground(Color.yellow);
   	   table.setForeground(Color.blue);
   	   table.setFont(new XFont("Courier", Font.BOLD, 12));
   	   table.setSortable(true);
   	   table.setVisibilityOfColumnsAllowed(true);
   	   table.setFreezeColumnsAllowed(true);
   	   
   	   ListTableCellColorModel colorModel = new ListTableCellColorModel();
   	   colorModel.add(new TableColumnColorModel("Logic", Color.blue, Color.green));
   	   colorModel.add(new TableColumnColorModel("Number", Color.gray, Color.green));
   	   ValueTableRowColorModel valueColorModel = new ValueTableRowColorModel();   	   
   	   valueColorModel.add("Number", new Integer(5), Color.black, Color.green);
   	   valueColorModel.add("Number", new Integer(10), Color.red, Color.blue);
   	   colorModel.add(valueColorModel);

   	   table.setTableCellColorModel(colorModel);
   	   table.setShowStatusRow(true);
//   	   table.setShowRowNumber(true);
   	   table.setWidth(400);
   	   table.setHeight(200);
   	   table.addMouseEvent(new ServerMouseEvent(ServerEvent.MOUSE_CLICKED_EVENT));
   	   table.addFocusEvent(new ServerFocusEvent(ServerEvent.FOCUS_GAINED_EVENT));
   	   table.addKeyEvent(new ServerKeyEvent(ServerEvent.KEY_TYPED_EVENT));
   	   
   	   ServerSelectionEvent selectionEvent = new ServerSelectionEvent();
   	   selectionEvent.addReturnValue("table");
   	   table.addSelectionEvent(selectionEvent);
   	   
   	   XBorderPanel panel = new XBorderPanel(10, 10);
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.setCenter(table);   	      	      	   
   	   
   	   XBoxPanel buttonPanel = new XBoxPanel(javax.swing.SwingConstants.HORIZONTAL);
   	   buttonPanel.setSameSizeForAllComponents(true);
   	   buttonPanel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
   	   buttonPanel.setGapForAll(10);
   	   panel.setSouth(buttonPanel);
   	   XButton button = new XButton("Pridaj", "Pridaj");   	   
   	   buttonPanel.add(button); 
   	   ServerActionEvent event = new ServerActionEvent();
   	   event.addReturnValue("table");   	   
   	   button = new XButton("Vymaz", "Vymaz", event);   	   
   	   buttonPanel.add(button); 
   	   button = new XButton("Oprav", "Oprav", event);   	   
   	   buttonPanel.add(button); 
   	   buttonPanel.add(new XButton("Refresh", "Refresh")); 
   	   buttonPanel.add(new XButton("Print", "Print"));    	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Client server table");
   	   
   	   return new FormPack(getId(), form);   	   
   }
   
   private int getSelectedIndex(ValuePack pack) {
   	   int rows[] = (int[]) pack.getValue("table");
   	   if (rows  == null) 
   	      return -1;
   	   return rows[0];   
   }
   
   
   private void refresh(ServerPack pack) {   	
   	   ClientServerTableSettings settings = new ClientServerTableSettings();
   	   dataSource.refresh();
   	   settings.setRefresh(true);   	   
   	   settings.setSelectedRowIndex(0);
   	   settings.setScrollRowToVisible(0);
   	   settings.setBackground(Color.cyan);
   	   settings.setForeground(Color.blue);
   	   settings.setFont(new XFont("Courier", Font.PLAIN, 12));
   	   ValuePack valuePack = new ValuePack();
   	   valuePack.put("table", settings);
   	   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));   	  
   }	
   
   private void addNewRow(ServerPack pack) {
   	   ClientServerTableSettings settings = new ClientServerTableSettings();
   	   dataSource.addNewRow();
   	   settings.setRefresh(true);   	   
   	   settings.setSelectedRowIndex(dataSource.size() - 1);
   	   settings.setScrollRowToVisible(dataSource.size() - 1);
   	   ValuePack valuePack = new ValuePack();
   	   valuePack.put("table", settings);   	   
   	   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));   	  
   } 
   
   private void deleteRow(int index, ServerPack pack) {
   	   ClientServerTableSettings settings = new ClientServerTableSettings();
   	   dataSource.deleteRow(index);
   	   settings.setRefresh(true);
   	   ValuePack valuePack = new ValuePack();
   	   valuePack.put("table", settings);
   	   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));   	  
   }
   
   
   private void updateRow(int index, ServerPack pack) {
   	   ClientServerTableSettings settings = new ClientServerTableSettings();
   	   dataSource.updateRow(index);
   	   settings.setRefresh(true);
   	   settings.setSelectedRowIndex(index);
   	   settings.setScrollRowToVisible(index);   	   
   	   ValuePack valuePack = new ValuePack();
   	   valuePack.put("table", settings);
   	   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));   	  
   }	
   
public class DataSource extends ClientServerTableDataSource  {	    

    TableContainer container;

    public DataSource() {
       container = new TableContainer(new String[] {"String", "Number", "Date", "Logic", "List"});
       refresh();
    }
    
	public Object[][] getBatch(int from, int to) throws Exception {
	    Object[][] batch = new Object[to - from][5];
	    int j = 0;
	    for (int i = from; i < to; i++) {
	    	for (int k = 0; k < 5; k++) {
	    	   batch[j][k] = container.getValueAt(i, k);
	        }
	    	j++;
	    } 
	    return batch;
	}

    public int getRowCount() throws Exception {
    	return container.getRowCount();
    }
    
    public int size() {
    	return container.getRowCount();
    }
    
    public void deleteRow(int index) {
    	container.deleteRow(index);
    }
    
    public void updateRow(int index) {
    	container.setValueAt(new Integer(20000), index, "Number");
    	container.setValueAt(new java.util.Date(), index, "Date");
    	container.setValueAt(new Boolean(false), index, "Logic");
    }
    
    public void addNewRow() {
       String key = "novyString" + Math.random();	
       container.addNewRow(new Object[] {key, new Integer(100000), new java.util.Date(), new Boolean(false), new Boolean(true)});
    }	
    
    public void refresh() {
       container.clear();	
       Calendar c = Calendar.getInstance();
       for (int i = 0; i < 1000; i++) {
       	   c.add(Calendar.DATE, 1);
       	   Object[] row = new Object[5];
       	   row[0] = "String " + i;
       	   row[1] = new Integer(i);       	   
       	   row[2] = c.getTime();
       	   row[3] = new Boolean(true);
       	   row[4] = new Boolean(false);
       	   container.addNewRow(row);
       }
   }

	@Override
	public void setFilter(List<TableHeaderFilterPrmts> prmts, ServerPack pack) {
		// nezavola sa, lebo nie je instalovany filter v stlpcoch.  
	}

	@Override
	public List<Object> getValuesForColumn(int columnIndex) {
		// nezavola sa, lebo nie je instalovany filter v stlpcoch.
		return null;
	}

	@Override
	public void tableRowCountChanged(int rowCount, ServerPack pack)	throws Exception {
		System.out.println("tableRowCountChanged.rowCount=" + rowCount);
	}

	@Override
	public void refreshExecuted(ServerPack pack) throws Exception {
	}

	@Override
	public boolean sort(TableColumnOrder[] orders) throws Exception {
		TableColumnOrder order = orders[0];
		container.sort(container.getColumnIndex(order.getColumnId()), order.isSortAsc());
    	return true;
	}
}


public static class PrintMediator extends BasicMediator {    

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
	   Parameters prmts = (Parameters) parameters;
   	   XPrintTablePreview preview = new XPrintTablePreview("viewer", prmts.tableId, prmts.mediatorId);
   	   preview.setWidth(700);
   	   preview.setHeight(500);
   	   XBorderPanel panel = new XBorderPanel(10, 10);
   	   panel.setCenter(preview);
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Preview");   	   
   	   serverPack.addFormPack(new FormPack(getId(), form)); 
    }

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}
	
	public static class Parameters implements MediatorParameters {
		public Object tableId;
		public Object mediatorId;
		
		public Parameters(Object tableId, Object mediatorId) {
			this.tableId = tableId;
			this.mediatorId = mediatorId; 
		}
	}
}

    public static void main(String...strings) {
    	MediatorRunner.run(DemoClientServerTable.class, null, null, "flat");
    }

}
