package demo.framework.components;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;

import netball.server.component.ListItem;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XComboBox;
import netball.server.component.XFont;
import netball.server.component.XForm;
import netball.server.component.XFormattedTextField;
import netball.server.component.renderer.FormattedTextRenderer;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientFocusEvent;
import netball.server.event.ClientKeyEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerEvent;
import netball.server.event.ServerFocusEvent;
import netball.server.event.ServerKeyEvent;
import netball.server.event.ServerMouseEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoComboBox1 extends BasicMediator { 


	@Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void focusEventExecuted(ClientFocusEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void keyEventExecuted(ClientKeyEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	   if (event.getSourceId().equals("Potvrd")) {
   	   	  System.out.println("value = " + event.getValuePack().getValue("comboBox"));
   	   }
   }

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
   	   XComboBox comboBox = new XComboBox("comboBox");
   	   comboBox.setVisibleCharCount(10);
   	   comboBox.setBackground(Color.yellow);
   	   comboBox.setForeground(Color.blue);
   	   comboBox.setFont(new XFont("Courier", Font.BOLD, 12));
   	   comboBox.addItem(new ListItem(null, ""));
   	   comboBox.addItem(new ListItem(new Integer(1), "AAAAA"));
   	   comboBox.addItem(new ListItem(new Integer(2), "BBBBB"));
   	   comboBox.addItem(new ListItem(new Integer(3), "CCCCC"));
   	   comboBox.addItem(new ListItem(new Integer(4), "DDDDD"));
   	   comboBox.setEditable(true);
   	   comboBox.setSearchable(true);
   	   //comboBox.setSelectedIndex(1);
   	   comboBox.setValue(new Integer(2));
   	   XFormattedTextField field = new XFormattedTextField("??-???");
   	   comboBox.setEditor(field);
   	   comboBox.setRenderer(new FormattedTextRenderer("??-???"));
   	   comboBox.setSelectedValueMustBeInList(true);
   	   
   	   
   	   //comboBox.setWidth(200);
   	   comboBox.addMouseEvent(new ServerMouseEvent(ServerEvent.MOUSE_CLICKED_EVENT));
   	   comboBox.addFocusEvent(new ServerFocusEvent(ServerEvent.FOCUS_GAINED_EVENT));
   	   comboBox.addKeyEvent(new ServerKeyEvent(ServerEvent.KEY_TYPED_EVENT));
   	   comboBox.addActionEvent(new ServerActionEvent());
   	   XBoxPanel panel = new XBoxPanel();
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.add(comboBox);
   	   panel.addGap(10);
   	   
   	   ServerActionEvent event = new ServerActionEvent();
   	   event.setReturnAllValues(true);
   	   panel.add(new XButton("Potvrd", "Potvrd", event));   	   
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Combo box");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }

	@Override
	public AccessAction[] getAccessActions() {
		return null;
    }

	public static void main(String...strings) {
		MediatorRunner.run(DemoComboBox1.class, null, null, "flat");
	}
}
