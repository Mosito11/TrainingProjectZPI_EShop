package demo.framework.components;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;

import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.plaf.FontUIResource;

import netball.client.ui.jtc.awt.lookandfeel.MetalLookAndFeelNew;
import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XCompoundField;
import netball.server.component.XExpressionField;
import netball.server.component.XForm;
import netball.server.component.XMultiColumnComboBox;
import netball.server.component.XTableColumn;
import netball.server.component.expressionfield.DateExpressionConvertor;
import netball.server.component.expressionfield.DurationTimeConvertor;
import netball.server.component.expressionfield.FormattedTextExpressionConvertor;
import netball.server.component.expressionfield.NumberExpressionConvertor;
import netball.server.component.renderer.FormattedTextRenderer;
import netball.server.component.table.TableContainer;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientFocusEvent;
import netball.server.event.ClientKeyEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ClientPopupEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerEvent;
import netball.server.event.ServerFocusEvent;
import netball.server.event.ServerKeyEvent;
import netball.server.event.ServerMouseEvent;
import netball.server.event.ServerPopupEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netball.server.utilities.TypeValues;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoExpressionField extends BasicMediator { 

   @Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	    if (event.getSourceId().equals("Potvrd")) {
    	   	System.out.println("value = " + event.getValuePack());
   	    }else if (event.getSourceId().equals("Reset")) {
            UpdatedPack updatedPack = new UpdatedPack(getId());
            updatedPack.setResetValues(true);
            pack.addUpdatedPack(updatedPack);
   	    }
	}

	@Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void focusEventExecuted(ClientFocusEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void keyEventExecuted(ClientKeyEvent event, ServerPack pack) {
		System.out.println(event);
	}
	
    @Override
	public void popupEventExecuted(ClientPopupEvent event, ServerPack pack) {
		if (event.getSourceId().equals("compoundField")) {
		     String item = "" + ((int) (Math.random() * 10000000));
		     ValuePack valuePack = new ValuePack();
		     valuePack.put("compoundField", item);
		     pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
		}
	}

@Override
   public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
   	   XBoxPanel panel = new XBoxPanel(SwingConstants.VERTICAL);
   	   panel.setGapForAll(10);
   	   panel.add(createNumberField());   	   
   	   panel.add(createMultiColumnComboBox());
   	   panel.add(createMultiColumnComboBox1());
   	   panel.add(createDateField());
   	   panel.add(createTimestampField());
   	   panel.add(createTimeField());
   	   panel.add(createAccountDateField());
   	   panel.add(createFormettedTextField());
   	   panel.add(createCompoundField());
   	   panel.add(createDurationTimeField());
   	   
   	   XBoxPanel buttonPanel = new XBoxPanel(SwingConstants.HORIZONTAL);
   	   buttonPanel.setGapForAll(5);
   	   buttonPanel.setHorizontalAlignment(SwingConstants.RIGHT);

   	   XBorderPanel mainPanel = new XBorderPanel(10, 10);
   	   mainPanel.setInsets(new Insets(10, 10, 10, 10));
   	   mainPanel.setCenter(panel);
   	   mainPanel.setSouth(buttonPanel);
   	   
   	   ServerActionEvent event = new ServerActionEvent();
   	   event.setReturnAllValues(true);
   	   buttonPanel.add(new XButton("Potvrd", "Potvrd", event));   	   
   	   buttonPanel.add(new XButton("Reset", "Reset", new ServerActionEvent()));
   	   
   	   XForm form = new XForm();
   	   form.setPanel(mainPanel); 
   	   form.setTitle("Expression field");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }

   public XExpressionField createNumberField() {
	   XExpressionField field = new XExpressionField("expressionField");
	   field.setBackground(Color.YELLOW);
	   field.setForeground(Color.BLUE);
	   //field.setFont(new XFont("Courier", Font.BOLD, 12));
	   field.setDescription("ja som expression field" );
	   field.setWidth(400);
	   field.setConvertor(new NumberExpressionConvertor(TypeValues.INTEGER));
	   
	   field.addMouseEvent(new ServerMouseEvent(ServerEvent.MOUSE_CLICKED_EVENT));
	   field.addFocusEvent(new ServerFocusEvent(ServerEvent.FOCUS_GAINED_EVENT));
	   field.addKeyEvent(new ServerKeyEvent(ServerEvent.KEY_TYPED_EVENT));
	   return field;
   }
   
	
   public XMultiColumnComboBox createMultiColumnComboBox() {
	   XExpressionField editor = new XExpressionField();
	   
	   XMultiColumnComboBox combo = new XMultiColumnComboBox("multiColumnComboBox", "MultiColumnComboBox", "col1");
	   combo.addFocusEvent(new ServerFocusEvent(ServerEvent.FOCUS_GAINED_EVENT));
	   combo.setWidth(300);
	   combo.setEditable(true);
	   combo.setEditor(editor);
	   combo.setPrimaryKey("col1");
	   List<XTableColumn> columns = new ArrayList<XTableColumn>();
	   columns.add(new XTableColumn("col1", "Col1", 30));
	   columns.add(new XTableColumn("col2", "Col2", 50));
	   combo.setColumns(columns);
	   TableContainer container = new TableContainer(new String[] {"col1", "col2"});
   	   container.addNewRow(new Object[] {"1", "1111111111"});
   	   container.addNewRow(new Object[] {"2", "2222222222"});
   	   container.addNewRow(new Object[] {"3", "3333333333"});
	   
	   combo.setDataSource(container);
	   //combo.setEnabled(false);
	   combo.setValue("123456");
	   return combo;
   }

   public XMultiColumnComboBox createMultiColumnComboBox1() {
	   XExpressionField editor = new XExpressionField();
	   editor.setConvertor(new FormattedTextExpressionConvertor("##.##"));
	   editor.setInstallDefaultDialog(false);
	   
	   XMultiColumnComboBox combo = new XMultiColumnComboBox("multiColumnComboBox1", "MultiColumnComboBox", "col1");
	   combo.addFocusEvent(new ServerFocusEvent(ServerEvent.FOCUS_GAINED_EVENT));
	   combo.setWidth(300);
	   combo.setEditable(true);
	   combo.setEditor(editor);
	   combo.setPrimaryKey("col1");
	   List<XTableColumn> columns = new ArrayList<XTableColumn>();
	   XTableColumn column = new XTableColumn("col1", "Col1", 50);
	   column.setRenderer(new FormattedTextRenderer("##.##"));
	   columns.add(column);
	   columns.add(new XTableColumn("col2", "Col2", 50));
	   combo.setColumns(columns);
	   TableContainer container = new TableContainer(new String[] {"col1", "col2"});
   	   container.addNewRow(new Object[] {"1111", "1111111111"});
   	   container.addNewRow(new Object[] {"2222", "2222222222"});
   	   container.addNewRow(new Object[] {"3333", "3333333333"});
	   
	   combo.setDataSource(container);
	   return combo;
   }
   
   public XCompoundField createCompoundField() {
	   XExpressionField editor = new XExpressionField();
	   editor.setInstallDefaultDialog(false);
	   
	   XCompoundField field = new XCompoundField("compoundField", "CompoundField");
	   field.setEditor(editor);
	   field.setWidth(300);
	   field.addPopupEvent(new ServerPopupEvent());
	   return field;
   }

   public XExpressionField createDateField() {
	   XExpressionField field = new XExpressionField("dateField");
	   field.setWidth(300);
	   field.setConvertor(new DateExpressionConvertor("dd.MM.yyyy", TypeValues.SQL_DATE));
	   return field;
   }
   
   public XExpressionField createTimestampField() {
	   XExpressionField field = new XExpressionField("timestampField");
	   field.setWidth(300);
	   field.setConvertor(new DateExpressionConvertor("dd.MM.yyyy HH:mm", TypeValues.TIMESTAMP));
	   field.setBackground(Color.CYAN);
	   field.addMouseEvent(new ServerMouseEvent(ServerEvent.MOUSE_CLICKED_EVENT));
	   field.setToolTipText("tool tip");
	   field.setDescription("description");
	   field.setForeground(Color.BLUE);
	   return field;
   }

   public XExpressionField createTimeField() {
	   XExpressionField field = new XExpressionField("timeField");
	   field.setWidth(300);
	   field.setConvertor(new DateExpressionConvertor("HH:mm:ss", TypeValues.TIME));
	   return field;
   }
   
   public XExpressionField createFormettedTextField() {
	   XExpressionField field = new XExpressionField("formatteedTextField");
	   field.setWidth(300);
	   field.setConvertor(new FormattedTextExpressionConvertor("##.??"));
	   return field;
   }

   public XExpressionField createAccountDateField() {
	   XExpressionField field = new XExpressionField("accountDateField");
	   field.setWidth(300);
	   field.setConvertor(new DateExpressionConvertor("yyyy.MM", TypeValues.ACCOUNT_DATE));
	   field.addFocusEvent(new ServerFocusEvent(ServerEvent.FOCUS_LAST_EVENT));
	   return field;
   }

   public XExpressionField createDurationTimeField() {
	   XExpressionField field = new XExpressionField("durationTimeField");
	   field.setWidth(300);
	   field.setConvertor(new DurationTimeConvertor("HH:mm", DurationTimeConvertor.MINUTE));
	   return field;
   }
   
   public static void main(String...strings) {
	   MediatorRunner.run(DemoExpressionField.class, null, null, "flat");
   }
}
