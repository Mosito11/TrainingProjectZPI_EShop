package demo.framework.components;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;
import java.util.Arrays;
import java.util.Calendar;

import javax.swing.UIManager;
import javax.swing.plaf.FontUIResource;

import netball.client.ui.jtc.awt.lookandfeel.MetalLookAndFeelNew;
import netball.server.comparator.NumberComparator;
import netball.server.component.KeyItem;
import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XClientTable;
import netball.server.component.XFont;
import netball.server.component.XForm;
import netball.server.component.XPrintTablePreview;
import netball.server.component.XTableColumn;
import netball.server.component.renderer.DateRenderer;
import netball.server.component.renderer.FormattedTextRenderer;
import netball.server.component.renderer.ListRenderer;
import netball.server.component.renderer.LogicalRenderer;
import netball.server.component.renderer.NumberRenderer;
import netball.server.component.setting.ClientTableSettings;
import netball.server.component.table.BasicTableCellColorModel;
import netball.server.component.table.ClientTableSelectedRow;
import netball.server.component.table.ComparisonTableRowColorModel;
import netball.server.component.table.ListTableCellColorModel;
import netball.server.component.table.TableColumnColorModel;
import netball.server.component.table.TableContainer;
import netball.server.component.table.TableRow;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientFocusEvent;
import netball.server.event.ClientKeyEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ClientSelectionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerEvent;
import netball.server.event.ServerFocusEvent;
import netball.server.event.ServerKeyEvent;
import netball.server.event.ServerMouseEvent;
import netball.server.event.ServerSelectionEvent;
import netball.server.event.alert.YesNoAlert;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoClientTable extends BasicMediator { 
	
	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

   @Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	   if (event.getSourceId().equals("Pridaj")) {
   	   	  addNewRow(pack);
   	   }else if (event.getSourceId().equals("Vymaz")) {
   	   	  Object key = this.getSelectedKey(event.getValuePack());
   	   	  deleteRow(key, pack);
   	   }else if (event.getSourceId().equals("Oprav")) {
   	   	  Object key = this.getSelectedKey(event.getValuePack());
   	   	  updateRow(key, pack);
   	   }else if (event.getSourceId().equals("Refresh")) {
   	   	  refresh(pack);
   	   }else if (event.getSourceId().equals("Print")) {
   		  this.runNext(PrintMediator.class, new PrintMediator.Parameters("table", getId()), pack);
   	   }
   }

   @Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
		System.out.println(event);
	}
	
	@Override
	public void focusEventExecuted(ClientFocusEvent event, ServerPack pack) {
		System.out.println(event);
	}
	
	@Override
	public void keyEventExecuted(ClientKeyEvent event, ServerPack pack) {
		System.out.println(event);
	}
	
	@Override
	public void selectionEventExecuted(ClientSelectionEvent event, ServerPack pack) {
		ClientTableSelectedRow[] rows = (ClientTableSelectedRow[]) event.getValuePack().getValue("table");
		System.out.println(event + " " + rows);
		if (rows != null) {
			System.out.println(Arrays.toString(rows));
		}
	}
   
	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
   	   XClientTable table = new XClientTable("table");
   	   XTableColumn column = new XTableColumn("String", "String", 70);
   	   table.addColumn(column);
   	   column = new XTableColumn("Number", "Number", 70);
   	   column.setRenderer(new NumberRenderer("####.00")); 
   	   column.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
   	   table.addColumn(column);
   	   column = new XTableColumn("Date", "Date", 70);
   	   column.setRenderer(new DateRenderer("dd.MM.yyyy"));
   	   table.addColumn(column);
   	   column = new XTableColumn("Logic", "Logic", 70);   	   
   	   column.setRenderer(new LogicalRenderer("Yes"));
   	   column.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
   	   column.setFont(new XFont("Courier", Font.ITALIC, 12));
   	   table.addColumn(column);
   	   column = new XTableColumn("List", "List", 70);   	   
   	   ListRenderer listRenderer = new ListRenderer();
   	   listRenderer.put(new Boolean(true), "1");
   	   listRenderer.put(new Boolean(false), "0");
   	   column.setRenderer(listRenderer);
   	   table.addColumn(column);
   	   column = new XTableColumn("Form.String", "Form.String", 70);   	   
   	   column.setRenderer(new FormattedTextRenderer("???-###"));
   	   table.addColumn(column);
   	      	   
   	   table.setDataSource(createContainer());
   	   table.setShowHorizontalLines(false);
   	   table.setShowVerticalLines(false);
   	   table.setBackground(Color.yellow);
   	   table.setForeground(Color.blue);
   	   table.setFont(new XFont("Courier", Font.BOLD, 12));
   	   table.setSortable(true);
   	   table.setPrimaryKey("String");
   	   table.setVisibilityOfColumnsAllowed(true);
   	   table.setFreezeColumnsAllowed(true);
   	   
   	   ListTableCellColorModel colorModel = new ListTableCellColorModel();
   	   ComparisonTableRowColorModel colorModel1 = new ComparisonTableRowColorModel();   	   
   	   colorModel1.add("Number", new NumberComparator(), ComparisonTableRowColorModel.EQ, new Integer(5), Color.PINK, Color.green);
   	   BasicTableCellColorModel colorModel2 = new BasicTableCellColorModel();
   	   colorModel2.add("Number", 2, Color.RED, Color.YELLOW);
   	   colorModel.add(colorModel1);
   	   colorModel.add(colorModel2);
   	   colorModel.add(new TableColumnColorModel("Logic", Color.blue, Color.green));
   	   table.setTableCellColorModel(colorModel);
   	   
   	   table.setShowStatusRow(true);
//   	   table.setShowRowNumber(true);
   	   table.setWidth(600);
   	   table.setHeight(200);
   	   
   	   table.addMouseEvent(new ServerMouseEvent(ServerEvent.MOUSE_CLICKED_EVENT));
   	   table.addFocusEvent(new ServerFocusEvent(ServerEvent.FOCUS_GAINED_EVENT));
   	   table.addKeyEvent(new ServerKeyEvent(ServerEvent.KEY_TYPED_EVENT));
   	   
   	   ServerSelectionEvent selectionEvent = new ServerSelectionEvent();
   	   selectionEvent.addReturnValue("table");
   	   table.addSelectionEvent(selectionEvent);
   	   
   	   XBorderPanel panel = new XBorderPanel(10, 10);
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.setCenter(table);   	      	      	      	   
   	   
   	   XBoxPanel buttonPanel = new XBoxPanel();
   	   buttonPanel.setGapForAll(5);
   	   panel.setSouth(buttonPanel);
   	   XButton button = new XButton("Pridaj", "Pridaj");   	      	   
   	   buttonPanel.add(button); 
   	   ServerActionEvent event = new ServerActionEvent();
   	   event.addReturnValue("table");   	      	   
   	   event.addAlert(new YesNoAlert("Skutocne si prajete vymazat polozku?"));
   	   button = new XButton("Vymaz", "Vymaz", event);   	   
   	   buttonPanel.add(button); 
   	   event = new ServerActionEvent();
   	   event.addReturnValue("table");   	      	   
   	   button = new XButton("Oprav", "Oprav", event);   	   
   	   buttonPanel.add(button); 
   	   buttonPanel.add(new XButton("Refresh", "Refresh")); 
   	   buttonPanel.add(new XButton("Print", "Print")); 
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Client table");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }
   
   private TableContainer createContainer() {
       TableContainer container = new TableContainer(new String[] {"String", "Number", "Date", "Logic", "List", "Form.String"});
       Calendar c = Calendar.getInstance();
       for (int i = 0; i < 93; i++) {
       	   c.add(Calendar.DATE, 1);
       	   Object[] row = new Object[6];
       	   KeyItem item = new KeyItem("String " + i, "String " + i);
       	   item.setToolTipText(item.getText());
       	   row[0] = item;
       	   //row[0] = "String " + i;
       	   row[1] = new Integer(i);       	   
       	   row[2] = c.getTime();
       	   row[3] = Boolean.TRUE;
       	   row[4] = Boolean.FALSE;
       	   row[5] = "AAA000";
       	   container.addNewRow(row);
       }
       return container;
   }   
   
   private Object getSelectedKey(ValuePack pack) {
   	   ClientTableSelectedRow rows[] = (ClientTableSelectedRow[]) pack.getValue("table");
   	   if (rows  == null) 
   	      return null;
   	   return rows[0].getId();   
   }
   
   private void refresh(ServerPack pack) {
   	   ValuePack valuePack = new ValuePack();
   	   valuePack.put("table", createContainer());
   	   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
   }	
   
   private void addNewRow(ServerPack pack) {
   	   ClientTableSettings settings = new ClientTableSettings();
   	   TableRow row = new TableRow();
   	   String key = "novyString" + Math.random();
   	   row.add("String", key);
   	   row.add("Number", new Integer(100000));
   	   row.add("Date", new java.util.Date());
   	   row.add("Logic", Boolean.FALSE);
   	   row.add("List", Boolean.TRUE);
   	   row.add("Form.String", "BBB111");
   	   settings.setInsertedRow(row);
   	   settings.setScrollRowToVisible(key);
   	   settings.setSelectedItem(key);
   	   ValuePack valuePack = new ValuePack();
   	   valuePack.put("table", settings);
   	   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
   } 
   
   private void deleteRow(Object key, ServerPack pack) {
   	   ClientTableSettings settings = new ClientTableSettings();
   	   settings.setDeletedRow(key);
   	   ValuePack valuePack = new ValuePack();
   	   valuePack.put("table", settings);
   	   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));   	  
   }
   
   private void updateRow(Object key, ServerPack pack) {
   	   ClientTableSettings settings = new ClientTableSettings();
   	   TableRow row = new TableRow(key);
   	   row.add("Number", new Integer(20000));
   	   row.add("Date", new java.util.Date());
   	   row.add("Logic", new Boolean(false));
   	   settings.setUpdatedRow(row);
   	   ValuePack valuePack = new ValuePack();
   	   valuePack.put("table", settings);
   	   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));   	   
   }	

   public static class PrintMediator extends BasicMediator {    

		@Override
		public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
		   Parameters prmts = (Parameters) parameters;
	   	   XPrintTablePreview preview = new XPrintTablePreview("viewer", prmts.tableId, prmts.mediatorId);
	   	   preview.setWidth(700);
	   	   preview.setHeight(500);
	   	   preview.setHeaderText("Hlavicka");
	   	   preview.setPrintHorizontalLines(false);
	   	   preview.setPrintVerticalLines(false);
	   	   XBorderPanel panel = new XBorderPanel();   	   
	   	   panel.setCenter(preview);
	   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel); 
	   	   form.setTitle("Preview");   	   
	   	   form.setResizable(false);	
	   	   serverPack.addFormPack(new FormPack(getId(), form)); 
	    }

		@Override
		public AccessAction[] getAccessActions() {
			return null;
		}
		
		public static class Parameters implements MediatorParameters {
			public Object tableId;
			public Object mediatorId;
			
			public Parameters(Object tableId, Object mediatorId) {
				this.tableId = tableId;
				this.mediatorId = mediatorId; 
			}
		}
	}

    public static void main(String...strings) {
    	UIManager.put(MetalLookAndFeelNew.DEFAULT_FONT, new FontUIResource(new Font("Dialog", Font.PLAIN, 12)));
    	MediatorRunner.run(DemoClientTable.class, null, null, "flat");
    } 
}

