package demo.framework.components;

import java.awt.Dimension;
import java.awt.Insets;

import netball.server.component.XBorderPanel;
import netball.server.component.XButton;
import netball.server.component.XForm;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoFrameIconified extends BasicMediator { 

		public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
			if (event.getSourceId().equals("iconifyButton")) {
				UpdatedPack updatedPack = new UpdatedPack(getId());
				updatedPack.setFrameIconified(UpdatedPack.FRAME_ICONIFIED);
				pack.addUpdatedPack(updatedPack);
			}else if (event.getSourceId().equals("maximizeButton")) {
				UpdatedPack updatedPack = new UpdatedPack(getId());
				updatedPack.setMaximum(true);
				pack.addUpdatedPack(updatedPack);
			}
		}

	   @Override
	   public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {   
   	   	   XBorderPanel panel = new XBorderPanel(10, 10);
   	   	   panel.setInsets(new Insets(10, 10, 10, 10));
	   
		   XButton button = new XButton("maximizeButton", "Maximize frame");
	   	   button.addActionEvent(new ServerActionEvent());
	   	   panel.setNorth(button);
	   	   
		   button = new XButton("iconifyButton", "Iconify frame");
	   	   button.addActionEvent(new ServerActionEvent());
	   	   panel.setSouth(button);
   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel);
	   	   form.setTitle("DemoFrameIconified");
	   	   form.setSize(new Dimension(500, 500));	 
	   	   form.setType(XForm.FRAME);
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	   	}

		@Override
		public AccessAction[] getAccessActions() {
			return null;
		}

		public static void main(String...strings) {
			MediatorRunner.run(DemoFrameIconified.class, null, null, "metal");
		}
}