package demo.framework.components;

import javax.swing.SwingConstants;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XForm;
import netball.server.component.XRollablePanel;
import netball.server.component.XTextArea;
import netball.server.component.setting.RollablePanelSettings;
import netball.server.event.ClientActionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoRollablePanel extends BasicMediator {

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
		XBorderPanel panel = new XBorderPanel();

		XBoxPanel boxPanel = new XBoxPanel(SwingConstants.VERTICAL);
		boxPanel.setGapForAll(5);
		boxPanel.add(new XButton("EAST0", "EAST 0"));
		boxPanel.add(new XButton("EAST1", "EAST 1"));
		boxPanel.add(new XButton("EAST2", "EAST 2"));
		boxPanel.add(new XButton("EAST3", "EAST 3"));
		boxPanel.add(new XButton("ZBALIT", "!! ZBALIT !!"));
		panel.setEast(new XRollablePanel("EAST", boxPanel, XRollablePanel.EAST));

		boxPanel = new XBoxPanel(SwingConstants.VERTICAL);
		boxPanel.setGapForAll(5);
		boxPanel.add(new XButton("WEST0", "WEST 0"));
		boxPanel.add(new XButton("WEST1", "WEST 1"));
		boxPanel.add(new XButton("WEST2", "WEST 2"));
		boxPanel.add(new XButton("WEST3", "WEST 3"));
		panel.setWest(new XRollablePanel(boxPanel, XRollablePanel.WEST));

		boxPanel = new XBoxPanel(SwingConstants.HORIZONTAL);
		boxPanel.setGapForAll(5);
		boxPanel.add(new XButton("SOUTH0", "SOUTH 0"));
		boxPanel.add(new XButton("SOUTH1", "SOUTH 1"));
		boxPanel.add(new XButton("SOUTH2", "SOUTH 2"));
		boxPanel.add(new XButton("SOUTH3", "SOUTH 3"));
		panel.setSouth(new XRollablePanel(boxPanel, XRollablePanel.SOUTH));

		boxPanel = new XBoxPanel(SwingConstants.HORIZONTAL);
		boxPanel.setGapForAll(5);
		boxPanel.add(new XButton("NORTH0", "NORTH 0"));
		boxPanel.add(new XButton("NORTH1", "NORTH 1"));
		boxPanel.add(new XButton("NORTH2", "NORTH 2"));
		boxPanel.add(new XButton("NORTH3", "NORTH 3"));
		panel.setNorth(new XRollablePanel(boxPanel, XRollablePanel.NORTH));

		XTextArea textField = new XTextArea("textField");
		textField.setVisibleCharCount(50);
		textField.setVisibleRowCount(15);
		panel.setCenter(textField);

		XForm form = new XForm();
		form.setPanel(panel);
		form.setTitle("Rollable panel");
		serverPack.addFormPack(new FormPack(getId(), form));
	}

	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
		if (event.getSourceId().equals("ZBALIT")) {
			RollablePanelSettings settings = new RollablePanelSettings();
			settings.setRolled(true);
			ValuePack valuePack = new ValuePack();
			valuePack.put("EAST", settings);
			pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
		}
	}

	public static void main(String... strings) {
		MediatorRunner.run(DemoRollablePanel.class, null, null, "flat");
	}

}
