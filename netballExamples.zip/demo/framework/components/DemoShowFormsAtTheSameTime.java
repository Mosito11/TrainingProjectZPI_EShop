package demo.framework.components;

import java.awt.Insets;

import javax.swing.SwingConstants;

import netball.server.component.XBoxPanel;
import netball.server.component.XForm;
import netball.server.component.XLabel;
import netball.server.component.XList;
import netball.server.component.XTextArea;
import netball.server.component.XTextField;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoShowFormsAtTheSameTime extends BasicMediator { 
	
	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}
	
	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
	   	   XBoxPanel panel = new XBoxPanel(SwingConstants.VERTICAL);
	   	   panel.setInsets(new Insets(10, 10, 10, 10));
	   	   XLabel label = new XLabel("label");
	   	   label.setText("Form 0");
	   	   panel.add(label);
	   	   panel.add(new XTextField("textField"));
	   	   XForm form = new XForm();
	   	   form.setTitle("Form 0");
	   	   form.setPanel(panel); 
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	   	   runNext(Form1.class, parameters, serverPack);
	   	   runNext(Form2.class, parameters, serverPack);
	   	   runNext(Form3.class, parameters, serverPack);
   }

   
   public static class Form1 extends BasicMediator { 
		 
		@Override
		public void init(MediatorParameters parameters,	ServerPack serverPack) throws Exception {
	   	   XBoxPanel panel = new XBoxPanel(SwingConstants.VERTICAL);
	   	   panel.setInsets(new Insets(10, 10, 10, 10));
	   	   XTextField field = new XTextField("textField");
	   	   field.setDescription("description");
	   	   field.setText("Form 1");
	   	   panel.add(field);
	   	   panel.add(new XTextField("textField1"));		   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel); 
	   	   form.setTitle("Form 1");
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
       }

		@Override
		public AccessAction[] getAccessActions() {
			return null;
		}
   }
   
   public static class Form2 extends BasicMediator { 
		 
		@Override
		public void init(MediatorParameters parameters,	ServerPack serverPack) throws Exception {
	   	   XBoxPanel panel = new XBoxPanel(SwingConstants.VERTICAL);
	   	   panel.setInsets(new Insets(10, 10, 10, 10));
	   	   XTextArea field = new XTextArea("textField");
	   	   field.setVisibleRowCount(5);
	   	   field.setVisibleCharCount(30);
	   	   field.setDescription("description");
	   	   field.setText("Form 2");
	   	   panel.add(field);
	   	   XForm form = new XForm();
	   	   form.setPanel(panel);
	   	   form.setTitle("Form 2");
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
       }
		
		@Override
		public AccessAction[] getAccessActions() {
			return null;
		}
   }
   
   public static class Form3 extends BasicMediator { 
		 
		@Override
		public void init(MediatorParameters parameters,	ServerPack serverPack) throws Exception {
	   	   XBoxPanel panel = new XBoxPanel(SwingConstants.VERTICAL);
	   	   panel.setInsets(new Insets(10, 10, 10, 10));
	   	   XList list = new XList("list");
	   	   list.addItem("form3.1");
	   	   list.addItem("form3.2");
	   	   list.addItem("form3.3");
	   	   list.addItem("form3.4");
	   	   list.addItem("form3.5");
	   	   list.addItem("form3.6");
	   	   list.setVisibleRowCount(5);
	   	   list.setWidth(200);
	   	   panel.add(list);
	   	   XForm form = new XForm();
	   	   form.setPanel(panel);
	   	   form.setTitle("Form 3");
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
       }
		
		@Override
		public AccessAction[] getAccessActions() {
			return null;
		}
   }
   
   public static void main(String...strings) {
	   MediatorRunner.run(DemoShowFormsAtTheSameTime.class, null, null, "flat");
   }
}	
