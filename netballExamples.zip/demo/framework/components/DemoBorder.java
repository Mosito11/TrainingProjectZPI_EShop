package demo.framework.components;

import java.awt.Insets;

import javax.swing.SwingConstants;

import netball.server.component.XBoxPanel;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XForm;
import netball.server.component.XIcon;
import netball.server.component.XTextField;
import netball.server.component.border.XTitleBorder;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.utilities.Utilities;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoBorder extends BasicMediator { 

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
	   XTitleBorder border = new XTitleBorder();
//	   border.setLineColor(Color.GRAY);
//	   border.setFont(new XFont("Dialog", Font.PLAIN | Font.BOLD , 12));
	   border.setTitleText("Title");
	   //border.setInsideInsets(new Insets(5, 5, 5, 5));
	   border.setOutsideInsets(new Insets(10, 10, 10, 10));
		
	   XDualComponentPanel panel = new XDualComponentPanel();
	   panel.setBorder(border);
	   panel.add(new XTextField("item0", "Item 0", 20));
	   panel.add(new XTextField("item1", "Item 1", 10));
		
       XBoxPanel panel1 = new XBoxPanel(SwingConstants.VERTICAL);
       panel1.setSameWidthForAllComponents(true);
	   
       XBoxPanel panel2 = new XBoxPanel(SwingConstants.VERTICAL);
	   panel2.add(new XTextField("item4", "Item 4", 20));
	   border = new XTitleBorder("Text4", true, true, false, true);
	   panel2.setBorder(border);
	   panel1.add(panel2);

       panel2 = new XBoxPanel(SwingConstants.HORIZONTAL);
       panel2.setHorizontalAlignment(SwingConstants.RIGHT);
	   panel2.add(new XTextField("item5", "Item 5", 15));
	   border = new XTitleBorder("Text5", true, true, false, true);
	   border.setTitleInsetAccepted(false);
	   panel2.setBorder(border);
	   panel1.add(panel2);
	   
       panel2 = new XBoxPanel(SwingConstants.VERTICAL);
	   panel2.add(new XTextField("item6", "Item 6", 10));
	   border = new XTitleBorder("Text6", false, false, false, false);
	   border.setInsideInsets(new Insets(0, 0, 0, 0));
	   panel2.setBorder(border);
	   panel1.add(panel2);
	   
	   XBoxPanel mainPanel = new XBoxPanel(SwingConstants.VERTICAL);
	   mainPanel.setInsets(new Insets(10,10,10,10));
	   mainPanel.add(panel);
	   mainPanel.add(panel1);
	   
   	   XForm form = new XForm();
   	   form.setPanel(mainPanel); 
   	   form.setTitle("Border");
	   form.setType(XForm.DIALOG);
   	   serverPack.addFormPack(new FormPack(getId(), form));   	      	      	   
   }
	
	public static void main(String...strings) {
		MediatorRunner.run(DemoBorder.class, null, null, "flat");
	}	
}
