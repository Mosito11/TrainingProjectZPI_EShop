package demo.framework.components;

import java.awt.Font;

import javax.swing.UIManager;

import netball.client.ui.jtc.awt.AWTUtilities;
import netball.server.component.XBorderPanel;
import netball.server.component.XButton;
import netball.server.component.XFont;
import netball.server.component.XForm;
import netball.server.component.XTree;
import netball.server.component.tree.TreeClientNode;
import netball.server.component.tree.TreeContainer;
import netball.server.component.tree.TreeNode;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientFocusEvent;
import netball.server.event.ClientKeyEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ClientSelectionEvent;
import netball.server.event.ClientTreeExpansionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerEvent;
import netball.server.event.ServerFocusEvent;
import netball.server.event.ServerKeyEvent;
import netball.server.event.ServerMouseEvent;
import netball.server.event.ServerSelectionEvent;
import netball.server.event.ServerTreeExpansionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MDUtilities;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoTree extends BasicMediator { 

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}
	
	@Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void focusEventExecuted(ClientFocusEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void keyEventExecuted(ClientKeyEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void selectionEventExecuted(ClientSelectionEvent event,	ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void treeExpansionEventExecuted(ClientTreeExpansionEvent event,	ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
	   	   if (event.getSourceId().equals("Potvrd")) {
	   	   	  Object value = event.getValuePack().getValue("tree");
	   	   	  if (value != null) {
	   	   	  	 TreeClientNode[] paths = (TreeClientNode[]) value;  
	   	   	  	 for (int i = 0; i < paths.length; i++) {
	   	   	        System.out.println("paths = " + paths[i]);
	   	   	     }   
	   	   	  }
	   	   }
	   }

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
	   	   XTree tree = new XTree("tree");
	   	   tree.setFont(new XFont("Courier", Font.BOLD, 12));
	   	   tree.setDescription("ja som tree");
	   	   tree.setDataSource(createModel());
	   	   tree.setWidth(600);
	   	   tree.setHeight(200);
	   	   tree.setRowHeight(20);
	   	   tree.setHelpNavigation(XTree.TOOL_TIP_HELP_NAVIGATION);
	   	   tree.setHorizontalAlignment(javax.swing.SwingUtilities.RIGHT);
	   	   tree.addMouseEvent(new ServerMouseEvent(ServerEvent.MOUSE_CLICKED_EVENT));
	   	   tree.addFocusEvent(new ServerFocusEvent(ServerEvent.FOCUS_GAINED_EVENT));
	   	   tree.addKeyEvent(new ServerKeyEvent(ServerEvent.KEY_TYPED_EVENT));
	   	   tree.addSelectionEvent(new ServerSelectionEvent());
	   	   tree.setHelpNavigation(XTree.TOOL_TIP_HELP_NAVIGATION);   //  aby sa zobrazil tooltyp
	   	   tree.addTreeExpansionEvent(new ServerTreeExpansionEvent(ServerTreeExpansionEvent.TREE_EXPANSION_EVENT));
	   	   tree.addTreeExpansionEvent(new ServerTreeExpansionEvent(ServerTreeExpansionEvent.TREE_COLAPSION_EVENT));
	   	   tree.addTreeExpansionEvent(new ServerTreeExpansionEvent(ServerTreeExpansionEvent.TREE_WILL_COLAPSION_EVENT));
	   	   tree.addTreeExpansionEvent(new ServerTreeExpansionEvent(ServerTreeExpansionEvent.TREE_WILL_EXPANSION_EVENT));
	   	   XBorderPanel panel = new XBorderPanel();
	   	   panel.setCenter(tree);   	   
	   	   
	   	   ServerActionEvent event = new ServerActionEvent();
	   	   event.setReturnAllValues(true);
	   	   panel.setSouth(new XButton("Potvrd", "Potvrd", event));   	   
	   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel); 
	   	   form.setTitle("Tree");
	   	   
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	   }   
	   
	   private TreeContainer createModel() {
	       TreeNode rootNode = new TreeNode("JavaReference");
	       TreeNode forums = new TreeNode("Forum");
	       forums.add(new TreeNode("Thread 1"));
	       forums.add(new TreeNode("Thread 2"));
	       TreeNode node = new TreeNode("Thread 3");
	       node.setDescription("description");
	       node.setFont(new XFont("Dialog", Font.PLAIN | Font.ITALIC, 13));
	       node.setIcon(MDUtilities.loadIcon(MDUtilities.ADD_ICON, null));
	       forums.add(node);
	       TreeNode articles = new TreeNode("Articles");
	       articles.setIcon(MDUtilities.loadIcon(AWTUtilities.ARRANGE_WINDOWS_CASCADE_ICON, getSessionObject()));
	       articles.add(new TreeNode("Article 1"));
	       articles.add(new TreeNode("Article 2"));
	       TreeNode examples = new TreeNode("Examples");
	       node  = new TreeNode("Examples 1 enabled");
	       node.setEnabled(false);
	       node.setToolTipText("enabled node");
	       examples.add(node);
	       examples.add(new TreeNode("Examples 2"));
	       examples.add(new TreeNode("Examples 3"));
	       
	       rootNode.add(forums);
	       rootNode.add(articles);
	       rootNode.add(examples);
	       
	       return new TreeContainer(rootNode);
	   }
	   
	   public static void main(String...strings) {
		   MediatorRunner.run(DemoTree.class, null, null, "flat");
	   }
}

