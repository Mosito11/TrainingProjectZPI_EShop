package demo.framework.components;

import java.awt.Color;
import java.awt.Font;

import netball.server.component.XBoxPanel;
import netball.server.component.XFont;
import netball.server.component.XForm;
import netball.server.component.XIcon;
import netball.server.component.XLabel;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.utilities.Utilities;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoLabel extends BasicMediator { 


	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
   	   byte[] icon = Utilities.loadIcon("src/demo/framework/components/duke.gif");   	      	       	   
   	   
   	   XLabel label = new XLabel("Hore");
   	   label.setBackground(Color.yellow);
   	   label.setForeground(Color.blue);
   	   label.setFont(new XFont("Courier", Font.BOLD, 12));
   	   label.setVerticalTextPosition(javax.swing.SwingConstants.TOP);                
   	   label.setText("Hore");
   	   label.setIcon(new XIcon(icon));
   	   label.setDescription("ja som label");
   	   //label.setWidth(200);
   	   label.setHorizontalAlignment(javax.swing.SwingUtilities.RIGHT);
   	   XBoxPanel panel = new XBoxPanel(javax.swing.SwingConstants.VERTICAL);
   	   panel.setSameSizeForAllComponents(true);   	   
   	   panel.add(label);
   	   
   	   label = new XLabel("Dole");
   	   label.setText("Dole");
   	   label.setBackground(Color.red);
   	   label.setForeground(Color.blue);
   	   label.setFont(new XFont("Courier", Font.BOLD, 12));
   	   label.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);                
   	   label.setIcon(new XIcon(icon));
   	   panel.add(label);
   	   
   	   label = new XLabel("Vlavo");
   	   label.setText("Vlavo");
   	   label.setBackground(Color.green);
   	   label.setForeground(Color.blue);
   	   label.setFont(new XFont("Courier", Font.BOLD, 12));
   	   label.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);        
   	   label.setIcon(new XIcon(icon));
   	   panel.add(label);

   	   label = new XLabel("Vpravo");
   	   label.setText("Vpravo");
   	   label.setBackground(Color.darkGray);
   	   label.setForeground(Color.blue);
   	   label.setFont(new XFont("Courier", Font.BOLD, 12));
   	   label.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);        
   	   label.setIcon(new XIcon(icon));
   	   panel.add(label);


   	   label = new XLabel("DoleCentrovany");
   	   label.setText("Dole\nCentrovany");
   	   label.setBackground(Color.pink);
   	   label.setForeground(Color.blue);
   	   label.setFont(new XFont("Courier", Font.BOLD, 12));
       label.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
       label.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);		
   	   label.setIcon(new XIcon(icon));
   	   panel.add(label);

   	   label = new XLabel("HoreCentrovany");
   	   label.setText("Hore\nCentrovany");
   	   label.setBackground(Color.cyan);
   	   label.setForeground(Color.blue);
   	   label.setFont(new XFont("Courier", Font.BOLD, 12));
       label.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
       label.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);		
   	   label.setIcon(new XIcon(icon));
   	   panel.add(label);
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Label");
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	public static void main(String...strings) {
		MediatorRunner.run(DemoLabel.class);
	}
}
