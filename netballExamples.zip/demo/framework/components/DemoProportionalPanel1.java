package demo.framework.components;

import java.awt.Insets;

import javax.swing.SwingConstants;

import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XForm;
import netball.server.component.XProportionaPanel;
import netball.server.component.XTree;
import netball.server.component.tree.TreeContainer;
import netball.server.component.tree.TreeNode;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoProportionalPanel1 extends BasicMediator { 


	  @Override
	  public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
	   	   XTree tree1 = new XTree("tree1");
	   	   tree1.setDataSource(createModel());		  

	   	   XTree tree2 = new XTree("tree2");
	   	   tree2.setDataSource(createModel());		  
	   	   
	   	   XBoxPanel boxPanel = new XBoxPanel(SwingConstants.VERTICAL);
	   	   boxPanel.setVerticalAlignment(SwingConstants.CENTER);
	   	   boxPanel.setHorizontalAlignment(SwingConstants.CENTER);
	   	   boxPanel.add(new XButton("button1", "Button1"));
	   	   boxPanel.addGap(10);
	   	   boxPanel.add(new XButton("button2", "Button2"));
	   	   
           XProportionaPanel panel = new XProportionaPanel(SwingConstants.HORIZONTAL);
           panel.setInsets(new Insets(10, 10, 10, 10));
           panel.add(tree1, 0.5);
           panel.addGap(10);
           panel.add(boxPanel, 0.0, true);
           panel.addGap(10);
           panel.add(tree2, 0.5);
           panel.setHeight(700);
           panel.setWidth(600);
		  
	   	   XForm form = new XForm();
	   	   form.setPanel(panel); 
	   	   form.setTitle("Proportional panel");
	   	   
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	   }

	   private TreeContainer createModel() {
	       TreeNode rootNode = new TreeNode("JavaReference");
	       TreeNode forums = new TreeNode("Forum");
	       forums.add(new TreeNode("Thread 1"));
	       forums.add(new TreeNode("Thread 2"));
	       TreeNode node = new TreeNode("Thread 3");
	       forums.add(node);
	       TreeNode articles = new TreeNode("Articles");
	       articles.add(new TreeNode("Article 1"));
	       articles.add(new TreeNode("Article 2"));
	       TreeNode examples = new TreeNode("Examples");
	       node  = new TreeNode("Examples 1 enabled");
	       node.setEnabled(false);
	       node.setToolTipText("enabled node");
	       examples.add(node);
	       examples.add(new TreeNode("Examples 2"));
	       examples.add(new TreeNode("Examples 3"));
	       
	       rootNode.add(forums);
	       rootNode.add(articles);
	       rootNode.add(examples);
	       
	       return new TreeContainer(rootNode);
	   }
	  
		@Override
		public AccessAction[] getAccessActions() {
			return null;
		}
		
		public static void main(String...strings) {
			MediatorRunner.run(DemoProportionalPanel1.class, null, null, "flat");
		} 
}	
