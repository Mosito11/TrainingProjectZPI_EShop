package demo.framework.components;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;

import netball.client.ui.FileChooserFilter;
import netball.client.ui.XFile;
import netball.server.component.XBorderPanel;
import netball.server.component.XButton;
import netball.server.component.XFileChooser;
import netball.server.component.XFont;
import netball.server.component.XForm;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientFocusEvent;
import netball.server.event.ClientKeyEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerEvent;
import netball.server.event.ServerFocusEvent;
import netball.server.event.ServerKeyEvent;
import netball.server.event.ServerMouseEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoFileChooser extends BasicMediator { 
	 
        
	   
		@Override
		public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
			System.out.println(event);
		}

		@Override
		public void focusEventExecuted(ClientFocusEvent event, ServerPack pack) {
			System.out.println(event);
		}

		@Override
		public void keyEventExecuted(ClientKeyEvent event, ServerPack pack) {
			System.out.println(event);
		}
	   
		@Override
		public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
	   	   if (event.getSourceId().equals("Potvrd")) {
	   		   XFile[] files = (XFile[]) event.getValuePack().getValue("fileChooser");
	   		   if (files != null) {
	   			   for (int i = 0; i < files.length; i++) {
	   	   	          System.out.println("file=" + files[i]);
	   			   }
	   		   }
	   	   }
	   }

		@Override
		public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
	   	   XFileChooser fileChooser = new XFileChooser("fileChooser");
	   	   fileChooser.setBackground(Color.yellow);
	   	   fileChooser.setForeground(Color.blue);
	   	   fileChooser.setInstallSelectedFileList(true);
	   	   fileChooser.setFont(new XFont("Courier", Font.BOLD, 12));
	   	   fileChooser.setType(XFileChooser.SAVE);
	   	   //fileChooser.setSelectionMode(XFileChooser.FILES_ONLY);
	   	   fileChooser.setSelectionMode(XFileChooser.DIRECTORIES_ONLY);
	   	   fileChooser.setMultiSelectionEnabled(true);
	   	   //fileChooser.setCurrentDirectory("c:/");
	   	   fileChooser.setCheckExistanceOfFile(true);
	   	   FileChooserFilter[] fileFilters = new FileChooserFilter[2];
	   	   fileFilters[0] = FileChooserFilter.EXCEL;
	   	   fileFilters[1] = FileChooserFilter.TEXT;
	   	   fileChooser.setFileFilter(fileFilters);
	   	   
	   	   fileChooser.addMouseEvent(new ServerMouseEvent(ServerEvent.MOUSE_CLICKED_EVENT));
	   	   fileChooser.addFocusEvent(new ServerFocusEvent(ServerEvent.FOCUS_GAINED_EVENT));
	   	   fileChooser.addKeyEvent(new ServerKeyEvent(ServerEvent.KEY_TYPED_EVENT));
	   	   
	   	   XBorderPanel panel = new XBorderPanel(10, 10);
	   	   panel.setInsets(new Insets(10, 10, 10, 10));
	   	   panel.setCenter(fileChooser);   	   
	   	   
	   	   ServerActionEvent event = new ServerActionEvent();
	   	   event.setReturnAllValues(true);
	   	   panel.setSouth(new XButton("Potvrd", "Potvrd", event));
	   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel); 
	   	   form.setTitle("File chooser");
	   	   
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
     }

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	public static void main(String...strings) {
		MediatorRunner.run(DemoFileChooser.class, null, null, "flat");
	}
}
