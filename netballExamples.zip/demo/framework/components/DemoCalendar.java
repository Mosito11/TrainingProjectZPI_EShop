package demo.framework.components;

import java.awt.Insets;
import java.sql.Date;

import javax.swing.SwingConstants;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XCalendar;
import netball.server.component.XForm;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoCalendar extends BasicMediator {
	
	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
	   XBoxPanel buttonPanel = new XBoxPanel();
	   buttonPanel.setHorizontalAlignment(SwingConstants.LEFT);
		
	   XButton button = new XButton("setButton", "Set");
	   button.addActionEvent(new ServerActionEvent());
	   buttonPanel.add(button);
	   buttonPanel.addGap(5);
	   
	   button = new XButton("getButton", "Get");
	   ServerActionEvent event = new ServerActionEvent();
	   event.addReturnValue("kalendar");
	   button.addActionEvent(event);
	   buttonPanel.add(button);
		
	   XCalendar calendar = new XCalendar("kalendar");    	
		
	   XBorderPanel panel = new XBorderPanel(10, 10);
	   panel.setInsets(new Insets(10, 10, 10, 10));
	   panel.setNorth(calendar);
	   panel.setSouth(buttonPanel);
	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Kalendar");
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	}
	
	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
		if (event.getSourceId().equals("setButton")) {
			Date date = new Date(System.currentTimeMillis());
			pack.addUpdatedPack(new UpdatedPack(getId(), new ValuePack("kalendar", date)));
		}else if (event.getSourceId().equals("getButton")) {
			System.out.println(event.getValuePack().getValue("kalendar"));
		}
	}
	
	public static void main(String...strings) {
		MediatorRunner.run(DemoCalendar.class, null, null, "flat");
	}
}
