package demo.framework.components;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;

import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XCompoundField;
import netball.server.component.XFont;
import netball.server.component.XForm;
import netball.server.component.XTextField;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientFocusEvent;
import netball.server.event.ClientKeyEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ClientPopupEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerEvent;
import netball.server.event.ServerFocusEvent;
import netball.server.event.ServerKeyEvent;
import netball.server.event.ServerMouseEvent;
import netball.server.event.ServerPopupEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoCompoundField extends BasicMediator {
	
	

   @Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	   if (event.getSourceId().equals("Potvrd")) {
   	   	  System.out.println("value = " + event.getValuePack().getValue("field"));
//   	   	  System.out.println("properties = " + ((CompoundFieldProperties) event.getProperties().get("field")).editableValue);
          System.out.println("properties = " + event.getProperties().get("field"));
   	   }
   }
   
   @Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
		System.out.println(event);
	}
	
	@Override
	public void focusEventExecuted(ClientFocusEvent event, ServerPack pack) {
		System.out.println(event);
	}
	
	@Override
	public void keyEventExecuted(ClientKeyEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void popupEventExecuted(ClientPopupEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
   	   XCompoundField field = new XCompoundField("field");
   	   field.setBackground(Color.yellow);
   	   field.setForeground(Color.blue);
   	   field.setFont(new XFont("Courier", Font.BOLD, 12));
   	   field.setDescription("ja som Compound field");
   	   field.setWidth(100);
   	   
   	   XTextField editor = new XTextField();
   	   field.setEditor(editor);
   	   field.setEditable(true);
   	   
   	   //field.setWidth(600);
   	   field.setHorizontalAlignment(javax.swing.SwingUtilities.RIGHT);
   	   field.addMouseEvent(new ServerMouseEvent(ServerEvent.MOUSE_CLICKED_EVENT));
   	   field.addFocusEvent(new ServerFocusEvent(ServerEvent.FOCUS_LAST_EVENT));
   	   field.addKeyEvent(new ServerKeyEvent(ServerEvent.KEY_TYPED_EVENT));
   	   field.addPopupEvent(new ServerPopupEvent());
   	   
   	   XBoxPanel panel = new XBoxPanel();
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.add(field);
   	   panel.addGap(10);
   	   
   	   ServerActionEvent event = new ServerActionEvent();
   	   event.addReturnProperty("field");
   	   event.setReturnAllValues(true);
   	   panel.add(new XButton("Potvrd", "Potvrd", event));   	   
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Compound field");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	public static void main(String...strings) {
		MediatorRunner.run(DemoCompoundField.class, null, null, "flat");
	}
}
