package demo.framework.components;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XDateField;
import netball.server.component.XDateSpinner;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XFont;
import netball.server.component.XForm;
import netball.server.component.XNumberField;
import netball.server.component.XNumberSpinner;
import netball.server.component.XTextField;
import netball.server.component.setting.DateFieldSettings;
import netball.server.component.setting.DateSpinnerSettings;
import netball.server.event.ClientActionEvent;
import netball.server.pack.EnabledPack;
import netball.server.pack.FormPack;
import netball.server.pack.RequiredPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoRequiredValues extends BasicMediator { 

	
   @Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	   if (event.getSourceId().equals("button1")) {
	      RequiredPack requiredPack = new RequiredPack();
	      requiredPack.put("numberField", false);
	      requiredPack.put("spinnerDateField", true);   	   	    
	      
	      EnabledPack enabledPack = new EnabledPack();
	      enabledPack.put("dateField", false);
	       	   	  
	      UpdatedPack updatedPack = new UpdatedPack(getId());
	      updatedPack.setRequiredPack(requiredPack);
	      updatedPack.setEnabledPack(enabledPack);
	      pack.addUpdatedPack(updatedPack);
   	   }else if (event.getSourceId().equals("button2")) {
	      ValuePack valuePack = new ValuePack();
	      DateFieldSettings date = new DateFieldSettings();
	      date.setEnabled(true);
	      valuePack.put("dateField", date);	      	      
	      
	      DateSpinnerSettings dateSpinner = new DateSpinnerSettings();
	      dateSpinner.setBackground(Color.red);   	   	  
	      valuePack.put("spinnerDateField", dateSpinner);	      	        
	       	   	  
	      UpdatedPack updatedPack = new UpdatedPack(getId());
	      updatedPack.setValuePack(valuePack);
	      pack.addUpdatedPack(updatedPack);	      
   	   }else if (event.getSourceId().equals("button3")) {
	      ValuePack valuePack = new ValuePack();	      
	      DateSpinnerSettings dateSpinner = new DateSpinnerSettings();
	      dateSpinner.setValueRequired(false);
	      valuePack.put("spinnerDateField", dateSpinner);	      	        
	       	   	  
	      UpdatedPack updatedPack = new UpdatedPack(getId());
	      updatedPack.setValuePack(valuePack);
	      pack.addUpdatedPack(updatedPack);	      
   	   }   	   
   }

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
   	   XDualComponentPanel panel = new XDualComponentPanel();
   	   panel.setCaptionLacation(XDualComponentPanel.CAPTION_ON_TOP);
   	   panel.setCaptionFont(new XFont("Courier", Font.BOLD, 12));
   	   panel.setColumnCount(2);
   	   panel.add(new XNumberField("numberField", "Number field", XNumberField.INTEGER, 10, 0));
   	   panel.add(new XNumberSpinner("spinnerNumberField", "Spinner number field", XNumberSpinner.BIG_DECIMAL, 10, 2));
       panel.add(new XDateField("dateField", "Date field", "dd.MM.yyyy", XDateField.SQL_DATE));   	   
       panel.add(new XDateSpinner("spinnerDateField", "Spinner date field", "dd.MM.yyyy", XDateSpinner.DATE));   	   
       panel.add(new XTextField("textField", "Text field", 10));   	          

       XBoxPanel buttonPanel = new XBoxPanel();
       buttonPanel.setGapForAll(5);
   	   buttonPanel.add(new XButton("button1", "Button1"));   	   
   	   buttonPanel.add(new XButton("button2", "Button2"));   	   
       buttonPanel.add(new XButton("button3", "Button3"));   	           

       XBorderPanel mainPanel = new XBorderPanel(10, 10);
       mainPanel.setInsets(new Insets(10, 10, 10, 10));
       mainPanel.setCenter(panel);  
       mainPanel.setSouth(buttonPanel);

       RequiredPack requiredPack = new RequiredPack();
       requiredPack.put("numberField", true);
       requiredPack.put("dateField", true);
       requiredPack.put("spinnerDateField", true);
       requiredPack.put("spinnerNumberField", true);
  
   	   XForm form = new XForm();
   	   form.setPanel(mainPanel); 
   	   form.setTitle("Required values");   	      	   
   	   
       FormPack formPack = new FormPack(getId(), form);
       formPack.setRequiredPack(requiredPack);
   	   
   	   serverPack.addFormPack(formPack);   	   
   }
	
   public static void main(String...strings) {
	   MediatorRunner.run(DemoRequiredValues.class, null, null, "flat");
   }	
}
