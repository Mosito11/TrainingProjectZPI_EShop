package demo.framework.components;

import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;

import javax.swing.SwingConstants;

import netball.client.ui.jtc.DynamicFilterEditorBuilder;
import netball.client.ui.jtc.awt.dynamicfilter.DynamicExpression;
import netball.client.ui.jtc.awt.dynamicfilter.DynamicLogicExpression;
import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XComboBox;
import netball.server.component.XComponent;
import netball.server.component.XDynamicFilter;
import netball.server.component.XExpressionField;
import netball.server.component.XForm;
import netball.server.component.XMultiColumnComboBox;
import netball.server.component.XTableColumn;
import netball.server.component.expressionfield.DateExpressionConvertor;
import netball.server.component.setting.DynamicFilterSettings;
import netball.server.component.table.TableContainer;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netball.server.utilities.TypeValues;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoDynamicFilter extends BasicMediator { 

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}
	
	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
		if (event.getSourceId().equals("ok")) {
			DynamicLogicExpression exp = (DynamicLogicExpression) event.getValuePack().getValue("filter"); 
			System.out.println(exp);
		}else if (event.getSourceId().equals("set")) {
			DynamicLogicExpression exp = new DynamicLogicExpression(DynamicLogicExpression.OP_AND);
			
			DynamicLogicExpression exp1 = new DynamicLogicExpression(DynamicLogicExpression.OP_OR);
			exp1.addExpression(new DynamicExpression("column1", "AAAAA"));
			exp1.addExpression(new DynamicExpression("column1", "BBBBB"));
			exp.addExpression(exp1);
			
			DynamicLogicExpression exp2 = new DynamicLogicExpression(DynamicLogicExpression.OP_OR);
			exp2.addExpression(new DynamicExpression("column2", "2222"));
			exp2.addExpression(new DynamicExpression("column3", "01.02.2018"));
			exp.addExpression(exp2);

			exp.addExpression(new DynamicExpression("column4", "111111111"));
			
			ValuePack valuePack = new ValuePack();
			valuePack.put("filter", exp);
			pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
		}else if (event.getSourceId().equals("reset")) {
			ValuePack valuePack = new ValuePack();
			valuePack.put("filter", null);
			UpdatedPack updatedPack = new UpdatedPack(getId());
			updatedPack.setResetValues(true);
			pack.addUpdatedPack(updatedPack);
		}else if (event.getSourceId().equals("deactivateAll")) {
			ValuePack valuePack = new ValuePack();
            DynamicFilterSettings settings = new DynamicFilterSettings();
            settings.setActiveAll(false);
            valuePack.put("filter", settings);
            pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
		}else if (event.getSourceId().equals("activateAll")) {
			ValuePack valuePack = new ValuePack();
            DynamicFilterSettings settings = new DynamicFilterSettings();
            settings.setActiveAll(true);
            valuePack.put("filter", settings);
            pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
		}
	}


	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
		XDynamicFilter filter = new XDynamicFilter("filter");
		filter.addField("column1", "Column1");
		filter.addField("column2", "Column2");
		filter.addField("column3", "Column3");
		filter.addField("column4", "Column4");
		filter.setEditorBuilder(new EditorBuilder(), this);
		filter.setHeight(500);
		filter.setWidth(600);
		//filter.setBackground(Color.YELLOW);
		
		XBoxPanel buttonPanel = new XBoxPanel(SwingConstants.HORIZONTAL);
		buttonPanel.setSameSizeForAllComponents(true);
		buttonPanel.setGapForAll(5);
		
		XButton button = new XButton("ok", "OK");
		ServerActionEvent event = new ServerActionEvent();
		event.setReturnAllValues(true);
		button.addActionEvent(event);
		buttonPanel.add(button);
		
		button = new XButton("set", "Set");
		button.addActionEvent(new ServerActionEvent());
		buttonPanel.add(button);

		button = new XButton("reset", "Reset");
		button.addActionEvent(new ServerActionEvent());
		buttonPanel.add(button);
		
		button = new XButton("deactivateAll", "Deactivate All");
		button.addActionEvent(new ServerActionEvent());
		buttonPanel.add(button);
		
		button = new XButton("activateAll", "Activate All");
		button.addActionEvent(new ServerActionEvent());
		buttonPanel.add(button);
		
		XBorderPanel panel = new XBorderPanel(10, 10);
		panel.setInsets(new Insets(10, 10, 10, 10));
		panel.setCenter(filter);
		panel.setSouth(buttonPanel);
	   
   	   	XForm form = new XForm();
   	   	form.setPanel(panel); 
   	   	form.setTitle("Dynamic filter");
   	   	serverPack.addFormPack(new FormPack(getId(), form));   	      	      	   
   }
	
	private class EditorBuilder extends DynamicFilterEditorBuilder {

		@Override
		public XComponent createEditor(Object fieldId, String componentId) throws Exception {
			if (fieldId.equals("column1")) {
				return new XExpressionField(componentId);
			}else if (fieldId.equals("column2")) {
				XExpressionField editor = new XExpressionField();
				editor.setInstallDefaultDialog(false);
					   
				XMultiColumnComboBox combo = new XMultiColumnComboBox(componentId, "Column2", "col1");
				combo.setEditable(true);
				combo.setEditor(editor);
				combo.setPrimaryKey("col1");
				List<XTableColumn> columns = new ArrayList<XTableColumn>();
				XTableColumn column = new XTableColumn("col1", "Col1", 50);
				columns.add(column);
				columns.add(new XTableColumn("col2", "Col2", 50));
				combo.setColumns(columns);
				TableContainer container = new TableContainer(new String[] {"col1", "col2"});
		   	   	container.addNewRow(new Object[] {"1111", "1111111111"});
		   	   	container.addNewRow(new Object[] {"2222", "2222222222"});
		   	   	container.addNewRow(new Object[] {"3333", "3333333333"});
				   
		   	   	combo.setDataSource(container);
		   	   	return combo;
			}else if (fieldId.equals("column3")) {
				XExpressionField field = new XExpressionField(componentId);
				field.setConvertor(new DateExpressionConvertor("dd.MM.yyyy", TypeValues.SQL_DATE));
				return field;
			}else if (fieldId.equals("column4")) {
			   	XComboBox comboBox = new XComboBox(componentId);
			   	comboBox.setEditable(false);
			   	comboBox.setVisibleCharCount(10);
			   	comboBox.addItem("111111111");
			   	comboBox.addItem("222222222");
			   	comboBox.addItem("333333333");
				return comboBox;
			}
			return null;
		}
	}  
	
	public static void main(String...strings) {
		MediatorRunner.run(DemoDynamicFilter.class, null, null, "flat");
	}	
}
