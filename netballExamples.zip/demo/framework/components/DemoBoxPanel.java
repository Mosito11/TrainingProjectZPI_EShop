package demo.framework.components;

import java.awt.Color;
import java.awt.Insets;

import javax.swing.SwingConstants;

import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XDateField;
import netball.server.component.XForm;
import netball.server.component.XNumberField;
import netball.server.component.XTextField;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;


public class DemoBoxPanel extends BasicMediator { 


	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
	   	   XBoxPanel panel1 = new XBoxPanel(SwingConstants.VERTICAL);
	   	   panel1.setInsets(new Insets(10, 10, 10, 10));
	   	   panel1.setBackground(Color.yellow);
	   	   panel1.setGapForAll(5);
	   	   panel1.setSameSizeForAllComponents(true);
	   	   panel1.add(new XButton("button1", "Button jedna"));
	   	   panel1.add(new XButton("button2", "Button dva"));
	   	   panel1.add(new XButton("button3", "Button tri"));
	   	   panel1.add(new XButton("button4", "Button styri"));
	   	   panel1.add(new XButton("button5", "Button pat"));

	   	   XBoxPanel panel2 = new XBoxPanel(SwingConstants.VERTICAL);
	   	   panel2.setInsets(new Insets(10, 10, 10, 10));
	   	   panel2.setBackground(Color.green);
	   	   panel2.add(new XTextField("textField"));
	   	   panel2.addGap(10);
	   	   panel2.add(new XNumberField("numberField", XNumberField.BIG_DECIMAL, 10, 2));
	   	   panel2.setGapForAll(20);
	   	   panel2.add(new XDateField("dateField", "dd.MM.yyyy", XDateField.SQL_DATE));

	   	   XBoxPanel panel3 = new XBoxPanel(SwingConstants.HORIZONTAL);
	   	   panel3.setInsets(new Insets(10, 10, 10, 10));
	   	   panel3.add(panel1);
	   	   panel3.add(panel2);

	   	   XForm form = new XForm();
	   	   form.setPanel(panel3); 
	   	   form.setTitle("Box panel");
	   	   
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	   }

		@Override
		public AccessAction[] getAccessActions() {
			return null;
		}
		
		public static void main(String...strings) {
			MediatorRunner.run(DemoBoxPanel.class, null, null, "flat");
		} 
}	
