package demo.framework.components;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;

import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XFont;
import netball.server.component.XForm;
import netball.server.component.XFormattedTextField;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientFocusEvent;
import netball.server.event.ClientKeyEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerEvent;
import netball.server.event.ServerFocusEvent;
import netball.server.event.ServerKeyEvent;
import netball.server.event.ServerMouseEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoFormattedTextField extends BasicMediator { 

	@Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void focusEventExecuted(ClientFocusEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void keyEventExecuted(ClientKeyEvent event, ServerPack pack) {
		System.out.println(event);
	}
  
	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	   if (event.getSourceId().equals("Potvrd")) {
   	   	  System.out.println("value = " + event.getValuePack().getValue("textField"));
   	   }
    }

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
   	   XFormattedTextField textField = new XFormattedTextField("textField", "textField", "###-###");
   	   textField.setBackground(Color.yellow);
   	   textField.setForeground(Color.blue);
   	   textField.setFont(new XFont("Courier", Font.BOLD, 12));
   	   textField.setAreLikeSymbolsAllowed(false);
   	   textField.setValue("123256");
   	   textField.setDescription("ja som formatted text field");
   	   
   	   //textField.setWidth(200);
   	   textField.setHorizontalAlignment(javax.swing.SwingUtilities.RIGHT);
   	   textField.addMouseEvent(new ServerMouseEvent(ServerEvent.MOUSE_CLICKED_EVENT));
   	   textField.addFocusEvent(new ServerFocusEvent(ServerEvent.FOCUS_LAST_EVENT));
   	   textField.addKeyEvent(new ServerKeyEvent(ServerEvent.KEY_TYPED_EVENT));
   	   XBoxPanel panel = new XBoxPanel();
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.add(textField);
   	   panel.addGap(10);
   	   
   	   ServerActionEvent event = new ServerActionEvent();
   	   event.setReturnAllValues(true);
   	   XButton b = new XButton("Potvrd", "Potvrd", event);
   	   b.setIgnoreLastFocus(false);
   	   panel.add(b);   	   
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Formatted text field");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	public static void main(String...strings) {
		MediatorRunner.run(DemoFormattedTextField.class, null, null, "flat");
	} 
}
