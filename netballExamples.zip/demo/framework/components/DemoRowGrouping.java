package demo.framework.components;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;

import javax.swing.SwingConstants;

import netball.server.component.GroupItem;
import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XFont;
import netball.server.component.XForm;
import netball.server.component.XRowGrouping;
import netball.server.component.setting.ColumnOrderingSettings;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoRowGrouping extends BasicMediator { 

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}
	
   @Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	   if (event.getSourceId().equals("Potvrd")) {
   	   	  Object[] values = (Object[]) event.getValuePack().getValue("list");
   	   	  if (values != null) {
   	   	    for (int i = 0; i < values.length; i++) {
   	   	       System.out.println("value = " + values[i]);
   	   	    }   
   	   	  }else{
   	   	  	 System.out.println("value = null");
   	   	  } 
   	   	  System.out.println("properties = " + event.getProperties().get("list"));  
   	   }else if (event.getSourceId().equals("Update")) {	  
   	      update(pack);
   	   }
   }

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
   	   XRowGrouping list = new XRowGrouping("list");
   	   list.setBackground(Color.yellow);
   	   list.setForeground(Color.blue);
   	   list.setFont(new XFont("Courier", Font.BOLD, 12));
   	   list.addItem(new GroupItem("111111111"));
   	   list.addItem(new GroupItem("222222222"));
   	   list.addItem(new GroupItem("333333333"));
   	   list.addItem(new GroupItem("333344444"));
   	   list.addItem(new GroupItem("555566666"));
   	   list.addItem(new GroupItem("777788888"));
   	   list.addItem(new GroupItem("999910000"));
   	   list.addItem(new GroupItem("888855555"));
   	   list.addSelectedItem(new GroupItem("333333333", false, false, true));
   	   list.setEnabled(true);
   	   
   	   list.setWidth(300);
   	   list.setHeight(200);
   	   XBorderPanel panel = new XBorderPanel(10, 10);
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.setCenter(list);   	   
   	   
   	   XBoxPanel buttonPanel = new XBoxPanel(SwingConstants.VERTICAL);
   	   buttonPanel.setGapForAll(5);
   	   buttonPanel.setSameWidthForAllComponents(true);
   	   
   	   ServerActionEvent event = new ServerActionEvent();
   	   event.setReturnAllValues(true);
   	   event.addReturnProperty("list");
   	   buttonPanel.add(new XButton("Potvrd", "Potvrd", event));   	   
   	   buttonPanel.add(new XButton("Update", "Update"));
   	   panel.setEast(buttonPanel);
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Row grouping");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }
   
   private void update(ServerPack pack) {
   	   ColumnOrderingSettings cbp = new ColumnOrderingSettings();
   	   cbp.addItem(new GroupItem("55555555"));
   	   cbp.addItem(new GroupItem("66666666"));
   	   cbp.addSelectedItem(new GroupItem("55555555"));
   	   cbp.setBackground(Color.red);
   	   cbp.setForeground(Color.white);
   	   cbp.setFont(new XFont("Courier", Font.ITALIC, 12));   	   
   	   ValuePack valuePack = new ValuePack();
   	   valuePack.put("list", cbp);
   	   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
   }
   
   public static void main(String...strings) {
	   MediatorRunner.run(DemoRowGrouping.class, null, null, "flat");
   } 
}	

