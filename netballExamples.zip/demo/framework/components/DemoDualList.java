package demo.framework.components;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;

import javax.swing.SwingConstants;

import netball.server.component.ListItem;
import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XDualList;
import netball.server.component.XFont;
import netball.server.component.XForm;
import netball.server.component.setting.DualListSettings;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientSelectionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerSelectionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoDualList extends BasicMediator { 

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}
	
   @Override
	public void selectionEventExecuted(ClientSelectionEvent event, ServerPack pack) {
	   System.out.println(event.getPropertie("list"));
	}


   @Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	   if (event.getSourceId().equals("Potvrd")) {
   	   	  Object[] values = (Object[]) event.getValuePack().getValue("list");
   	   	  if (values != null) {
   	   	    for (int i = 0; i < values.length; i++) {
   	   	       System.out.println("value = " + values[i]);
   	   	    }   
   	   	  }else{
   	   	  	System.out.println("value = null");
   	   	  }   
   	   	  System.out.println("properties = " + event.getProperties().get("list"));
   	   }else if (event.getSourceId().equals("Update")) {	  
   	      update(pack);
   	   }
   }

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
   	   XDualList list = new XDualList("list");
   	   list.setBackground(Color.yellow);
   	   //list.setListHeaderText("ssss");
   	   //list.setSelectedListHeaderText("ddddddddd");
   	   list.setForeground(Color.blue);
   	   list.setFont(new XFont("Courier", Font.BOLD, 12));
   	   list.addItem("111111111");
   	   list.addItem("222222222");
   	   list.addItem("333333333");
   	   list.addItem("333344444");
   	   list.addItem("555566666");
   	   list.addItem("777788888");
   	   list.addItem("999910000");
   	   list.addItem("888855555");
   	   list.addSelectedItem("333333333");
   	   list.setEnabled(true);
   	   
   	   ServerSelectionEvent selectionEvent = new ServerSelectionEvent();
   	   selectionEvent.addReturnProperty("list");
   	   list.addSelectionEvent(selectionEvent);
   	   
   	   list.setWidth(300);
   	   list.setHeight(200);
   	   
   	   ServerActionEvent event = new ServerActionEvent();
   	   event.setReturnAllValues(true);
   	   event.addReturnProperty("list");

   	   XBoxPanel buttonPanel = new XBoxPanel();
   	   buttonPanel.setHorizontalAlignment(SwingConstants.RIGHT);
   	   buttonPanel.setGapForAll(5);
   	   buttonPanel.add(new XButton("Potvrd", "Potvrd", event));   	   
   	   buttonPanel.add(new XButton("Update", "Update"));
   	   
   	   XBorderPanel panel = new XBorderPanel(10, 10);
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.setCenter(list);
   	   panel.setSouth(buttonPanel);
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Double list");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }
   
   private void update(ServerPack pack) {
   	   DualListSettings cbp = new DualListSettings();
   	   cbp.addItem(new ListItem("55555555"));
   	   cbp.addItem(new ListItem("66666666"));
   	   cbp.setBackground(Color.red);
   	   cbp.setForeground(Color.white);
   	   cbp.setFont(new XFont("Courier", Font.ITALIC, 12));
   	   cbp.addSelectedItem("55555555");
   	   ValuePack valuePack = new ValuePack();
   	   valuePack.put("list", cbp);
   	   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
   }
   
   public static void main(String...strings) {
	   MediatorRunner.run(DemoDualList.class, null, null, "flat");
   }
}
