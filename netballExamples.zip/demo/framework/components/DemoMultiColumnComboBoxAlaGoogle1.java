package demo.framework.components;

import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;

import netball.server.component.EditingAndSelectedValue;
import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XForm;
import netball.server.component.XMultiColumnComboBoxAlaGoogle;
import netball.server.component.XTableColumn;
import netball.server.component.table.TableContainer;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

/**
 * Priklad ked primarnyColumn != serachableColumn 
 * @author Cernak
 *
 */
public class DemoMultiColumnComboBoxAlaGoogle1 extends BasicMediator { 

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}
	
	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
	   	   XMultiColumnComboBoxAlaGoogle comboBox = new XMultiColumnComboBoxAlaGoogle("comboBox");
	   	   List<XTableColumn> cols = new ArrayList<XTableColumn>();   
	   	   cols.add(new XTableColumn("nazov", "Nazov", 120));
	   	   cols.add(new XTableColumn("kod", "Kod", 50));
	   	   comboBox.setColumns(cols);
	   	   TableContainer source = new TableContainer(new Object[] {"nazov", "kod"});
	   	   source.addNewRow(new Object[] {"Nohavice", "01"});
	   	   source.addNewRow(new Object[] {"Trenirky", "02"});
	   	   source.addNewRow(new Object[] {"Trenirky", "03"});
	   	   source.addNewRow(new Object[] {"Trenirky", "04"});
	   	   source.addNewRow(new Object[] {"Kosela", "05"});
	   	   source.addNewRow(new Object[] {"Kosela", "06"});
	   	   source.addNewRow(new Object[] {"Kosela", "07"});
	   	   source.addNewRow(new Object[] {"Rukavice", "08"});
	   	   source.addNewRow(new Object[] {"Rukavice", "09"});
	   	   comboBox.setDataSource(source);
	   	   comboBox.setPrimaryColumn("kod");
	   	   comboBox.setSearchableColumn("nazov");
	   	   comboBox.setVisibleCharCount(30);
	   	   comboBox.setValue(new EditingAndSelectedValue("Trenirky", "03"));
	   	   comboBox.setValue("03");
	   	   
	   	   XButton button = new XButton("button", "Test");
	   	   ServerActionEvent event = new ServerActionEvent();
	   	   event.setReturnAllValues(true);
	   	   button.addEvent(event);
	   	   
	   	   XBoxPanel panel = new XBoxPanel();
	   	   panel.setInsets(new Insets(10, 10, 10, 10));
	   	   panel.add(comboBox);
	   	   panel.addGap(20);	
	   	   panel.add(button);
	   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel); 
	   	   form.setTitle("combo box ala google");
	   	   
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	   }
	   
	   @Override
	   public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
			if (event.getSourceId().equals("button")) {
				System.out.println(event.getValuePack());
			}
	  }

	public static void main(String...strings) {
		   MediatorRunner.run(DemoMultiColumnComboBoxAlaGoogle1.class, null, null, "flat");
    }
}	
