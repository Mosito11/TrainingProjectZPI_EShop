package demo.framework.components;

import java.awt.Color;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.awt.image.BufferedImage;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;

import netball.server.print.PRBorderPanel;
import netball.server.print.PRByteImage;
import netball.server.print.PRCanvas;
import netball.server.print.PRCaptionComp;
import netball.server.print.PRComponent;
import netball.server.print.PRDoubleLabel;
import netball.server.print.PREmptyComponent;
import netball.server.print.PRFlowCaptionComp;
import netball.server.print.PRFlowPanel;
import netball.server.print.PRFont;
import netball.server.print.PRForm;
import netball.server.print.PRGridPanel;
import netball.server.print.PRGridPanelComponent;
import netball.server.print.PRHorizontalSeparator;
import netball.server.print.PRHtmlLabel;
import netball.server.print.PRImage;
import netball.server.print.PRLabel;
import netball.server.print.PRMargin;
import netball.server.print.PRMultiLineLabel;
import netball.server.print.PRPage;
import netball.server.print.PRPageFormat;
import netball.server.print.PRPageSize;
import netball.server.print.PRReport;
import netball.server.print.PRSignature;
import netball.server.print.PRSimpleMultiLineGrid;
import netball.server.print.PRTable;
import netball.server.print.PRTableWithGridHeader;
import netball.server.print.PRTitle;
import netball.server.print.PRTitlePanel;
import netball.server.print.PRVerticalSeparator;
import netball.server.print.table.PRBlankTableRow;
import netball.server.print.table.PRGroupTableFooter;
import netball.server.print.table.PRGroupTableFooterItem;
import netball.server.print.table.PRGroupTableHeader;
import netball.server.print.table.PRTableCell;
import netball.server.print.table.PRTableGridHeader;
import netball.server.print.table.PRTableHeader;
import netball.server.print.table.PRTableHeaderColumn;
import netball.server.print.table.PRValueTableRow;
import netball.server.utilities.Utilities;
import netframework.mediator.MDReportPreview;
import netframework.mediator.MediatorRunner;
public class DemoPrint {

	public PRPage createPage1() {
		PRReport page = new PRReport();
		PRFlowPanel panel = new PRFlowPanel(SwingConstants.VERTICAL);
		panel.add(createSeparator("PRLabel"));
		panel.add(createLabel());
		panel.add(createSeparator("PRMultiLineLabel"));
		panel.add(createMultiLineLabel());
		panel.add(createSeparator("PRHtmlLabel"));
		panel.add(createHtmlLabel());
		panel.add(createSeparator("PRBorderPanel"));
		panel.add(createBorderPanel());
		panel.add(createSeparator("PRDoubleLabel"));
		panel.add(createDoubleLabel());
		panel.add(createSeparator("PRCaptionComp"));		
		panel.add(createCaptionComp());
		panel.add(createSeparator("PRFlowCaptionComp"));
		panel.add(createFlowCaptionComp());
		panel.add(createSeparator("PRForm"));
		panel.add(createForm());
		panel.add(createSeparator("PRSignature"));
		panel.add(createSignature());
		panel.add(createSeparator("PRMargin"));
		panel.add(createMargin());
		panel.add(createSeparator("PRTitle"));
		panel.add(createTitle());
		panel.add(createSeparator("PRVerticalSeparator"));
		panel.add(createVerticalSeparator());
		panel.add(createSeparator("PREmptyComponent"));
		panel.add(createEmptyComponent());
		panel.add(createSeparator("PRCanvas"));
		panel.add(createCanvas());
		panel.add(createSeparator("PRByteImage"));
		panel.add(createByteImage());
		panel.add(createSeparator("PRImage"));
		panel.add(createImage());
		panel.add(createSeparator("PRFlowPanel"));
		panel.add(createFlowPanel());
		panel.add(createSeparator("PRTitlePanel"));
		panel.add(createTitlePanel());
		panel.add(createSeparator("PRGridPanel"));
		panel.add(createGridPanel());
		panel.add(createSeparator("PRTableWithGridHeader"));
		panel.add(createTable());
		panel.add(createSeparator("PRTable"));
		panel.add(createTableWithGridHeader());
		panel.add(createSeparator("PRSimpleMultiLineGrid"));
		panel.add(createSimpleMultiLineGrid());
		page.setBody(panel);
		return page; 
	}
	
	public PRComponent createSeparator(String text) {
		PRHorizontalSeparator separator = new PRHorizontalSeparator();
		separator.setTitle(text);
		separator.setFont(new PRFont("Dialog", Font.BOLD, 20));
		separator.setWidth(530);
		return new PRMargin(separator, new Insets(15, 0, 0, 0));
	} 

	public PRLabel createLabel() {
		PRLabel label = new PRLabel();
		label.setBackground(Color.ORANGE);
		label.setForeground(Color.BLUE);
		label.setInsets(new Insets(5, 10, 5, 10));
		label.setText("Text");
		label.setFont(new PRFont("Dialog", Font.BOLD, 17));
		label.setWidth(400);
		label.setHeight(60);
		label.setHorizontalAlign(SwingConstants.RIGHT);
		label.setVerticalAlign(SwingConstants.BOTTOM);
		label.setPaintBorder(true);
		label.setBorderColor(Color.RED);
		return label;
	} 

	public PRMultiLineLabel createMultiLineLabel() {
		PRMultiLineLabel label = new PRMultiLineLabel();
		label.setBackground(Color.YELLOW);
		label.setForeground(Color.RED);
		label.setInsets(new Insets(5, 10, 5, 10));
		label.setText("Riadok1\nRiadok2");
		label.setFont(new PRFont("Dialog", Font.BOLD, 17));
		label.setWidth(300);
		label.setRowHeight(60);
		label.setHorizontalAlign(SwingConstants.RIGHT);
		label.setVerticalAlign(SwingConstants.TOP);
		label.setPaintBorder(true);
		label.setBorderColor(Color.BLUE);
		return label;
	} 
	
	public PRBorderPanel createBorderPanel() {
		PRLabel label = new PRLabel("Border panel");
		label.setBackground(Color.YELLOW);
		PRBorderPanel panel = new PRBorderPanel(label);
		panel.setLineColor(Color.RED);
		panel.setInsets(new Insets(20, 20, 20, 20));
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setTitle("Title");
		panel.setAlign(SwingConstants.RIGHT);
		panel.setPaintBorder(false);
		panel.setPaintLeftLine(true);
		panel.setPaintRightLine(true);
		panel.setPaintTopLine(true);
		panel.setPaintBottonLine(true);
		panel.setFont(new PRFont("Dialog", Font.BOLD | Font.ITALIC, 15));
		panel.setTitleColor(Color.WHITE);
		return panel; 
	}
	
	public PRHtmlLabel createHtmlLabel() {
		PRHtmlLabel htmlLabel = new PRHtmlLabel();
		htmlLabel.setBackground(Color.YELLOW);
		htmlLabel.setForeground(Color.BLUE);
		htmlLabel.setInsets(new Insets(5, 10, 5, 10));
		htmlLabel.setText("<html>Html label</html>");
		htmlLabel.setFont(new PRFont("Dialog", Font.BOLD, 15));
		return htmlLabel;
	} 
	
	public PRCaptionComp createCaptionComp() {
		PRCaptionComp captionComp = new PRCaptionComp();
		captionComp.setRowHeight(30);
		captionComp.setWidth(300);
		captionComp.setGap(10);
		captionComp.setSameWidthForLabels(true);
		captionComp.setPaintValueLines(true);
		captionComp.setPaintBorder(true);
		captionComp.setLineBorderColor(Color.RED);
		captionComp.setLineValueColor(Color.YELLOW);
		captionComp.setInsets(new Insets(10, 10, 10, 10));
		captionComp.setValueColor(Color.BLUE);
		captionComp.setLabelColor(Color.MAGENTA);
		captionComp.setBackground(Color.LIGHT_GRAY);
		captionComp.setValueFont(new PRFont("Dialog", Font.BOLD, 15));
		captionComp.setLabelFont(new PRFont("Dialog", Font.PLAIN, 14));
		captionComp.addItem("Meno", "Juraj");
		captionComp.addItem("Priezvisko", "Janosik");
		captionComp.addItem("Vek", "30", SwingConstants.RIGHT);
		return captionComp;
	}
	
	public PRFlowCaptionComp createFlowCaptionComp() {
		//PRFlowCaptionComp component = new PRFlowCaptionComp(SwingConstants.VERTICAL);
		PRFlowCaptionComp component = new PRFlowCaptionComp(SwingConstants.HORIZONTAL);
		component.setRowHeight(30);
		component.addItem("Meno", "Juraj", 70);
		component.addItem("Priezvisko", "Janosik", 80);
		component.setValueFont(new PRFont("Dialog", Font.BOLD, 15));
		component.setLabelFont(new PRFont("Dialog", Font.PLAIN, 14));
		component.setValueColor(Color.BLUE);
		component.setLabelColor(Color.MAGENTA);
		component.setBackground(Color.LIGHT_GRAY);
		component.setPaintValueLines(false);
		return component;
	}
	
	public PRForm createForm() {
		PRForm form = new PRForm();
		form.setGap(10);
		form.setRowHeight(25);
		form.setWidth(300);
		form.setPaintValueLines(false);
		form.setSameWidthForAllLabels(false);
		form.setBackground(Color.LIGHT_GRAY);
		form.setValueColor(Color.RED);
		form.setLabelColor(Color.YELLOW);
		form.setValueFont(new PRFont("Dialog", Font.BOLD, 15));
		form.setLabelFont(new PRFont("Dialog", Font.PLAIN, 14));		
		form.addItem("Meno", "Juraj");
		form.addItem("Priezvisko", "Janosik");
		form.addItem("Vek", "30", SwingConstants.RIGHT, new PRFont("Dialog", Font.BOLD, 20), new PRFont("Dialog", Font.BOLD, 19));
		return form;
	}
	
	public PRDoubleLabel createDoubleLabel() {
		PRDoubleLabel label = new PRDoubleLabel("Meno", "Juraj Janosik");
		label.setSize(new Dimension(200, 50));
		label.setValueFont(new PRFont("Dialog", Font.BOLD, 15));
		label.setLabelFont(new PRFont("Dialog", Font.PLAIN, 14));
		label.setPaintColon(true);
		label.setLineBorderColor(Color.RED);
		label.setValueColor(Color.BLUE);
		label.setLabelColor(Color.GREEN);
		label.setBackground(Color.YELLOW);
		label.setInsets(new Insets(5, 5, 5, 5));
		return label;
	}
	
	public PRCanvas createCanvas() {
	  	PRCanvas canvas = new PRCanvas();
	  	canvas.setBackground(Color.LIGHT_GRAY);
	  	canvas.setSize(new Dimension(300, 200));
	   	canvas.addLine(0, 0, 100, 0, Color.RED);
	   	canvas.addLine(0, 0, 0, 100, Color.BLUE);
	   	canvas.addText(0, 0, "Canvas text", Color.ORANGE, new PRFont("Dialog", Font.PLAIN, 20));
	   	canvas.addRectangle(40, 40, 100, 150, Color.RED, Color.yellow);
	   	PRMultiLineLabel label = new PRMultiLineLabel("Canvas\ntext");
	   	label.setRowHeight(10);
	   	canvas.addItem(200, 30, label);
	   	return canvas;
	}

	public PRMargin createMargin() {
		PRLabel label = new PRLabel("Toto je text");
		label.setBackground(Color.YELLOW);
		PRMargin margin = new PRMargin(label);
		margin.setInsets(new Insets(10, 10, 10, 10));
		margin.setBackground(Color.RED);
		return margin;
	}
	
	public PREmptyComponent createEmptyComponent() {
		PREmptyComponent component = new PREmptyComponent(100, 100);
		component.setBackground(Color.CYAN);
		return component;
	}
	
	public PRSignature createSignature() {
		PRSignature signature = new PRSignature("Juraj Janosik", "Generalny riaditel");
		signature.setNameFont(new PRFont("Dialog", Font.BOLD, 15));
		signature.setLabelFont(new PRFont("Dialog", Font.PLAIN, 14));
		signature.setLabelHeight(50);
		signature.setNameHeight(60);
		signature.setPaintBorder(true);
		signature.setInsets(new Insets(0, 10, 0, 10));
		return signature;
	}

	public PRTitle createTitle() {
		PRLabel label = new PRLabel("Titulok");
		label.setBackground(Color.YELLOW);		
		PRTitle title = new PRTitle(label);
		title.setBackground(Color.ORANGE);
		return title;
	}

	public PRByteImage createByteImage() {
		byte[] duke = Utilities.loadIcon("src/demo/framework/components/duke.gif");
		PRByteImage image = new PRByteImage(duke, new Dimension(64, 64));
		return image;
	}
	
	public PRImage createImage() {
		BufferedImage duke;
		try {
			Class cls = Class.forName(this.getClass().getName());
			URL url = cls.getClassLoader().getSystemResource("demo/framework/components/duke.gif");
			duke = ImageIO.read(url);
			PRImage image = new PRImage(new ImageIcon(duke));
			return image;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public PRVerticalSeparator createVerticalSeparator() {
		PRVerticalSeparator separator = new PRVerticalSeparator(50);
		separator.setLineColor(Color.BLUE);
		return separator;
	}
	
	public PRSimpleMultiLineGrid createSimpleMultiLineGrid() {
		PRSimpleMultiLineGrid.Header header = new PRSimpleMultiLineGrid.Header();
		header.setFont(new PRFont("Dialog", Font.PLAIN | Font.BOLD, 13));
		header.setRowHeight(25);
		header.setBackground(Color.LIGHT_GRAY);
		header.setForeground(Color.WHITE);
		header.addColumn(new PRSimpleMultiLineGrid.ColumnHeader("Col\n1", 70, SwingConstants.LEFT)); 
		header.addColumn(new PRSimpleMultiLineGrid.ColumnHeader("Col\n2", 80, SwingConstants.LEFT)); 
		header.addColumn(new PRSimpleMultiLineGrid.ColumnHeader("Col\n3", 100, SwingConstants.LEFT)); 
		PRSimpleMultiLineGrid grid = new PRSimpleMultiLineGrid(header);
		grid.setFont(new PRFont("Dialog", Font.PLAIN, 13));
		grid.setRowHeight(22);
		grid.setForeground(Color.RED);
		grid.setBackground(Color.YELLOW);
		PRSimpleMultiLineGrid.Row row = new PRSimpleMultiLineGrid.Row();
		row.add("text1\ntext2");
		row.add("text3");
		row.add("text4\ntext5\ntext6");
		grid.addRow(row);
		row = new PRSimpleMultiLineGrid.Row();
		row.add("text7\ntext9\ntext10");
		row.add("text11\ntext12");
		row.add("text13\ntext14\ntext15\ntext16");
		grid.addRow(row);
		return grid;
	}
	
	public PRGridPanel createGridPanel() {
		PRGridPanel panel = new PRGridPanel(new int[] {20, 30, 40}, new int[] {100, 120, 150, 160});
		//panel.setBackground(Color.YELLOW);
		panel.setLineColor(Color.blue);

		PRGridPanelComponent item = new PRGridPanelComponent(new PRLabel("Cell[0, 0, 1, 3]"));
		item.setHorizontalAlign(SwingConstants.CENTER);
		item.setVerticalAlign(SwingConstants.BOTTOM);
		item.setPaintBorder(false);
		item.setPaintBottonLine(true);
		item.setPaintTopLine(true);
		item.setBackground(Color.ORANGE);
		item.setLineColor(Color.BLUE);
		panel.addCell(0, 0, 1, 3, item);

		item = new PRGridPanelComponent(new PRMultiLineLabel("Cell\n[0, 1, 2, 2]"));
		item.setHorizontalAlign(SwingConstants.CENTER);
		item.setVerticalAlign(SwingConstants.CENTER);
		item.setPaintBorder(false);
		item.setPaintBottonLine(true);
		item.setPaintTopLine(true);
		item.setBackground(Color.GREEN);
		item.setLineColor(Color.BLUE);
		panel.addCell(0, 1, 2, 2, item);

		item = new PRGridPanelComponent(new PRLabel("Cell[2, 1, 1, 1]"));
		item.setHorizontalAlign(SwingConstants.CENTER);
		item.setVerticalAlign(SwingConstants.CENTER);
		item.setPaintBorder(false);
		item.setPaintBottonLine(true);
		item.setPaintTopLine(true);
		item.setBackground(Color.GRAY);
		item.setLineColor(Color.BLUE);
		panel.addCell(2, 1, 1, 1, item);

		item = new PRGridPanelComponent(new PRLabel("Cell[0, 3, 1, 2]"));
		item.setHorizontalAlign(SwingConstants.RIGHT);
		item.setVerticalAlign(SwingConstants.CENTER);
		item.setPaintBorder(false);
		item.setPaintBottonLine(true);
		item.setPaintTopLine(true);
		item.setBackground(Color.YELLOW);
		item.setLineColor(Color.BLUE);
		panel.addCell(0, 3, 1, 2, item);

		item = new PRGridPanelComponent(new PRLabel("Cell[2, 2, 2, 1]"));
		item.setHorizontalAlign(SwingConstants.LEFT);
		item.setVerticalAlign(SwingConstants.CENTER);
		item.setPaintBorder(false);
		item.setPaintBottonLine(true);
		item.setPaintTopLine(true);
		item.setBackground(Color.PINK);
		item.setLineColor(Color.BLUE);
		panel.addCell(2, 2, 2, 1, item);
		
		return panel;
	}

	public PRTableWithGridHeader createTableWithGridHeader() {
		PRTableGridHeader header = new PRTableGridHeader(new int[] {20, 20, 40}, new int[] {100, 50, 50, 50, 50});
		header.getPanel().setBackground(Color.PINK);
		PRLabel label = new PRLabel("Item 1");
		label.setFont(new PRFont("Dialog", Font.BOLD, 20));
		PRGridPanelComponent item = new PRGridPanelComponent(label);
		header.getPanel().addCell(0, 0, 1, 3, item);
		for (int i = 1; i <= 4; i++) {
			item = new PRGridPanelComponent(new PRLabel("Item 1" + i));
			item.setPaintBorder(false);
			header.getPanel().addCell(0, i, 1, 1, item);
		}
		item = new PRGridPanelComponent(new PRLabel("Item 2"), SwingConstants.RIGHT);
		item.setBackground(new Color(200, 200, 200));
		header.getPanel().addCell(1, 1, 4, 1, item);
		for (int i = 1; i <= 4; i++) {
			PRMultiLineLabel mlabel = new PRMultiLineLabel("Item\n[3" + i + "]");
			mlabel.setHorizontalAlign(SwingConstants.CENTER);
			mlabel.setRowHeight(10);
			item = new PRGridPanelComponent(mlabel);
			header.getPanel().addCell(2, i, 1, 1, item);
		}
		header.setHorizontalColumnCellAlign(2, SwingConstants.RIGHT);
		PRTableWithGridHeader table = new PRTableWithGridHeader(header);
		table.setPaintCellBorders(true);
		table.setColumnMargin(2);
		table.addRow(new PRGroupTableHeader("Header"));
		table.addRow(new PRValueTableRow("111", "222", "333", "444", "555"));
		table.addRow(new PRValueTableRow("666", "777", "888", "999", "000"));
		table.addRow(new PRBlankTableRow());
		PRGroupTableFooter footer = new PRGroupTableFooter("Footer");
		footer.addItem(new PRGroupTableFooterItem("1221", 2));
		footer.addItem(new PRGroupTableFooterItem("555", 4));
		table.addRow(footer);
		return table;
	}

	public PRTable createTable() {
    	PRTableHeader header = new PRTableHeader();
        header.setFont(new PRFont("Dialog", Font.PLAIN | Font.BOLD, 14));
        header.setRowHeight(20);
        header.setBackground(Color.LIGHT_GRAY);
        header.add(new PRTableHeaderColumn("Col 1", 70));
		PRTableHeaderColumn col2 = new PRTableHeaderColumn("Col 2");
		col2.add(new PRTableHeaderColumn("Col\n21", 70));
		col2.add(new PRTableHeaderColumn("Col\n22", 70));
		header.add(col2);
		PRTableHeaderColumn col3 = new PRTableHeaderColumn("Col 3");
		col3.add(new PRTableHeaderColumn("Col 31", 100, SwingConstants.CENTER));
		col3.add(new PRTableHeaderColumn("Col 32", 70));
		header.add(col3);
		
		PRTable table = new PRTable(header);
		table.setPaintCellBorders(true);
		table.setColumnMargin(2);
		table.setRowHeight(20);
		table.addRow(new PRGroupTableHeader("Header", Color.PINK));
		table.addRow(new PRValueTableRow(new PRTableCell("111", Color.ORANGE, Color.RED, new PRFont("Dialog", Font.PLAIN | Font.ITALIC, 12)), 
										 new PRTableCell("222"), new PRTableCell("333", Color.GREEN), new PRTableCell("444"), new PRTableCell("555")));
		table.addRow(new PRValueTableRow("666", "777", "888", "999", "000"));
		table.addRow(new PRBlankTableRow());
		PRGroupTableFooter footer = new PRGroupTableFooter("Footer", Color.YELLOW);
		footer.addItem(new PRGroupTableFooterItem("1221", 2));
		footer.addItem(new PRGroupTableFooterItem("555", 4));
		table.addRow(footer);
		return table;
	}
	
	
	public PRFlowPanel createFlowPanel() {
		PRFont font = new PRFont("Dialog", Font.PLAIN, 20); 
		PRFlowPanel panel1 = new PRFlowPanel(SwingConstants.HORIZONTAL);
		PRLabel label = new PRLabel("Text1", font);
		label.setHeight(30);
		label.setWidth(80);
		label.setPaintBorder(true);	
		panel1.add(label);
		label = new PRLabel("Text2", font);
		label.setHeight(30);
		label.setWidth(90);
		label.setPaintBorder(true);
		panel1.add(label);
		label = new PRLabel("Text3", font);
		label.setHeight(30);
		label.setWidth(100);
		label.setPaintBorder(true);
		panel1.add(label);
		
		PRFlowPanel panel2 = new PRFlowPanel(SwingConstants.HORIZONTAL);
		label = new PRLabel("Text4", font);
		label.setHeight(30);
		label.setWidth(135);
		label.setPaintBorder(true);	
		panel2.add(label);
		label = new PRLabel("Text5", font);
		label.setHeight(30);
		label.setWidth(135);
		label.setPaintBorder(true);
		panel2.add(label);
		
		PRFlowPanel panel3 = new PRFlowPanel(SwingConstants.VERTICAL);
		panel3.add(panel1);
		panel3.add(panel2);
		
		PRFlowCaptionComp component = new PRFlowCaptionComp(SwingConstants.VERTICAL);
		component.setRowHeight(30);
		component.addItem("Meno", "Juraj", 70);
		component.addItem("Priezvisko", "Janosik", 80);
		component.addItem("Vek", "30", 40);
		component.setValueFont(new PRFont("Dialog", Font.BOLD, 15));
		component.setLabelFont(new PRFont("Dialog", Font.PLAIN, 14));
		
		PRFlowPanel panel4 = new PRFlowPanel(SwingConstants.HORIZONTAL);
		panel4.setBackground(Color.GREEN);
		panel4.add(panel3);
		panel4.addGap(20);
		panel4.add(component);
		return panel4;
	}
	
	public PRTitlePanel createTitlePanel() {
		PRTitlePanel titlePanel = new PRTitlePanel();
		titlePanel.setBackground(Color.YELLOW);
		PRFont font = new PRFont("Dialog", Font.PLAIN, 20);
		PRLabel label = new PRLabel("Left", font);
		label.setWidth(80);
		label.setHeight(40);
		label.setPaintBorder(true);
		label.setBackground(Color.ORANGE);
		label.setHorizontalAlign(SwingConstants.CENTER);
		titlePanel.setLeftComponent(label);
		
		label = new PRLabel("Right", font);
		label.setWidth(80);
		label.setHeight(50);
		label.setPaintBorder(true);
		label.setHorizontalAlign(SwingConstants.CENTER);
		label.setBackground(Color.ORANGE);
		titlePanel.setRightComponent(label);

		label = new PRLabel("Center", font);
		label.setWidth(100);
		label.setHeight(40);
		label.setPaintBorder(true);
		label.setBackground(Color.ORANGE);
		label.setHorizontalAlign(SwingConstants.CENTER);
		titlePanel.setCenterComponent(label);
		
		return titlePanel;
	}  
	
	public PRPage[] getPages() {
		PRPage[] pages = new PRPage[1];
		pages[0] = createPage1();
		return pages;
	}

	public PRPageFormat getPageFormat() {
		PRPageSize size = new PRPageSize(210, 1100, "Custom");
		return new PRPageFormat(size);
	}
	
	public static void main(String...strings) {
		DemoPrint print = new DemoPrint(); 
		MediatorRunner.run(MDReportPreview.class, new MDReportPreview.ArrayPageParameters(print.getPages(), print.getPageFormat()), null, "metal");
	} 

}
