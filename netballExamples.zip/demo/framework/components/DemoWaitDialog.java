package demo.framework.components;

import java.awt.Insets;

import netball.server.component.XBorderPanel;
import netball.server.component.XButton;
import netball.server.component.XForm;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.alert.YesNoAlert;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoWaitDialog extends BasicMediator { 


	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	   if (event.getSourceId().equals("button")) {
		    try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
			}				    
   	   }
   }

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
	   XBorderPanel panel = new XBorderPanel();
	   panel.setInsets(new Insets(100, 100, 100, 100));
	   ServerActionEvent event = new ServerActionEvent();
	   event.setShowWaitDialog(true);
	   event.setWaitText("Cakajte prosim");
	   event.addAlert(new YesNoAlert("Oznam"));
	   XButton button = new XButton("button", "Vysviet okno");
	   button.addActionEvent(event);
	   panel.setCenter(button);
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Cakacie okno");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	public static void main(String...strings) {
		MediatorRunner.run(DemoWaitDialog.class, null, null, "flat");
	} 
}
