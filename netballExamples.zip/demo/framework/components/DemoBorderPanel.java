package demo.framework.components;

import java.awt.Color;
import java.awt.Insets;

import netball.server.component.XBorderPanel;
import netball.server.component.XButton;
import netball.server.component.XForm;
import netball.server.component.border.XTitleBorder;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoBorderPanel extends BasicMediator { 


	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
   	   XBorderPanel panel = new XBorderPanel(10, 10);
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   //panel.setBackground(Color.red);
   	   panel.setBorder(new XTitleBorder());
   	   panel.setSouth(new XButton("South", "South"));
   	   panel.setEast(new XButton("East", "East"));
   	   panel.setWest(new XButton("West", "West"));
   	   panel.setCenter(new XButton("Center", "Center"));
   	   panel.setNorth(new XButton("North", "North"));

   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Border panel");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}
	
	public static void main(String...strings) {
		MediatorRunner.run(DemoBorderPanel.class, null, null, "flat");
	}
}	
