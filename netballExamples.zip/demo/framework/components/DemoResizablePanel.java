package demo.framework.components;

import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;

import javax.swing.SwingConstants;

import netball.server.component.ListItem;
import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XClientTable;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XForm;
import netball.server.component.XList;
import netball.server.component.XPanel;
import netball.server.component.XResizablePanel;
import netball.server.component.XScrollPane;
import netball.server.component.XTableColumn;
import netball.server.component.XTextField;
import netball.server.component.table.TableContainer;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoResizablePanel extends BasicMediator { 

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
	   XBoxPanel panel = new XBoxPanel(SwingConstants.HORIZONTAL);
	   panel.setInsets(new Insets(10, 10, 10, 10));
	   panel.add(new XResizablePanel("resizablePanel1",  createList()));
	   panel.addGap(10);
	   panel.add(new XResizablePanel("resizablePanel2",  createPanel1()));
	   panel.addGap(10);
	   panel.add(new XResizablePanel("resizablePanel3",  createPanel2()));

   	   XForm form = new XForm();
   	   form.setPanel(new XScrollPane(panel)); 
   	   form.setTitle("Resizable panel");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	}
	
	private XList createList() {
		XList list = new XList("list"); 
		for (int i = 0; i < 10; i++) {
			list.addItem(new ListItem("list" + i, "List " + i));
		}
		return list;
	}
	
	private XPanel createPanel1() {
		XDualComponentPanel panel = new XDualComponentPanel();
		panel.setInsets(new Insets(10, 10, 10, 10));
		for (int i = 0; i < 10; i++) {
			panel.add(new XTextField("textField" + i, "Text " + i, 100));
		}
		return new XScrollPane(panel);
	}
	
	private XPanel createPanel2() {
		XClientTable table = new XClientTable("table");
		List<Object> ids = new ArrayList<>();
		for (int i = 0; i < 10; i ++) {
			String colId = "col" + i;
			table.addColumn(new XTableColumn(colId, "Column " + i, 70));
			ids.add(table.getColumnIndex(colId));
		} 
		TableContainer container = new TableContainer(ids);
		for (int i = 0; i < 100; i++) {
			List<Object> row = new ArrayList<>();
			for (int j = 0; j < ids.size(); j++) {
				row.add("Item [" + i + ", " + j + "]");
			}
			container.addNewRow(row);
		}
		table.setDataSource(container);
		
		XBoxPanel buttonPanel = new XBoxPanel(SwingConstants.HORIZONTAL);
		buttonPanel.setGapForAll(5);
		for (int i = 0; i < 5; i++) {
			buttonPanel.add(new XButton("button" + i, "Button " + i));
		}
		
		XBorderPanel panel = new XBorderPanel(10, 10);
		panel.setCenter(table);
		panel.setSouth(buttonPanel);
		return panel;
	}

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}
	
	public static void main(String...strings) {
		MediatorRunner.run(DemoResizablePanel.class, null, null, "flat");
	}
}	
