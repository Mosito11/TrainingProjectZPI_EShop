package demo.framework.components;

import java.awt.Insets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import netball.client.ui.TableColumnOrder;
import netball.client.ui.TableHeaderFilterPrmts;
import netball.server.component.XBorderPanel;
import netball.server.component.XClientServerTable;
import netball.server.component.XExpressionField;
import netball.server.component.XForm;
import netball.server.component.XTableColumn;
import netball.server.component.expressionfield.NumberExpressionConvertor;
import netball.server.component.renderer.LogicalRenderer;
import netball.server.component.table.ClientServerTableDataSource;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.rowexpression.Row;
import netball.server.rowexpression.RowExpression;
import netball.server.rowexpression.RowExpressionBuilder;
import netball.server.utilities.TypeValues;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoClientServerTableWithHeaderFilter extends BasicMediator { 
	
	
	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}
   
	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
   	   XClientServerTable table = new XClientServerTable("table");
   	   XTableColumn column = new XTableColumn("id");
   	   column.setVisible(false);
   	   table.addColumn(column);
   	   
   	   column = new XTableColumn("firstName", "First Name", 150);
   	   column.setFilterComponent(new XExpressionField());
   	   table.addColumn(column);
   	   
   	   column = new XTableColumn("lastName", "Last Name", 150);
   	   column.setFilterComponent(new XExpressionField());
   	   table.addColumn(column);
   	   
   	   column = new XTableColumn("sport", "Sport", 150);
   	   column.setFilterComponent(new XExpressionField());
   	   table.addColumn(column);
   	   
   	   column = new XTableColumn("years", "# of Years", 150);
   	   XExpressionField field = new XExpressionField();
   	   field.setConvertor(new NumberExpressionConvertor(TypeValues.INTEGER));
   	   column.setFilterComponent(field);
   	   table.addColumn(column);
   	
   	   column = new XTableColumn("vegetarian", "Vegetarian", 70);
   	   column.setRenderer(new LogicalRenderer());
   	   table.addColumn(column);
   	      	   
   	   table.setDataSource(new TableDataSource(), this);
   	   table.setSortable(true);
   	   table.setVisibilityOfColumnsAllowed(true);
   	   table.setFreezeColumnsAllowed(true);
   	   table.setShowStatusRow(true);
   	   table.setWidth(700);

   	   XBorderPanel panel = new XBorderPanel(10, 10);
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.setCenter(table);   	      	      	      	   
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Client server table with header filter");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }
	
   private class TableDataSource extends ClientServerTableDataSource {
        
	    private String[] columns;
	    private Object[][] data;
	    private List<Integer> filterRowIndexes = new ArrayList<>();
	    private RowExpression expression;
	   
	    public TableDataSource() {
		    columns = new String[]{"id", "firstName", "lastName", "sport", "years", "vegetarian"};
		    data = new Object[][] {{ 0, "Kathy", "Smith", "Snowboarding", 5, false},
								    {1, "John", "Doe",	"Rowing", 3, true},
								    {2, "Sue", "Black", "Knitting", 2, false},
								    {3, "Jane", "White", "Speed reading", 20, true},
								    {4, "Joe", "Brown", "Pool", 10, false}};
	    }
	   
		@Override
		public Object[][] getBatch(int from, int to) throws Exception {
		    Object[][] batch = new Object[to - from][columns.length];
		    int j = 0;
		    for (int i = from; i < to; i++) {
		    	for (int k = 0; k < columns.length; k++) {
		    	   int rowIndex = expression != null ? filterRowIndexes.get(i) : i; 	
		    	   batch[j][k] = data[rowIndex][k];
		        }
		    	j++;
		    }
		    return batch;
		}
	
		@Override
		public int getRowCount() throws Exception {
			if (expression != null)
				return filterRowIndexes.size();
			return data.length;
		}
	
		@Override
		public void setFilter(List<TableHeaderFilterPrmts> filterParameters, ServerPack serverPack) throws Exception {
			 if (filterParameters != null) { 
				 expression = RowExpressionBuilder.createExpression(filterParameters);
				 RowImpl row = new RowImpl();
				 filterRowIndexes.clear();
				 for (int i = 0; i < data.length; i++) {
					 row.rowIndex = i;
					 if (expression.accept(row)) {
						 filterRowIndexes.add(i);
					 }
				 }
			 }else{
				 filterRowIndexes.clear();
				 expression = null;
			 }
		}
	
		@Override
		public List<Object> getValuesForColumn(int columnIndex) throws Exception {
			List<Object> list = new ArrayList<>();
			for (int i = 0; i < data.length; i++) {
				Object value = data[i][columnIndex];
				if (value != null) {
					if (!list.contains(value)) {
						list.add(value);
					}
				}
			}
			return list;
		}
	
		@Override
		public boolean sort(TableColumnOrder[] orders) throws Exception {
			if (getRowCount() < 2)
				return false;
			TableColumnOrder order = orders[0];
			int columnIndex = getColumnIndex(order.getColumnId());
			if (expression != null) {
				FilterRowComparator comparator = new FilterRowComparator(columnIndex, order.isSortAsc());
				Collections.sort(filterRowIndexes, comparator);
			}else{
				RowComparator comparator = new RowComparator(columnIndex, order.isSortAsc());
				Arrays.sort(data, comparator);
			}
			return true;
		}
	
		@Override
		public void tableRowCountChanged(int rowCount, ServerPack pack)	throws Exception {
			System.out.println("tableRowCountChanged.rowCount=" + rowCount);
		}

	    public int getColumnIndex(Object columnName) {
	        for (int i = 0; i < columns.length; i++) {
	           if (columns[i].equals(columnName))
	              return i;
	        } 
	        return -1;
	    }
		
	    private class RowImpl implements Row {

			public int rowIndex; 
				 
			@Override
			public Object getValueAt(int columnIndex) {
				return data[rowIndex][columnIndex];
			}

			@Override
			public int getColumnIndex(Object columnName) {
				return TableDataSource.this.getColumnIndex(columnName);
			}
				 
	   }
	    
	   private class FilterRowComparator implements Comparator<Integer> {
	 	   
		    private RowComparator rowComparator;
		    
			public FilterRowComparator(int columnIndex, boolean ascending) {
				rowComparator = new RowComparator(columnIndex, ascending);
			} 

			@Override
			public int compare(Integer o1, Integer o2) {
				Object[] row1 = data[((Number) o1).intValue()];
				Object[] row2 = data[((Number) o2).intValue()];
				return rowComparator.compare(row1, row2);
			}
	   }

		@Override
		public void refreshExecuted(ServerPack pack) throws Exception {
		}
   }	
   
   private class RowComparator implements Comparator<Object[]> {

		private int columnIndex;
		private boolean ascending;
		
		public RowComparator(int columnIndex, boolean ascending) {
			this.columnIndex = columnIndex;
			this.ascending = ascending;
		} 
		   
		@Override
		public int compare(Object[] o1, Object[] o2) {
			Object value1 = o1[columnIndex];
			Object value2 = o2[columnIndex];
			int answer = 0;
			if (value1 == null && value2 == null) {
				answer = 0;
			}else if (value1 == null && value2 != null) {
				answer = -1;
			}else if (value1 != null && value2 == null) {
				answer = 1;
			}else if (value1 instanceof Comparable) {
				answer = ((Comparable) value1).compareTo(value2);
			}else{
				answer = value1.toString().compareTo(value2.toString());
			}
			if (!this.ascending && answer != 0)
				answer = answer * -1;
			return answer;
		}
   }

    public static void main(String...strings) {
    	MediatorRunner.run(DemoClientServerTableWithHeaderFilter.class, null, null, "flat");
    } 
}
