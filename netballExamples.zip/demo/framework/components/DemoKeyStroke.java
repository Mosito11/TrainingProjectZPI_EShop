package demo.framework.components;

import java.awt.Insets;

import javax.swing.SwingConstants;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XClientTable;
import netball.server.component.XForm;
import netball.server.component.XLabel;
import netball.server.component.XPanel;
import netball.server.component.XTableColumn;
import netball.server.component.XTextArea;
import netball.server.component.setting.ClientTableSettings;
import netball.server.component.table.ClientTableSelectedRow;
import netball.server.component.table.TableRow;
import netball.server.event.ClientActionEvent;
import netball.server.event.KeyStrokeAction;
import netball.server.event.ServerActionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoKeyStroke extends BasicMediator { 

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
   	   XBorderPanel panel = new XBorderPanel(10, 10);
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.setId("mainPanel");		// nastavime id pretoze budeme registrovat KeyStroke 
   	   panel.setNorth(createTextAreaPanel());
   	   panel.setCenter(createTablePanel());
		
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("DemoKeyStroke");
   	   
   	   KeyStrokeAction action = new KeyStrokeAction("textArea", "ctrl shift U", KeyStrokeAction.WHEN_FOCUSED, "upperCase"); // bude fungovat len vtedy, ked komponent bude mat focus
   	   action.addReturnValue("textArea");
   	   form.addKeyStrokeAction(action);
   	   
   	   action = new KeyStrokeAction("textArea", "ctrl shift L", KeyStrokeAction.WHEN_FOCUSED, "lowerCase"); // bude fungovat len vtedy, ked komponent bude mat focus
   	   action.addReturnValue("textArea");
   	   form.addKeyStrokeAction(action);

   	   action = new KeyStrokeAction("mainPanel", "F5", KeyStrokeAction.WHEN_IN_FOCUSED_WINDOW, "insertRow");  // bude fungovat aj ked tabulka nebude mat focus
   	   form.addKeyStrokeAction(action);

   	   action = new KeyStrokeAction("mainPanel", "F6", KeyStrokeAction.WHEN_IN_FOCUSED_WINDOW, "deleteRow");  // bude fungovat aj ked tabulka nebude mat focus
  	   action.addReturnValue("table");
   	   form.addKeyStrokeAction(action);
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	}
	
	private XPanel createTextAreaPanel() {
	   XTextArea textArea = new XTextArea("textArea");
	   textArea.setVisibleRowCount(5);
	   textArea.setVisibleCharCount(30);
	   
	   XLabel label = new XLabel("Ctrl+Shift+U Upper Case      Ctrl+Shift+L Lower Case");
	   label.setHorizontalAlignment(SwingConstants.LEFT);
			   
   	   XBorderPanel panel = new XBorderPanel();
   	   panel.setCenter(textArea);
   	   panel.setSouth(label);
   	   return panel;
	}
	
	private XPanel createTablePanel() {
		XClientTable table = new XClientTable("table");
		table.addColumn(new XTableColumn("col0", "Col 0", 70));
		table.addColumn(new XTableColumn("col1", "Col 1", 70));
		table.addColumn(new XTableColumn("col2", "Col 2", 70));
		table.setPrimaryKey("col0");
   	   	
		XBoxPanel buttonPanel = new XBoxPanel();
		buttonPanel.setGapForAll(5);
		buttonPanel.setSameSizeForAllComponents(true);
		buttonPanel.setHorizontalAlignment(SwingConstants.RIGHT);
		
   	   	XButton button = new XButton("insertButton", "F5 Insert");
   	   	ServerActionEvent event = new ServerActionEvent();
   	   	event.setActionKey("insertRow");
   	   	button.addActionEvent(event);
   	   	buttonPanel.add(button);

   	   	button = new XButton("deleteButton", "F6 Delete");
   	   	event = new ServerActionEvent();
   	   	event.setActionKey("deleteRow");
   	   	event.addReturnValue("table");
   	   	button.addActionEvent(event);
   	   	buttonPanel.add(button);
   	   	
   	   	XBorderPanel panel = new XBorderPanel(5, 5);
   	   	panel.setCenter(table);
   	   	panel.setSouth(buttonPanel);
   	   	return panel;
	} 

	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
		if (event.getSourceId().equals("textArea")) {
			if ("upperCase".equals(event.getActionKey())) {
				String text = (String) event.getValuePack().getValue("textArea");
				if (text != null) {
					text = text.toUpperCase();
					ValuePack valuePack = new ValuePack();
					valuePack.put("textArea", text);
					pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
				}
			}else if ("lowerCase".equals(event.getActionKey())) {
				String text = (String) event.getValuePack().getValue("textArea");
				if (text != null) {
					text = text.toLowerCase();
					ValuePack valuePack = new ValuePack();
					valuePack.put("textArea", text);
					pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
				}
			}
		}else if ("insertRow".equals(event.getActionKey())) {
			ClientTableSettings settings = new ClientTableSettings();
			TableRow row = new TableRow();
			int id = (int) (Math.random() * 1000);
			row.add("col0", id);
			row.add("col1", "aaaa");
			row.add("col2", "bbbb");
			settings.setInsertedRow(row);
			settings.setSelectedItem(id);
			settings.setScrollRowToVisible(id);
			ValuePack valuePack = new ValuePack();
			valuePack.put("table", settings);
			pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
		}else if ("deleteRow".equals(event.getActionKey())) {
			if (event.getValuePack().getValue("table") != null) {
				ClientTableSelectedRow row = ((ClientTableSelectedRow[]) event.getValuePack().getValue("table")) [0];  
				ClientTableSettings settings = new ClientTableSettings();
				settings.setDeletedRow(row.getId());
				ValuePack valuePack = new ValuePack();
				valuePack.put("table", settings);
				pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
			}
		}
	}

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}
	
	public static void main(String...strings) {
		MediatorRunner.run(DemoKeyStroke.class, null, null, "flat");
	}
}
