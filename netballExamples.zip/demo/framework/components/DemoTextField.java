package demo.framework.components;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;

import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XFont;
import netball.server.component.XForm;
import netball.server.component.XTextField;
import netball.server.component.setting.TextFieldSettings;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientFocusEvent;
import netball.server.event.ClientKeyEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerEvent;
import netball.server.event.ServerFocusEvent;
import netball.server.event.ServerKeyEvent;
import netball.server.event.ServerMouseEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoTextField extends BasicMediator { 

	@Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void focusEventExecuted(ClientFocusEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void keyEventExecuted(ClientKeyEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	   if (event.getSourceId().equals("Potvrd")) {
   	   	  System.out.println("value = " + event.getValuePack().getValue("textField"));
   	   	  System.out.println("property = " + event.getProperties().get("textField"));
   	   }else if (event.getSourceId().equals("Update")) {	  
   	      update(pack);   	   	  
   	   }
   }

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
   	   XTextField textField = new XTextField("textField");
   	   textField.setVisibleCharCount(30);
   	   textField.setBackground(Color.yellow);
   	   textField.setForeground(Color.blue);
   	   textField.setFont(new XFont("Courier", Font.BOLD, 12));
   	   textField.setLimit(100);
   	   textField.setTypeLetters(XTextField.CAPITAL_LETTERS);
   	   textField.setAllowableChars("LS{,;\n\t<>}");
   	   textField.setDescription("ja som text field");
   	   textField.setMargin(new Insets(5,5,5,5));
   	   
   	   //textField.setWidth(600);
   	   textField.setHorizontalAlignment(javax.swing.SwingUtilities.RIGHT);
   	   textField.addMouseEvent(new ServerMouseEvent(ServerEvent.MOUSE_CLICKED_EVENT));
   	   textField.addFocusEvent(new ServerFocusEvent(ServerEvent.FOCUS_GAINED_EVENT));
   	   textField.addKeyEvent(new ServerKeyEvent(ServerEvent.KEY_TYPED_EVENT));
   	   
   	   XBoxPanel panel = new XBoxPanel();
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.add(textField);  
   	   panel.addGap(20);
   	   
   	   ServerActionEvent event = new ServerActionEvent();
   	   event.addReturnProperty("textField");
   	   event.setReturnAllValues(true);
   	   panel.add(new XButton("Potvrd", "Potvrd", event));
   	   panel.addGap(5);
   	   panel.add(new XButton("Update", "Update"));   	   
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Text field");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }
   
   private void update(ServerPack pack) {
   	   TextFieldSettings tfp = new TextFieldSettings();
   	   tfp.setAddedText("<pridanytext>");
   	   tfp.setInsertedText("<vlozenytext>");
   	   tfp.setBackground(Color.green);
   	   tfp.setForeground(Color.black);
   	   tfp.setFont(new XFont("Courier", Font.ITALIC, 12));   	   
   	   ValuePack valuePack = new ValuePack();
   	   valuePack.put("textField", tfp);
   	   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
   }

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	public static void main(String...strings) {
		MediatorRunner.run(DemoTextField.class, null, null, "flat");
	} 
}
