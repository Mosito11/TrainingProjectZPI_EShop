package demo.framework.components;

import java.awt.Insets;

import javax.swing.SwingConstants;

import netball.server.component.AllowableActionNode;
import netball.server.component.XAllowableAccessActionTree;
import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XForm;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoAllowableAccessActionTree extends BasicMediator { 

    @Override
	public AccessAction[] getAccessActions() {
		return null;
	}
	
	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
	   	   XAllowableAccessActionTree tree = new XAllowableAccessActionTree("allowableAccessActionTree", createNode());
	   	   tree.addForbiddenNodes("ffff");
	   	   tree.setHeight(500);
	   	   tree.setWidth(500);
	   	   
	   	   XBorderPanel mainPanel = new XBorderPanel(10, 10);
	   	   mainPanel.setInsets(new Insets(10, 10, 10, 10));
	   	   mainPanel.setCenter(tree);

	   	   XBoxPanel buttonPanel = new XBoxPanel();
	   	   buttonPanel.setHorizontalAlignment(SwingConstants.RIGHT);
	   	   mainPanel.setSouth(buttonPanel);
	   	   
	   	   ServerActionEvent event = new ServerActionEvent();
	   	   event.setReturnAllValues(true);
	   	   buttonPanel.add(new XButton("Potvrd", "Potvrd", event));   	   
	   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(mainPanel); 
	   	   form.setTitle("AllowableAccessActionTree");
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	}
   
   @Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	    if (event.getSourceId().equals("Potvrd")) {
    	  System.out.println("value = " + event.getValuePack().getValue("allowableAccessActionTree"));
   	    }
	}

   private AllowableActionNode createNode() {
       AllowableActionNode[] nodes3 = new AllowableActionNode[3];
   	   nodes3[0] = new AllowableActionNode("node3.1", "node3.1", "node3.1popkec"); 
   	   nodes3[1] = new AllowableActionNode("node3.2", "node3.2", "node3.2popkec"); 
   	   nodes3[2] = new AllowableActionNode("node3.3", "node3.3", "node3.3popkec"); 
   	   
   	   AllowableActionNode[] nodes2 = new AllowableActionNode[3];
   	   nodes2[0] = new AllowableActionNode("node2.1", "node2.1", "node2.1popkec", nodes3); 
   	   nodes2[1] = new AllowableActionNode("node2.2", "node2.2", "node2.2popkec"); 
   	   nodes2[2] = new AllowableActionNode("node2.3", "node2.3", "node2.3popkec"); 
   	   
   	   AllowableActionNode[] nodes1 = new AllowableActionNode[3];
   	   nodes1[0] = new AllowableActionNode("node1.1", "node1.1", "node1.1popkec", nodes2); 
   	   nodes1[1] = new AllowableActionNode("node1.2", "node1.2", "node1.2popkec"); 
   	   nodes1[2] = new AllowableActionNode("node1.3", "node1.3", "node1.3popkec"); 
   	   
   	   AllowableActionNode root = new AllowableActionNode("root", "Root", "Pokec", nodes1);
   	   return root;
   }
   
   public static void main(String...strings) {
	   MediatorRunner.run(DemoAllowableAccessActionTree.class, null, null, "flat");
   }
}

