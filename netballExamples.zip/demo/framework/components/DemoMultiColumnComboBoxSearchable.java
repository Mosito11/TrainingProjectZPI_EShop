package demo.framework.components;

import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;

import netball.server.component.XBoxPanel;
import netball.server.component.XComboBox;
import netball.server.component.XForm;
import netball.server.component.XMultiColumnComboBox;
import netball.server.component.XTableColumn;
import netball.server.component.setting.MultiColumnComboBoxSettings;
import netball.server.component.table.TableContainer;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoMultiColumnComboBoxSearchable extends BasicMediator {

	@Override
    public AccessAction[] getAccessActions(){
        return null;
    }

    @Override
    public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception{

        List<XTableColumn> cols = new ArrayList<>();
        cols.add(new XTableColumn("col1", "Column1", 200));

        XMultiColumnComboBox comboBox = new XMultiColumnComboBox("multiComboBox");
        comboBox.setColumns(cols);
        comboBox.setEditable(true);
        comboBox.setSearchable(true);
        comboBox.setPrimaryKey("col1");
        comboBox.setWidth(200);

        XBoxPanel panel = new XBoxPanel();
        panel.setInsets(new Insets(10, 10, 10, 10));
        panel.add(comboBox);
        panel.addGap(10);
        panel.add(createComboBox());

        XForm form = new XForm();
        form.setPanel(panel);
        form.setTitle("combo box");

        this.load(serverPack);
        serverPack.addFormPack(new FormPack(getId(), form));
    }

    private void load(ServerPack pack){
        TableContainer source = new TableContainer(new Object[]{"col1"});
        source.addNewRow(new Object[]{"1 - 1111"});
        source.addNewRow(new Object[]{"3 - 2222"});
        source.addNewRow(new Object[]{"6 - 3333"});
        source.addNewRow(new Object[]{"7 - 4444"});
        source.addNewRow(new Object[]{"12 - 5555"});
        source.addNewRow(new Object[]{"14 - 6666"});
        source.addNewRow(new Object[]{"17 - 777"});
        source.addNewRow(new Object[]{"18 - 888"});

        MultiColumnComboBoxSettings cbp =  new MultiColumnComboBoxSettings();
        cbp.setDataSource(source);

        ValuePack vp = new ValuePack();
        vp.put("multiComboBox", cbp);

        pack.addUpdatedPack(new UpdatedPack(this.getId(), vp));
    }
    
    private XComboBox createComboBox() {
        XComboBox comboBox = new XComboBox("comboBox");
        comboBox.addItem("1 - 1111");
        comboBox.addItem("3 - 2222");
        comboBox.addItem("6 - 3333");
        comboBox.addItem("7 - 4444");
        comboBox.addItem("12 - 5555");
        comboBox.addItem("14 - 6666");
        comboBox.addItem("17 - 777");
        comboBox.addItem("18 - 888");
        comboBox.setEditable(false);
        comboBox.setSearchable(true);
        comboBox.setWidth(200);
    	return comboBox;
    }

    public static void main(String... strings){
        MediatorRunner.run(DemoMultiColumnComboBoxSearchable.class, null, null, "flat");
    }
}