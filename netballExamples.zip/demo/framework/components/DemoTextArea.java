package demo.framework.components;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;

import javax.swing.SwingConstants;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XFont;
import netball.server.component.XForm;
import netball.server.component.XTextArea;
import netball.server.component.setting.TextAreaSettings;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientFocusEvent;
import netball.server.event.ClientKeyEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.ServerEvent;
import netball.server.event.ServerFocusEvent;
import netball.server.event.ServerKeyEvent;
import netball.server.event.ServerMouseEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoTextArea extends BasicMediator { 

	@Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void focusEventExecuted(ClientFocusEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void keyEventExecuted(ClientKeyEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
	   	   if (event.getSourceId().equals("Potvrd")) {
	    	   System.out.println("value = " + event.getValuePack().getValue("textArea"));
    	   	   System.out.println("property = " + event.getProperties().get("textArea"));
    	   }else if (event.getSourceId().equals("Update")) {	  
	    	   update(pack);
    	   }else if (event.getSourceId().equals("ScrollToTop")) {
    	   	   TextAreaSettings settings = new TextAreaSettings();
    	   	   settings.setScrollTo(TextAreaSettings.SCROLL_TO_TOP);
    	   	   ValuePack valuePack = new ValuePack();
    	   	   valuePack.put("textArea", settings);
    	   	   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
    	   }else if (event.getSourceId().equals("ScrollToBottom")) {
    		   TextAreaSettings settings = new TextAreaSettings();
    	   	   settings.setScrollTo(TextAreaSettings.SCROLL_TO_BOTTOM);
    	   	   ValuePack valuePack = new ValuePack();
    	   	   valuePack.put("textArea", settings);
    	   	   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
    	   }
    }

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
   	   XTextArea textArea = new XTextArea("textArea");
   	   textArea.setVisibleCharCount(10);
   	   //textArea.setBackground(Color.yellow);
   	   textArea.setForeground(Color.blue);
   	   textArea.setFont(new XFont("Courier", Font.BOLD, 12));
   	   textArea.setLimit(100);
   	   textArea.setTypeLetters(XTextArea.CAPITAL_LETTERS);
   	   textArea.setAllowableChars("LS{,;\n\t<>}");
   	   textArea.setDescription("ja som text field");
   	   textArea.setVisibleRowCount(10);
   	   textArea.setVisibleCharCount(20);
   	   textArea.setLineWrap(true);
   	   textArea.setShowHorizontalScrollbarAlways(true);
   	   textArea.setShowVerticalScrollbarAlways(true);
   	   textArea.setWrapStyleWord(true);
   //	textArea.setValueRequired(true);
   	   //textArea.setHeight(50);
   	   //textArea.setWidth(500);
   	   textArea.setHorizontalAlignment(javax.swing.SwingUtilities.RIGHT);
   	   textArea.addMouseEvent(new ServerMouseEvent(ServerEvent.MOUSE_CLICKED_EVENT));
   	   textArea.addFocusEvent(new ServerFocusEvent(ServerEvent.FOCUS_GAINED_EVENT));
   	   textArea.addKeyEvent(new ServerKeyEvent(ServerEvent.KEY_TYPED_EVENT));
   	   
   	   XBorderPanel panel = new XBorderPanel(10, 10);
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.setCenter(textArea);   	   
   	   
   	   XBoxPanel buttonPanel = new XBoxPanel(SwingConstants.VERTICAL);
   	   buttonPanel.setGapForAll(5);
   	   buttonPanel.setSameWidthForAllComponents(true);
   	   
   	   ServerActionEvent event = new ServerActionEvent();
   	   event.setReturnAllValues(true);
   	   event.addReturnProperty("textArea");
	   buttonPanel.add(new XButton("Potvrd", "Potvrd", event));   	   
	   buttonPanel.add(new XButton("Update", "Update"));   	   
	   buttonPanel.add(new XButton("ScrollToTop", "Scroll to top"));
	   buttonPanel.add(new XButton("ScrollToBottom", "Scroll to bottom"));
	   panel.setEast(buttonPanel);
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("Text area");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }
   
   private void update(ServerPack pack) {
   	   TextAreaSettings tfp = new TextAreaSettings();
   	   tfp.setAddedText("<pridanytext>");
   	   tfp.setInsertedText("<vlozenytext>");
   	   ValuePack valuePack = new ValuePack();
   	   valuePack.put("textArea", tfp);
   	   tfp.setBackground(Color.green);
   	   tfp.setForeground(Color.black);
   	   tfp.setFont(new XFont("Courier", Font.ITALIC, 12));   	      	   
   	   pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
   }

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}
	
	public static void main(String...strings) {
		MediatorRunner.run(DemoTextArea.class, null, null, "flat");
	}
}
