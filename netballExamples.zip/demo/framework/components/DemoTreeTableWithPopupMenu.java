package demo.framework.components;

import java.util.List;
import java.util.Map;

import netball.server.component.PopupMenuBuilder;
import netball.server.component.XBorderPanel;
import netball.server.component.XForm;
import netball.server.component.XMenu;
import netball.server.component.XPopupMenu;
import netball.server.component.XTableColumn;
import netball.server.component.XTreeTable;
import netball.server.component.property.ComponentProperties;
import netball.server.component.setting.TreeTableSettings;
import netball.server.component.table.TableRow;
import netball.server.component.treetable.TreeTableClientNode;
import netball.server.component.treetable.TreeTableContainer;
import netball.server.component.treetable.TreeTableNode;
import netball.server.event.ClientActionEvent;
import netball.server.event.ClientFocusEvent;
import netball.server.event.ClientKeyEvent;
import netball.server.event.ClientMouseEvent;
import netball.server.event.ClientSelectionEvent;
import netball.server.event.ClientTreeExpansionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.event.alert.YesNoAlert;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netball.server.pack.ValuePack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoTreeTableWithPopupMenu extends BasicMediator { 

	int lastId = 100;
	
	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}
	
	@Override
	public void mouseEventExecuted(ClientMouseEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void focusEventExecuted(ClientFocusEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void keyEventExecuted(ClientKeyEvent event, ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void selectionEventExecuted(ClientSelectionEvent event,	ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void treeExpansionEventExecuted(ClientTreeExpansionEvent event,	ServerPack pack) {
		System.out.println(event);
	}

	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
		if (event.getSourceId().equals("add")) {
			TreeTableClientNode[] nodes = (TreeTableClientNode[]) event.getValuePack().getValue("tree");
			if (nodes != null && nodes.length > 0) {
				Object parentNodeId = nodes[0].getId();
				TreeTableSettings settings = new TreeTableSettings();
				TreeTableSettings.AddedNode addedNode = new TreeTableSettings.AddedNode(parentNodeId);
				settings.setAddedNode(addedNode);
				lastId++;
				TreeTableNode childNode = new TreeTableNode(lastId, "add node" + lastId);
				childNode.addValues("555", "666");
				addedNode.addNode(childNode);
				settings.setExpandPath(parentNodeId);
				settings.setScrollRowToVisible(childNode.getId());
				settings.setSelectedRow(childNode.getId());
				ValuePack valuePack = new ValuePack();
				valuePack.put("tree", settings);				
				pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
			}
		}else if (event.getSourceId().equals("update")) {
			TreeTableClientNode[] nodes = (TreeTableClientNode[]) event.getValuePack().getValue("tree");
			if (nodes != null && nodes.length > 0) {
				Object nodeId = nodes[0].getId();
				TreeTableSettings settings = new TreeTableSettings();
				TreeTableSettings.UpdatedNode node = new TreeTableSettings.UpdatedNode(nodeId);
				node.setUserObject("updateNode");
				TableRow row = new TableRow();
				row.add("col0", "updateCol0");
				row.add("col1", "updateCol1");
				node.setRow(row);
				settings.setUpdatedNode(node);
				ValuePack valuePack = new ValuePack();
				valuePack.put("tree", settings);				
				pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
			}
		}else if (event.getSourceId().equals("delete")) {
			TreeTableClientNode[] nodes = (TreeTableClientNode[]) event.getValuePack().getValue("tree");
			if (nodes != null && nodes.length > 0) {
				Object nodeId = nodes[0].getId();
				TreeTableSettings settings = new TreeTableSettings();
				settings.setDeletedNode(nodeId);
				ValuePack valuePack = new ValuePack();
				valuePack.put("tree", settings);				
				pack.addUpdatedPack(new UpdatedPack(getId(), valuePack));
			}
		}
    }

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
	   	   XTreeTable treeTable = new XTreeTable("tree");
	   	   treeTable.setPopupMenuBuilder(new TablePopupMenuBuilder(), this);  // registracia popup menu
	   	   treeTable.setDataSource(createModel());
	   	   treeTable.setTreeColumnWidth(200);
	   	   treeTable.setRootVisible(true);
	   	   treeTable.setWidth(600);
	   	   treeTable.setHeight(300);
	   	   treeTable.setTreeHeaderText("tree header");
	   	   treeTable.addColumn(new XTableColumn("col0", "Column0", 80));
	   	   treeTable.addColumn(new XTableColumn("col1", "Column1", 80));
	   	  // treeTable.setSelectionMode(XTreeTable.MULTIPLE_INTERVAL_SELECTION);
	   	   XBorderPanel panel = new XBorderPanel(10, 10);
	   	   panel.setCenter(treeTable);   	   
	   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel); 
	   	   form.setTitle("TreeTable");
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	 }
	   
	 public TreeTableContainer createModel() {
		 String[] cols = new String[] {"col0", "col1"};
		 TreeTableNode node = new TreeTableNode("root"); 
		 TreeTableContainer container = new TreeTableContainer(node, cols);
		 node = new TreeTableNode(1, "node1");
		 node.addValues("111", "222");
		 container.getRootNode().add(node);
		 
		 node = new TreeTableNode(2, "node2");
		 node.addValues("aaaa", "bbbb");
		 container.getRootNode().add(node);

		 node = new TreeTableNode(3, "node3");
		 node.addValues("ssss", "zzzz");
		 container.getRootNode().getChildAt(1).add(node);
		 return container;
	 }
	 
	   private class TablePopupMenuBuilder extends PopupMenuBuilder {

			@Override
			public XPopupMenu getPopupMenu(ValuePack valuePack, Map<Object, ComponentProperties> componentProperties) {
				XPopupMenu popupMenu = new XPopupMenu();
		   	    ServerActionEvent event = new ServerActionEvent();
		   	    event.addReturnValue("tree");
				XMenu item = new XMenu("add", "Pridaj", event);   	      	   
				popupMenu.addMenuItem(item);
				
			   	event = new ServerActionEvent();
			   	event.addReturnValue("tree");   	      	   
			   	event.addAlert(new YesNoAlert("Skutocne si prajete vymazat polozku?"));
			   	item = new XMenu("delete", "Vymaz", event);   	   
			   	popupMenu.addMenuItem(item); 
			   	
			   	event = new ServerActionEvent();
			   	event.addReturnValue("tree");   	      	   
			   	item = new XMenu("update", "Oprav", event);   	   
			   	popupMenu.addMenuItem(item); 
				return popupMenu;
			}
		
			@Override
			public List<Object> returnValues() throws Exception {
				return null;
			}

			@Override
			public List<Object> returnProperties() throws Exception {
				return null;
			}
	   }
	 
	   
	 public static void main(String...strings) {
		   MediatorRunner.run(DemoTreeTableWithPopupMenu.class, null, null, "flat");
	   }
}
