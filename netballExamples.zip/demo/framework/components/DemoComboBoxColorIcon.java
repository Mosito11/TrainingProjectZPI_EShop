package demo.framework.components;

import java.awt.Color;
import java.awt.Insets;

import javax.swing.SwingConstants;

import netball.client.ui.jtc.awt.AWTUtilities;
import netball.server.component.ColorIcon;
import netball.server.component.ListItem;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XComboBox;
import netball.server.component.XForm;
import netball.server.component.XIcon;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoComboBoxColorIcon extends BasicMediator { 

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}
	
	@Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	   if (event.getSourceId().equals("Potvrd")) {
   	   	  System.out.println("value = " + event.getValuePack().getValue("comboBox"));
   	   }
    }

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
   	   XComboBox comboBox = new XComboBox("comboBox");
   	   comboBox.setEditable(false);
   	   comboBox.setVisibleCharCount(16);
   	   comboBox.addItem(createItem(Color.RED));
   	   comboBox.addItem(createItem(Color.YELLOW));
   	   comboBox.addItem(createItem(Color.GREEN));
   	   comboBox.addItem(createItem(Color.GRAY));
   	   comboBox.setSelectedIndex(0);
   	   
   	   XBoxPanel panel = new XBoxPanel(SwingConstants.HORIZONTAL);
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   panel.add(comboBox);
   	   panel.addGap(20);
   	   
   	   ServerActionEvent event = new ServerActionEvent();
   	   event.setReturnAllValues(true);
   	   panel.add(new XButton("Potvrd", "Potvrd", event));   	   
   	   
   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("DemoComboBoxColorChooser");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));
	}
	
	private ListItem createItem(Color color) {
		ColorIcon colorIcon = new ColorIcon(color, 100, 16);
		colorIcon.setPaintBorder(true);
		colorIcon.setBorderColor(Color.BLACK);
		colorIcon.setCornerRound(10);
		colorIcon.setText(color.getRed() + "," + color.getGreen() + "," + color.getBlue());
		XIcon icon = new XIcon(colorIcon.convertIconToBytes());
		ListItem item = new ListItem(color, null, icon);
		return item;
	}

	public static void main(String...strings) {
	   MediatorRunner.run(DemoComboBoxColorIcon.class, null, null, "flat");
	}
}	

