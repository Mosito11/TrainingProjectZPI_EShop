package demo.framework.components;

import java.awt.Insets;

import netball.server.component.XComponent;
import netball.server.component.XDateField;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XForm;
import netball.server.component.XNumberField;
import netball.server.component.XNumberSpinner;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class DemoTollTip extends BasicMediator { 

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
   	   XDualComponentPanel panel = new XDualComponentPanel();
   	   panel.setInsets(new Insets(10, 10, 10, 10));
   	   XComponent component = new XNumberField("numberField", "Number field", XNumberField.INTEGER, 10, 0);
   	   component.setToolTipText("BOO");
   	   panel.add(component);
   	   component = new XNumberSpinner("spinnerNumberField", "Spinner number field", XNumberSpinner.INTEGER, 10, 2);
   	   component.setToolTipText("Spinner number field tool tip");
   	   panel.add(component);
   	   component = new XDateField("dateField", "Date field", "dd.MM.yyyy", XDateField.SQL_DATE);
   	   component.setToolTipText("Date field tool tip");
       panel.add(component);   	   

   	   XForm form = new XForm();
   	   form.setPanel(panel); 
   	   form.setTitle("ToolTip demo");
   	   
   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
   }
	
	public static void main(String...strings) {
		MediatorRunner.run(DemoTollTip.class, null, null, "flat");
	}

}
