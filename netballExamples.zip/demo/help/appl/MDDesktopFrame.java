package demo.help.appl;

import java.awt.Dimension;

import javax.swing.SwingConstants;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XDesktopPanel;
import netball.server.component.XForm;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.EnabledPack;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class MDDesktopFrame extends BasicMediator { 
	 
	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
	   	   XBoxPanel buttonPanel = new XBoxPanel(SwingConstants.HORIZONTAL);
	   	   buttonPanel.setSameSizeForAllComponents(true);
	   	   buttonPanel.setGapForAll(5);
	   	   buttonPanel.add(new XButton("internalFrame1", "Internal frame1", new ServerActionEvent()));
	   	   buttonPanel.add(new XButton("internalFrame2", "Internal Frame2", new ServerActionEvent()));
	   	   
	   	   XBorderPanel panel = new XBorderPanel();
	   	   panel.setNorth(buttonPanel);
	   	   XDesktopPanel desktopPanel = new XDesktopPanel("desktopPanel");
	   	   desktopPanel.setSize(new Dimension(500, 500));
	   	   desktopPanel.setMode(XDesktopPanel.INTERNAL_FRAMES_MODE);
	   	   panel.setCenter(desktopPanel);
	   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel); 
	   	   form.setTitle("Desktop frame");
	   	   form.setType(XForm.DIALOG);
	   	   form.setHelpId("desktopFrame");
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	}

    @Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	   if (event.getSourceId().equals("internalFrame1")) {
   		   this.runNext(MDInternalFrame1.class, null, pack, this.getId(), "desktopPanel");
   		   EnabledPack enabledPack = new EnabledPack();
   		   enabledPack.put("internalFrame1", false);
   		   UpdatedPack updatedPack = new UpdatedPack(getId());
   		   updatedPack.setEnabledPack(enabledPack);
   		   pack.addUpdatedPack(updatedPack);
   	   }else if (event.getSourceId().equals("internalFrame2")) {
   		   this.runNext(MDInternalFrame2.class, null, pack, this.getId(), "desktopPanel");
   		   EnabledPack enabledPack = new EnabledPack();
   		   enabledPack.put("internalFrame2", false);
   		   UpdatedPack updatedPack = new UpdatedPack(getId());
   		   updatedPack.setEnabledPack(enabledPack);
   		   pack.addUpdatedPack(updatedPack);
   	   }
   }
    
    public static void main(String...strings) {
 		MediatorRunner.run(MDDesktopFrame.class, null, "demo/help/HelpSet.hs" );
    }	
}
