package demo.help.appl;

import java.awt.Insets;

import netball.server.component.XBorderPanel;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XForm;
import netball.server.component.XTextField;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class MDInternalFrame2 extends BasicMediator { 

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
	   XDualComponentPanel panel = new XDualComponentPanel();
	   XTextField field1 = new XTextField("text7", "Text 7", 15);
	   XTextField field2 = new XTextField("text8", "Text 8", 20);
	   XTextField field3 = new XTextField("text9", "Text 9", 25);
	   panel.add(field1);
	   panel.add(field2);
	   panel.add(field3);
		
	   XBorderPanel mainPanel = new XBorderPanel(10, 10);
	   mainPanel.setInsets(new Insets(10, 10, 10, 10));
	   mainPanel.setWest(panel);
	   
   	   XForm form = new XForm();
   	   form.setHelpId("internalFrame2");
   	   form.setPanel(mainPanel); 
   	   form.setTitle("Internal Frame 2");
   	   form.setType(XForm.FRAME);
   	   serverPack.addFormPack(new FormPack(getId(), form));   	      	      	   
   }

   public static void main(String...strings) {
		MediatorRunner.run(MDInternalFrame2.class, null, "demo/help/HelpSet.hs" );
   }	
}
