package demo.help.appl;

import java.awt.Insets;

import netball.server.component.XBorderPanel;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XForm;
import netball.server.component.XLabel;
import netball.server.component.XTabbedPage;
import netball.server.component.XTabbedPane;
import netball.server.component.XTextField;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class MDComponents extends BasicMediator { 

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
	   XDualComponentPanel panel = new XDualComponentPanel();
	   XTextField field1 = new XTextField("textField1", "Text 1", 15);
	   field1.setHelpId("component1");
	   XTextField field2 = new XTextField("textField2", "Text 2", 15);
	   field2.setHelpId("component2");
	   panel.add(field1);
	   panel.add(field2);
	   
   	   XTabbedPane pane = new XTabbedPane("tabbedPane");
   	   XTabbedPage page = new XTabbedPage("tab1", "Tab1");
   	   XBorderPanel pagePanel = new XBorderPanel();
   	   pagePanel.setCenter(new XTextField("text1", "text", 10));
   	   page.setItem(pagePanel);
   	   page.setHelpId("tab1");
   	   pane.add(page);
   	   
   	   page = new XTabbedPage("tab2", "Tab2", new XLabel("label"));
   	   page.setHelpId("tab2");
   	   pane.add(page);
	   
	   XBorderPanel mainPanel = new XBorderPanel(10, 10);
	   mainPanel.setInsets(new Insets(10, 10, 10, 10));
	   mainPanel.setSouth(panel);
	   mainPanel.setCenter(pane);
	   
   	   XForm form = new XForm();
   	   form.setHelpId("dialog");
   	   form.setPanel(mainPanel); 
   	   form.setTitle("Diaog");
   	   form.setType(XForm.DIALOG);
   	   serverPack.addFormPack(new FormPack(getId(), form));   	      	      	   
   }
	
	public static void main(String...strings) {
		MediatorRunner.run(MDComponents.class, null, "demo/help/HelpSet.hs" );
	}	
}
