package demo.help.appl;

import java.awt.Insets;

import javax.swing.SwingConstants;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XForm;
import netball.server.component.XTextField;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class MDDialog extends BasicMediator { 

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
	   XDualComponentPanel panel = new XDualComponentPanel();
	   XTextField field1 = new XTextField("text3", "Text 3", 15);
	   XTextField field2 = new XTextField("text4", "Text 4", 15);
	   panel.add(field1);
	   panel.add(field2);
		
	   XBoxPanel buttonPanel = new XBoxPanel(SwingConstants.HORIZONTAL);
	   buttonPanel.setHorizontalAlignment(SwingConstants.RIGHT);
	   buttonPanel.setGapForAll(5);
	   buttonPanel.setSameSizeForAllComponents(true);
	   
	   XButton button = new XButton("dialogDesktopFrame", "Show Desktop Frame", new ServerActionEvent());
	   buttonPanel.add(button);
	   
	   XBorderPanel mainPanel = new XBorderPanel(10, 10);
	   mainPanel.setInsets(new Insets(10, 10, 10, 10));
	   mainPanel.setWest(panel);
	   mainPanel.setSouth(buttonPanel);
	   
   	   XForm form = new XForm();
   	   form.setHelpId("dialog");
   	   form.setPanel(mainPanel); 
   	   form.setTitle("Diaog");
   	   form.setType(XForm.DIALOG);
   	   serverPack.addFormPack(new FormPack(getId(), form));   	      	      	   
   }
	
    @Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
	   if (event.getSourceId().equals("dialogDesktopFrame")) {
		   this.runNext(MDDesktopFrame.class, null, pack);
	   }
	}
	
	public static void main(String...strings) {
		MediatorRunner.run(MDDialog.class, null, "demo/help/HelpSet.hs" );
	}	
}
