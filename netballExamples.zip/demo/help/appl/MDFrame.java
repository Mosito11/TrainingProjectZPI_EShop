package demo.help.appl;

import java.awt.Insets;

import javax.swing.SwingConstants;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XForm;
import netball.server.component.XTextField;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class MDFrame extends BasicMediator { 

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
	   XDualComponentPanel panel = new XDualComponentPanel();
	   XTextField field1 = new XTextField("text1", "Text 1", 20);
	   XTextField field2 = new XTextField("text2", "Text 2", 10);
	   panel.add(field1);
	   panel.add(field2);
		
	   XBoxPanel buttonPanel = new XBoxPanel(SwingConstants.HORIZONTAL);
	   buttonPanel.setHorizontalAlignment(SwingConstants.RIGHT);
	   buttonPanel.setGapForAll(5);
	   buttonPanel.setSameSizeForAllComponents(true);
	   
	   XButton button = new XButton("dialog", "Show Dialog", new ServerActionEvent());
	   buttonPanel.add(button);
	   
	   XBorderPanel mainPanel = new XBorderPanel(10, 10);
	   mainPanel.setInsets(new Insets(10, 10, 10, 10));
	   mainPanel.setWest(panel);
	   mainPanel.setSouth(buttonPanel);
	   
   	   XForm form = new XForm();
   	   form.setHelpId("frame");
   	   form.setPanel(mainPanel); 
   	   form.setTitle("Frame");
   	   form.setType(XForm.FRAME);
   	   serverPack.addFormPack(new FormPack(getId(), form));   	      	      	   
   }
	
    @Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
	   if (event.getSourceId().equals("dialog")) {
		   this.runNext(MDDialog.class, null, pack);
	   }
	}

   public static void main(String...strings) {
		MediatorRunner.run(MDFrame.class, null, "demo/help/HelpSet.hs" );
   }	
}
