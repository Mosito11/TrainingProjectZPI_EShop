package demo.help.appl;

import java.awt.Insets;

import netball.server.component.XBorderPanel;
import netball.server.component.XDualComponentPanel;
import netball.server.component.XForm;
import netball.server.component.XTextField;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class MDInternalFrame1 extends BasicMediator { 

	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack) throws Exception {
	   XDualComponentPanel panel = new XDualComponentPanel();
	   XTextField field1 = new XTextField("text5", "Text 5", 40);
	   XTextField field2 = new XTextField("text6", "Text 6", 40);
	   panel.add(field1);
	   panel.add(field2);
		
	   XBorderPanel mainPanel = new XBorderPanel(10, 10);
	   mainPanel.setInsets(new Insets(10, 10, 10, 10));
	   mainPanel.setWest(panel);
	   
   	   XForm form = new XForm();
   	   form.setHelpId("internalFrame1");
   	   form.setPanel(mainPanel); 
   	   form.setTitle("Internal Frame 1");
   	   form.setType(XForm.FRAME);
   	   serverPack.addFormPack(new FormPack(getId(), form));   	      	      	   
   }

   public static void main(String...strings) {
		MediatorRunner.run(MDInternalFrame1.class, null, "demo/help/HelpSet.hs" );
   }	
}
