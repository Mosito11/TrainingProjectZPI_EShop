package demo.help.appl;

import java.awt.Dimension;

import javax.swing.SwingConstants;

import netball.server.component.XBorderPanel;
import netball.server.component.XBoxPanel;
import netball.server.component.XButton;
import netball.server.component.XDynamicPane;
import netball.server.component.XForm;
import netball.server.event.ClientActionEvent;
import netball.server.event.ServerActionEvent;
import netball.server.pack.FormPack;
import netball.server.pack.ServerPack;
import netball.server.pack.UpdatedPack;
import netframework.access.AccessAction;
import netframework.mediator.BasicMediator;
import netframework.mediator.MediatorParameters;
import netframework.mediator.MediatorRunner;

public class MDDynamicPane extends BasicMediator { 
	 
	private Object internalId;
	
	@Override
	public AccessAction[] getAccessActions() {
		return null;
	}

	@Override
	public void init(MediatorParameters parameters, ServerPack serverPack)	throws Exception {
	   	   XBoxPanel buttonPanel = new XBoxPanel(SwingConstants.HORIZONTAL);
	   	   buttonPanel.setSameSizeForAllComponents(true);
	   	   buttonPanel.setGapForAll(5);
	   	   buttonPanel.add(new XButton("internalFrame1", "Internal frame1", new ServerActionEvent()));
	   	   buttonPanel.add(new XButton("internalFrame2", "Internal Frame2", new ServerActionEvent()));
	   	   
	   	   XBorderPanel panel = new XBorderPanel();
	   	   panel.setNorth(buttonPanel);
	   	   XDynamicPane dynamicPane = new XDynamicPane("dynamicPane");
	   	   dynamicPane.setSize(new Dimension(500, 500));
	   	   panel.setCenter(dynamicPane);
	   	   
	   	   XForm form = new XForm();
	   	   form.setPanel(panel); 
	   	   form.setTitle("Dynamic pane");
	   	   form.setType(XForm.DIALOG);
	   	   form.setHelpId("desktopFrame");
	   	   serverPack.addFormPack(new FormPack(getId(), form));   	   
	}

    @Override
	public void actionEventExecuted(ClientActionEvent event, ServerPack pack) {
   	   if (event.getSourceId().equals("internalFrame1")) {
   		   internalId = this.runNext(MDInternalFrame1.class, null, pack, this.getId(), "dynamicPane");
   		   UpdatedPack updatedPack = new UpdatedPack(internalId);
   		   updatedPack.setFocusTo("text5");
   		   pack.addUpdatedPack(updatedPack);
   	   }else if (event.getSourceId().equals("internalFrame2")) {
   		   internalId = this.runNext(MDInternalFrame2.class, null, pack, this.getId(), "dynamicPane");
   		   UpdatedPack updatedPack = new UpdatedPack(internalId);
   		   updatedPack.setFocusTo("text7");
   		   pack.addUpdatedPack(updatedPack);
   	   }
   }
    
    public static void main(String...strings) {
 		MediatorRunner.run(MDDynamicPane.class, null, "demo/help/HelpSet.hs" );
    }	
}
