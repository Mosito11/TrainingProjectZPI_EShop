<?xml version='1.0' encoding='ISO-8859-1' ?>

<helpset version="2.0">
     <title>Napoveda</title>
     
     <maps>
          <mapref location="Map.jhm"/>
          <homeID>overview</homeID>
     </maps>
     
     <!-- zalozka obsah napovedy -->
     <view>
         <name>TOC</name>
         <label>Text Utility TOC</label>
         <type>javax.help.TOCView</type>
         <data>TOC.xml</data>
     </view>
     
     <!-- zalozka indexy -->
     <view>
          <name>Index</name>
          <label>Text Utility Index</label>
          <type>javax.help.IndexView</type>
          <data>Index.xml</data>
     </view>     
     
     <!-- zalozka fulltextov vyhladavanie -->
     <view>
          <name>Search</name>
          <label>Vyhladavanie slova</label>
          <type>javax.help.SearchView</type>
          <data engine="com.sun.java.help.search.DefaultSearchEngine">
            JavaHelpSearch
          </data>
     </view>
</helpset>



      